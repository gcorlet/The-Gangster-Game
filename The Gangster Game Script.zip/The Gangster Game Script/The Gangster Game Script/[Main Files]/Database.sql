 
-- Tabel structuur voor tabel `bescherming`
-- 

CREATE TABLE `bescherming` (
  `id` int(1) NOT NULL auto_increment,
  `type` int(1) NOT NULL default '0',
  `minuten` int(255) NOT NULL default '0',
  `prijs` int(255) NOT NULL default '0',
  `naam` varchar(255) NOT NULL default '',
  `time` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `bescherming`
-- 

INSERT INTO `bescherming` VALUES (1, 1, 5, 15000, 'Bodyguard', 300);
INSERT INTO `bescherming` VALUES (2, 2, 10, 25000, 'The Mafia', 600);
INSERT INTO `bescherming` VALUES (3, 3, 15, 35000, 'SAS', 900);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `blackjack`
-- 

CREATE TABLE `blackjack` (
  `id` int(255) NOT NULL auto_increment,
  `player` varchar(16) NOT NULL default '',
  `status` int(1) NOT NULL default '0',
  `kaart1computer` varchar(64) NOT NULL default '',
  `kaart2computer` varchar(64) NOT NULL default '',
  `kaart3computer` varchar(64) NOT NULL default '',
  `kaart4computer` varchar(64) NOT NULL default '',
  `kaart5computer` varchar(64) NOT NULL default '',
  `kaart6computer` varchar(64) NOT NULL default '',
  `kaart1speler` varchar(64) NOT NULL default '',
  `kaart2speler` varchar(64) NOT NULL default '',
  `kaart3speler` varchar(64) NOT NULL default '',
  `kaart4speler` varchar(64) NOT NULL default '',
  `kaart5speler` varchar(64) NOT NULL default '',
  `kaart6speler` varchar(64) NOT NULL default '',
  `puntencomputer` int(2) NOT NULL default '0',
  `puntenspeler` int(2) NOT NULL default '0',
  `aas1` int(2) NOT NULL default '0',
  `aas2` int(2) NOT NULL default '0',
  `inzet` int(8) NOT NULL default '0',
  `login` varchar(255) NOT NULL default '',
  `kaart` varchar(255) NOT NULL default '',
  `kaartpic` varchar(255) NOT NULL default '',
  `aas` varchar(255) NOT NULL default '',
  `dealer` varchar(255) NOT NULL default '',
  `dealerpic` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=6101 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `blackjack`
-- 

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[cage]`
-- 



CREATE TABLE IF NOT EXISTS `[cage]` (
  `id` int(5) NOT NULL auto_increment,
  `naam` varchar(150) NOT NULL default '',
  `inzet` int(100) NOT NULL default '0',
  `wanneer` datetime NOT NULL default '0000-00-00 00:00:00',
  `land` tinyint(20) NOT NULL default '0',
  `naam2` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1097 ;





-- 
-- Gegevens worden uitgevoerd voor tabel `[cage]`
-- 



-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `betaald`
-- 

CREATE TABLE `betaald` (
  `id` int(255) NOT NULL auto_increment,
  `datum` datetime NOT NULL default '0000-00-00 00:00:00',
  `ip` varchar(255) default NULL,
  `login` varchar(255) default NULL,
  `prijs` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `betaald`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `chat`
-- 

CREATE TABLE `chat` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(100) NOT NULL default '',
  `chat` text NOT NULL,
  `target` int(11) NOT NULL default '1',
  `speler` varchar(25) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=150 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `chat`
-- 

INSERT INTO `chat` VALUES (149, '<font class=normal>Admin</font>', 'Welcome To the Chat</b></u></s></i>', 1, '');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `chat_config`
-- 

CREATE TABLE `chat_config` (
  `id` int(11) NOT NULL default '1',
  `silence` varchar(20) NOT NULL default 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `chat_config`
-- 

INSERT INTO `chat_config` VALUES (1, 'N');

-- --------------------------------------------------------

-- 
-- Table structure for table `cms`
-- 

CREATE TABLE `cms` (
  `id` int(255) NOT NULL auto_increment,
  `soort` varchar(255) NOT NULL default '',
  `cms` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

-- 
-- Dumping data for table `cms`
-- 

INSERT INTO `cms` VALUES (1, 'Welcome Page', 'Thank You for Signing Up and Welcome to \\\'The Gangster Game\\\'

The Extreme Mobster Source looks just like another Online Multiplayer Gangster RPG.. Well its not. Its more advanced than any competetive rivals. With advanced and uncountable features, this game will stride above the rest.

The Source, which is what you see here running on this website, is up for sale for only $30. It come as is, with full sql database, installation manual, all the features shown for a reasonable price of $30.

Well hope you enjoy the game and thank you if you purchase the script.

www.mafiagameshop.com \r\n\r\n');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `crewreplys`
-- 

CREATE TABLE `crewreplys` (
  `datum` datetime NOT NULL default '0000-00-00 00:00:00',
  `titel` varchar(255) NOT NULL default '',
  `text` text NOT NULL,
  `schrijver` varchar(255) NOT NULL default '',
  `forum` int(255) NOT NULL default '1',
  `id` int(255) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `crewreplys`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `crewtopics`
-- 

CREATE TABLE `crewtopics` (
  `titel` varchar(255) NOT NULL default '',
  `datum` datetime NOT NULL default '0000-00-00 00:00:00',
  `forum` int(255) NOT NULL default '1',
  `text` text NOT NULL,
  `poster` varchar(255) NOT NULL default '',
  `id` int(255) NOT NULL auto_increment,
  `last` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` int(1) NOT NULL default '0',
  `locked` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `crewtopics`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `dood`
-- 

CREATE TABLE `dood` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(255) NOT NULL default '',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `rang` int(11) NOT NULL default '0',
  `attack` int(100) NOT NULL default '0',
  `defence` int(100) NOT NULL default '0',
  `rank` int(100) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `dood`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `dragrace`
-- 

CREATE TABLE `dragrace` (
  `id` int(255) NOT NULL auto_increment,
  `naam1` varchar(255) NOT NULL default '',
  `id1` int(255) NOT NULL default '0',
  `deelnemers` int(255) NOT NULL default '0',
  `type` varchar(255) NOT NULL default '',
  `bedrag` int(255) NOT NULL default '0',
  `naam2` varchar(255) NOT NULL default '',
  `id2` int(255) NOT NULL default '0',
  `naam3` varchar(255) NOT NULL default '',
  `naam4` varchar(255) NOT NULL default '',
  `naam5` varchar(255) NOT NULL default '',
  `naam6` varchar(255) NOT NULL default '',
  `naam7` varchar(255) NOT NULL default '',
  `naam8` varchar(255) NOT NULL default '',
  `deelnemer` int(10) NOT NULL default '0',
  `route` varchar(255) NOT NULL default '',
  `id3` int(255) NOT NULL default '0',
  `id4` int(255) NOT NULL default '0',
  `id5` int(255) NOT NULL default '0',
  `id6` int(255) NOT NULL default '0',
  `id7` int(255) NOT NULL default '0',
  `id8` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `dragrace`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `eerpunten`
-- 

CREATE TABLE `eerpunten` (
  `login` varchar(255) NOT NULL default '',
  `person` varchar(255) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `code` int(255) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `eerpunten`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `equipment`
-- 

CREATE TABLE `equipment` (
  `id` int(11) NOT NULL auto_increment,
  `owner` int(11) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `power` int(11) NOT NULL default '0',
  `status` char(1) NOT NULL default 'U',
  `type` char(1) NOT NULL default 'W',
  `cost` int(11) NOT NULL default '0',
  `energy` int(11) NOT NULL default '0',
  `voorraad` int(11) NOT NULL default '1000',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `equipment`
-- 

INSERT INTO `equipment` VALUES (1, 0, 'McKroket', 0, 'U', 'S', 1000, 10, 1000);
INSERT INTO `equipment` VALUES (2, 0, 'Hamburger', 0, 'U', 'S', 2000, 20, 1000);
INSERT INTO `equipment` VALUES (3, 0, 'Quarter Pounder', 0, 'U', 'S', 3000, 30, 1000);
INSERT INTO `equipment` VALUES (4, 0, 'Big Mac', 0, 'U', 'S', 4000, 40, 1000);
INSERT INTO `equipment` VALUES (5, 0, 'McChicken', 0, 'U', 'S', 5000, 50, 1000);
INSERT INTO `equipment` VALUES (6, 0, 'McNuggets', 0, 'U', 'S', 6000, 60, 1000);
INSERT INTO `equipment` VALUES (7, 0, 'Big Tasty with Bacon', 0, 'U', 'S', 7000, 70, 1000);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `famtransfer`
-- 

CREATE TABLE `famtransfer` (
  `van` varchar(255) NOT NULL default '',
  `naar` varchar(255) NOT NULL default '',
  `hoeveel` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `opmerking` varchar(15) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `famtransfer`
-- 


-- --------------------------------------------------------


-- 
-- Tabel structuur voor tabel `helpdesk`
-- 

CREATE TABLE `helpdesk` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(25) NOT NULL default '',
  `operator` varchar(25) NOT NULL default '',
  `categorie` varchar(50) NOT NULL default '',
  `onderwerp` varchar(30) NOT NULL default '',
  `vraag` text NOT NULL,
  `antwoord` text NOT NULL,
  `behandelt` varchar(20) NOT NULL default 'Nee',
  `anoniem` int(5) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `helpdesk`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `help`
-- 

CREATE TABLE `help` (
  `id` int(255) NOT NULL auto_increment,
  `soort` varchar(255) NOT NULL default '',
  `help` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

-- 
-- Dumping data for table `help`
-- 

INSERT INTO `help` VALUES(1, 'Welcome', 'Welcome to The Extreme Mobster Help Menu.<br><br>\r\nEach Menu is assorted as shown on the site, i.e, Under \\"City Streets\\", you will find information on Business\\''s, Hospital, Marriage, Prison, MaC Donalds, Your Home, RedLight District, Cage Fighting and Work.\r\n\r\n<br><br>\r\nJust Click the appropriate link to get information on the topic you wish for help on.<br><br>\r\n\r\nThank You!');
INSERT INTO `help` VALUES(2, 'Ranks', 'There are 17 Ranks which you can advance through.\r\n<br>\r\n<br>\r\nHeres a full list of current ranks, from lowest to highest:\r\n<br><br>\r\n1.Cafone<br>\r\n2.Lowlife<br>\r\n3.Pickpocket<br>\r\n4.Shoplifter<br>\r\n5.Mugger<br>\r\n6.Thief<br>\r\n7.Wiseguy<br>\r\n8.Assosiate<br>\r\n9.Mobster<br>\r\n10.Gangster<br>\r\n11.Assasin<br>\r\n12.Good Fella<br>\r\n13.Mob Boss<br>\r\n14.The Don<br>\r\n15.The Legendary Don<br>\r\n16.The Godfather<br>\r\n17.The Legendary Godfather<br>');
INSERT INTO `help` VALUES(21, 'Criminal Types', 'At current, the Criminal Types only offer one option, which will be more advanced in the next updates.<br><br>\r\nCurrently 50% have defence Bonuses and the other 50% have Attack Bonuses.<br><br>\r\nTo view which have which viewed on the starter Page!');
INSERT INTO `help` VALUES(3, 'STATUS', 'The Status is the place where all your valuble information is kept. Only you can view your own status. Other than your profile, but that doesnt show all this information.<br><br>\r\n\r\n<font color=\\"red\\"><b>Power</b></font>: This shows your current attack and defence. Power is a total of your defence plus your attack. You can gain defence and attack buy purchasing weapons and protection from the Weaponry Shop. And for VIP Members the Specialised Shop. The protection and weapons bought from here are not the weapons you holster. The weapons you holster are found under Crime Playground-Attack Options-Weapons Training.\r\n<br><br>\r\n<font color=\\"red\\"><b>Gear</b></font>: This shows your current weapon and proctection your are holstering. Weapons bought from the Weaponry Store do not show up here. The weapon that shows up here are from Attack Options-Weapons Training.\r\n<br><br>\r\n<font color=\\"red\\"><b>Status Charts</b></font>: Status Charts are to show you your current progress in things such as rank. When it reaches 100% you will advance to the next rank. Health will be 100% other than when you are shot, fail in Attack Experience training or fail a Organised Crime. Energy will be 100% other than the times you do a crime, steal a car, attack someone or do training.');
INSERT INTO `help` VALUES(7, 'City Streets', '<font color=\\"red\\"><b>Business</font></b>: In here you can view most business''s in each country and the owner of that business.<br><br>\r\n<font color=\\"red\\"><b>Hospital</font></b>: The Hospital is where you should visit once your health percentage has gone down. You can view your Health Percentage in STATUS. The Hospital can also be owned as a business.<br><br>\r\n<font color=\\"red\\"><b>Marriage</font></b>: You can propose and get married to a person of your choice. Although there are no extended features for this, there will be in future updates.<br><br>\r\n<font color=\\"red\\"><b>Prison</font></b>: You will be sent here for a certain period of time depending on what you commit. For crimes, organised crimes, missions, stealing cars, transport heist, assaults. Also during your prison sentence you are able to increase your dealing rank by doing some inside dealing. By dealing you generate Deal Points, which can be exchanged for Cash.\r\n<br><br>\r\n<font color=\\"red\\"><b>MaC Donalds</font></b>: You take a visit to here when your Energy Percentage becomes low. You can view your energy percentage in STATUS.<br><br>\r\n<font color=\\"red\\"><b>Your Home</font></b>: Your Home is where you view the house you have purchased, one of 14, each increasing in value and size. You can also purchase Weed Plantations from your house, maximum of 35. The weed which you get from your plantations can be sol in the Ganja Cultivation centre.<br><br>\r\n<font color=\\"red\\"><b>Redlight District</font></b>:The idea is to pimp as many ho''s as you can and place them in booths which you hire, then they earn you cash. The more Ho''s, the more cash. Bewarned however, you must be an excellent PIMP master before you start pimping ho''s. And to prove this, you must first get your Pimp Diploma.<br><br>\r\n<font color=\\"red\\"><b>Cage Fighting</font></b>: Cage Fighting is just simple, either accept an open challenge or put a challenge out for someone to accept. The winner Takes all the betted cash.<br><br>\r\n<font color=\\"red\\"><b>Work</font></b>:\r\nHere you can choose one of 3 jobs to work as for the next 5 days. For each day you will earn a small amount of cash. Howeever, there are 12 employment ranks, each with 3 jobs to choose from. So after your 5 days of working, you might receive a promotion to go onto the next level. In which case you will start to earn more cash. And the higher you Job rank, the more cash you earn.');
INSERT INTO `help` VALUES(8, 'Car Options', '<font color=\\"red\\"><b>Garage</font></b>:\r\nThe Garage is store all your purchased cars, and yes... your stolen ones too. Here you can select each car and choose to repair it, race it, pimp it, sell it to a licensed dealer, sell it on the player auction or use it in an organised crime attempt.\r\n\r\n<br><br>\r\n<font color=\\"red\\"><b>Car Theft</font></b>:\r\nA great thing about this feature is that you can steal any car on the game, and it costs you absolutely nothing. Theres also 4 hidden cars in here somewhere which cant be put into auction or bought anywhere.\r\n\r\n\r\n<br><br>\r\n<font color=\\"red\\"><b>Missions</font></b>:\r\nThere are 12 exciting and very time demanding missions. You must train your character to even attempt some of these faultless missions. Steal Cars for the mafia, transport cocaine and so on.\r\n\r\n\r\n\r\n<br><br>\r\n<font color=\\"red\\"><b>Car Dealer</font></b>:\r\n See out what car to buy next, then pimp it up to race against other players. There are 12 cars in here which you can purchase, of a possible 26cars. You can figure out how you get the rest....\r\n\r\n<br><br>\r\n<font color=\\"red\\"><b>Auction</font></b>:\r\nThe auction is for made solely for cars. You place a car of your choice on auction, then wait for other players to bid on it. You sell it to the highest current bidder. You can also bid on other peoples cars that are on the auction. And if you lose the bid, decalre war on there gang. Well... thats one way of sorting a dispute.\r\n\r\n\r\n\r\n<br><br>\r\n<font color=\\"red\\"><b>Driving School</font></b>:\r\nThe driving school is a school where you can enter yourself to get your driving license. Dont be worried, you can drive without a license ofcourse, what kinda game would this be if you need a license to drive tut... The Driving School can also be purchased as a business, where you can make profit by increasing the price of a license entry. Oh yes!\r\n\r\n\r\n<br><br>\r\n<font color=\\"red\\"><b>PiMP Garage</font></b>:\r\nThe PIMP Garage is where you can pimp/tune your cars to maximum power, to fight off the competitor racers in a street race. There 8 different car options to pimp up, such as engine, system, rims, brakes, etc.\r\n\r\n\r\n<br><br>\r\n<font color=\\"red\\"><b>PiMP Race</font></b>:\r\nIn the PIMP Race you can accept or put open challenges out, to race against other players and be the top driver on the game. With a top winners table coming out in the next update. There are 4 tracks to race against and its all automatted. Once a race has finnished, each racer who took part are emailed an ingame message with the result, they will either find a congratulations email, or a, "F***ing Loser" email. Either way you feel some kind of emotional change inside yourself.\r\n\r\n');
INSERT INTO `help` VALUES(9, 'Casino', '<font color=\\"red\\"><b>Casino Games</font></b>:\r\n Theres a choice of 9 Casino games which are available to all members of the site, which are very entertaining to most players. And, some of the casino games can be purchased as a business to earn profit from other peoples losses. However, if the player beats your casino and you dont have enough cash in the casino bank to pay them. Well, then... the casino game becomes property of that player. All is fair in guns and games. Casino Games List is: 50/50, Dice Game, Scratch Card, Rock Paper Scissors, Roulette, Numbers Game, High Card, BlackJack, and the players favourite, Multiplayer BlackJack. This is where 4 players on your site can compete against each other in back to back rounds of intense BlackJack.\r\n');
INSERT INTO `help` VALUES(10, 'Personal Options', '<font color=\\"red\\"><b>Personal Options </font></b>:\r\nIn personal options you have the choice of editing yourn profile, also being able to view your own profile as other people see it.\r\n<br><br>\r\n<font color=\\"red\\"><b>Support Ticket </font></b>: \r\nHere you can submit a support ticket directly to the admins, with any information you may hold about bugs or an abusive player.\r\n<br><br>\r\n<font color=\\"red\\"><b>Respect Points </font></b>: \r\n Respect points can be given abd received by any player on the game. You can either send ''Respect'' or ''Shame'' to a player of your choice. A tally of points received and sent are kept for each player. Each player receives 10 respect points every hour to do with what they see fit.\r\n<br><br>\r\n<font color=\\"red\\"><b>Pimpin Name</font></b>:\r\nHere you can add symbols, smileys onto your name for everyone to see. Gives you that bit of individuality. More options will be added in future updates.\r\n\r\n');
INSERT INTO `help` VALUES(12, 'Credits Options', '<font color=\\"red\\"><b>Credits\r\n</font></b>:\r\nCredits can be purchased via the website using SMS or PHONE. The Game Credits can be used to purchase extra goodies from the credit shop such as cash, power stations for you gang, gang protection, bullets, extra attack and defence, etc. For only 100 Game Credits you can purchase 50% of your current rank.\r\n<br><br>\r\n<font color=\\"red\\"><b>Crack The Safe\r\n</font></b>:\r\nIt costs only 10 Game Credits to have a go at cracking the safe and you can have 5 attempts each day. The person who guesses the right code, wins the contents of the safe. Which is a high number of credits.\r\n\r\n');
INSERT INTO `help` VALUES(13, 'VIP Menu', 'These VIP Options are the options only granted to the members of the website who purchase VIP Member status.\r\n<br><br>\r\n<font color="red"><b>Boxing</font></b>:\r\nBoxing is similar to Cage fighting. Accept you must train up your boxing skilll to stand a chance against some players.\r\n\r\n<br><br>\r\n<font color="red"><b>Specialised Shop</font></b>:\r\nIn the specialised shop, there are multiple types of shops, far better than the standard shops, that Non-VIP members get. The Specialised Shop contains; weapons, protections, home protection, mafia mode, boats, aircraft, tanks and specials. A much more greater selection being a VIP member.\r\n\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Ganja Cultivation</font></b>:\r\nIn the Ganja Cultivation Centre you can grow and sell weed, even send it to other players around the website.\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Drug Dealing</font></b>:\r\nDrug dealing is all about buying the drugs in the cheaper countries, then flying to the countries where its expensive, and selling it.\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Car Theft Training</font></b>:\r\n A brilliant VIP feature is this, car theft training. A big advantage over the non-VIP members as your car theft percentage will rise alot faster. Meaning more cars for you to sell on the auction and use the missions.\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Crime Training</font></b>:\r\nAnother great advantage over the non-VIP members, with this VIP feature of crime training. INcrease your overall crime rank faster meaning more successful crimes, which leads to more cash in your pocket.\r\n\r\n<br><br>\r\n<font color="red"><b>Home Grown</font></b>:\r\n\r\nThis is a very special VIP feature to me, as it requires you to take care of your own cannabis plant. You must water your plant twice a day, and then crop it after a certain time period, or lose out on all that goodness.\r\n\r\n<br><br>\r\n<font color="red"><b>Cocaine Factory</font></b>:\r\nThe idea behind them is that some members buy the cocaine factories and start producing lots of cocaine in them. And the members not luckily enough to get there hands on a factory can become drug runners for the factory owners. How it works is... the factory owner producers the coke, then distributes it out between there drug runners, whom then sell it for a nice price. Keeping a small percentage of that price, and giving the bigger amount of profit back to the factory owner.\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Hire Murderer</font></b>:\r\nA VIP option which is useful to use against the Non-VIP members. You can choose to hire one of three contract killers, each rising in price as they become more skilled. The killer is hired and then set on his way to complete the objective at hand. This has multiple outcomes so be warned.\r\n ');
INSERT INTO `help` VALUES(14, 'Crime PlayGround', '<font color="red"><b>Hire Protection</font></b>:\r\nAnyone can hire protection from who they choose, either S.A.S, The Mafia or BodyGuards. Each lasting for a time depending on how long the player hired them for. With this protection, this player cannot be killed by a contract killer, or killed by another player. But remember, the protection will always run out, then you strike\r\n\r\n<br><br>\r\n<font color="red"><b>Stock Market</font></b>:\r\nThe Stock Market is a good place for new players to start off. A fair amount of cash you need to begin the game can be gained here. The idea is to purchase a number of shares in a company which is low priced, then wait for it the rise in the stock market, then SELL SELL SELL. Sometimes even doubling or trippling your cash within an hour or two. There are 4 share holder companies, but more will feature in the next update.\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Beginner Crimes</font></b>:\r\nThis is where the new gangster start off as they begin there reign of terror. Known as the ''Cafone`s'' of the Gangster society. They can mug old people or try stealing spare change of some drunks, what evers up there street. Beginner Crimes contains 3 crimes, more will be featured in the next update\r\n\r\n<br><br>\r\n<font color="red"><b>Advanced Crimes</font></b>:\r\nThese crimes are for when the gangster players know there arse from there elbow, and start to get into the flow of things. After a certain rank they can do these crimes. They can rob a cinema, nightclub or a casino. Each giving out a different sum of cash in successful.\r\n\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Steal From A Player</font></b>:\r\nThis I have to admit can be painstakingly fun, or down right fustrating. You can choose a player and then an amount of cash to steal from that player. And you can guess theres always a good outcome and a bad. Let your players figure out which ones which.\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Bullet Factory</font></b>:\r\nThe bullet factory is... well the name kind of gives it away. Its a factory that produces bullets. You need bullets to attack other players and to do weapons training. The bullet factory can also be owned by a player as there own business. They then decide the price of the bullets and howmany to despence at a time. So buy when the time is right.\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Fraud</font></b>:\r\nFraud is a good way of getting some quick cash, but a nasty prison sentence if you fail. You can choose the defraud a bank, tax income, or life insurance. Each one giving different sums of money as profit winnings. Let your players be the judge of which they prefer.\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Transport Heist</font></b>:\r\nThe transport heist can be very unpredictable, which ends up seeing many players to the prison. The idea is to hijack a Truck Load, either during loading, transporting or unloading. You also have the option of choosing between 3 different types of equipment to use during your heist. Basic tools, dynamite or use the inteligence from a ex-employee. Which will be the players downfall, and which one will be the players miracle worker.\r\n\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Organised Crimes</font></b>:\r\nThis is an extremely popular feature amongst players of all types. To begin a organised crime you must first select someone to be your drive, and then someone else to be your weapons expert. When confirmed by all party members the mission will be given to you. Its down to individual total abilities of the players, and joint abilities. A few hours crime training will make all the difference. This is one of the hardest crimes to succeed in, as it has one of the highest cash reward\r\n\r\n<br><br>\r\n<font color="red"><b>Weapons Handling</font></b>:\r\nWeapons Handling is all about import/export. Your players must first purchase a boat they can afford and then sail out to the nearby islands. There they must purchase as many weapons as there boat can carry and sail back to the mainland. The weapons sell for alot more on the mainland which is why you then sell the weapons you brought from the islands. Thus they make a nice hefty profit. The key is to have a boat that carries the most weapons obviously.\r\n\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Assaults</font></b>:\r\n Assault is where your players place an assault of a leading shop, or business such as MaC Donalds. Then try to escape with the cash they got from terrorising the ppor employees. Not an easy task to do, but very rewarding if successful. There are 3 different assaults. MaC Donalds, The SuperMarket, and the Media Market. Each more rewarding than the previous one.\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Bank Robbery</font></b>:\r\nWhat could be more thrilling than to rob a bank. Each player can choose howmcuh they wish to rob, if they succeed, they gain that amount of cash, if they fail, the bank gains the money instead.\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>WILL & Testament</font></b>:\r\n You must select a person you can trust, then send your WILL to them. In this writen will is all your current belongings and cash. So in the likely event of being murdered, you can retrieve your WILL back from this player and gain some of your possessions back. Dont let it fall into the wrong hands though!\r\n');
INSERT INTO `help` VALUES(15, 'President Menu', '<font color="red"><b>President Menu</font></b>:\r\nIf a player becomes a president of a country, they have certain options they can choose from which standard players dont have.\r\nFirstly they can bannish someone to prison for 5 minutes, but only if there in there country. This can be done a maximum of 10x a day total. As is removing someone from prison 10x a day maximum.\r\nThey earn $50,000 every hour.\r\nAnd finally they can move a person out of there country as many times as they wish.\r\nObviously if you feel that the chosen player is abusing the presidency, you could always revoke it.');
INSERT INTO `help` VALUES(16, 'Gang Options', '<font color="red"><b>Gang Options</font></b>:\r\n\r\nIn the Gang Options, the gang profile can be edited by the gang leaders to suit there gang atmosphere, and there is also an option to ban anyone from a gang in the options menu.\r\n\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Gang Wars</font></b>:\r\nGang wars have to be a big bonus for this gang system and any gang system that has gang wars. It seperates the men from the boys. The Gang Wars are completely reliable on the most powerfully, not nessecary the biggest gang on winning there gang wars. It comes down to defence and attack fo the gang, and total power of all the members.\r\n\r\n<br><br>\r\n<font color="red"><b>Gang Shops</font></b>:\r\nThere are four types of shops for the gang to browse, although only the Owner, general and leader may purchase from the gang shops. There is, buildings shop, where you can purchase buildings such as houses, power stations, oil rigs, all add cash levels and defence levels to the overall gang status. \r\nTheres a weapons shop, where obviously your members can purchase multiple weapons, such as bazookas, miniguns, which all adds onto your gang total attack power.\r\nA defence shop to purchase items such as Brick walls, guard dogs, raid bunkers, which all add on to you gang defence incase of any invasions from other gangs.\r\nAnd finally, the land shop. You can purchase acres and acres of land to build you buildings on. Because without the land, you cant have buildings.\r\n\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Gang Forum</font></b>: Here you can post topics related to your own gang and chat to other gang members, It is moderated entirely by the leaders of the gang[Owner, General, Leader].\r\n\r\n<br><br>\r\n<font color="red"><b>Gang Bank</font></b>:\r\nWhere would a gang be without a gang bank? I dunno what the answer to that is but your website members can donate as much of there own cash into the gang bank to help buy gang supplies, like weapons, defences, land, buildings.\r\n\r\n\r\n<br><br>\r\n<font color="red"><b>Gang Recruits</font></b>:\r\nHere is where the owner, general and leaders of the gangs can view who has sent a request to join there gang. They can easily Reject or Accept the recruit with a simple click of a button. On the other hand, if you check the members list more frequently then the Gang Recuirts page, a member who has applied to be in a gang, will have the gangs name, and a recruit tag on the players name.\r\n\r\n\r\n\r\n\r\n\r\n\r\n');
INSERT INTO `help` VALUES(17, 'Forum', 'Here your allowed to post your own topics on current events in the General Category. There is also a Help, Bugs and Gang Recruitment categories. Post your topic in the designated category.');
INSERT INTO `help` VALUES(18, 'MSN', 'The MSN Option is to allow you to extract your available MSN contacts, then send a automatted Mass EMAIL to all of them. This can be done with ease by following the instructions shown by clicking on the MSN tab. There is a big cash reward for any member who sends the email to 50 contacts!');
INSERT INTO `help` VALUES(19, 'Stats', 'In here you can view different statistics of your game. Firstly, theres a page showing the most warranted game stats, such as; How many members registered, how many members registered in the last 24 hours, cars in the game, gangs in the game, messages sent and number of players currently online. Second stats page shows the top 10 richest players, along with howmuch cash is in the game and average amount of cash per player etc. The third stats page shows the top 10 players ranked on total power. This is defence and attack added together. And the final stats page shows the top 10 players on game rank. From Legendary Godfarther down to Cafone.\r\n');



-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `hogerlager`
-- 

CREATE TABLE `hogerlager` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(16) NOT NULL default '',
  `number` varchar(32) default NULL,
  `round` varchar(32) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `hogerlager`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `instellingen`
-- 

CREATE TABLE `instellingen` (
  `id` int(255) NOT NULL auto_increment,
  `layout` char(3) NOT NULL default '001',
  `sitetitle` char(25) NOT NULL default 'Game Name',
   PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `instellingen`
--

INSERT INTO `instellingen` (`id`, `layout`, `sitetitle`) VALUES
(1, '001', 'Game Name');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `kavels`
-- 

CREATE TABLE `kavels` (
  `beheerder` varchar(255) NOT NULL default '',
  `message` varchar(255) NOT NULL default 'Geen bericht!',
  `land` varchar(255) NOT NULL default '',
  `klanten` varchar(255) NOT NULL default '0',
  `kosten` varchar(255) NOT NULL default '0',
  `kmvrij` varchar(255) NOT NULL default '20000',
  `km` varchar(255) NOT NULL default '0',
  `bouwen` datetime NOT NULL default '0000-00-00 00:00:00',
  `winst` varchar(255) NOT NULL default '0',
  `huizen` varchar(255) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `kavels`
-- 

INSERT INTO `kavels` VALUES ('', 'No Message!', '3', '0', '20000', '20000', '0', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `kavels` VALUES ('', 'No Message!', '1', '0', '0', '20000', '0', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `kavels` VALUES ('', 'No Message!', '2', '0', '0', '20000', '0', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `kavels` VALUES ('', 'No Message!', '4', '0', '0', '20000', '0', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `kavels` VALUES ('', 'No Message!', '5', '0', '0', '20000', '0', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `kavels` VALUES ('', 'No Message!', '6', '0', '0', '244339', '0', '2007-07-10 20:32:59', '0', '0');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `multiblackjack`
-- 

CREATE TABLE `multiblackjack` (
  `id` int(11) NOT NULL auto_increment,
  `player1` varchar(50) NOT NULL default '',
  `player2` varchar(50) NOT NULL default '',
  `player3` varchar(50) NOT NULL default '',
  `player4` varchar(50) NOT NULL default '',
  `score1` int(11) NOT NULL default '0',
  `score2` int(11) NOT NULL default '0',
  `score3` int(11) NOT NULL default '0',
  `score4` int(11) NOT NULL default '0',
  `gestart` int(11) NOT NULL default '0',
  `tijd1` int(11) NOT NULL default '0',
  `tijd2` int(11) NOT NULL default '0',
  `tijd3` int(11) NOT NULL default '0',
  `tijd4` int(11) NOT NULL default '0',
  `startnew` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `multiblackjack`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `nieuws1`
-- 

CREATE TABLE `nieuws1` (
  `id` int(9) NOT NULL auto_increment,
  `naam` varchar(32) NOT NULL default '',
  `datum` datetime default '0000-00-00 00:00:00',
  `IP` varchar(32) NOT NULL default '',
  `subject` varchar(50) NOT NULL default '',
  `bericht` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `nieuws1`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `nummerspel`
-- 

CREATE TABLE `nummerspel` (
  `owner` varchar(250) default '0',
  `spel` int(255) default '1',
  `land` int(10) NOT NULL default '0',
  `tijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `vw` int(11) NOT NULL default '0',
  `maximum` int(255) NOT NULL default '0',
  `bank` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `nummerspel`
-- 

INSERT INTO `nummerspel` VALUES ('', 1, 1, '0000-00-00 00:00:00', 1000, 1000, 1000);
INSERT INTO `nummerspel` VALUES ('', 1, 2, '0000-00-00 00:00:00', 1000, 1000, 1000);
INSERT INTO `nummerspel` VALUES ('', 1, 3, '0000-00-00 00:00:00', 1000, 1000, 1000);
INSERT INTO `nummerspel` VALUES ('', 1, 4, '0000-00-00 00:00:00', 1000, 1000, 1000);
INSERT INTO `nummerspel` VALUES ('', 1, 5, '0000-00-00 00:00:00', 1000, 1000, 1000);
INSERT INTO `nummerspel` VALUES ('', 1, 6, '0000-00-00 00:00:00', 1000, 1000, 1000);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `oc`
-- 

CREATE TABLE `oc` (
  `id` int(11) NOT NULL auto_increment,
  `wapenexpert` varchar(50) NOT NULL default '',
  `leader` varchar(50) NOT NULL default '',
  `chauffeur` varchar(50) NOT NULL default '',
  `auto` tinyint(11) NOT NULL default '0',
  `wapen` tinyint(11) NOT NULL default '0',
  `geld` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=172 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `oc`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `partners`
-- 

CREATE TABLE `partners` (
  `id` int(255) NOT NULL auto_increment,
  `login` varchar(16) NOT NULL default '',
  `vriend` varchar(16) NOT NULL default '',
  `status` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `partners`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `playxwusersplay`
-- 

CREATE TABLE `playxwusersplay` (
  `id` varchar(255) NOT NULL default '',
  `heroine` varchar(255) NOT NULL default '0',
  `cash` varchar(255) NOT NULL default '0',
  `login` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `playxwusersplay`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `poll`
-- 

CREATE TABLE `poll` (
  `id` int(11) NOT NULL auto_increment,
  `vraag` varchar(200) NOT NULL default '',
  `actief` int(1) NOT NULL default '0',
  `datum` int(20) NOT NULL default '0',
  `keuze1` varchar(50) NOT NULL default '',
  `keuze2` varchar(50) NOT NULL default '',
  `keuze3` varchar(50) NOT NULL default '',
  `keuze4` varchar(50) NOT NULL default '',
  `keuze5` varchar(50) NOT NULL default '',
  `keuze6` varchar(50) NOT NULL default '',
  `keuze7` varchar(50) NOT NULL default '',
  `keuze8` varchar(50) NOT NULL default '',
  `keuze9` varchar(50) NOT NULL default '',
  `keuze10` varchar(50) NOT NULL default '',
  `antwoord1` int(11) NOT NULL default '0',
  `antwoord2` int(11) NOT NULL default '0',
  `antwoord3` int(11) NOT NULL default '0',
  `antwoord4` int(11) NOT NULL default '0',
  `antwoord5` int(11) NOT NULL default '0',
  `antwoord6` int(11) NOT NULL default '0',
  `antwoord7` int(11) NOT NULL default '0',
  `antwoord8` int(11) NOT NULL default '0',
  `antwoord9` int(11) NOT NULL default '0',
  `antwoord10` int(11) NOT NULL default '0',
  `gestemd` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `poll`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `puntenlog`
-- 

CREATE TABLE `puntenlog` (
  `login` varchar(255) NOT NULL default '',
  `person` varchar(255) NOT NULL default '',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `code` int(255) NOT NULL default '0',
  `area` varchar(255) NOT NULL default 'punted',
  `IP` varchar(255) NOT NULL default '',
  `van` varchar(255) NOT NULL default '',
  `jou` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `puntenlog`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `rechtbank`
-- 

CREATE TABLE `rechtbank` (
  `id` int(4) NOT NULL auto_increment,
  `login` varchar(17) default NULL,
  `reden` varchar(30) default NULL,
  `straf` varchar(17) default NULL,
  `time` varchar(25) NOT NULL default '',
  `date` varchar(255) NOT NULL default '0000-00-00 00:00:00',
  `rechter` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `rechtbank`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `tickets`
-- 

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(50) NOT NULL default '',
  `afzender` varchar(50) NOT NULL default '',
  `bericht` text NOT NULL,
  `antwoord` text NOT NULL,
  `datum` datetime NOT NULL default '0000-00-00 00:00:00',
  `ban` varchar(5) NOT NULL default '0',
  `optie` varchar(50) NOT NULL default 'geen',
  `onderwerp` varchar(50) NOT NULL default 'nul',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `tickets`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `tunegarage`
-- 

CREATE TABLE `tunegarage` (
  `id` int(255) NOT NULL auto_increment,
  `auto` varchar(255) NOT NULL default '',
  `tuning` int(255) NOT NULL default '0',
  `eigenaar` varchar(255) NOT NULL default '',
  `banden` int(32) NOT NULL default '0',
  `motor` int(32) NOT NULL default '0',
  `interieur` int(32) NOT NULL default '0',
  `uitlaat` int(32) NOT NULL default '0',
  `remmen` int(32) NOT NULL default '0',
  `body` int(32) NOT NULL default '0',
  `velgen` int(32) NOT NULL default '0',
  `nitro` int(32) NOT NULL default '0',
  `rijbewijs` int(150) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `tunegarage`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[admin_checked]`
-- 

CREATE TABLE `[admin_checked]` (
  `check_id` smallint(5) unsigned NOT NULL auto_increment,
  `ip_adres` varchar(15) NOT NULL default '0.0.0.0',
  `status` text NOT NULL,
  `door_admin` varchar(50) NOT NULL default 'Niemand',
  `op` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`check_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[admin_checked]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[autorace]`
-- 

CREATE TABLE `[autorace]` (
  `id` int(255) NOT NULL auto_increment,
  `naam1` varchar(255) NOT NULL default '',
  `naam2` varchar(255) NOT NULL default '',
  `auto1` int(20) NOT NULL default '0',
  `schade1` int(100) NOT NULL default '0',
  `inzet` int(2) NOT NULL default '0',
  `geld` int(255) NOT NULL default '0',
  `aid` int(255) NOT NULL default '0',
  `land` int(10) NOT NULL default '0',
  `gewonnen` varchar(255) NOT NULL default '',
  `verloren` varchar(255) NOT NULL default '',
  `date` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[autorace]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[autoveiling]`
-- 

CREATE TABLE `[autoveiling]` (
  `id` int(11) NOT NULL auto_increment,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `date2` datetime NOT NULL default '0000-00-00 00:00:00',
  `naam` varchar(255) NOT NULL default '',
  `bel` int(255) NOT NULL default '0',
  `text` text NOT NULL,
  `bod` int(255) NOT NULL default '0',
  `door` varchar(255) NOT NULL default '',
  `soort` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[autoveiling]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[auto]`
-- 

CREATE TABLE `[auto]` (
  `id` int(255) NOT NULL auto_increment,
  `soort` int(3) NOT NULL default '0',
  `schade` int(3) NOT NULL default '0',
  `owner` varchar(255) NOT NULL default '',
  `land` int(10) NOT NULL default '1',
  `bezig` int(10) NOT NULL default '0',
  `tekoop` int(255) NOT NULL default '0',
  `snelheid` int(3) NOT NULL default '0',
  `repkosten` int(3) NOT NULL default '0',
  `bombed` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1937 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[auto]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[bankoverval]`
-- 

CREATE TABLE `[bankoverval]` (
  `geld` bigint(255) NOT NULL default '10000000',
  `land` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[bankoverval]`
-- 

INSERT INTO `[bankoverval]` VALUES (10495000, '1');
INSERT INTO `[bankoverval]` VALUES (10000000, '2');
INSERT INTO `[bankoverval]` VALUES (10000000, '3');
INSERT INTO `[bankoverval]` VALUES (10000000, '4');
INSERT INTO `[bankoverval]` VALUES (10000000, '5');
INSERT INTO `[bankoverval]` VALUES (10000000, '6');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[beurs]`
-- 

CREATE TABLE `[beurs]` (
  `id` int(2) NOT NULL default '0',
  `beurstijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `waarde` int(9) NOT NULL default '100',
  `positie` int(2) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[beurs]`
-- 

INSERT INTO `[beurs]` VALUES (1, '2007-09-28 17:20:15', 1000, 1);
INSERT INTO `[beurs]` VALUES (2, '2006-12-25 10:40:41', 1000, 1);
INSERT INTO `[beurs]` VALUES (3, '2006-12-25 10:40:55', 1000, 0);
INSERT INTO `[beurs]` VALUES (4, '2006-12-25 10:41:04', 1000, 0);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[beveiliging]`
-- 

CREATE TABLE `[beveiliging]` (
  `id` int(50) NOT NULL default '0',
  `naam` varchar(255) NOT NULL default '',
  `tijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `uren` int(10) NOT NULL default '0',
  `soort` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[beveiliging]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[bezinestation]`
-- 

CREATE TABLE `[bezinestation]` (
  `id` int(2) NOT NULL default '0',
  `owner` varchar(16) NOT NULL default '',
  `geld` int(3) NOT NULL default '0',
  `klanten` int(255) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[bezinestation]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[buddylist]`
-- 

CREATE TABLE `[buddylist]` (
  `id` int(255) NOT NULL auto_increment,
  `login` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[buddylist]`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `[buildings]`
-- 

CREATE TABLE `[buildings]` (
  `type` varchar(225) NOT NULL default '',
  `city` varchar(225) NOT NULL default '',
  `owner` varchar(225) NOT NULL default 'unowned',
  `start` datetime NOT NULL default '0000-00-00 00:00:00',
  `price` int(11) NOT NULL default '0',
  `production` datetime NOT NULL default '0000-00-00 00:00:00',
  `profit` int(50) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `amount` int(50) NOT NULL default '0',
  `code` int(2) NOT NULL default '0',
  `bank` int(11) NOT NULL default '250000',
  `aantalx` mediumint(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `[buildings]`
-- 

INSERT INTO `[buildings]` VALUES ('trainstation', '1', '', '2005-12-16 16:15:03', 2500, '0000-00-00 00:00:00', 940000, 0, 0, 34, -335440, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '2', '', '2005-12-16 16:17:17', 2500, '0000-00-00 00:00:00', 242500, 0, 0, 27, 250000, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '3', '', '2005-12-16 16:17:56', 2500, '0000-00-00 00:00:00', 260000, 0, 0, 23, 250000, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '4', '', '2006-01-06 12:24:27', 2500, '0000-00-00 00:00:00', 237500, 0, 0, 13, -335440, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '5', '', '2006-01-03 00:58:52', 2500, '0000-00-00 00:00:00', 120000, 0, 0, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '6', '', '2006-01-10 21:08:04', 2500, '0000-00-00 00:00:00', 147500, 0, 0, 76, 250000, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '7', '', '2005-12-16 19:03:31', 2500, '0000-00-00 00:00:00', 242500, 0, 0, 10, -27560, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '8', '', '2006-01-03 01:01:42', 2500, '0000-00-00 00:00:00', 177500, 0, 0, 59, -335440, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '9', '', '2006-01-06 17:03:11', 2500, '0000-00-00 00:00:00', 195000, 0, 0, 20, -335440, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '10', '', '2005-12-16 16:15:03', 2500, '0000-00-00 00:00:00', 940000, 0, 0, 34, -335440, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '11', '', '2005-12-16 16:15:03', 2500, '0000-00-00 00:00:00', 940000, 0, 0, 34, -335440, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '12', '', '2005-12-16 16:17:17', 2500, '0000-00-00 00:00:00', 242500, 0, 0, 27, 250000, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '13', '', '2005-12-16 16:17:56', 2500, '0000-00-00 00:00:00', 260000, 0, 0, 23, 250000, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '14', '', '2006-01-06 12:24:27', 2500, '0000-00-00 00:00:00', 237500, 0, 0, 13, -335440, 0);
INSERT INTO `[buildings]` VALUES ('trainstation', '15', '', '2006-01-03 00:58:52', 2500, '0000-00-00 00:00:00', 120000, 0, 0, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '1', '', '2006-01-06 13:34:56', 0, '0000-00-00 00:00:00', 299997, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '2', '', '2006-01-06 13:38:54', 200, '0000-00-00 00:00:00', 4331, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '3', '', '2006-01-06 13:56:53', 99999, '0000-00-00 00:00:00', 1001, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '4', '', '2006-01-06 16:08:39', 50000, '0000-00-00 00:00:00', 19840, 0, 0, 0, 240000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '5', '', '2005-09-01 13:29:00', 1000, '0000-00-00 00:00:00', 0, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '6', '', '2006-01-06 12:44:14', 2500, '0000-00-00 00:00:00', 0, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '7', '', '2006-01-06 15:58:15', 99999, '0000-00-00 00:00:00', 34000, 0, 0, 0, 247440, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '8', '', '2006-01-08 11:54:27', 30000, '0000-00-00 00:00:00', 0, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '9', '', '2005-09-11 21:23:29', 99999, '0000-00-00 00:00:00', 2104079, 0, 0, 0, 239950, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '10', '', '2006-01-06 13:34:56', 0, '0000-00-00 00:00:00', 299997, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '11', '', '2006-01-06 13:34:56', 0, '0000-00-00 00:00:00', 299997, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '12', '', '2006-01-06 13:38:54', 200, '0000-00-00 00:00:00', 4331, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '13', '', '2006-01-06 13:56:53', 99999, '0000-00-00 00:00:00', 1001, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '14', '', '2006-01-06 16:08:39', 50000, '0000-00-00 00:00:00', 19840, 0, 0, 0, 240000, 0);
INSERT INTO `[buildings]` VALUES ('racetrack', '15', '', '2005-09-01 13:29:00', 1000, '0000-00-00 00:00:00', 0, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '1', '', '2005-12-15 19:48:37', 25000, '0000-00-00 00:00:00', 1596009, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '2', '', '2005-12-15 21:38:14', 99999, '0000-00-00 00:00:00', 1679667, 0, 0, 0, -27560, 0);
INSERT INTO `[buildings]` VALUES ('slot', '3', '', '2005-12-28 19:01:08', 25000, '0000-00-00 00:00:00', 2559757, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '4', '', '2005-12-16 09:52:12', 25000, '0000-00-00 00:00:00', 130398, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '5', '', '2006-01-10 21:08:38', 99999, '0000-00-00 00:00:00', 20, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '6', '', '2006-01-12 20:22:36', 25000, '0000-00-00 00:00:00', 51017, 0, 0, 0, 8950, 0);
INSERT INTO `[buildings]` VALUES ('slot', '7', '', '2005-09-01 14:55:13', 99999, '0000-00-00 00:00:00', 4818357, 0, 0, 0, -27560, 0);
INSERT INTO `[buildings]` VALUES ('slot', '8', '', '2006-01-10 11:00:42', 2500, '0000-00-00 00:00:00', -70000, 0, 0, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('slot', '9', '', '2005-10-02 11:16:28', 20000, '0000-00-00 00:00:00', 5739687, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '10', '', '2005-12-15 19:48:37', 25000, '0000-00-00 00:00:00', 1596009, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '11', '', '2005-12-15 19:48:37', 25000, '0000-00-00 00:00:00', 1596009, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '12', '', '2005-12-15 21:38:14', 99999, '0000-00-00 00:00:00', 1679667, 0, 0, 0, -27560, 0);
INSERT INTO `[buildings]` VALUES ('slot', '13', '', '2005-12-28 19:01:08', 25000, '0000-00-00 00:00:00', 2559757, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '14', '', '2005-12-16 09:52:12', 25000, '0000-00-00 00:00:00', 130398, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('slot', '15', '', '2006-01-10 21:08:38', 99999, '0000-00-00 00:00:00', 20, 0, 0, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '1', 'admin', '2005-09-01 12:35:00', 10000, '0000-00-00 00:00:00', 2147133647, 1000, 19386, 0, -610440, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '2', 'admin', '2005-09-01 15:05:50', 10000, '0000-00-00 00:00:00', 2146483647, 1000, 20000, 0, -613000, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '3', 'admin', '2005-09-01 12:32:20', 10000, '0000-00-00 00:00:00', 2146933647, 1000, 11000, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '4', 'admin', '2006-01-06 11:53:16', 10000, '0000-00-00 00:00:00', 2145433647, 1000, 44974, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '5', 'admin', '2005-12-10 18:32:47', 10000, '0000-00-00 00:00:00', 2147083647, 1000, 8000, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '6', 'admin', '2006-01-06 11:51:21', 10000, '0000-00-00 00:00:00', 2146583647, 1000, 25934, 0, -749990, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '7', 'admin', '2006-01-07 21:52:28', 10000, '0000-00-00 00:00:00', 2147133647, 1000, 7000, 0, -613000, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '8', 'admin', '2005-10-02 11:14:18', 14750, '0000-00-00 00:00:00', 2147133647, 1000, 7000, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '9', 'admin', '2006-01-06 11:47:39', 25000, '0000-00-00 00:00:00', 2145933647, 1000, 31000, 0, 250000, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '10', 'admin', '2005-09-01 12:35:00', 10000, '0000-00-00 00:00:00', 2147133647, 1000, 19386, 0, -610440, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '11', 'admin', '2005-09-01 12:35:00', 10000, '0000-00-00 00:00:00', 2147133647, 1000, 19386, 0, -610440, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '12', 'admin', '2005-09-01 15:05:50', 10000, '0000-00-00 00:00:00', 2146483647, 1000, 20000, 0, -613000, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '13', 'admin', '2005-09-01 12:32:20', 10000, '0000-00-00 00:00:00', 2146933647, 1000, 11000, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '14', 'admin', '2006-01-06 11:53:16', 10000, '0000-00-00 00:00:00', 2145433647, 1000, 44974, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('bulletfactory', '15', 'admin', '2005-12-10 18:32:47', 10000, '0000-00-00 00:00:00', 2147083647, 1000, 8000, 0, -335440, 0);
INSERT INTO `[buildings]` VALUES ('roulette', '2', '', '2006-01-10 12:00:10', 2500, '0000-00-00 00:00:00', 0, 0, 0, 0, 3190710, 145);
INSERT INTO `[buildings]` VALUES ('roulette', '1', '', '2006-01-10 11:04:34', 99999, '0000-00-00 00:00:00', 2400043, 0, 0, 0, 15716649, 1109);
INSERT INTO `[buildings]` VALUES ('roulette', '3', '', '0000-00-00 00:00:00', 100, '0000-00-00 00:00:00', 4154726, 0, 0, 0, 4404726, 259);
INSERT INTO `[buildings]` VALUES ('roulette', '4', '', '2006-01-10 07:30:38', 2500, '0000-00-00 00:00:00', 101, 0, 0, 0, 8429734, 206);
INSERT INTO `[buildings]` VALUES ('roulette', '5', '', '2006-01-10 17:26:59', 100, '0000-00-00 00:00:00', 608, 0, 0, 0, 742698, 115);
INSERT INTO `[buildings]` VALUES ('roulette', '6', '', '2006-01-12 20:22:45', 10000, '0000-00-00 00:00:00', 2184385, 0, 0, 0, 3651328, 130);
INSERT INTO `[buildings]` VALUES ('roulette', '7', '', '2006-01-10 11:00:45', 2147483647, '0000-00-00 00:00:00', 50000, 0, 0, 0, 404541, 93);
INSERT INTO `[buildings]` VALUES ('roulette', '8', '', '2006-01-10 11:00:45', 2147483647, '0000-00-00 00:00:00', 50000, 0, 0, 0, 404541, 93);
INSERT INTO `[buildings]` VALUES ('roulette', '9', '', '2006-01-16 18:14:30', 100, '0000-00-00 00:00:00', 0, 0, 0, 0, 1375536, 181);
INSERT INTO `[buildings]` VALUES ('roulette', '10', '', '2006-01-10 12:00:10', 2500, '0000-00-00 00:00:00', 0, 0, 0, 0, 3190710, 145);
INSERT INTO `[buildings]` VALUES ('roulette', '11', '', '2006-01-10 11:04:34', 99999, '0000-00-00 00:00:00', 2400043, 0, 0, 0, 15716649, 1109);
INSERT INTO `[buildings]` VALUES ('roulette', '12', '', '0000-00-00 00:00:00', 100, '0000-00-00 00:00:00', 4154726, 0, 0, 0, 4404726, 259);
INSERT INTO `[buildings]` VALUES ('roulette', '13', '', '2006-01-10 07:30:38', 2500, '0000-00-00 00:00:00', 101, 0, 0, 0, 8429734, 206);
INSERT INTO `[buildings]` VALUES ('roulette', '14', '', '2006-01-10 17:26:59', 100, '0000-00-00 00:00:00', 608, 0, 0, 0, 742698, 115);
INSERT INTO `[buildings]` VALUES ('roulette', '15', '', '2006-01-10 12:00:10', 2500, '0000-00-00 00:00:00', 0, 0, 0, 0, 3190710, 145);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[casinoo]`
-- 

CREATE TABLE `[casinoo]` (
  `owner` varchar(250) default '0',
  `spel` int(250) default NULL,
  `land` varchar(255) NOT NULL default '0',
  `tijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `vw` int(255) NOT NULL default '0',
  `maximum` int(255) NOT NULL default '0',
  `casinobank` bigint(255) NOT NULL default '0',
  `login` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[casinoo]`
-- 

INSERT INTO `[casinoo]` VALUES ('', 3, '4', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 3, '3', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 3, '1', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 3, '2', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 2, '6', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 2, '3', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 2, '0', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 2, '5', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 2, '2', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 3, '0', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 3, '6', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 2, '4', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 2, '1', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 2, '0', '0000-00-00 00:00:00', 0, 500, 0, '');
INSERT INTO `[casinoo]` VALUES ('', 3, '5', '0000-00-00 00:00:00', 0, 500, 0, '');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[chemielab]`
-- 

CREATE TABLE `[chemielab]` (
  `id` int(255) NOT NULL auto_increment,
  `login` varchar(255) NOT NULL default '',
  `gram` varchar(255) NOT NULL default '',
  `ontsteking` varchar(255) NOT NULL default '',
  `extra` varchar(255) NOT NULL default '',
  `inhoud` varchar(255) NOT NULL default '',
  `tekoop` int(255) NOT NULL default '0',
  `installatie` varchar(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[chemielab]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[clanban]`
-- 

CREATE TABLE `[clanban]` (
  `id` int(255) NOT NULL default '0',
  `clan` varchar(255) NOT NULL default '',
  `speler` varchar(255) NOT NULL default '',
  `door` varchar(255) NOT NULL default '',
  `datum` datetime NOT NULL default '0000-00-00 00:00:00',
  `reden` varchar(255) NOT NULL default '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[clanban]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[clanlogs]`
-- 

CREATE TABLE `[clanlogs]` (
  `id` int(11) NOT NULL auto_increment,
  `wie` varchar(32) default NULL,
  `wat` varchar(32) default NULL,
  `wat2` varchar(255) default NULL,
  `waar` varchar(16) default NULL,
  `hoeveel` int(10) default NULL,
  `datum` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2637 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[clanlogs]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[clans]`
-- 

CREATE TABLE `[clans]` (
  `name` varchar(16) NOT NULL default '',
  `owner` varchar(16) NOT NULL default '',
  `started` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` int(1) NOT NULL default '0',
  `info` text NOT NULL,
  `avatarc` varchar(255) NOT NULL default '',
  `clicks` int(5) NOT NULL default '0',
  `clickstoday` int(3) NOT NULL default '0',
  `cash` int(9) NOT NULL default '0',
  `bank` int(9) NOT NULL default '0',
  `bankleft` int(2) NOT NULL default '50',
  `bankmax` int(5) NOT NULL default '250000',
  `attwins` int(6) NOT NULL default '0',
  `attlosses` int(6) NOT NULL default '0',
  `defwins` int(6) NOT NULL default '0',
  `deflosses` int(6) NOT NULL default '0',
  `land` int(6) NOT NULL default '400',
  `homes` int(3) NOT NULL default '2',
  `money_lvl1` int(3) NOT NULL default '25',
  `money_lvl2` int(3) NOT NULL default '0',
  `money_lvl3` int(3) NOT NULL default '0',
  `centrale` int(9) NOT NULL default '25',
  `platform` int(255) NOT NULL default '0',
  `coffeeshop` int(255) NOT NULL default '0',
  `drugslab` int(255) NOT NULL default '0',
  `def_lvl1` int(3) NOT NULL default '0',
  `def_lvl2` int(3) NOT NULL default '0',
  `def_lvl3` int(3) NOT NULL default '0',
  `IPs` text NOT NULL,
  `blocklist` text NOT NULL,
  `maandag` int(100) NOT NULL default '0',
  `dinsdag` int(100) NOT NULL default '0',
  `woensdag` int(100) NOT NULL default '0',
  `donderdag` int(100) NOT NULL default '0',
  `vrijdag` int(100) NOT NULL default '0',
  `zaterdag` int(100) NOT NULL default '0',
  `zondag` int(100) NOT NULL default '0',
  `donatie` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[clans]`
-- 



-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[clanuit]`
-- 

CREATE TABLE `[clanuit]` (
  `id` int(255) NOT NULL auto_increment,
  `rang` int(3) NOT NULL default '0',
  `datum` datetime NOT NULL default '0000-00-00 00:00:00',
  `clan` varchar(255) default NULL,
  `login` varchar(255) default NULL,
  `type` int(3) NOT NULL default '1',
  `dagen` int(3) NOT NULL default '5',
  `acc` int(3) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[clanuit]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[clanwar]`
-- 

CREATE TABLE `[clanwar]` (
  `id` int(255) NOT NULL auto_increment,
  `attack` varchar(255) NOT NULL default '',
  `defence` varchar(255) NOT NULL default '0',
  `geld` int(255) NOT NULL default '0',
  `land` int(10) NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `gewonnen` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[clanwar]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[coffeshop]`
-- 

CREATE TABLE `[coffeshop]` (
  `id` int(2) NOT NULL default '29',
  `owner` varchar(16) NOT NULL default '',
  `code` int(2) NOT NULL default '0',
  `prijs` int(3) NOT NULL default '250',
  `aantal` int(5) NOT NULL default '30000',
  `plantages` int(255) NOT NULL default '9',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[coffeshop]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[cokefabriek]`
-- 

CREATE TABLE `[cokefabriek]` (
  `land` int(2) NOT NULL default '0',
  `nummer` int(2) NOT NULL default '0',
  `owner` varchar(16) NOT NULL default '',
  `coke` bigint(255) NOT NULL default '0',
  `runner1` varchar(16) NOT NULL default '',
  `runner2` varchar(16) NOT NULL default '',
  `runner3` varchar(16) NOT NULL default '',
  `runner4` varchar(16) NOT NULL default '',
  `runner5` varchar(16) NOT NULL default '',
  `runner6` varchar(16) NOT NULL default '',
  `runner7` varchar(16) NOT NULL default '',
  `runner8` varchar(16) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[cokefabriek]`
-- 

INSERT INTO `[cokefabriek]` VALUES (1, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (1, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (1, 3, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (2, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (2, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (2, 3, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (3, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (3, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (3, 3, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (4, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (4, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (4, 3, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (5, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (5, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (5, 3, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (6, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (6, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (7, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (7, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (7, 3, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (8, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (8, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (8, 3, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (9, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (9, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (9, 3, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (10, 2, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (10, 1, '', 10500, '', '', '', '', '', '', '', '');
INSERT INTO `[cokefabriek]` VALUES (10, 3, '', 10500, '', '', '', '', '', '', '', '');


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[cron]`
-- 

CREATE TABLE `[cron]` (
  `time` datetime default NULL,
  `name` varchar(16) NOT NULL default '',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[cron]`
-- 

INSERT INTO `[cron]` VALUES ('2007-09-29 15:00:00', 'hour');
INSERT INTO `[cron]` VALUES ('2007-09-29 10:47:10', 'day');
INSERT INTO `[cron]` VALUES ('2007-09-27 16:46:26', 'week');
INSERT INTO `[cron]` VALUES ('2007-09-20 18:30:52', 'month');
INSERT INTO `[cron]` VALUES ('2007-09-28 21:01:30', 'horserace');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[dealen]`
-- 

CREATE TABLE `[dealen]` (
  `wiet` int(5) default NULL,
  `hash` int(5) default NULL,
  `LSD` int(5) default NULL,
  `speed` int(5) default NULL,
  `vuurwerk` int(5) default NULL,
  `heroine` int(5) default NULL,
  `XTC` int(5) default NULL,
  `prijs` int(2) default NULL,
  KEY `wiet` (`wiet`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[dealen]`
-- 

INSERT INTO `[dealen]` VALUES (684, 92, 1766, 180, 6520, 2917, 270, 1);
INSERT INTO `[dealen]` VALUES (575, 94, 2697, 320, 5721, 3227, 388, 2);
INSERT INTO `[dealen]` VALUES (626, 74, 2603, 295, 6049, 3379, 75, 8);
INSERT INTO `[dealen]` VALUES (598, 77, 1638, 204, 6541, 3184, 298, 9);
INSERT INTO `[dealen]` VALUES (753, 99, 2653, 172, 6356, 2809, 354, 10);
INSERT INTO `[dealen]` VALUES (880, 75, 2439, 260, 5131, 2980, 352, 11);
INSERT INTO `[dealen]` VALUES (868, 66, 2511, 348, 7046, 3440, 297, 12);
INSERT INTO `[dealen]` VALUES (760, 87, 1834, 302, 5557, 3194, 330, 3);
INSERT INTO `[dealen]` VALUES (737, 70, 1892, 225, 5306, 3041, 251, 4);
INSERT INTO `[dealen]` VALUES (537, 79, 1994, 239, 5873, 3433, 254, 5);
INSERT INTO `[dealen]` VALUES (804, 98, 2546, 302, 7400, 2733, 259, 6);
INSERT INTO `[dealen]` VALUES (897, 62, 2731, 213, 5666, 3072, 66, 7);
INSERT INTO `[dealen]` VALUES (845, 62, 2475, 328, 6239, 3312, 96, 13);
INSERT INTO `[dealen]` VALUES (946, 55, 1596, 229, 5453, 3373, 224, 14);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[detective]`
-- 

CREATE TABLE `[detective]` (
  `id` int(200) NOT NULL auto_increment,
  `naam` varchar(200) default NULL,
  `zoeker` varchar(200) default NULL,
  `uren` int(200) NOT NULL default '0',
  `tijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `vind` int(200) NOT NULL default '0',
  `status` int(200) NOT NULL default '0',
  `land` int(200) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[detective]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[dobbel]`
-- 

CREATE TABLE `[dobbel]` (
  `id` int(4) NOT NULL auto_increment,
  `?tarter` varchar(255) NOT NULL default '',
  `inzet` int(255) NOT NULL default '0',
  `gekozen` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=3807 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[dobbel]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[dograce]`
-- 

CREATE TABLE `[dograce]` (
  `id` int(255) NOT NULL auto_increment,
  `naam1` varchar(255) NOT NULL default '',
  `id1` int(255) NOT NULL default '0',
  `deelnemers` int(255) NOT NULL default '0',
  `type` varchar(255) NOT NULL default '',
  `bedrag` int(255) NOT NULL default '0',
  `naam2` varchar(255) NOT NULL default '',
  `id2` int(255) NOT NULL default '0',
  `naam3` varchar(255) NOT NULL default '',
  `naam4` varchar(255) NOT NULL default '',
  `naam5` varchar(255) NOT NULL default '',
  `naam6` varchar(255) NOT NULL default '',
  `naam7` varchar(255) NOT NULL default '',
  `naam8` varchar(255) NOT NULL default '',
  `deelnemer` int(10) NOT NULL default '0',
  `track` varchar(255) NOT NULL default '',
  `id3` int(255) NOT NULL default '0',
  `id4` int(255) NOT NULL default '0',
  `id5` int(255) NOT NULL default '0',
  `id6` int(255) NOT NULL default '0',
  `id7` int(255) NOT NULL default '0',
  `id8` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[dograce]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[dogs]`
-- 

CREATE TABLE `[dogs]` (
  `owner` varchar(255) NOT NULL default '',
  `ras` varchar(5) NOT NULL default '',
  `skill` varchar(255) NOT NULL default '',
  `skill2` varchar(255) NOT NULL default '',
  `race` int(255) NOT NULL default '0',
  `inzet` varchar(255) NOT NULL default '',
  `leeftijd` varchar(255) NOT NULL default '0',
  `voeding` varchar(255) NOT NULL default '0',
  `mood` varchar(11) NOT NULL default '1',
  `id` int(255) NOT NULL auto_increment,
  `trainend` int(11) NOT NULL default '0',
  `voed` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[dogs]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[donatelogs]`
-- 

CREATE TABLE `[donatelogs]` (
  `time` datetime default NULL,
  `IP` varchar(32) default NULL,
  `forwardedFor` varchar(32) default NULL,
  `login` varchar(16) default NULL,
  `person` varchar(16) default NULL,
  `code` int(10) default NULL,
  `area` varchar(32) default NULL,
  KEY `login` (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[donatelogs]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[drugs]`
-- 

CREATE TABLE `[drugs]` (
  `land` int(10) NOT NULL default '0',
  `verandertijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `prijs1` int(10) NOT NULL default '0',
  `prijs2` int(10) NOT NULL default '0',
  `prijs3` int(10) NOT NULL default '0',
  `prijs4` int(10) NOT NULL default '0',
  `prijs5` int(10) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[drugs]`
-- 

INSERT INTO `[drugs]` VALUES (1, '2005-07-03 00:04:58', 367, 48, 123, 146, 98);
INSERT INTO `[drugs]` VALUES (2, '2005-07-01 17:02:31', 450, 35, 147, 300, 164);
INSERT INTO `[drugs]` VALUES (3, '2005-07-01 16:32:36', 458, 17, 92, 224, 209);
INSERT INTO `[drugs]` VALUES (4, '2005-07-02 20:55:33', 352, 19, 71, 181, 89);
INSERT INTO `[drugs]` VALUES (5, '2005-07-01 15:03:49', 463, 52, 97, 136, 117);
INSERT INTO `[drugs]` VALUES (6, '2005-07-02 22:12:57', 320, 182, 186, 112, 159);
INSERT INTO `[drugs]` VALUES (7, '2005-07-02 22:43:29', 387, 26, 98, 219, 186);
INSERT INTO `[drugs]` VALUES (8, '2005-07-01 17:02:31', 450, 35, 147, 300, 164);
INSERT INTO `[drugs]` VALUES (9, '2005-07-01 16:32:36', 458, 17, 92, 224, 209);
INSERT INTO `[drugs]` VALUES (10, '2005-07-02 20:55:33', 352, 19, 71, 181, 89);


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[extra]`
-- 

CREATE TABLE `[extra]` (
  `time` datetime default NULL,
  `name` varchar(16) NOT NULL default '',
  `wie` varchar(255) NOT NULL default '',
  `waarde` int(9) NOT NULL default '0',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[extra]`
-- 

INSERT INTO `[extra]` VALUES (NULL, 'clanbank', '', 20000);
INSERT INTO `[extra]` VALUES (NULL, 'bank', '', 20000);
INSERT INTO `[extra]` VALUES (NULL, 'energiecentrales', '', 150);
INSERT INTO `[extra]` VALUES (NULL, 'banken', '', 30);
INSERT INTO `[extra]` VALUES (NULL, 'powerb', '', 30000);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[forum_sub]`
-- 

CREATE TABLE `[forum_sub]` (
  `id` int(5) NOT NULL auto_increment,
  `area` int(5) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `text` varchar(255) NOT NULL default '',
  `mods` varchar(255) NOT NULL default '',
  `topics` int(9) NOT NULL default '0',
  `replys` int(9) NOT NULL default '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[forum_sub]`
-- 

INSERT INTO `[forum_sub]` VALUES (4, 1, 'General', 'General topics', 'Admins,', 0, 0);
INSERT INTO `[forum_sub]` VALUES (3, 1, 'Gangs', 'Looking for a gang/Looking for gang members', 'Admins,', 0, 0);
INSERT INTO `[forum_sub]` VALUES (2, 1, 'Help!', 'Post here if you require any help!', 'Admins,', 0, 0);
INSERT INTO `[forum_sub]` VALUES (1, 1, 'News', 'All news from the site will be posted here!', 'Admins,', 0, 0);
INSERT INTO `[forum_sub]` VALUES (5, 1, 'Bugs!', 'Any bugs found can be posted here', 'Admins,', 0, 0);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[forum_topics]`
-- 

CREATE TABLE `[forum_topics]` (
  `id` int(5) NOT NULL auto_increment,
  `subid` int(5) NOT NULL default '0',
  `datum` varchar(64) NOT NULL default '',
  `datum1` varchar(64) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `login` varchar(64) NOT NULL default '',
  `text` text NOT NULL,
  `replys` int(5) NOT NULL default '0',
  `sticky` int(3) NOT NULL default '0',
  `slotje` int(3) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `date1` datetime NOT NULL default '0000-00-00 00:00:00',
  `clan` varchar(32) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[forum_topics]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[foum_replys]`
-- 

CREATE TABLE `[foum_replys]` (
  `id` int(5) NOT NULL auto_increment,
  `subid` int(5) NOT NULL default '0',
  `topicid` int(5) NOT NULL default '0',
  `datum` varchar(64) NOT NULL default '',
  `del` int(3) NOT NULL default '0',
  `login` varchar(64) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `text` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[foum_replys]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[garage]`
-- 


CREATE TABLE IF NOT EXISTS `[garage]` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(255) NOT NULL default '',
  `naam` varchar(255) NOT NULL default '',
  `auto` varchar(255) NOT NULL default '',
  `waarde` varchar(25) NOT NULL default '',
  `verkoop` varchar(100) NOT NULL default '',
  `soort` int(3) NOT NULL default '0',
  `schade` int(3) NOT NULL default '0',
  `owner` varchar(255) NOT NULL default '',
  `land` int(10) NOT NULL default '1',
  `bezig` int(10) NOT NULL default '0',
  `tekoop` int(255) NOT NULL default '0',
  `snelheid` int(3) NOT NULL default '0',
  `repkosten` int(3) NOT NULL default '0',
  `bombed` int(255) NOT NULL default '0',
  `tuning` int(255) NOT NULL default '0',
  `banden` int(32) NOT NULL default '0',
  `motor` int(32) NOT NULL default '0',
  `interieur` int(32) NOT NULL default '0',
  `uitlaat` int(32) NOT NULL default '0',
  `remmen` int(32) NOT NULL default '0',
  `body` int(32) NOT NULL default '0',
  `velgen` int(32) NOT NULL default '0',
  `nitro` int(32) NOT NULL default '0',
  `rijbewijs` int(150) NOT NULL default '0',
  `eigenaar` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=470 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[garage]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `gijzelen`
-- 

CREATE TABLE `gijzelen` (
  `id` int(10) NOT NULL auto_increment,
  `naam` varchar(35) NOT NULL default '',
  `partner` varchar(35) NOT NULL default '',
  `slachtoffer` varchar(35) NOT NULL default '',
  `opgesloten` int(5) NOT NULL default '0',
  `gestart` int(2) NOT NULL default '0',
  `auto` int(2) NOT NULL default '0',
  `kogels` int(10) NOT NULL default '0',
  `losgeld` int(20) NOT NULL default '0',
  `bericht` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1354 ;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[handdruk]`
-- 

CREATE TABLE `[handdruk]` (
  `id` int(5) NOT NULL auto_increment,
  `naam` varchar(150) NOT NULL default '',
  `inzet` int(100) NOT NULL default '0',
  `wanneer` datetime NOT NULL default '0000-00-00 00:00:00',
  `land` tinyint(20) NOT NULL default '0',
  `naam2` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1007 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[handdruk]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[heist]`
-- 

CREATE TABLE `[heist]` (
  `id` int(255) NOT NULL auto_increment,
  `login1` varchar(150) NOT NULL default '',
  `login2` varchar(150) NOT NULL default '',
  `wapen` varchar(255) NOT NULL default '',
  `aantalwapens` int(3) NOT NULL default '0',
  `wapenwaarde` int(50) NOT NULL default '0',
  `kogels` int(50) NOT NULL default '0',
  `auto` varchar(150) NOT NULL default '',
  `rank1` int(10) NOT NULL default '0',
  `rank2` int(10) NOT NULL default '0',
  `klaar` int(3) NOT NULL default '0',
  `autowaarde` int(150) NOT NULL default '0',
  `wklaar` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[heist]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[hitlist]`
-- 

CREATE TABLE `[hitlist]` (
  `id` int(255) NOT NULL auto_increment,
  `naam` varchar(255) NOT NULL default '',
  `reden` text NOT NULL,
  `geld` int(255) NOT NULL default '0',
  `invoeger` varchar(255) NOT NULL default 'Anoniem',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=464 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[hitlist]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[huwelijk]`
-- 

CREATE TABLE `[huwelijk]` (
  `id` int(255) NOT NULL auto_increment,
  `persoon1` varchar(255) NOT NULL default '',
  `persoon2` varchar(255) NOT NULL default '',
  `status` int(255) NOT NULL default '0',
  `appertament` int(5) NOT NULL default '0',
  `kinderen` int(5) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[huwelijk]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[ipbanz]`
-- 

CREATE TABLE `[ipbanz]` (
  `IP` varchar(100) NOT NULL default '',
  `naam` varchar(50) NOT NULL default '.',
  `reden` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[ipbanz]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[ip]`
-- 

CREATE TABLE `[ip]` (
  `id` int(4) NOT NULL auto_increment,
  `admin` varchar(255) NOT NULL default '',
  `reden` text NOT NULL,
  `login` varchar(255) NOT NULL default '',
  `ip` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[ip]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[kavels]`
-- 

CREATE TABLE `[kavels]` (
  `owner` varchar(16) NOT NULL default '',
  `land` int(1) NOT NULL default '0',
  `kavel` int(3) NOT NULL default '0',
  `hout` int(255) NOT NULL default '0',
  `steen` int(255) NOT NULL default '0',
  `ijzer` int(255) NOT NULL default '0',
  `gebouw1` int(255) NOT NULL default '0',
  `gebouw2` int(255) NOT NULL default '0',
  `gebouw3` int(255) NOT NULL default '0',
  `bouwtijd` datetime NOT NULL default '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[kavels]`
-- 

INSERT INTO `[kavels]` VALUES ('', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 2, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 3, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 4, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 5, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 6, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 7, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 8, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 9, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 10, 7600, 13400, 18800, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 11, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 12, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 14, 4600, 5500, 6950, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 15, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 20, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 21, 96000, 6350, 6650, 6, 5, 4, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 23, 999994599, 999995199, 999995499, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 1, 24, 6400, 6800, 28000, 6, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 2, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 3, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 4, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 5, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 6, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 7, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 8, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 9, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 10, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 11, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 12, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 14, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 15, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 20, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 21, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 23, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 24, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 25, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 26, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 27, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 28, 0, 0, 0, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 29, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 30, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 31, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 32, 0, 0, 0, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 33, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 1, 0, 0, 0, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 2, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 3, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 4, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 5, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 6, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 7, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 8, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 9, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 10, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 11, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 12, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 14, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 15, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 20, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 21, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 2, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 3, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 4, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 5, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 6, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 7, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 8, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 9, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 10, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 11, 0, 200, 0, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 12, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 14, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 15, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 20, 6400, 96900, 97150, 6, 4, 3, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 21, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 23, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 24, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 25, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 26, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 27, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 28, 1000, 10000, 100000, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 29, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 30, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 31, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 32, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 33, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 34, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 35, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 36, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 37, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 38, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 39, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 40, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 41, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 7, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 8, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 9, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 10, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 11, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 12, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 14, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 15, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 20, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 21, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 23, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 24, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 25, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 26, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 27, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 28, 0, 0, 0, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 29, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 30, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 31, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 32, 0, 0, 0, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 2, 33, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 1, 0, 0, 0, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 2, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 3, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 4, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 5, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 6, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 7, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 8, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 9, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 10, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 11, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 12, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 14, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 15, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 20, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 21, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 3, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 2, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 3, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 4, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 5, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 6, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 7, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 8, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 9, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 10, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 11, 0, 200, 0, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 12, 4600, 5200, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 14, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 15, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 20, 6400, 96900, 97150, 6, 4, 3, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 21, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 23, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 24, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 25, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 26, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 27, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 28, 1000, 10000, 100000, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 29, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 30, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 31, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 32, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 33, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 34, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 35, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 36, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 37, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 38, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 39, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 40, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 4, 41, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 32, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 3, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 4, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 5, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 6, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 7, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 8, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 9, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 10, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 11, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 12, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 14, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 15, 4600, 5200, 95500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 20, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 21, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 23, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 24, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 25, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 26, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 27, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 28, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 29, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 30, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 31, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 32, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 33, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 34, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 35, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 36, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 37, 5610, 96200, 995500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 38, 94700, 5300, 5500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 39, 16600, 26200, 115500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 40, 7300, 6700, 7000, 1, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 41, 4700, 95200, 96500, 6, 6, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 42, 7900, 98150, 98500, 1, 3, 5, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 5, 43, 1096000, 96350, 9996650, 6, 4, 5, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 1, 3600, 3200, 3000, 0, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 2, 3600, 3200, 3000, 0, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 3, 3600, 3200, 3000, 0, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 4, 3600, 3200, 3000, 0, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 5, 3600, 3200, 3000, 0, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 6, 3600, 3200, 3100, 0, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 7, 3600, 3200, 3000, 0, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 8, 3600, 3200, 3000, 0, 0, 6, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 9, 5400, 4800, 4500, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 10, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 11, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 12, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 13, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 14, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 15, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 16, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 17, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 18, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 19, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 20, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 21, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 22, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 23, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 24, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 25, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 26, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 27, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 28, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 29, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 30, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 31, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 32, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 33, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 34, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 35, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 36, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 37, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 38, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 39, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 40, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 41, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 42, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 43, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 44, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');
INSERT INTO `[kavels]` VALUES ('', 6, 45, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[kavelveiling]`
-- 

CREATE TABLE `[kavelveiling]` (
  `owner` varchar(16) NOT NULL default '',
  `land` int(1) NOT NULL default '0',
  `kavel` int(2) NOT NULL default '0',
  `beginbod` int(255) NOT NULL default '0',
  `bieder` varchar(16) NOT NULL default '',
  `hoogstebod` int(255) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[kavelveiling]`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `krassen`
-- 

CREATE TABLE `krassen` (
  `a` int(255) default '0',
  `b` int(255) default '0',
  `c` int(255) default '0',
  `d` int(255) default '0',
  `e` int(255) default '0',
  `f` int(255) default '0'
) ENGINE=MyISAM DEFAULT CHARSET=ujis;

-- 
-- Dumping data for table `krassen`
-- 

INSERT INTO `krassen` VALUES (0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `lottery-tickets`
-- 

CREATE TABLE `lottery-tickets` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(225) NOT NULL default '',
  `lotterynr` mediumint(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `IP` varchar(225) NOT NULL default '0.0.0.0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3001 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3001 ;

-- 
-- Dumping data for table `lottery-tickets`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `lottery`
-- 

CREATE TABLE `lottery` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(225) NOT NULL default '',
  `active` tinyint(1) NOT NULL default '1',
  `ticketprice` mediumint(11) NOT NULL default '100000',
  `ticketssold` mediumint(11) NOT NULL default '0',
  `pot` bigint(11) NOT NULL default '0',
  `winner` varchar(16) NOT NULL default 'Niemand',
  `winner-login` varchar(16) NOT NULL default '',
  `start` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

-- 
-- Dumping data for table `lottery`
-- 

INSERT INTO `lottery` VALUES (35, 'Weekly Lottery', 1, 100000, 0, 0, 'Nobody', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[keno]`
-- 

CREATE TABLE `[keno]` (
  `land` int(255) NOT NULL default '0',
  `winst` bigint(255) NOT NULL default '0',
  `owner` varchar(50) NOT NULL default 'Admin',
  `geld` int(255) NOT NULL default '500'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[keno]`
-- 

INSERT INTO `[keno]` VALUES (1, 1000000, '', 5000000);
INSERT INTO `[keno]` VALUES (2, 1000000, '', 5000000);
INSERT INTO `[keno]` VALUES (3, 1000000, '', 5000000);
INSERT INTO `[keno]` VALUES (4, 1000000, '', 5000000);
INSERT INTO `[keno]` VALUES (5, 1000000, '', 5000000);
INSERT INTO `[keno]` VALUES (6, 1000000, '', 5000000);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[klikmissie]`
-- 

CREATE TABLE `[klikmissie]` (
  `id` int(3) NOT NULL default '0',
  `kliklink` varchar(255) NOT NULL default '',
  `waardekl` int(40) NOT NULL default '10000'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[klikmissie]`
-- 



-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[kooigevecht]`
-- 

CREATE TABLE `[kooigevecht]` (
  `naam1` varchar(16) NOT NULL default '',
  `naam2` varchar(16) NOT NULL default '',
  `pot` bigint(255) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[kooigevecht]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[kraakkluis]`
-- 

CREATE TABLE `[kraakkluis]` (
  `kluis` int(10) NOT NULL default '10000',
  `code` int(10) NOT NULL default '3',
  `winnaar` varchar(10) NOT NULL default '',
  `area` int(4) NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[kraakkluis]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[kraaknr]`
-- 

CREATE TABLE `[kraaknr]` (
  `id` int(4) NOT NULL default '0',
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `login` varchar(255) NOT NULL default '',
  `getal` int(3) NOT NULL default '0',
  `area` int(3) NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[kraaknr]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[land]`
-- 

CREATE TABLE `[land]` (
  `id` int(11) NOT NULL default '0',
  `owner` varchar(255) NOT NULL default '',
  `naam` varchar(255) NOT NULL default '',
  `land` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[land]`
-- 

INSERT INTO `[land]` VALUES (0, '', '', 1);
INSERT INTO `[land]` VALUES (1, '', '', 4);
INSERT INTO `[land]` VALUES (2, '', '', 4);
INSERT INTO `[land]` VALUES (7, '', '', 4);
INSERT INTO `[land]` VALUES (3, '', '', 4);
INSERT INTO `[land]` VALUES (4, '', '', 4);
INSERT INTO `[land]` VALUES (5, '', '', 4);
INSERT INTO `[land]` VALUES (1, '', '', 1);
INSERT INTO `[land]` VALUES (2, '', '', 1);
INSERT INTO `[land]` VALUES (7, '', '', 1);
INSERT INTO `[land]` VALUES (3, '', '', 1);
INSERT INTO `[land]` VALUES (4, '', '', 1);
INSERT INTO `[land]` VALUES (5, '', '', 1);
INSERT INTO `[land]` VALUES (1, '', '', 2);
INSERT INTO `[land]` VALUES (2, '', '', 2);
INSERT INTO `[land]` VALUES (7, '', '', 2);
INSERT INTO `[land]` VALUES (3, '', '', 2);
INSERT INTO `[land]` VALUES (4, '', '', 2);
INSERT INTO `[land]` VALUES (5, '', '', 2);
INSERT INTO `[land]` VALUES (1, '', '', 3);
INSERT INTO `[land]` VALUES (2, '', '', 3);
INSERT INTO `[land]` VALUES (7, '', '', 3);
INSERT INTO `[land]` VALUES (3, '', '', 3);
INSERT INTO `[land]` VALUES (4, '', '', 3);
INSERT INTO `[land]` VALUES (5, '', '', 3);
INSERT INTO `[land]` VALUES (1, '', '', 5);
INSERT INTO `[land]` VALUES (2, '', '', 5);
INSERT INTO `[land]` VALUES (7, '', '', 5);
INSERT INTO `[land]` VALUES (3, '', '', 5);
INSERT INTO `[land]` VALUES (4, '', '', 5);
INSERT INTO `[land]` VALUES (5, '', '', 5);
INSERT INTO `[land]` VALUES (1, '', '', 6);
INSERT INTO `[land]` VALUES (2, '', '', 6);
INSERT INTO `[land]` VALUES (7, '', '', 6);
INSERT INTO `[land]` VALUES (3, '', '', 6);
INSERT INTO `[land]` VALUES (4, '', '', 6);
INSERT INTO `[land]` VALUES (5, '', '', 6);
INSERT INTO `[land]` VALUES (1, '', '', 7);
INSERT INTO `[land]` VALUES (2, '', '', 7);
INSERT INTO `[land]` VALUES (7, '', '', 7);
INSERT INTO `[land]` VALUES (3, '', '', 7);
INSERT INTO `[land]` VALUES (4, '', '', 7);
INSERT INTO `[land]` VALUES (5, '', '', 7);
INSERT INTO `[land]` VALUES (1, '', '', 8);
INSERT INTO `[land]` VALUES (2, '', '', 8);
INSERT INTO `[land]` VALUES (7, '', '', 8);
INSERT INTO `[land]` VALUES (3, '', '', 8);
INSERT INTO `[land]` VALUES (4, '', '', 8);
INSERT INTO `[land]` VALUES (5, '', '', 8);
INSERT INTO `[land]` VALUES (1, '', '', 9);
INSERT INTO `[land]` VALUES (2, '', '', 9);
INSERT INTO `[land]` VALUES (7, '', '', 9);
INSERT INTO `[land]` VALUES (3, '', '', 9);
INSERT INTO `[land]` VALUES (4, '', '', 9);
INSERT INTO `[land]` VALUES (5, '', '', 9);
INSERT INTO `[land]` VALUES (1, '', '', 10);
INSERT INTO `[land]` VALUES (2, '', '', 10);
INSERT INTO `[land]` VALUES (7, '', '', 10);
INSERT INTO `[land]` VALUES (3, '', '', 10);
INSERT INTO `[land]` VALUES (4, '', '', 10);
INSERT INTO `[land]` VALUES (5, '', '', 10);





-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[login]`
-- 

CREATE TABLE `[login]` (
  `id` int(4) NOT NULL auto_increment,
  `login` varchar(16) default NULL,
  `tijd` time NOT NULL default '00:00:00',
  `IP` varchar(60) NOT NULL default '0',
  `type` varchar(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[login]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[logs]`
-- 

CREATE TABLE `[logs]` (
  `time` datetime default NULL,
  `IP` varchar(32) default NULL,
  `forwardedFor` varchar(32) default NULL,
  `login` varchar(16) default NULL,
  `person` varchar(16) default NULL,
  `code` int(10) default NULL,
  `area` varchar(32) default NULL,
  `clan` varchar(10) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[logs]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[meestonline]`
-- 

CREATE TABLE `[meestonline]` (
  `id` int(1) NOT NULL default '0',
  `online` int(3) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[meestonline]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[messages]`
-- 

CREATE TABLE `[messages]` (
  `id` int(9) NOT NULL auto_increment,
  `IP` varchar(32) NOT NULL default '',
  `forwardedFor` varchar(32) default NULL,
  `time` datetime default NULL,
  `from` varchar(16) default NULL,
  `to` varchar(16) default NULL,
  `subject` varchar(50) NOT NULL default '',
  `message` text NOT NULL,
  `read` int(1) NOT NULL default '0',
  `inbox` int(1) default '1',
  `outbox` int(1) default '1',
  `saved` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=6848 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[messages]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[missie]`
-- 

CREATE TABLE `[missie]` (
  `id` int(5) NOT NULL auto_increment,
  `missie` int(5) NOT NULL default '0',
  `partner` text NOT NULL,
  `autoid` int(8) NOT NULL default '0',
  `login` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[missie]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[omnilog]`
-- 

CREATE TABLE `[omnilog]` (
  `time` datetime default NULL,
  `login` varchar(16) default NULL,
  `IP` varchar(32) default NULL,
  `forwardedFor` varchar(32) default NULL,
  `file` varchar(64) default NULL,
  `$_POST` text,
  `$_GET` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[omnilog]`
-- 

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[poker]`
-- 

CREATE TABLE `[poker]` (
  `id` int(4) NOT NULL auto_increment,
  `owner` varchar(32) NOT NULL default '',
  `land` varchar(32) NOT NULL default '',
  `inzet` bigint(255) NOT NULL default '0',
  `winst` bigint(255) NOT NULL default '0',
  `casinobank` bigint(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[poker]`
-- 

INSERT INTO `[poker]` VALUES (1, '', '1', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (2, '', '2', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (3, '', '3', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (4, '', '4', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (5, '', '5', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (6, '', '6', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (7, '', '7', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (8, '', '8', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (9, '', '9', 0, 0, 1000000);
INSERT INTO `[poker]` VALUES (10, '', '10', 0, 0, 1000000);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[rechtbank]`
-- 

CREATE TABLE `[rechtbank]` (
  `id` int(11) NOT NULL auto_increment,
  `login` longtext NOT NULL,
  `ip` longtext NOT NULL,
  `straf` longtext NOT NULL,
  `reden` longtext NOT NULL,
  `datum` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[rechtbank]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[redlight]`
-- 

CREATE TABLE `[redlight]` (
  `ramen` int(255) NOT NULL default '1000000',
  `land` int(6) NOT NULL default '1',
  `id` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[redlight]`
-- 

INSERT INTO `[redlight]` VALUES (19939, 1, '1');
INSERT INTO `[redlight]` VALUES (20000, 2, '2');
INSERT INTO `[redlight]` VALUES (20000, 3, '3');
INSERT INTO `[redlight]` VALUES (20000, 4, '4');
INSERT INTO `[redlight]` VALUES (20000, 5, '5');
INSERT INTO `[redlight]` VALUES (20000, 6, '6');
INSERT INTO `[redlight]` VALUES (20000, 7, '7');
INSERT INTO `[redlight]` VALUES (20000, 8, '8');
INSERT INTO `[redlight]` VALUES (20000, 9, '9');
INSERT INTO `[redlight]` VALUES (20000, 10, '10');

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[respect]`
-- 

CREATE TABLE `[respect]` (
  `time` datetime default NULL,
  `login` varchar(16) default NULL,
  `person` varchar(16) default NULL,
  `code` int(10) default NULL,
  `area` varchar(32) default NULL,
  `com` varchar(255) NOT NULL default 'Geen'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[respect]`
-- 

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[rijbewijsban]`
-- 

CREATE TABLE `[rijbewijsban]` (
  `naam` varchar(255) NOT NULL default '',
  `tijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `plaatser` varchar(255) NOT NULL default '',
  `reden` varchar(255) NOT NULL default '',
  `land` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[rijbewijsban]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[rijbewijs]`
-- 

CREATE TABLE `[rijbewijs]` (
  `id` int(255) NOT NULL default '0',
  `owner` varchar(255) NOT NULL default 'Admin',
  `leerlingen` int(255) NOT NULL default '0',
  `winst` bigint(255) NOT NULL default '0',
  `geslaagde` int(255) NOT NULL default '0',
  `naam` varchar(255) NOT NULL default 'This school has no name jet',
  `kosten` int(255) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[rijbewijs]`
-- 

INSERT INTO `[rijbewijs]` VALUES (1, 'admin', 0, 0, 0, 'Driving school 1', 1000);
INSERT INTO `[rijbewijs]` VALUES (6, 'admin', 0, 0, 0, 'Driving school 6', 1000);
INSERT INTO `[rijbewijs]` VALUES (3, 'admin', 0, 0, 0, 'Driving school 3', 1000);
INSERT INTO `[rijbewijs]` VALUES (4, 'admin', 0, 0, 0, 'Driving school 4', 1000);
INSERT INTO `[rijbewijs]` VALUES (2, 'admin', 0, 0, 0, 'Driving school 2', 1000);
INSERT INTO `[rijbewijs]` VALUES (5, 'admin', 0, 0, 0, 'Driving school 5', 1000);
INSERT INTO `[rijbewijs]` VALUES (7, 'admin', 0, 0, 0, 'Driving school 3', 1000);
INSERT INTO `[rijbewijs]` VALUES (8, 'admin', 0, 0, 0, 'Driving school 4', 1000);
INSERT INTO `[rijbewijs]` VALUES (9, 'admin', 0, 0, 0, 'Driving school 2', 1000);
INSERT INTO `[rijbewijs]` VALUES (10, 'admin', 0, 0, 0, 'Driving school 5', 1000);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[runnertemp]`
-- 

CREATE TABLE `[runnertemp]` (
  `owner` varchar(16) NOT NULL default '',
  `land` int(1) NOT NULL default '0',
  `runner` varchar(16) NOT NULL default '',
  `runnernr` int(1) NOT NULL default '0',
  `nummer` int(1) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[runnertemp]`
-- 

INSERT INTO `[runnertemp]` VALUES ('', 4, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 4, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 4, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 4, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 5, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 5, '', 0, 8);
INSERT INTO `[runnertemp]` VALUES ('', 5, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 2, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 5, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 2, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 1, '', 0, 1);
INSERT INTO `[runnertemp]` VALUES ('', 1, '', 0, 1);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[slot]`
-- 

CREATE TABLE `[slot]` (
  `type` varchar(225) NOT NULL default '',
  `city` varchar(225) NOT NULL default '',
  `owner` varchar(225) NOT NULL default 'unowned',
  `start` datetime NOT NULL default '0000-00-00 00:00:00',
  `price` int(11) NOT NULL default '0',
  `production` datetime NOT NULL default '0000-00-00 00:00:00',
  `profit` int(50) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `amount` int(50) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[slot]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[SPS]`
-- 

CREATE TABLE `[SPS]` (
  `id` int(6) NOT NULL auto_increment,
  `uitdager` varchar(36) NOT NULL default '',
  `aannemer` varchar(36) NOT NULL default '',
  `inzet` bigint(36) NOT NULL default '0',
  `soort` varchar(35) NOT NULL default '',
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `id_2` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[SPS]`
-- 


-- --------------------------------------------------------


-- 
-- Tabel structuur voor tabel `[stadowner]`
-- 

CREATE TABLE `[stadowner]` (
  `id` int(255) NOT NULL auto_increment,
  `owner` varchar(255) NOT NULL default '',
  `land` varchar(255) NOT NULL default '',
  `gevang` int(59) NOT NULL default '3',
  `gevanguit` int(59) NOT NULL default '3',
  `uitzetten` int(55) NOT NULL default '3',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[stadowner]`
-- 

INSERT INTO `[stadowner]` VALUES (1, '', '1', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (2, '', '2', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (3, '', '3', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (4, '', '4', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (5, '', '5', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (6, '', '6', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (7, '', '7', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (8, '', '8', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (9, '', '9', 3, 3, 3);
INSERT INTO `[stadowner]` VALUES (10, '', '10', 3, 3, 3);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[stationban]`
-- 

CREATE TABLE `[stationban]` (
  `naam` varchar(255) NOT NULL default '',
  `tijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `plaatser` varchar(255) NOT NULL default '',
  `reden` varchar(255) NOT NULL default '',
  `land` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Gegevens worden uitgevoerd voor tabel `[stationban]`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `spel_statestieken`
-- 

CREATE TABLE `spel_statestieken` (
  `id` int(255) NOT NULL auto_increment,
  `link1` int(255) NOT NULL default '0',
  `link2` int(255) NOT NULL default '0',
  `link3` int(255) NOT NULL default '0',
  `link4` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

-- 
-- Dumping data for table `spel_statestieken`
-- 

INSERT INTO `spel_statestieken` VALUES (1, 0, 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[temp]`
-- 

CREATE TABLE `[temp]` (
  `id` int(16) NOT NULL auto_increment,
  `time` datetime default NULL,
  `login` varchar(16) default NULL,
  `IP` varchar(32) default NULL,
  `forwardedFor` varchar(32) default NULL,
  `code` int(10) unsigned NOT NULL default '0',
  `area` varchar(32) default NULL,
  `naar` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=539 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[temp]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[tunen]`
-- 

CREATE TABLE `[tunen]` (
  `id` int(255) NOT NULL auto_increment,
  `auto` varchar(255) NOT NULL default '',
  `tuning` int(255) NOT NULL default '0',
  `eigenaar` varchar(255) NOT NULL default '',
  `banden` int(32) NOT NULL default '0',
  `motor` int(32) NOT NULL default '0',
  `interieur` int(32) NOT NULL default '0',
  `uitlaat` int(32) NOT NULL default '0',
  `remmen` int(32) NOT NULL default '0',
  `body` int(32) NOT NULL default '0',
  `velgen` int(32) NOT NULL default '0',
  `nitro` int(32) NOT NULL default '0',
  `rijbewijs` int(150) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[tunen]`
-- 


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[users]`
-- 

CREATE TABLE `[users]` (
  `A1` int(100) NOT NULL default '0',
  `A2` int(100) NOT NULL default '0',
  `A3` int(100) NOT NULL default '0',
  `A4` int(100) NOT NULL default '0',
  `A5` int(100) NOT NULL default '0',
  `aanuit` int(2) NOT NULL default '1',
  `aanzoek` varchar(255) collate latin1_general_ci NOT NULL default '',
  `accban` int(1) NOT NULL default '1',
  `achternaam` text NOT NULL,
  `activated` int(1) NOT NULL default '1',
  `admin` int(5) NOT NULL default '0',
  `aftel` int(3) NOT NULL default '0',
  `airplane` int(255) NOT NULL default '0',
  `Ak Beta` int(5) NOT NULL default '0',
  `ak47` int(255) NOT NULL default '0',
  `ak47b` int(255) NOT NULL default '0',
  `ak47v` int(255) NOT NULL default '0',
  `allies` text NOT NULL,
  `am1` int(255) default '5',
  `am2` int(255) default '5',
  `am3` int(255) default '5',
  `am4` int(255) default '5',
  `amisdaad` int(255) default '0',
  `apower` int(255) default '0',
  `ar` int(5) NOT NULL default '0',
  `attack` bigint(255) NOT NULL default '0',
  `attackdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `attacktime` int(255) NOT NULL default '0',
  `attlevel` int(4) NOT NULL default '0',
  `attlevnew` int(4) NOT NULL default '0',
  `attlosses` varchar(255) NOT NULL default '0',
  `attwins` varchar(255) NOT NULL default '0',
  `auto` datetime NOT NULL default '0000-00-00 00:00:00',
  `auto1` int(255) NOT NULL default '0',
  `autocrime` int(2) NOT NULL default '2',
  `autoP` varchar(255) NOT NULL default '0',
  `autos1` int(2) NOT NULL default '0',
  `autos10` int(2) NOT NULL default '0',
  `autos2` int(2) NOT NULL default '0',
  `autos3` int(2) NOT NULL default '0',
  `autos4` int(2) NOT NULL default '0',
  `autos5` int(2) NOT NULL default '0',
  `autos6` int(2) NOT NULL default '0',
  `autos7` int(2) NOT NULL default '0',
  `autos8` int(2) NOT NULL default '0',
  `autos9` int(2) NOT NULL default '0',
  `autotime` varchar(255) collate latin1_general_ci NOT NULL default '',
  `avatarc` varchar(255) collate latin1_general_ci NOT NULL default 'images/nopicture.jpg',
  `avaurl` varchar(255) NOT NULL default 'images/overige/nopicture.jpg',
  `b1` int(255) NOT NULL default '0',
  `b2` int(255) NOT NULL default '0',
  `b3` int(255) NOT NULL default '0',
  `b4` int(255) NOT NULL default '0',
  `baan` int(255) NOT NULL default '0',
  `baantjegezocht` int(5) NOT NULL default '0',
  `backfire` varchar(255) NOT NULL default '0',
  `ban` int(3) NOT NULL default '0',
  `bank` bigint(255) NOT NULL default '20000',
  `bankleft` int(1) NOT NULL default '15',
  `bankmax` int(255) NOT NULL default '500000',
  `bankpas` int(1) NOT NULL default '0',
  `bankpogingen` int(1) NOT NULL default '0',
  `banned` int(1) NOT NULL default '1',
  `bedrijf` text NOT NULL,
  `belcredits` int(255) NOT NULL default '0',
  `beroofP` int(255) NOT NULL default '0',
  `bescherming` int(11) NOT NULL default '0',
  `besteld` int(3) NOT NULL default '0',
  `betaal` int(11) NOT NULL default '0',
  `betaald` char(3) collate latin1_general_ci NOT NULL default 'Nee',
  `beurs1` int(32) NOT NULL default '0',
  `beurs2` int(32) NOT NULL default '0',
  `beurs3` int(32) NOT NULL default '0',
  `beurs4` int(32) NOT NULL default '0',
  `beursw1` int(32) NOT NULL default '0',
  `beursw2` int(32) NOT NULL default '0',
  `beursw3` int(32) NOT NULL default '0',
  `beursw4` int(32) NOT NULL default '0',
  `bezet` int(5) NOT NULL default '0',
  `bezet1` int(1) default '0',
  `bezet2` int(1) default '0',
  `bezet3` int(1) default '0',
  `bf` varchar(5) collate latin1_general_ci NOT NULL default '',
  `blocklist` text NOT NULL,
  `bloed` int(1) default NULL,
  `bloodtype` char(3) collate latin1_general_ci NOT NULL default '1',
  `Bodyguard` int(5) NOT NULL default '0',
  `boksinzet` varchar(255) NOT NULL default '0',
  `boksnaam` varchar(255) NOT NULL default '',
  `bomlevel` varchar(255) NOT NULL default '1',
  `bonus` text collate latin1_general_ci NOT NULL,
  `boot` int(2) NOT NULL default '0',
  `bouwlevel1` int(1) NOT NULL default '0',
  `bouwlevel2` int(1) NOT NULL default '0',
  `bouwlevel3` int(1) NOT NULL default '0',
  `bouwstatus` int(1) NOT NULL default '0',
  `bugmisbruik` int(255) NOT NULL default '0',
  `Bulldog` int(5) NOT NULL default '0',
  `Bunker` int(5) NOT NULL default '0',
  `bustouts` varchar(255) NOT NULL default '0',
  `c4` int(255) NOT NULL default '0',
  `c4b` int(255) NOT NULL default '0',
  `c4v` int(255) NOT NULL default '0',
  `Camera` int(5) NOT NULL default '0',
  `capo` varchar(255) NOT NULL default '',
  `capoinvite` varchar(255) collate latin1_general_ci NOT NULL default '',
  `capolvl` int(255) NOT NULL default '0',
  `cars` int(11) NOT NULL default '0',
  `cash` bigint(255) NOT NULL default '500000',
  `casino1` text collate latin1_general_ci NOT NULL,
  `casino2` text collate latin1_general_ci NOT NULL,
  `casino3` text collate latin1_general_ci NOT NULL,
  `cdonatie` int(9) NOT NULL default '0',
  `chatrank` varchar(100) NOT NULL default 'member',
  `clan` varchar(26) NOT NULL default '',
  `clandonatie` bigint(255) NOT NULL default '0',
  `clanlevel` int(3) NOT NULL default '0',
  `clicks` varchar(255) NOT NULL default '0',
  `clickss` int(4) NOT NULL default '0',
  `clickstoday` varchar(255) NOT NULL default '0',
  `clicktext` text NOT NULL,
  `codechecker` int(50) NOT NULL default '0',
  `coffeshop` int(1) NOT NULL default '0',
  `coke` int(255) NOT NULL default '0',
  `cokefabriek` int(1) NOT NULL default '0',
  `coketijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `cokeverkoop` int(255) NOT NULL default '0',
  `controle` datetime NOT NULL default '0000-00-00 00:00:00',
  `crewleden` int(255) default '0',
  `crewwapen1` int(255) default '0',
  `crewwapen2` int(255) default '0',
  `crewwapen3` int(255) default '0',
  `crewwapen4` int(255) default '0',
  `crewwapen5` int(255) default '0',
  `crime` int(2) NOT NULL default '5',
  `crimes` int(255) NOT NULL default '0',
  `crush` datetime NOT NULL default '0000-00-00 00:00:00',
  `crushtime` int(11) NOT NULL default '0',
  `ctype` int(1) NOT NULL default '0',
  `dagen` int(255) default '0',
  `dagenwerken` int(255) NOT NULL default '0',
  `dealing` varchar(255) NOT NULL default '',
  `dealvordering` varchar(255) NOT NULL default '0',
  `death` int(11) NOT NULL default '0',
  `deathdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `defence` bigint(255) NOT NULL default '0',
  `deflevel` int(4) NOT NULL default '0',
  `deflevnew` int(4) NOT NULL default '0',
  `deflosses` varchar(255) NOT NULL default '0',
  `defwins` varchar(255) NOT NULL default '0',
  `dogs` int(5) NOT NULL default '0',
  `dogvoed` int(11) NOT NULL default '0',
  `dpower` int(255) default '0',
  `drugs` int(100) NOT NULL default '0',
  `drugs1` int(255) default '0',
  `drugs2` int(255) default '0',
  `drugs3` int(255) default '0',
  `drugs4` int(255) default '0',
  `drugs5` int(255) default '0',
  `drugs6` int(255) default '0',
  `drugsbellen` int(255) NOT NULL default '0',
  `drugsmeter` varchar(255) NOT NULL default '10',
  `drugspower` varchar(255) NOT NULL default '10',
  `Dynamite` int(5) NOT NULL default '0',
  `eerpunten` int(255) NOT NULL default '0',
  `eilanden` int(1) NOT NULL default '0',
  `elite` int(255) NOT NULL default '0',
  `email` varchar(64) default NULL,
  `enemies` text NOT NULL,
  `energie` int(5) NOT NULL default '100',
  `ervenis` varchar(255) collate latin1_general_ci NOT NULL default '',
  `escort` datetime NOT NULL default '0000-00-00 00:00:00',
  `F14` int(5) NOT NULL default '0',
  `F15` int(5) NOT NULL default '0',
  `F16` int(5) NOT NULL default '0',
  `fabriekown` int(255) NOT NULL default '0',
  `famconsig` int(1) NOT NULL default '0',
  `familie` varchar(255) NOT NULL default '',
  `family` varchar(50) collate latin1_general_ci NOT NULL default '',
  `faminvite` varchar(50) collate latin1_general_ci NOT NULL default '',
  `famleader` int(1) NOT NULL default '0',
  `famlevel` int(255) NOT NULL default '0',
  `famsotto` int(11) NOT NULL default '0',
  `Ferrari` int(5) NOT NULL default '0',
  `Flashbang` int(5) NOT NULL default '0',
  `FN P90` int(5) NOT NULL default '0',
  `forumban` int(1) NOT NULL default '0',
  `forumposts` int(255) NOT NULL default '0',
  `forumstatus` varchar(16) NOT NULL default 'default',
  `fraudetijd` varchar(255) NOT NULL default '',
  `G36C` int(5) NOT NULL default '0',
  `garage` int(1) NOT NULL default '0',
  `gebeltx` int(255) NOT NULL default '0',
  `geld` int(255) default '5000',
  `gelukt` int(5) NOT NULL default '0',
  `geslacht` varchar(16) NOT NULL default 'Onbekend',
  `gestart` int(1) NOT NULL default '0',
  `getaway` datetime NOT NULL default '0000-00-00 00:00:00',
  `gevangenis_tijd` int(15) default '0',
  `gevangenis` datetime NOT NULL default '0000-00-00 00:00:00',
  `gevangenistijd` int(100) NOT NULL default '0',
  `gevangP` int(255) NOT NULL default '0',
  `gezondheid` int(11) NOT NULL default '100',
  `gijzel` int(255) NOT NULL default '10',
  `gmisdaad` int(255) default '0',
  `gstart` int(2) NOT NULL default '0',
  `gvu` int(100) NOT NULL default '0',
  `hasj` int(255) NOT NULL default '0',
  `health` varchar(255) NOT NULL default '100',
  `heist` datetime default '0000-00-00 00:00:00',
  `Hek` int(5) NOT NULL default '0',
  `helpdeska` int(11) default '0',
  `heroine` int(11) NOT NULL default '0',
  `hitlist` int(255) default '0',
  `hmisdaad` int(255) default '0',
  `hmoorden` int(1) NOT NULL default '0',
  `hoeren` int(255) NOT NULL default '0',
  `hoerenwerkend` int(255) NOT NULL default '0',
  `hoermissie` int(255) NOT NULL default '0',
  `hoerpimped` int(255) NOT NULL default '0',
  `honourpoints` int(255) NOT NULL default '0',
  `honourpoints2` int(255) NOT NULL default '0',
  `hostmask` varchar(32) collate latin1_general_ci default 'JA',
  `HS` int(6) NOT NULL default '0',
  `HSN` int(6) NOT NULL default '0',
  `huisnaam` text NOT NULL,
  `hulpa` int(11) default '0',
  `hulpadmin` int(4) NOT NULL default '0',
  `huur` datetime NOT NULL default '0000-00-00 00:00:00',
  `huur1` int(255) NOT NULL default '0',
  `huurm` int(5) NOT NULL default '2',
  `huurmoorden` int(255) NOT NULL default '0',
  `huwelijk` varchar(255) collate latin1_general_ci NOT NULL default '',
  `id` int(4) NOT NULL auto_increment,
  `image` varchar(255) collate latin1_general_ci default 'images/nopicture.jpg',
  `inclevel` int(4) NOT NULL default '0',
  `info` text NOT NULL,
  `invitetype` int(1) NOT NULL default '0',
  `inzet` int(255) NOT NULL default '0',
  `IP` varchar(32) default NULL,
  `ip2` varchar(255) NOT NULL default '',
  `ipban` int(11) NOT NULL default '0',
  `IPs` text NOT NULL,
  `j13` int(10) NOT NULL default '0',
  `joint` int(5) NOT NULL default '50',
  `jointtijd` int(255) NOT NULL default '0',
  `kansen` int(1) default '2',
  `keervermoord` int(11) NOT NULL default '0',
  `killedby` varchar(255) collate latin1_general_ci NOT NULL default '',
  `killedppl` int(255) NOT NULL default '0',
  `klikdl` int(11) NOT NULL default '0',
  `klikmissie` int(3) NOT NULL default '0', 
  `kliklink` varchar(255) NOT NULL default '0',
  `kliklink2` varchar(11) NOT NULL default '0',
  `kliktijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `kogelfabriek` text collate latin1_general_ci NOT NULL,
  `kogels` int(255) NOT NULL default '100',
  `Kogelvrij vest` int(5) NOT NULL default '0',
  `krassencount` int(10) NOT NULL default '0',
  `krassentime` datetime NOT NULL default '0000-00-00 00:00:00',
  `krieg550` int(255) NOT NULL default '0',
  `krieg550b` int(255) NOT NULL default '0',
  `krieg550v` int(255) NOT NULL default '0',
  `kt` int(255) NOT NULL default '1',
  `ktp` varchar(255) NOT NULL default '0',
  `land` int(2) NOT NULL default '1',
  `landcheck` int(2) NOT NULL default '3',
  `lang` varchar(10) NOT NULL default 'en',
  `ledenrank` int(255) default '0',
  `leeftijd` text NOT NULL,
  `legaalstatus` int(1) NOT NULL default '0',
  `legaaltransport` int(1) NOT NULL default '0',
  `legaaltransport1` int(1) NOT NULL default '0',
  `legaaltransport2` int(1) NOT NULL default '0',
  `legaaltransport3` int(1) NOT NULL default '0',
  `level` int(3) NOT NULL default '1',
  `leven` int(3) NOT NULL default '100',
  `link1` int(1) NOT NULL default '1',
  `link2` int(1) NOT NULL default '1',
  `link3` int(1) NOT NULL default '1',
  `link4` int(1) NOT NULL default '0',
  `login` varchar(16) default NULL,
  `lost` int(255) NOT NULL default '0',
  `loten` int(11) NOT NULL default '0',
  `lotto` int(2) NOT NULL default '1',
  `lotuselise` int(5) NOT NULL default '0',
  `lpv` datetime NOT NULL default '0000-00-00 00:00:00',
  `lsd` int(11) NOT NULL default '0',
  `m1` int(255) default '0',
  `m16` int(255) NOT NULL default '0',
  `m16b` int(255) NOT NULL default '0',
  `m16v` int(255) NOT NULL default '0',
  `m2` int(255) default '0',
  `m3` int(255) default '0',
  `m4` int(11) NOT NULL default '0',
  `m5` int(255) default '0',
  `m6` int(255) default '0',
  `m60` int(255) NOT NULL default '0',
  `m60b` int(255) NOT NULL default '0',
  `m60v` int(255) NOT NULL default '0',
  `maffiamode` int(5) NOT NULL default '0',
  `Magazijn` int(1) NOT NULL default '0',
  `mailing` varchar(255) collate latin1_general_ci NOT NULL default '1',
  `mails` int(1) NOT NULL default '1',
  `maxpoints` int(255) NOT NULL default '0',
  `mayor` int(255) NOT NULL default '0',
  `melding` int(255) NOT NULL default '0',
  `memberdays` datetime default '0000-00-00 00:00:00',
  `Mes` int(5) NOT NULL default '0',
  `messages` int(11) NOT NULL default '0',
  `misdaad` datetime NOT NULL default '0000-00-00 00:00:00',
  `misdaadl` int(100) NOT NULL default '0',
  `misdaadP` int(4) NOT NULL default '0',
  `misdaadtime` int(11) NOT NULL default '0',
  `misluk` int(5) NOT NULL default '0',
  `missie` int(255) NOT NULL default '0',
  `missie1` int(1) NOT NULL default '1',
  `missie2` int(1) NOT NULL default '0',
  `missie3` int(1) NOT NULL default '0',
  `missie5` int(3) NOT NULL default '0',
  `mmisdaad` int(255) default '0',
  `Mobieltje` int(1) NOT NULL default '0',
  `moord` datetime NOT NULL default '0000-00-00 00:00:00',
  `moorden` varchar(255) NOT NULL default '0',
  `moordervaring` varchar(255) NOT NULL default '0',
  `moordexp` varchar(100) collate latin1_general_ci NOT NULL default '0',
  `moordtijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `moordtime` varchar(50) collate latin1_general_ci NOT NULL default '',
  `muntjes` bigint(255) NOT NULL default '0',
  `music` varchar(255) collate latin1_general_ci NOT NULL default '',
  `Muur` int(5) NOT NULL default '0',
  `name` varchar(20) collate latin1_general_ci NOT NULL default 'Onbekend',
  `nederwiet` int(11) NOT NULL default '0',
  `nonactief` int(11) NOT NULL default '0',
  `note` text NOT NULL,
  `oc_lost` int(11) NOT NULL default '0',
  `oc_won` int(11) NOT NULL default '0',
  `ocs` int(11) NOT NULL default '0',
  `ocsdoen` int(11) NOT NULL default '2',
  `odminuten` int(255) default '0',
  `onderduiken` int(255) NOT NULL default '0',
  `onderduiktime` datetime default '0000-00-00 00:00:00',
  `online` datetime NOT NULL default '0000-00-00 00:00:00',
  `online2` varchar(5) NOT NULL default 'nee',
  `ontslag` int(255) NOT NULL default '0',
  `opdruktijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `opdruktijd1` int(255) NOT NULL default '0',
  `opium` int(11) NOT NULL default '0',
  `orgtime` datetime NOT NULL default '0000-00-00 00:00:00',
  `overval` varchar(255) NOT NULL default '1',
  `p1` int(255) NOT NULL default '0',
  `p2` int(255) NOT NULL default '0',
  `p3` int(255) NOT NULL default '0',
  `p4` int(255) NOT NULL default '0',
  `paddo` int(11) NOT NULL default '0',
  `page` varchar(100) NOT NULL default '',
  `pakket1` int(255) default '0',
  `pakket2` int(255) default '0',
  `parnters` varchar(255) NOT NULL default '0',
  `partners` varchar(255) NOT NULL default '0',
  `pass` varchar(32) default NULL,
  `paying` int(3) NOT NULL default '0',
  `picture` varchar(128) collate latin1_general_ci NOT NULL default 'images/nopicture.jpg',
  `pimpdiploma` varchar(255) NOT NULL default '0',
  `pimprecht` int(2) NOT NULL default '0',
  `pin` varchar(32) collate latin1_general_ci default NULL,
  `plantage` int(6) NOT NULL default '0',
  `poker` int(1) NOT NULL default '0',
  `president` int(1) NOT NULL default '0',
  `protection` int(255) NOT NULL default '0',
  `punten` int(11) NOT NULL default '0',
  `race` datetime default '0000-00-00 00:00:00',
  `racexp` int(255) default '0',
  `ramen` int(255) NOT NULL default '0',
  `rank` varchar(100) NOT NULL default '1',
  `rankvord` varchar(100) NOT NULL default '0',
  `rankvordering` int(255) default '0',
  `recruiter` varchar(16) collate latin1_general_ci default NULL,
  `recruiters` int(4) NOT NULL default '0',
  `recruits` int(11) NOT NULL default '0',
  `reden` int(5) NOT NULL default '0',
  `referals` varchar(20) collate latin1_general_ci NOT NULL default '0',
  `reistijd` int(15) unsigned NOT NULL default '0',
  `reizen` datetime default '0000-00-00 00:00:00',
  `respect` int(255) NOT NULL default '0',
  `rijbewijsauto` int(255) NOT NULL default '0',
  `rijbewijsmissie` int(255) NOT NULL default '0',
  `Rijbewijsvordering` int(255) NOT NULL default '0',
  `rn` int(18) default '0',
  `rp` int(255) NOT NULL default '10',
  `rtijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `rtijden` int(11) NOT NULL default '0',
  `runner` int(1) NOT NULL default '0',
  `Scherpschut geweer` int(5) NOT NULL default '0',
  `schiet` datetime NOT NULL default '0000-00-00 00:00:00',
  `Schietende Tank` int(5) NOT NULL default '0',
  `schiettijd` varchar(50) collate latin1_general_ci NOT NULL default '',
  `scooterstelen` int(11) NOT NULL default '0',
  `security` int(255) NOT NULL default '0',
  `sex` int(1) NOT NULL default '0',
  `sh` int(255) NOT NULL default '1',
  `Shotgun` int(5) NOT NULL default '0',
  `showonline` int(1) NOT NULL default '1',
  `shp` varchar(255) NOT NULL default '0',
  `sig552` int(255) NOT NULL default '0',
  `sig552b` int(255) NOT NULL default '0',
  `sig552v` int(255) NOT NULL default '0',
  `signup` datetime default NULL,
  `smstegoed` int(5) NOT NULL default '20',
  `speed` int(11) NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `statusbalk` int(1) NOT NULL default '0',
  `steel` datetime NOT NULL default '0000-00-00 00:00:00',
  `steel1` datetime NOT NULL default '0000-00-00 00:00:00',
  `steel2` datetime NOT NULL default '0000-00-00 00:00:00',
  `steelgroot` int(3) NOT NULL default '0',
  `steelklein` int(3) NOT NULL default '0',
  `steelP` varchar(255) NOT NULL default '0',
  `steeltijd` int(255) NOT NULL default '0',
  `steeltijd1` int(225) NOT NULL default '0',
  `steeltijd2` int(225) NOT NULL default '0',
  `straat` varchar(255) collate latin1_general_ci NOT NULL default '',
  `strength` int(100) NOT NULL default '0',
  `testament` varchar(255) NOT NULL default '',
  `topbalk` int(255) NOT NULL default '0',
  `train` varchar(255) NOT NULL default '0',
  `training1` int(11) NOT NULL default '0',
  `training2` int(11) NOT NULL default '0',
  `training3` int(11) NOT NULL default '0',
  `trainuur` varchar(255) NOT NULL default '0',
  `transP` varchar(255) NOT NULL default '0',
  `transportstatus` int(1) NOT NULL default '0',
  `trlvl` int(10) NOT NULL default '0',
  `turns` int(3) NOT NULL default '100',
  `type` int(1) NOT NULL default '0',
  `typew` int(2) NOT NULL default '2',
  `uh` int(255) NOT NULL default '1',
  `uhp` varchar(255) NOT NULL default '0',
  `uitbreek` int(255) NOT NULL default '0',
  `uitnodiging` varchar(255) NOT NULL default 'geen',
  `untlevel` int(7) NOT NULL default '0',
  `upgrade_recruits` int(2) NOT NULL default '0',
  `url` varchar(128) collate latin1_general_ci NOT NULL default '',
  `Uzi` int(5) NOT NULL default '0',
  `vaartijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `verbannen` varchar(255) NOT NULL default '0',
  `verkoop` int(255) default '0',
  `verkooptijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `vermoord` varchar(255) NOT NULL default '0',
  `vermoorden` datetime default '0000-00-00 00:00:00',
  `vermoordtijd` int(11) NOT NULL default '0',
  `vip` int(5) NOT NULL default '0',
  `vipdays` int(11) NOT NULL default '0',
  `vlammenwerper` int(5) NOT NULL default '0',
  `vliegen` datetime NOT NULL default '0000-00-00 00:00:00',
  `vliegentime` varchar(50) collate latin1_general_ci NOT NULL default '',
  `vliegtijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `vliegtuig` int(255) NOT NULL default '1800',
  `voertuig` tinyint(2) unsigned NOT NULL default '1',
  `voornaam` text NOT NULL,
  `Walter P99` int(5) NOT NULL default '0',
  `wapens` varchar(9) collate latin1_general_ci NOT NULL default '0',
  `warning` int(1) NOT NULL default '0',
  `weapon` int(255) NOT NULL default '0',
  `werk` int(5) NOT NULL default '0',
  `werk2` int(255) NOT NULL default '0',
  `werken` datetime NOT NULL default '0000-00-00 00:00:00',
  `werken1` int(255) NOT NULL default '0',
  `werkend` int(5) NOT NULL default '0',
  `werklevel` int(255) NOT NULL default '1',
  `wiet` int(255) NOT NULL default '0',
  `wijn` int(3) NOT NULL default '0',
  `winnaar` varchar(16) NOT NULL default '',
  `winst` int(255) NOT NULL default '0',
  `won` int(255) NOT NULL default '0',
  `woning` int(5) NOT NULL default '0',
  `woningtekst` text NOT NULL,
  `woonplaats` varchar(255) collate latin1_general_ci NOT NULL default '',
  `wskill` int(3) NOT NULL default '0',
  `xtc` int(11) NOT NULL default '0',
  `zoeken` int(11) NOT NULL default '0',
  `Zonda` int(5) NOT NULL default '0',
  
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1958 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[users]`
-- 
-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[veilingboden]`
-- 

CREATE TABLE `[veilingboden]` (
  `id` int(255) NOT NULL auto_increment,
  `veilid` int(255) NOT NULL default '0',
  `login` varchar(255) NOT NULL default '',
  `bod` bigint(255) NOT NULL default '0',
  `tijd` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[veilingboden]`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `[userinfo]`
-- 

CREATE TABLE `[userinfo]` (
  `login` varchar(36) NOT NULL default '',
  `leeftijd` int(4) NOT NULL default '0',
  `lijfwachten` bigint(4) NOT NULL default '0',
  `b1` int(255) NOT NULL default '0',
  `b2` int(255) NOT NULL default '0',
  `b3` int(255) NOT NULL default '0',
  `b4` int(255) NOT NULL default '0',
  `p1` int(255) NOT NULL default '0',
  `p2` int(255) NOT NULL default '0',
  `p3` int(255) NOT NULL default '0',
  `p4` int(255) NOT NULL default '0',
  `bustprijs` bigint(255) NOT NULL default '0',
  `celltime` datetime NOT NULL default '0000-00-00 00:00:00',
  `cellstraf` int(1) NOT NULL default '0',
  `busting` int(7) NOT NULL default '0',
  `cellpoging` int(3) NOT NULL default '0',
  `handlvl` int(255) NOT NULL default '0',
  `handtrain` datetime NOT NULL default '0000-00-00 00:00:00',
  `A1` int(4) NOT NULL default '0',
  `A2` int(4) NOT NULL default '0',
  `A3` int(4) NOT NULL default '0',
  `A4` int(4) NOT NULL default '0',
  `A5` int(4) NOT NULL default '0',
  `geslacht` varchar(36) NOT NULL default 'Onbekend',
  `kliklink` int(4) NOT NULL default '0',
  `loon` int(4) NOT NULL default '1',
  `beurs1` int(36) NOT NULL default '0',
  `beurs2` int(36) NOT NULL default '0',
  `beurs3` int(36) NOT NULL default '0',
  `beurs4` int(36) NOT NULL default '0',
  `beursw1` int(36) NOT NULL default '0',
  `beursw2` int(36) NOT NULL default '0',
  `beursw3` int(36) NOT NULL default '0',
  `beursw4` int(36) NOT NULL default '0',
  `A6` int(6) NOT NULL default '0',
  `A7` int(6) NOT NULL default '0',
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[veiling]`
-- 

CREATE TABLE `[veiling]` (
  `id` int(11) NOT NULL auto_increment,
  `soort` int(255) NOT NULL default '0',
  `plaatser` varchar(255) NOT NULL default '',
  `hoeveel` bigint(255) NOT NULL default '0',
  `bieder` varchar(255) NOT NULL default '',
  `bod` bigint(255) NOT NULL default '0',
  `tijd` datetime NOT NULL default '0000-00-00 00:00:00',
  `vid` int(255) NOT NULL default '0',
  `info` text NOT NULL,
  `veiltijd` int(255) NOT NULL default '3600',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[veiling]`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `[voertuigen]`
-- 

CREATE TABLE `[voertuigen]` (
  `voertuig_id` tinyint(2) unsigned NOT NULL auto_increment,
  `voertuig` varchar(35) collate latin1_general_ci NOT NULL default 'On Foot',
  `reistijd` smallint(5) unsigned NOT NULL default '10800',
  `reiskosten` mediumint(6) unsigned NOT NULL default '0',
  `inhoud` tinyint(3) unsigned NOT NULL default '1',
  `rank` tinyint(2) unsigned NOT NULL default '0',
  `prijs` int(12) NOT NULL default '0',
  PRIMARY KEY  (`voertuig_id`),
  UNIQUE KEY `voertuig` (`voertuig`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `[voertuigen]`
-- 

INSERT INTO `[voertuigen]` VALUES (1, 'On foot', 10800, 100, 1, 0, 100);
INSERT INTO `[voertuigen]` VALUES (2, 'On a bicycle', 5400, 200, 5, 0, 200);
INSERT INTO `[voertuigen]` VALUES (3, 'by the bus', 4500, 300, 10, 0, 300);
INSERT INTO `[voertuigen]` VALUES (4, 'On a Scooter', 4500, 500, 20, 2, 500);
INSERT INTO `[voertuigen]` VALUES (5, 'By Car', 6000, 1000, 30, 3, 1000);
INSERT INTO `[voertuigen]` VALUES (6, 'By Boat', 6800, 2000, 40, 4, 2000);
INSERT INTO `[voertuigen]` VALUES (7, 'By Silboat', 10800, 5000, 50, 5, 5000);
INSERT INTO `[voertuigen]` VALUES (8, 'Cruise ship', 10800, 6000, 60, 6, 6000);
INSERT INTO `[voertuigen]` VALUES (9, 'Private jet', 10800, 7000, 70, 7, 7000);
INSERT INTO `[voertuigen]` VALUES (10, 'Space shuttle', 10800, 8000, 80, 8, 8000);


-- --------------------------------------------------------


--
-- Table structure for table `[winkel]`
--

DROP TABLE IF EXISTS `[winkel]`;
CREATE TABLE `[winkel]` (
  `login` varchar(50) NOT NULL default '',
  `wapen1` int(11) NOT NULL default '0',
  `wapen2` int(11) NOT NULL default '0',
  `wapen3` int(11) NOT NULL default '0',
  `wapen4` int(11) NOT NULL default '0',
  `wapen5` int(11) NOT NULL default '0',
  `wapen6` int(11) NOT NULL default '0',
  `wapen7` int(11) NOT NULL default '0',
  `wapen8` int(11) NOT NULL default '0',
  `wapen9` int(11) NOT NULL default '0',
  `wapen10` int(11) NOT NULL default '0',
  `wapen11` int(11) NOT NULL default '0',
  `wapen12` int(11) NOT NULL default '0',
  `wapen13` int(11) NOT NULL default '0',
  `wapen14` int(11) NOT NULL default '0',
  `wapen15` int(11) NOT NULL default '0',
  `wapen16` int(11) NOT NULL default '0',
  `bescherming1` int(11) NOT NULL default '0',
  `bescherming2` int(11) NOT NULL default '0',
  `tank1` int(11) NOT NULL default '0',
  `tank2` int(11) NOT NULL default '0',
  `tank3` int(11) NOT NULL default '0',
  `tank4` int(11) NOT NULL default '0',
  `tank5` int(11) NOT NULL default '0',
  `tank6` int(11) NOT NULL default '0',
  `verdediging1` int(11) NOT NULL default '0',
  `verdediging2` int(11) NOT NULL default '0',
  `verdediging3` int(11) NOT NULL default '0',
  `verdediging4` int(11) NOT NULL default '0',
  `verdediging5` int(11) NOT NULL default '0',
  `verdediging6` int(11) NOT NULL default '0',
  `vliegtuig1` int(11) NOT NULL default '0',
  `vliegtuig2` int(11) NOT NULL default '0',
  `vliegtuig3` int(11) NOT NULL default '0',
  `vliegtuig4` int(11) NOT NULL default '0',
  `vliegtuig5` int(11) NOT NULL default '0',
  `vliegtuig6` int(11) NOT NULL default '0',
  `onderzeeboot1` int(11) NOT NULL default '0',
  `onderzeeboot2` int(11) NOT NULL default '0',
  `onderzeeboot3` int(11) NOT NULL default '0',
  `onderzeeboot4` int(11) NOT NULL default '0',
  `schip1` int(11) NOT NULL default '0',
  `schip2` int(11) NOT NULL default '0',
  `schip3` int(11) NOT NULL default '0',
  `schip4` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `[winkel]`
--

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[wietplantage]`
-- 

CREATE TABLE `[wietplantage]` (
  `id` int(255) NOT NULL auto_increment,
  `eigenaar` varchar(255) NOT NULL default '',
  `planten` varchar(255) NOT NULL default '',
  `begonnen` int(59) NOT NULL default '3',
  `procent` int(59) NOT NULL default '3',
  `aantalkopen` int(55) NOT NULL default '3',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[wietplantage]`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `[weed]`
-- 

CREATE TABLE `[weed]` (
  `id` int(11) NOT NULL auto_increment,
  `dagen` int(4) NOT NULL default '0',
  `member` int(11) default NULL,
  `status` int(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `[weed]`
-- 

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `[weapons]`
-- 

CREATE TABLE `[weapons]` (
  `id` int(4) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `area` int(2) default NULL,
  `costs` int(7) default NULL,
  `url` varchar(40) default NULL,
  `attack` int(5) default NULL,
  `defence` int(5) default NULL,
  `max` text,
  `eval` text,
  `error` text,
  `extra` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Gegevens worden uitgevoerd voor tabel `[weapons]`
-- 

INSERT INTO `[weapons]` VALUES (1, 'Knife', 1, 2000, 'item-Knife', 20, 20, '1 per $type_s (Je hebt $num $type_p die dit wapen nog niet hebben)', '$num = $data->clicks-$data->Mes; return $num;', 'Al je $type_p hebben al een mes', NULL);
INSERT INTO `[weapons]` VALUES (2, 'Walter P99', 1, 5000, 'item-Walter_P99', 50, 50, '1 per $type_s (Je hebt $num $type_p die dit wapen nog niet hebben)', '$num = $data->clicks-$data->{''Walter P99''}; return $num;', 'Al je $type_p hebben al een Walter P99', NULL);
INSERT INTO `[weapons]` VALUES (3, 'Uzi', 1, 6000, 'item-Uzi', 65, 65, '1 per $type_s (Je hebt $num $type_p die dit wapen nog niet hebben)', '$num = $data->clicks-$data->Uzi; return $num;', 'Al je $type_p hebben al een uzi', NULL);
INSERT INTO `[weapons]` VALUES (4, 'Flashbang', 1, 10000, 'item-Flashbang', 110, 110, '1 per $type_s (Je hebt $num $type_p die deze granaat nog niet hebben)', '$num = $data->clicks-$data->Flashbang; return $num;', 'Al je $type_p hebben al een flashbang', NULL);
INSERT INTO `[weapons]` VALUES (5, 'Grenade', 1, 15000, 'item-Grenade', 170, 170, '1 per $type_s (Je hebt $num $type_p die deze granaat nog niet hebben)', '$num = $data->clicks-$data->Granaat; return $num;', 'Al je $type_p hebben al een granaat', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `ziekenhuis`
-- 

CREATE TABLE `ziekenhuis` (
  `id` int(255) NOT NULL auto_increment,
  `owner` varchar(16) NOT NULL default '',
  `land` varchar(64) NOT NULL default '',
  `aantala` int(10) NOT NULL default '0',
  `aantalb` int(10) NOT NULL default '0',
  `aantalab` int(10) NOT NULL default '0',
  `aantalo` int(10) NOT NULL default '0',
  `prijsa` int(6) NOT NULL default '0',
  `prijsb` int(6) NOT NULL default '0',
  `prijsab` int(6) NOT NULL default '0',
  `prijso` int(6) NOT NULL default '0',
  `verkoop` int(1) NOT NULL default '0',
  `prijsinkoopa` int(8) NOT NULL default '1200',
  `prijsinkoopb` int(8) NOT NULL default '1200',
  `prijsinkoopab` int(8) NOT NULL default '1200',
  `prijsinkoopo` int(8) NOT NULL default '1200',
  `klanten` int(8) NOT NULL default '1',
  `winst` int(8) NOT NULL default '1000',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

-- 
-- Dumping data for table `ziekenhuis`
-- 

INSERT INTO `ziekenhuis` VALUES (1, 'admin', 'Netherlands', 550, 546, 536, 542, 1500, 1600, 1800, 1000, 0, 1248, 824, 1235, 940, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (2, 'admin', 'France', 600, 574, 600, 567, 1000, 1000, 2000, 1500, 0, 1168, 764, 820, 910, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (3, 'admin', 'Cuba', 200, 188, 200, 310, 1500, 1500, 1750, 1450, 0, 807, 647, 1456, 618, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (4, 'admin', 'Russia', 200, 200, 200, 200, 1500, 1500, 1650, 1400, 0, 717, 889, 864, 864, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (5, 'admin', 'Australia', 1550, 1545, 1550, 1533, 1400, 1400, 1300, 1100, 0, 759, 1091, 1300, 839, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (6, 'admin', 'USA', 993, 1000, 1007, 985, 1200, 1200, 1400, 900, 0, 712, 1156, 1295, 851, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (7, 'admin', 'Germany', 4552, 3545, 3558, 4558, 2000, 2000, 2000, 700, 0, 1095, 822, 1059, 899, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (8, 'admin', 'Belgium', 481, 467, 500, 497, 900, 900, 900, 900, 0, 844, 1262, 990, 637, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (9, 'admin', 'England', 1089, 1050, 1097, 1081, 2000, 2000, 2000, 2000, 0, 1225, 707, 985, 852, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (10, 'admin', 'Ireland', 700, 685, 1200, 386, 1500, 1500, 1750, 1200, 0, 806, 965, 1071, 796, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (11, 'admin', 'Japan', 2755, 2799, 2800, 2787, 1200, 1150, 1400, 1000, 0, 827, 1180, 1213, 746, 1, 1000);
INSERT INTO `ziekenhuis` VALUES (12, 'admin', 'Cuba', 488, 497, 490, 493, 1400, 1400, 1400, 1000, 0, 1077, 753, 969, 955, 1, 1000);
