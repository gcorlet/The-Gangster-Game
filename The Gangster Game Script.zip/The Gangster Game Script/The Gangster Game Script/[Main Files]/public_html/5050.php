<?php
error_reporting(0);

include("_include-config.php");
    include("_include-gevangenis.php");

  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

    $dbres         = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'"); 
    $data				= mysql_fetch_object($dbres);

?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">

<center>
<table  width=70%><table width=70% cellspacing=0 cellpadding=2><table width=70%> 
  <tr>
<td width="70%" class=subTitle><b>Give it a try!</b></td>
<table  width=70%>
<td class="mainTxt"><center><img border=0 src=images/game/50picture.jpg border=0 width="100%"></center>
</td>
</table></tr></table></table></table></center>

<table align="center" width="70%">
<tr><td class="subTitle">50/50</td></tr>
<tr><td class="mainTxt">
Welcome to 50/50,<br>
In this game you have 50% chance of winning!<br> On the other hand, theres 50% chance you could lose!
</td></tr>
<form method="POST">
<tr><td class="mainTxt" align="center"><input maxlength="13" class="btn btn-info" type="text" name="inzet"> <input class="btn btn-info" type="submit" value="Give it a Go!"></td></tr>
</form>
<?
if(isset($_POST['inzet'])){
$kans = rand(1,2);
if($data->cash < $_POST['inzet']) {
print"<tr><td class=\"mainTxt\" align=\"center\">You dont have enough cash!</td></tr>";
} else if(!preg_match('/^[0-9]{1,15}$/',$_POST['inzet'])) {
print"<tr><td class=\"mainTxt\" align=\"center\">Only enter numbers.</td></tr>";
} else if($kans == 1) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'{$_POST['inzet']}' WHERE `login`='{$data->login}'");
print"<tr><td class=\"mainTxt\" align=\"center\">Unlucky, you have lost</td></tr>";
} else if($kans == 2) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'{$_POST['inzet']}*2' WHERE `login`='{$data->login}'");
print"<tr><td class=\"mainTxt\" align=\"center\">Well Done! You have won!</td></tr>";
}
}
?>
</table>
</body>
</html>