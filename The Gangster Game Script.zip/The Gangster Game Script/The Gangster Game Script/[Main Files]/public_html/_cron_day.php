<?php
error_reporting(0);

  if($cron_pass != "secretcronpassword")  exit;
  mysql_query("UPDATE `[users]` SET `link1`='1'");
  mysql_query("UPDATE `[users]` SET `link2`='1',`link4`='1'");
mysql_query("UPDATE `[users]` SET `baantjegezocht`=`baantjegezocht`='0'");
mysql_query("UPDATE `[users]` SET `vip`=`vip`-'1' WHERE `vip`>'0'");
mysql_query("UPDATE `[users]` SET `kliklink2`='0'");
mysql_query("UPDATE `[users]` SET `moorden`='0'");
mysql_query("UPDATE `[users]` SET `huurmoorden`='0'");
mysql_query("UPDATE `[users]` SET `bankpogingen`='0'");
mysql_query("UPDATE `[users]` SET `bankleft`='25'");
mysql_query("UPDATE `[users]` SET `krassencount`='0'");
mysql_query("UPDATE `[dogs]` SET `leeftijd`=`leeftijd`+'1'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'6000' WHERE `vip`>'0'");
mysql_query("UPDATE `[users]` SET `joint`=`joint`+`plantage`*1000 WHERE `plantage`>'0' AND`joint`<50000");
mysql_query("UPDATE `[users]` SET `jointtijd`='0'");
  mysql_query("UPDATE `[users]` SET `staking`=`staking`-1 WHERE `staking` >0");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+100 WHERE (`baan`) =1");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+200 WHERE (`baan`) =2");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+400 WHERE (`baan`) =3");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+600 WHERE (`baan`) =4");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+700 WHERE (`baan`) =5");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+800 WHERE (`baan`) =6");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+1200 WHERE (`baan`) =7");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+1400 WHERE (`baan`) =8");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+1500 WHERE (`baan`) =9");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+1800 WHERE (`baan`) =10");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+2200 WHERE (`baan`) =11");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+2500 WHERE (`baan`) =12");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+2800 WHERE (`baan`) =13");
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+3000 WHERE (`baan`) =14");
  mysql_query("UPDATE `[users]` SET `dagenwerken`=`dagenwerken`-1 WHERE (`dagenwerken`) > 1");
  mysql_query("UPDATE `[users]` SET `ontslag`=`ontslag`-1 WHERE (`ontslag`) > 0");
  mysql_query("UPDATE `[users]` SET `nietstaken`=`nietstaken`-1 WHERE (`nietstaken`) > 0");
  mysql_query("UPDATE `[users]` SET `staking`=`staking`-1, `nietstaken`=`nietstaken`+2 WHERE (`staking`) == 1");
  mysql_query("UPDATE `[users]` SET `staking`=`staking`-1 WHERE (`staking`) > 1");
  mysql_query("UPDATE `spel_statestieken` SET `link1`='0'");
mysql_query("UPDATE `spel_statestieken` SET `link2`='0'");
mysql_query("UPDATE `spel_statestieken` SET `link3`='0'");
mysql_query("UPDATE `spel_statestieken` SET `link4`='0'");


  mysql_query("UPDATE `[users]` SET `lotto`=2");
  mysql_query("UPDATE `weed` SET `dagen`= `dagen`+1"); 
  mysql_query("UPDATE `weed` SET `status`= `status`-1"); 
  mysql_query("DELETE FROM `weed` WHERE `status`=-1"); 
  mysql_query("TRUNCATE TABLE `backup-[users]`");
  mysql_query("OPTIMIZE TABLE `backup-[users]`");
  mysql_query("INSERT INTO `backup-[users]` SELECT * FROM `[users]`");

  mysql_query("INSERT INTO `backup-[users]` SELECT * FROM `[users]`");
  mysql_query("DELETE FROM `[logs]` WHERE `area`='click'");
  mysql_query("UPDATE `[users]` SET `nonactief`=`nonactief`-1 WHERE `dagen`='1'");
  mysql_query("UPDATE `[users]` SET `nederwiet`=`nederwiet`+1 WHERE `nederwiet` < 20");
  mysql_query("UPDATE `[users]` SET `xtc`=`xtc`+1 WHERE `xtc` < 20");
  mysql_query("UPDATE `[users]` SET `lsd`=`lsd`+1 WHERE `lsd` < 20");
  mysql_query("UPDATE `[users]` SET `speed`=`speed`+1 WHERE `speed` < 20");
  mysql_query("UPDATE `[users]` SET `paddo`=`paddo`+1 WHERE `paddo` < 20");
  mysql_query("UPDATE `[users]` SET `opium`=`opium`+1 WHERE `opium` < 20");
  mysql_query("UPDATE `[users]` SET `nederwiet`=`nederwiet`+2 WHERE `paying` > 1 AND `nederwiet` < 40");
  mysql_query("UPDATE `[users]` SET `xtc`=`xtc`+2 WHERE `paying` > 1 AND `xtc` < 40");
  mysql_query("UPDATE `[users]` SET `lsd`=`lsd`+2 WHERE `paying` > 1 AND `lsd` < 40");
  mysql_query("UPDATE `[users]` SET `speed`=`speed`+2 WHERE `paying` > 1 AND `speed` < 40");
  mysql_query("UPDATE `[users]` SET `paddo`=`paddo`+2 WHERE `paying` > 1 AND `paddo` < 40");
  mysql_query("UPDATE `[users]` SET `opium`=`opium`+2 WHERE `paying` > 1 AND `opium` < 40");
  mysql_query("UPDATE `[users]` SET `ocs`='0',`ocsdoen`='2',`clickstoday`='0'");
  
  mysql_query("UPDATE `[stadowner]` SET `gevang`=`gevang`+3 WHERE `gevang` < 20");
  mysql_query("UPDATE `[stadowner]` SET `gevanguit`=`gevanguit`+3 WHERE `gevanguit` < 20");
  mysql_query("UPDATE `[stadowner]` SET `uitzetten`=`uitzetten`+3 WHERE `uitzetten` < 20");

  mysql_query("UPDATE `[users]` SET `autos1`='0',`autos2`='0',`autos3`='0',`autos4`='0',`autos5`='0',`autos6`='0',`autos7`='0',`autos8`='0',`autos9`='0',`autos10`='0'");

  mysql_query("OPTIMIZE TABLE `[clans]`");
  mysql_query("OPTIMIZE TABLE `[logs]`");
  mysql_query("OPTIMIZE TABLE `[temp]`");
  mysql_query("OPTIMIZE TABLE `[users]`");

?>