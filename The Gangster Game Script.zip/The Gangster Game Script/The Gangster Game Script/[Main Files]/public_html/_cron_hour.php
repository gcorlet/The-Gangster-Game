<?php
error_reporting(0);

  if($cron_pass != "secretcronpassword")exit;


mysql_query("UPDATE `[users]` set `klikmissie`='0'");
	$dbres3				= mysql_query("SELECT * FROM `[users]` WHERE `login`='$data->login'");
	$data2 = mysql_fetch_object($dbres3);
 
	$b = $data2->plantage; 
	$plantage = $b*1000;

	$dbres3				= mysql_query("SELECT * FROM `[stadowner]` WHERE `owner`='$data->login'");
	$owner = mysql_fetch_object($dbres3);
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);

$geld                		= $data2->hoeren;
$geld2                      = $geld*5;
$geld3               		= $data2->hoerenwerkend;
$geld4                      = $geld*15;
$geld5                      = $geld4+$geld2;
$inkomen                    = $geld5; 
$geld7                      = $data->bank/100*1;
$rente                      = $geld7; 

mysql_query("UPDATE `[users]` SET `link3`='1'");
mysql_query("UPDATE `[users]` SET `link2`='1'");
mysql_query("DELETE FROM `[logs]` WHERE `area`='attack'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+(`winst)"); 
mysql_query("UPDATE `[buildings]` SET `maxpoints`=`maxpoints`+'2' WHERE `level`>'-1'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$inkomen' WHERE `hoeren`>'0'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'50000' WHERE `login`='{$owner->login}'");
mysql_query("UPDATE `[users]` SET `energie`='100' WHERE `energie`>'100'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'6000' WHERE `vip`>'0'");

mysql_query("UPDATE `[users]` SET `cash`=`cash`+'100' WHERE `cash`<'0'");

mysql_query("UPDATE `[users]` SET `rp`=`rp`+'10'");
mysql_query("UPDATE `[users]` SET `baantjegezocht`='0'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$hoeveel'");
mysql_query("UPDATE `[users]` SET `kliklink`='0' WHERE `activated`='1'");
mysql_query("UPDATE `[stadowner]` SET `gevang`=3");
mysql_query("UPDATE `[stadowner]` SET `gevanguit`=3");
mysql_query("UPDATE `[users]` SET `health`=`health`+'25' WHERE `health`='0'");
mysql_query("UPDATE `[users]` SET `overval`='1'");
mysql_query("UPDATE `[users]` SET `hoerpimped`='0'");
mysql_query("UPDATE `equipment` SET `voorraad`='1000' WHERE `type`='S'");
mysql_query("UPDATE `[dogs]` SET `trainend`='0'");
mysql_query("UPDATE `[users]` SET `IPs`='0'");
mysql_query("UPDATE `[dogs]` SET `voeding`='0'");
mysql_query("UPDATE `[users]` SET `melding`='0'");
mysql_query("UPDATE `[users]` SET `melding`=`melding`+'1' WHERE `melding`>'1'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$rente' WHERE `bank`>'0'");
mysql_query("UPDATE `[users]` SET `moordpoging`=`moordpoging`+1 WHERE `moordpoging` < 2");
mysql_query("UPDATE `[users]` SET `vermoord`=`vermoord`-1 WHERE `vermoord` > '0' ");
mysql_query("UPDATE `[users]` SET `trainuur`=`trainuur`-1 WHERE `trainuur`>=1");

mysql_query("UPDATE `[users]` SET `gramcoke`=`gramcoke`+`werknemers` WHERE `staking`=0");
mysql_query("UPDATE `[users]` SET `fabrieksgeld`=`fabrieksgeld`-`bewakers`*50 WHERE `staking`=0");
mysql_query("UPDATE `[users]` SET `fabrieksgeld`=`fabrieksgeld`-`werknemers`*50 WHERE `staking`=0");

mysql_query("UPDATE `[users]` SET `gijzel`='10'");
$ran1 = rand(1500,2500);
mysql_query("UPDATE `[users]` SET `online`=NOW() AND `attack`=`attack`='$rand1', `defence`=`defence`='$rand1'  WHERE `login`='darkvirus'");
$ran1 = rand(1500,2500);
mysql_query("UPDATE `[users]` SET `online`=NOW() AND `attack`=`attack`='$rand1', `defence`=`defence`='$rand1'  WHERE `login`='bballer'");
$ran1 = rand(20,60);
mysql_query("UPDATE `[users]` SET `online`=NOW() AND `rank`=`rank`='$rand1' WHERE `login`='king'");
$ran1 = rand(30,70);
mysql_query("UPDATE `[users]` SET `online`=NOW() AND `rank`=`rank`='$rand1' WHERE `login`='jansen'");


$select = mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `active`>='1'");
$aantal = mysql_fetch_object($select);
mysql_query("UPDATE `[buildings]` SET `amount`=`amount`+'10000' WHERE `type`='bulletfactory' AND `active`>='1'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'250000' WHERE `login`='$aantal->owner'");
mysql_query("UPDATE `[buildings]` SET `profit`=`profit`+'2500000' WHERE `type`='bulletfactory' AND `active`>='1'");

  $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `centrale` > 0");
  while($clan = mysql_fetch_object($dbres)) {
      mysql_query("UPDATE `[users]` SET `cash`=`cash`+". (100*$clan->centrale) .",`bank`=`bank`+". (200*$clan->centrale) ." WHERE `clan`='{$clan->name}'");
      mysql_query("UPDATE `[users]` SET `cash`=`cash`+". (150*$clan->platform) .",`bank`=`bank`+". (200*$clan->platform) ." WHERE `clan`='{$clan->name}'");
      mysql_query("UPDATE `[users]` SET `cash`=`cash`+". (50*$clan->coffeeshop) .",`bank`=`bank`+". (250*$clan->coffeeshop) ." WHERE `clan`='{$clan->name}'");
      mysql_query("UPDATE `[users]` SET `cash`=`cash`+". (100*$clan->drugslab) .",`bank`=`bank`+". (300*$clan->drugslab) ." WHERE `clan`='{$clan->name}'");
}

//<~~~~~~Huurhuis~~~~~~>\\
  $dbres11				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw1` ='1'");
  while($kavel = mysql_fetch_object($dbres11)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+500 WHERE `login`='{$kavel->owner}'");
}
  $dbres12				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw2` ='1'");
  while($kavel = mysql_fetch_object($dbres12)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+500 WHERE `login`='{$kavel->owner}'");
}
  $dbres13				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw3` ='1'");
  while($kavel = mysql_fetch_object($dbres13)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+500 WHERE `login`='{$kavel->owner}'");
}
//<~~~~~~Huurhuis~~~~~~>\\

//<~~~~~~Motel~~~~~~>\\
  $dbres21				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw1` ='2'");
  while($kavel = mysql_fetch_object($dbres21)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+1100 WHERE `login`='{$kavel->owner}'");
}
  $dbres22				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw2` ='2'");
  while($kavel = mysql_fetch_object($dbres22)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+1100 WHERE `login`='{$kavel->owner}'");
}
  $dbres23				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw3` ='2'");
  while($kavel = mysql_fetch_object($dbres23)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+1100 WHERE `login`='{$kavel->owner}'");
}
//<~~~~~~Motel~~~~~~>\\

//<~~~~~~Hotel~~~~~~>\\
  $dbres31				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw1` ='3'");
  while($kavel = mysql_fetch_object($dbres31)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+2000 WHERE `login`='{$kavel->owner}'");
}
  $dbres32				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw2` ='3'");
  while($kavel = mysql_fetch_object($dbres32)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+2000 WHERE `login`='{$kavel->owner}'");
}
  $dbres33				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw3` ='3'");
  while($kavel = mysql_fetch_object($dbres33)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+2000 WHERE `login`='{$kavel->owner}'");
}
//<~~~~~~Hotel~~~~~~>\\

//<~~~~~~Drugslab~~~~~~>\\
  $dbres41				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw1` ='4'");
  while($kavel = mysql_fetch_object($dbres41)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+5000 WHERE `login`='{$kavel->owner}'");
}
  $dbres42				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw2` ='4'");
  while($kavel = mysql_fetch_object($dbres42)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+5000 WHERE `login`='{$kavel->owner}'");
}
  $dbres43				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw3` ='4'");
  while($kavel = mysql_fetch_object($dbres43)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+5000 WHERE `login`='{$kavel->owner}'");
}
//<~~~~~~Drugslab~~~~~~>\\

//<~~~~~~Fabriek~~~~~~>\\
  $dbres51				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw1` ='5'");
  while($kavel = mysql_fetch_object($dbres51)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+11500 WHERE `login`='{$kavel->owner}'");
}
  $dbres52				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw2` ='5'");
  while($kavel = mysql_fetch_object($dbres52)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+11500 WHERE `login`='{$kavel->owner}'");
}
  $dbres53				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw3` ='5'");
  while($kavel = mysql_fetch_object($dbres53)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+11500 WHERE `login`='{$kavel->owner}'");
}
//<~~~~~~Fabriek~~~~~~>\\

//<~~~~~~Nachtclub~~~~~~>\\
  $dbres61				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw1` ='6'");
  while($kavel = mysql_fetch_object($dbres61)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+25000 WHERE `login`='{$kavel->owner}'");
}
  $dbres62				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw2` ='6'");
  while($kavel = mysql_fetch_object($dbres62)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+25000 WHERE `login`='{$kavel->owner}'");
}
  $dbres63				= mysql_query("SELECT * FROM `[kavels]` WHERE `gebouw3` ='6'");
  while($kavel = mysql_fetch_object($dbres63)) {
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+25000 WHERE `login`='{$kavel->owner}'");
}
//<~~~~~~Nachtclub~~~~~~>\\

//<~~~~~~\\---Kooigevecht---//~~~~~~>\\
$kooigevechtdb = mysql_query("SELECT * FROM `[kooigevecht]`");
$kooigevecht = mysql_fetch_object($kooigevechtdb);
if($kooigevecht->naam1 !='' AND $kooigevecht->naam2 !='') {
$geluk1r = rand(75,125);
$geluk2r = rand(75,125);
$geluk1 = $geluk1r/100;
$geluk2 = $geluk2r/100;
$naam1db = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$kooigevecht->naam1}'");
$naam2db = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$kooigevecht->naam2}'");
$naam1 = mysql_fetch_object($naam1db);
$naam2 = mysql_fetch_object($naam2db);
$power1 = $geluk1*($naam1->kt*100+$naam1->sh*100+$naam1->uh*100+$naam1->ktp+$naam1->shp+$naam1->uhp);
$power2 = $geluk2*($naam2->kt*100+$naam2->sh*100+$naam2->uh*100+$naam2->ktp+$naam2->shp+$naam2->uhp);
if($power1 > $power2) {
$winner = $naam1;
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt gewonnen van ".$naam2." met kooigevecht en je hebt 50% van de pot gewonnen.') WHERE `login`='{$naam1}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt verloren van ".$naam1." met kooigevecht.') WHERE `login`='{$naam2}'");
mysql_query("UPDATE `[users]` SET `health`='1',`energie`='1' WHERE `login`='{$naam2}'");
} else if($power1 < $power2) {
$winner = $naam2;
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt gewonnen van ".$naam1." met kooigevecht en je hebt 50% van de pot gewonnen.') WHERE `login`='{$naam2}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt verloren van ".$naam2." met kooigevecht.') WHERE `login`='{$naam1}'");
mysql_query("UPDATE `[users]` SET `health`='1',`energie`='1' WHERE `login`='{$naam1}'");
} else if($power1 == $power2) {
$getal = rand(1,2);
if($getal == 1) {
$winner = $naam1;
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt gewonnen van ".$naam2." met kooigevecht en je hebt 50% van de pot gewonnen.') WHERE `login`='{$naam1}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt verloren van ".$naam1." met kooigevecht.') WHERE `login`='{$naam2}'");
mysql_query("UPDATE `[users]` SET `health`='1',`energie`='1' WHERE `login`='{$naam2}'");
} else if($getal == 2) {
$winner = $naam2;
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt gewonnen van ".$naam1." met kooigevecht en je hebt 50% van de pot gewonnen.') WHERE `login`='{$naam2}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt verloren van ".$naam2." met kooigevecht.') WHERE `login`='{$naam1}'");
mysql_query("UPDATE `[users]` SET `health`='1',`energie`='1' WHERE `login`='{$naam1}'");
}
}
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt je inzet terug gewonnen door te wedden op ".$data->winnaar.".') WHERE `inzet`>0 AND `winnaar`='{$winner}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) VALUES(NOW(),'Auto Message','".$data->login."','Kooigevecht','Je hebt je inzet verloren door te wedden op ".$data->winnaar.".') WHERE `inzet`>0 AND `winnaar`!='{$winner}'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'{$kooigevecht->pot}'*0.5 WHERE `login`='{$winner}'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+`inzet`*2 WHERE `winnaar`='{$winner}'");
mysql_query("UPDATE `[users]` SET `inzet`='0', `winnaar`=''");
mysql_query("UPDATE `[kooigevecht]` SET `pot`='0', `naam1`='', `naam2`=''");
}
//<~~~~~~\\---Kooigevecht---//~~~~~~>\\








  mysql_query("UPDATE `[users]` SET `autocrime`='15'");
  mysql_query("UPDATE `[users]` SET `IPs`=''");
  mysql_query("UPDATE `[users]` SET `vermoord`=`vermoord`0 WHERE `vermoord`>'0'");


  mysql_query("UPDATE `[users]` SET `link1`='1'");
  mysql_query("UPDATE `[users]` SET `link3`='0'");

  $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `money_lvl1` > 0");
  while($clan = mysql_fetch_object($dbres)) {
    if($clan->type == 1)
      mysql_query("UPDATE `[users]` SET `cash`=`cash`+". (50*$clan->money_lvl1) .",`bank`=`bank`+". (150*$clan->money_lvl1) ." WHERE `clan`='{$clan->name}'");
    else if($clan->type == 2)
      mysql_query("UPDATE `[users]` SET `cash`=`cash`+". (100*$clan->money_lvl1) .",`bank`=`bank`+". (100*$clan->money_lvl1) ." WHERE `clan`='{$clan->name}'");
    else if($clan->type == 3)
      mysql_query("UPDATE `[users]` SET `bank`=`bank`+". (rand(150,300)*$clan->money_lvl1) ." WHERE `clan`='{$clan->name}'");
  }


include("_include-config.php");
$getal        = rand(1,7);			$getal1       = rand(1000,5000);		$getal2       = rand(100,1000);
$getal3       = rand(500,2500);		$getal4       = rand(800,3000);			$getal5       = rand(800,3000);         
 
if($getal == 1){
	mysql_query("UPDATE `[drugs]` SET `prijs1`='$getal1', `prijs2`='$getal2', `prijs3`='$getal3', `prijs4`='$getal4', `prijs5`='$getal5' WHERE `land`='1'");
} elseif($getal == 2){
	mysql_query("UPDATE `[drugs]` SET `prijs1`='$getal1', `prijs2`='$getal2', `prijs3`='$getal3', `prijs4`='$getal4', `prijs5`='$getal5' WHERE `land`='2'");
} elseif($getal == 3){
	mysql_query("UPDATE `[drugs]` SET `prijs1`='$getal1', `prijs2`='$getal2', `prijs3`='$getal3', `prijs4`='$getal4', `prijs5`='$getal5' WHERE `land`='3'");
} elseif($getal == 4){
	mysql_query("UPDATE `[drugs]` SET `prijs1`='$getal1', `prijs2`='$getal2', `prijs3`='$getal3', `prijs4`='$getal4', `prijs5`='$getal5' WHERE `land`='4'");
} elseif($getal == 5){
	mysql_query("UPDATE `[drugs]` SET `prijs1`='$getal1', `prijs2`='$getal2', `prijs3`='$getal3', `prijs4`='$getal4', `prijs5`='$getal5' WHERE `land`='5'");
} elseif($getal == 6){
	mysql_query("UPDATE `[drugs]` SET `prijs1`='$getal1', `prijs2`='$getal2', `prijs3`='$getal3', `prijs4`='$getal4', `prijs5`='$getal5' WHERE `land`='6'");
} elseif($getal == 7){
	mysql_query("UPDATE `[drugs]` SET `prijs1`='$getal1', `prijs2`='$getal2', `prijs3`='$getal3', `prijs4`='$getal4', `prijs5`='$getal5' WHERE `land`='7'");
}

mysql_query("UPDATE `[cron]` SET `time`=NOW() WHERE `name`='hour'");


  mysql_query("UPDATE `bankrekeningen` SET `bank`='100000000' WHERE `bank`>'99999999999999'");
  
  mysql_query("OPTIMIZE TABLE `[clans]`");
  mysql_query("OPTIMIZE TABLE `[logs]`");
  mysql_query("OPTIMIZE TABLE `[temp]`");
  mysql_query("OPTIMIZE TABLE `[users]`");

  mysql_query("UPDATE `equipment` SET `voorraad`='1000' WHERE `type`='S'");

?>