<?php
error_reporting(0);

  if($cron_pass != "secretcronpassword")

mysql_query("DELETE FROM `[messages]` WHERE `saved`='0'");

  mysql_query("UPDATE `[users]` SET `IPs`=''");
  mysql_query("UPDATE `[clans]` SET `IPs`=''");
  mysql_query("DELETE FROM `[logs]` WHERE `area`='click'");
  mysql_query("OPTIMIZE TABLE `[logs]`");

?>