<?php
error_reporting(0);
include("settings.php");

function quote_smart($value) {
if (get_magic_quotes_gpc()) {
$value = stripslashes($value);
}
if(version_compare(phpversion(),"4.3.0") == "-1") {
return mysql_escape_string($value);
} else {
return mysql_real_escape_string($value);
}
}

  if(!(@mysql_connect("$host","$user","$pass") && @mysql_select_db("$tablename"))) {
    print <<<ENDHTML
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<script language="javascript">
function showTxt(id) {
    document.getElementById(id).style.position		= "relative";
    document.getElementById(id).style.visibility	= "visible";
}
</script>
</head>


  <table width=50%>
    <tr><td class="subTitle"><b>Game is offline</b></td></tr>
    <tr><td class="mainTxt">
<center>There is a database connection issue, this will be corrected as soon as possible. Thank you for your understanding and patience!

</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
    exit;
  }


  error_reporting ( 0 );
  session_start();
  include("_include-funcs2.php");
  if(isset($_SESSION['login'])) {
    $dbres				= mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup`,UNIX_TIMESTAMP(`online`) AS `online` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);
    if($data->ip  == '')
    {
$IP = $_SERVER['REMOTE_ADDR'];    
mysql_query("UPDATE `[users]` SET `IP`='$IP' WHERE `login`='$data->login'");

}
  }

  
  
  foreach($_POST as $key => $value) {
    if(gettype($_POST[$key]) == "array")
      foreach($_POST[$key] as $key2 => $value2)
        $_POST[$key][$key2]		= addslashes($_POST[$key][$key2]);
    else
      $_POST[$key]			= addslashes($_POST[$key]);
  }
  foreach($_GET as $key => $value) {
    if(gettype($_GET[$key]) == "array")
      foreach($_GET[$key] as $key2 => $value2)
        $_GET[$key][$key2]		= addslashes($_GET[$key][$key2]);
    else
      $_GET[$key]			= addslashes($_GET[$key]);
  }
  foreach($_COOKIE as $key => $value) {
    if(gettype($_COOKIE[$key]) == "array")
      foreach($_COOKIE[$key] as $key2 => $value2)
        $_COOKIE[$key][$key2]		= addslashes($_COOKIE[$key][$key2]);
    else
      $_COOKIE[$key]			= addslashes($_COOKIE[$key]);
  }


  $clientIP				= $_SERVER['REMOTE_ADDR'];
  $forwardedFor				= ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['HTTP_CLIENT_IP'];
  $forwardedFor				= preg_replace('/, .+/','',$forwardedFor);
  $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `level`='-1' AND `login`='{$data->login}'");

  if(mysql_num_rows($dbres) == 1) {
    print "
<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel=\"stylesheet\" type=\"text/css\" href=\"<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css\">
</head>
<body>
<center><table align=\"center\" width=\"50%\">
  <tr><td class=\"subTitle\"><b>Unbanned</b></td></tr>
<tr><td class=\"mainTxt\">You are unbanned. If you want to re-enter The Gangster Game, Click on this Link:<br>
<center><a href=\"klikmissiebanned.php\" target=\"_new\"><img style=\"border; 1px solid #000000;\" src=\"images/stem.gif\" width=\"100\" height=\"20\"></a></center></td></tr>
  </table>
</body>
</html>
";
mysql_query("UPDATE `[users]` SET `IP`='$clientIP' WHERE `login`='$data->login'");
    exit;
  }


  if(isset($UPDATE_DB)) {
    $dbres                              = mysql_query("SELECT UNIX_TIMESTAMP(`time`) AS `time`,`name` FROM `[cron]`");
    while($x = mysql_fetch_object($dbres))
      $update[$x->name]         = $x->time;

    if(floor($update['hour']/3600) != floor(time()/3600)) {
      $dbres                            = mysql_query("SELECT GET_LOCK('hour_update',0)");
      if(mysql_result($dbres,0) == 1) {
        $cron_pass                      = "secretcronpassword";
        mysql_query("UPDATE `[cron]` SET `time`=NOW() WHERE `name`='hour'");
        include("_cron_hour.php");
        mysql_query("SELECT RELEASE_LOCK('hour_update')");
      }
    }

    if(floor($update['day']/86400) != floor(time()/86400)) {
      $dbres                            = mysql_query("SELECT GET_LOCK('day_update',0)");
      if(mysql_result($dbres,0) == 1) {
        $cron_pass                      = "secretcronpassword";
        mysql_query("UPDATE `[cron]` SET `time`=NOW() WHERE `name`='day'");
        include("_cron_day.php");
        mysql_query("SELECT RELEASE_LOCK('day_update')");
      }
    }

    if(floor($update['week']/604800) != floor(time()/604800)) {
      $dbres                            = mysql_query("SELECT GET_LOCK('week_update',0)");
      if(mysql_result($dbres,0) == 1) {
        $cron_pass                      = "secretcronpassword";
        mysql_query("UPDATE `[cron]` SET `time`=NOW() WHERE `name`='week'");
        include("_cron_week.php");
        mysql_query("SELECT RELEASE_LOCK('week_update')");
      }
    }

    if(date('n',$update['month']) != date('n',time())) {
      $dbres                            = mysql_query("SELECT GET_LOCK('month_update',0)");
      if(mysql_result($dbres,0) == 1) {
        $cron_pass                      = "secretcronpassword";
        mysql_query("UPDATE `[cron]` SET `time`=NOW() WHERE `name`='month'");
        include("_cron_month.php");
        mysql_query("SELECT RELEASE_LOCK('month_update')");
      }
    }

    if((date('G',time()) >= 16 && date('z',time()) != date('z',$update['horserace'])) || (date('G',time()) >= 21 && date('G',$update['horserace']) < 21)) {
      $dbres                            = mysql_query("SELECT GET_LOCK('horserace_update',0)");
      if(mysql_result($dbres,0) == 1) {
        $cron_pass                      = "secretcronpassword";
        mysql_query("UPDATE `[cron]` SET `time`=NOW() WHERE `name`='horserace'");
        include("_cron_horserace.php");
        mysql_query("SELECT RELEASE_LOCK('horserace_update')");
      }
    }
  }

    mysql_query("UPDATE `[users]` SET `online2`='ja' WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300");
    mysql_query("UPDATE `[users]` SET `online2`='nee' WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) >= 300");

    $dbres				= mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup`,UNIX_TIMESTAMP(`online`) AS `online` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);

if($data->rankvord >= 100 && $data->rank <17) {
$rank	                  	= array("Cafone","LowLife","Pickpocket","Shoplifter","Mugger","Thief","WiseGuy","Associate","Mobster","Gangster","Assassin","Good Fella","Mob Boss","The Don","The Lengendary Don","The Godfather","The Legendary Godfather");
$rank = $rank[$data->rank];

mysql_query("UPDATE `[users]` SET `rank`=`rank`+'1',`rankvord`=`rankvord`-'100' WHERE `login`='".$data->login."'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'**Note**','".$data->login."','Rank Increased','You have been promted to ".$rank.".')"); 

}
if($data->rijbewijsmissie == 10 AND $data->rijbewijsauto > 4){

mysql_query("UPDATE `tunegarage`  SET `banden`=`banden`+'$rand1',`motor`=`motor`+'$rand8',`interieur`=`interieur`+'$rand2',`uitlaat`=`uitlaat`+'$rand3',`remmen`=`remmen`+'$rand4',`body`=`body`+'$rand5',`velgen`=`velgen`+'$rand6',`nitro`=`nitro`+'$rand7' WHERE `eigenaar`='{$data->login}' AND `rijbewijs`='1'");
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`='11' WHERE `login`='{$data->login}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'TGGame Staff','{$data->login}','Driving License','<center><b>Congratulations</b><br>You have received your drivers license!<br>You pimped car has<br> <b>{$rand1}</b> Link levels<br> <b>{$rand8}</b> Engine levels<br> <b>{$rand2}</b> Interieur levels<br> <b>{$rand3}</b> Exhaust levels<br> <b>{$rand4}</b> Brake levels<br> <b>{$rand5}</b> Body levels<br> <b>{$rand6}</b> Rim levels<br> <b>{$rand7}</b> Nitro levels!<br><br><b>We congratulate you on behalf of the staff</b></center> ')"); 
}

$gelderaf = $data->werknemers*50+$data->bewakers*50;
if($data->fabrieksgeld < $gelderaf AND $data->staking == 0 AND $data->nietstaken == 0){

mysql_query("UPDATE `[users]` SET `staking`='3' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `fabrieksgeld`='0' WHERE `login`='{$data->login}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Your employees','{$data->login}','Strike','We are striking for 3 days, you have to pay up because nobody else will make you any cash. ')"); 
}

      if($data->dagenwerken == 1){
mysql_query("UPDATE `[users]` SET `werklevel`=`werklevel`+1 WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `baan`='0' WHERE `login`='{$data->login}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Your Boss','{$data->login}','You have been promoted','Congratulations, you have stuck at it for these 5 days and so you worklevel has increased by 1.')");
mysql_query("UPDATE `[users]` SET `dagenwerken`='0' WHERE `login`='{$data->login}'");
    }

  $dbres				= mysql_query("SELECT `id` FROM `rechtbankusers` WHERE `leven`<'1' AND `login`='{$data->login}'");
  if(mysql_num_rows($dbres) == 1) {
echo 'You have been murdered, you can no longer play for 2 hours.';
exit;
}

$ipban1 = mysql_query("SELECT * FROM `[ipbanz]` WHERE IP='{$_SERVER['REMOTE_ADDR']}'");
$ipban = mysql_num_rows($ipban1);
if($ipban != 0){
$ipa = mysql_fetch_object($ipban1);
print 'You have been banned via your IP.<br>
Reason:'.$ipa->reden.'';
exit;
}



// 
$locatie = $_SERVER['REQUEST_URI'];
$array = Array();
$array[] = "mysql";
$array[] = ")";
$array[] = ";";
$array[] = "}";
$array[] = "INSERT";
$array[] = "DROPTABLE";
$array[] = "TRUNCATE";
$array[] = "DROP";
$array[] = "UPDATE";
$array[] = "COOKIE";
$array[] = "ENV";
$array[] = "FILES";
$array[] = "GET";
$array[] = "POST";
$array[] = "REQUEST";
$array[] = "SERVER";
foreach($array As $foutbezig) {
if(eregi($foutbezig,$locatie)) {
exit("Dont use sql injections.");
}
}

$type = array("","DrugDealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","Original Gangster","Rude Boy","PeaceKeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger","Mugger","Capone","Thief","PIMP","Pretty Women","WiseGuy","Mobster","Fella","Gangster Girl","The Daddy" );
$ctype = $type[$data->ctype];

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);

mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='1'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='2'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='3'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='4'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='5'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE`ctype`='6'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='7'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='8'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='9'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE`ctype`='10'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='11'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='12'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='13'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='14'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='15'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='16'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='17'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='18'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='19'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='20'");

mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='21'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='22'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='23'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='24'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='25'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='26'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='27'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='28'");
mysql_query("UPDATE `[users]` SET `camera`=`camera`+'25' WHERE `ctype`='29'");
mysql_query("UPDATE `[users]` SET `shotgun`=`shotgun`+'30' WHERE `ctype`='30'");


/* ------------------------- */ ?>
