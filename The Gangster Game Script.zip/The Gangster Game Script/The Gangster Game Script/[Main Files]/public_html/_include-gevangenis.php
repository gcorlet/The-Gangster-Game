<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body style="margin: 0px;">
<?php
error_reporting(0);

include("_include-log.php");
   $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'"); 
  $gn             = mysql_fetch_object($gn1);  
if($gn->gevangenis + $gn->gevangenistijd > time() && $data->login != 1){ 

   list($uur,$min,$sec)=explode(":",date("H:i:s",$gn->gevangenis+$gn->gevangenistijd-time()-3600));

if(isset($_POST['betaal'])) {
$borg = $data->gevangenistijd * 105;
if($data->cash < $borg){
 print "  <tr><td class=\"subTitle\"><b>Prison</b></td></tr> <td class=\"mainTxt\" align=\"center\" >You dont have enough cash on you.";   
exit;
}
 mysql_query("UPDATE `[users]` SET `gevangenistijd`='0',`cash`=`cash`-$borg WHERE `login`='$data->login'"); 
 print "   <tr><td class=\"subTitle\"><b>Prison</b></td></tr><td class=\"mainTxt\" align=\"center\" >You have paid the $borg .";   
exit;
}
if(isset($_POST['delete'])) {
$getal = 	rand(1,7);
if($getal != 1){

    mysql_query("UPDATE `[users]` SET `gevangenistijd`=`gevangenistijd`+600 WHERE `login`='$data->login'"); 
 print "   <tr><td class=\"subTitle\"><b>Prison</b></td></tr><td class=\"mainTxt\" align=\"center\" >Bad Luck! Now the Prison sentence has gone up to 10 minutes.";   
exit;
}
  if($getal = 4){

    mysql_query("UPDATE `[users]` SET `gevangenistijd`='0' WHERE `login`='$data->login'"); 
    mysql_query("UPDATE `[users]` SET `j1`=`j1`+'1'WHERE `login`='$data->login'");   
       mysql_query("UPDATE `[users]` SET `j13`=`j13`+'1'WHERE `login`='$data->login'"); 
    mysql_query("UPDATE `[users]` SET `klaar`='1'WHERE `login`='$data->login'"); 
print "   <tr><td class=\"subTitle\"><b>Prison</b></td></tr><td class=\"mainTxt\" align=\"center\" >You have been released from prison!"; 
   exit;
} 

}
$borg = $data->gevangenistijd * 105;
#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);










$deal = $data->dealvordering;
if ($deal <= 10) {
    $mrank = "Amateur";
} elseif ($deal > 10 AND $deal <= 20) {
    $mrank = "Pro dealer";
} elseif ($deal > 20 AND $deal <= 30) {
    $mrank = "Dealing king";
} elseif ($deal > 30 AND $deal <= 40) {
    $mrank = "Pro Dealer";
} elseif ($deal > 40 AND $deal <= 50) {
    $mrank = "Dealer King";
} elseif ($deal > 50 AND $deal <= 60) {
    $mrank = "Born Dealer";
} elseif ($deal > 60 AND $deal <= 70) {
    $mrank = "Prison King";
} elseif ($deal > 70 AND $deal <= 80) {
    $mrank = "Prison Lord";
} elseif ($deal > 80 AND $deal <= 90) {
    $mrank = "Prison God";
} elseif ($deal > 90) {
    $mrank = "Master of the Prison";
}












	
?>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<script type="text/javascript">
 <?echo 'var u='.$uur.';var m='.$min.';var s='.$sec.'+1;';?>
 function settimer(i){return (i>9)?i:"0"+i;}
 function timer(){s--;
 if((s==0)&&(m==0)&&(u==0)){document.getElementById('timeout').submit();}
 if((s==0)&&(m==0)&&(u!=0)){u--;m=59;}
 if((s==-1)&&(m!=0)){m--;s=59;}
 if(s>=0){document.getElementById('timer').value=settimer(u)+':'+settimer(m)+':'+settimer(s);}}
 setInterval("timer()",1000);
</script>
 <form  method="POST">
<table width=100%>
 <tr><td class="subTitle"><b>Prison</b></td></tr>
  <td class="mainTxt" align="center" >
  Your sat in the prison<br><br>You will be released when this timer hits 15.00.00 <input style="border: 0px solid;" type="text" size=6 maxlength=8 id="timer" value="<?=date("H:i:s",$gn->gevangenis+$gn->gevangenistijd-time()-3600)?>">.<br>
Pay your own Break Out Cost, its <?print"$borg";?>.<br>
	<input type="submit" name="betaal" value="PAY" style="width: 250px;"><br>
	


	</td>
 </tr>
</form>

</table>
</body>
</html>
<script language="javascript">
    
    function getKeyCode(eventObject)
    {
      if (!eventObject) keyCode = window.event.keyCode; //IE
      else keyCode = eventObject.which;   //Mozilla
      return keyCode;
    }
      
    function onlyNumeric(eventObject)
    {
      keyCode = getKeyCode(eventObject);
      if (((keyCode > 31) && (keyCode < 48)) || ((keyCode > 57) && (keyCode < 127)))
      {
          if (!eventObject) window.event.keyCode = 0; //IE
          else eventObject.preventDefault(); //Mozilla
          return false;
      }
    }
  </script>
<?


if(isset($_POST['profile'])) {
 print" <table width=100%><tr><td class=\"subTitle\"><b>Edit Break Out</b></td></tr>";
 $bel				= preg_replace('/\</','&#60;',substr($_POST['bel'],0,500));
if($bel <= 0){
print "<tr><td class=\"mainTxt\">Invalid Number.</td></tr>";
exit;
}
if ($data->bank < $bel){
print "<tr><td class=\"mainTxt\">You dont have that sort of cash in your bank account.</td></tr>";
exit;
}
mysql_query("UPDATE `[users]` SET `uitbreek`='$bel' WHERE `login`='$data->login'");

print "<tr><td class=\"mainTxt\">Your Break Out Fee has been changed.</td></tr>";
exit;
}



 print <<<ENDHTML
 <table width=100%>
	<form method="post">
<tr><td class="subTitle"><b>Edit Break Out</b></td></tr>
   <tr><td class="mainTxt">Payment for Break Outs:<br>
  <input type="text" name="bel" value="$data->uitbreek" onkeypress="onlyNumeric(arguments[0])" size="10">
<input type="submit" name="profile" value="Change"></td></tr></form>
    	</table> 

ENDHTML;
  $man1              = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `gevangenistijd` > '0'"); 
    print "   <table width=\"100%\"><tr><td class=\"subTitle\"><b>Sentenced to Prison:</b></td></tr>  ";

    print "    <table width=\"100%\"><tr> 
<td class=\"subTitle\" align=\"center\" width=25%>Name</td>  <td class=\"subTitle\" align=\"center\" width=25%>Gang</td>  <td class=\"subTitle\" align=\"center\" width=25%>Length of Time</td> <td class=\"subTitle\" align=\"center\" width=25%><b>Break Out:</td> "; 
     
     
    while($man = mysql_fetch_object($man1)) { 
     
    $tijd      = $man->gevangenistijd+$man->gevangenis; 
    $tijdg1    = $man->gevangenistijd+$man->gevangenis-time()-3600; 
    $tijdg     = date("i:s", "$tijdg1"); 
 $borg	=	$man->gevangenistijd*100;
   list($uur,$min,$sec)=explode(":",date("H:i:s",$tijdg1));    
    if($tijd < time()){ 
    } 
    else{ 
     
    if($man->clan ==""){ 
    $man->clan   = "(None)"; 
    } 

    print " <tr> 
<td class=\"mainTxt\" width=25%><a href=\"profile.php?x={$man->login}\">{$man->login}</a></td> 
<td class=\"mainTxt\" width=25%><a href=\"clan.php?x={$man->clan}\">{$man->clan}</a></td> 
   <td class=\"mainTxt\" width=25%><input type=\"text\" size=8 maxlength=8
"; 
?>

 id="timer" value="<?=date("H:i:s",$tijdg1)?>"></td>
<?
   print"<td class=\"mainTxt\" width=25%>$man->uitbreek</td></tr>";
 } 
     
    } 
print "
<tr><td></td><td class=\"subTitle\" colspan=\"2\">Dealing</td></tr>
<tr><td></td><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You can still deal <b>$data->gijzel</b>x this current hour.<br><a href=\"dealings.php\">Go Deal!</a><br><br>
Your dealing progress is {$data->dealvordering}%<br>  Your dealing Rank is $mrank!
</td></tr>
";
exit;
}
else{
print"";
}
?>