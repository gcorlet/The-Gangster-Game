<?php
error_reporting(0);

  $OMNILOG                                = 1;
  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }
  $UPDATE_DB				= 1;
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");



  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenistijd`) AS `gevangenistijd`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $gn             = mysql_fetch_object($gn1);  if($gn->gevangenis + $gn->gevangenistijd > time()){
  $verschil1             = ($gn->gevangenis+$gn->gevangenistijd) - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");

    print <<<ENDHTML
<br><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<html>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">




<base target="mainFrame" />

</head>

<table width=100%><tr><td class='mainTxt'><left>You have <b>".$verschil."</b> seconds to wait until you get released.<br><br><br>You can deal for <b>$data->gijzel</b> longer <br><br>(<a href=dealings.php target = frame><b>Click Here to go dealing!</b></a>)<td class='mainTxt' align=center height=150 colspan=3><img src=/images/Jail.jpg></td></tr></table>

</html>
ENDHTML;
exit;
  }
?>
<?

if($data->energie <= 0) {
?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css" rel="stylesheet" type="text/css">

<base target="I1" />

</head>

<table align=center width=60%>
  <tr><td class=subTitle><b>Energy</b></td></tr>
  <tr><td class=mainTxt>
		<b>You have no <b>energy</b>, try swing by<br> Mac Donalds and buying some energy food.<br> Click 
<a target=mainFrame href="mac.php">HERE</a> to go directly to Mac Donalds!
		</td></tr>
	  </table>
	</body>
	
	</html>
	<?
    exit;
}
?>