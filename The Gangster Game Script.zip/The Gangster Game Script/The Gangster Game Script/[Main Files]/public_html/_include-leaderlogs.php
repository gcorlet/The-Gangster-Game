<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">





<table width="100%"  border="0" cellspacing="2" cellpadding="2">



 <table align="center" width=100%>
  <tr><td class="subTitle"><b>Leaderlogs</b></td>
  <tr><td class="mainTxt">
<center>
 <input type="button" style="width: 230;" value=" Central's "onClick="window.self.location=('leaderopties.php?x=centrale');"></form>
<input type="button" style="width: 230;" value=" Walls "onClick="window.self.location=('leaderopties.php?x=muren');"></form><br><br>
<input type="button" style="width: 230;" value=" Houses "onClick="window.self.location=('leaderopties.php?x=huizen');"></form>
<input type="button" style="width: 230;" value=" Land "onClick="window.self.location=('leaderopties.php?x=land');"></form><br><br>
<input type="button" style="width: 230;" value=" Outing Press "onClick="window.self.location=('leaderopties.php?x=Uitstappers');"></form>
<input type="button" style="width: 230;" value=" Gang Profile "onClick="window.self.location=('leaderopties.php?x=verwijderd');"></form>
<br><br><input type="button" style="width: 230;" value=" Kick "onClick="window.self.location=('leaderopties.php?x=kick');"></form>
<input type="button" style="width: 230;" value=" Bank in/out "onClick="window.self.location=('leaderopties.php?x=bank');"></form>
<br><br><input type="button" style="width: 230;" value=" Clicks "onClick="window.self.location=('leaderopties.php?x=clickss');"></form>
<input type="button" style="width: 230;" value=" Accepted "onClick="window.self.location=('leaderopties.php?x=aan');"></form><br><br>
 <input type="button" style="width: 230;" value=" Central's bought with VIP Credits "onClick="window.self.location=('leaderopties.php?x=belcen');"></form>
</center><br></td>
</tr>







