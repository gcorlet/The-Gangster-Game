<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">





<table width="100%"  border="0" cellspacing="2" cellpadding="2">



 <table align="center" width=100%>
  <tr><td class="subTitle"><b>Gang Leader Options</b></td>
  <tr><td class="mainTxt">
<center>

<input type="button" style="width: 230;" value=" Spread Cash  "onClick="window.self.location=('cuit.php');"></form><br><br>
<input type="button" style="width: 230;" value=" Gang establishment donate "onClick="window.self.location=('leaderopties.php?x=clandon');"></form><br><br>
<input type="button" style="width: 230;" value=" Gang ban "onClick="window.self.location=('leaderopties.php?x=clanban');"></form><br><br>
<input type="button" style="width: 230;" value=" Gang Profile Editor "onClick="window.self.location=('clanhq.php?p=info');"></form>
</center><br></td>
</tr>







