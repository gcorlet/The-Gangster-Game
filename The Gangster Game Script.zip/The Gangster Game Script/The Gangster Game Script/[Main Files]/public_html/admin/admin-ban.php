<?php /* ------------------------- */ 

  $UPDATE_DB                                = 1; 
  include("../_include-config.php"); 
      include("../_include-gevangenis.php");
  if(! check_login) { 
    header("Location: ../login.php"); 
    exit; 
  } 

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'"); 

    if($data->login == $admin2 || $data->login == $admin1) {

?>

<html>

<html> 
<head> 
<title><?php echo $page->sitetitle; ?></title> 
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<center>
</head> 


<body style="background: #c0c0c0; margin: 0px"> 


<head> 
<title><?php echo $page->sitetitle; ?></title> 
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head> 
<body style="background: #c0c0c0; margin: 0px;"> 
<center>
<?php

print<<<ENDHTML

<table width="90%" align="center" border=1><tr><td class="subTitle">
IP Player Ban</td>
<tr><td class="mainTxt" align=center>


<form method="post">
Name: <input type="text" name="naam"><br>
Reason: <input type="reden" name="reden"><br><br>
<input type="checkbox" name="ip">IP Ban<br>
<input type="submit" name="submit" value="Proceed">
</table><br>


ENDHTML;

if($_POST['submit']){
$naam = $_POST['naam'];
$reden = $_POST['reden'];
$usersql = mysql_query("SELECT * FROM `[users]` WHERE login='$naam'");
$user = mysql_fetch_object($usersql) or die ('This user could not be found due to the following reason: '.mysql_error().'');
$ip = $user->IP;


if($_POST['recht'] == 'on'){
mysql_query("INSERT INTO `rechtbankusers` ( `login` , `reden` , `ip` , `time` ) VALUES('$naam', '$reden', '$ip', NOW())") or die ('There was an error, the user could not be put into Court due to: '.mysql_error().'');
print ''.$naam.' has been put into the District Court<br>';
}

if($_POST['ip'] == 'on'){
mysql_query("INSERT INTO `[ipbanz]` (IP,naam,reden) VALUES ('$ip','$naam','$reden')") or die('This user could not be banned due to the following reason: '.mysql_error().'');
  mysql_query("UPDATE `[users]` SET `level`=-1 WHERE `login`='{$naam}'");
print ''.$naam.' , has been successfully IP banned: '.$ip.'<br>';
$berichten = $_POST['berichten'];
}
if($berichten == 'on'){
print '';
mysql_query("DELETE FROM `[messages]` WHERE `from`='$naam'") or die (mysql_error());
print 'The Message Could not be deleted!<br>';
}
}

$geband1 = mysql_query("SELECT * FROM `[ipbanz]`");
print '<table width="90%" align="center" border=1>';
print '<tr><td class="subTitle" width="25%"> Name<td class="subTitle" width="25%">IP<td class="subTitle" width="40%"> Reason <td class="subTitle" width="10%">Unban';

while($geband = mysql_fetch_object($geband1)){
print '<tr><td class="mainTxt" width="25%">'.$geband->naam.'<td class="mainTxt" width="25%">'.$geband->IP.'<td class="mainTxt" width="50%">'.$geband->reden.' <td class="mainTxt" width="25%"><a href="admin-ban.php?unban='.$geband->naam.'">unban</a>';
}
print '</table>';


if($_GET['unban']){
$naam = $_GET['unban'];
mysql_query("DELETE FROM `[ipbanz]` WHERE naam='$naam'");
print ''.$naam.' has been Unbanned from IP';
}
}
?>
</center>
</body>
</html>
