<?php /* ------------------------- */


  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }


/* ------------------------- */ ?>
<html>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>


<table width=100%>
<?php /* ------------------------- */
if ($_GET['p'] == "setturns"){
    print "  <tr><td class=\"subTitle\"><b>Admin - Setup Turns</b></td></tr>\n";
    if(isset($_POST['to'])) {
if (isset($_POST['amount1'])){
 if($member = mysql_fetch_object(mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_POST['to']}'"))) {
          mysql_query("UPDATE `[users]` SET `turn`=`turn`+1000 WHERE `login`='{$member->login}'");
          mysql_query("UPDATE `[users]` SET `turn`=`turn`+100");
print "  <tr><td class=\"mainTxt\">U hebt 1000 turns toegevoegd bij {$_POST['to']}</td></tr>\n";
}
}
if(isset($_POST['amount2'])){
 if($member = mysql_fetch_object(mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_POST['to']}'"))) {
          mysql_query("UPDATE `[users]` SET `turn`=`turn`+2000 WHERE `login`='{$member->login}'");
          mysql_query("UPDATE `[users]` SET `turn`=`turn`+200");
print "  <tr><td class=\"mainTxt\">U hebt 2000 turns toegevoegd bij {$_POST['to']}</td></tr>\n";
}
}
if(isset($_POST['amount3'])){
 if($member = mysql_fetch_object(mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_POST['to']}'"))) {
          mysql_query("UPDATE `[users]` SET `turn`=`turn`+3000 WHERE `login`='{$member->login}'");
          mysql_query("UPDATE `[users]` SET `turn`=`turn`+300");
print "  <tr><td class=\"mainTxt\">U hebt 3000 turns toegevoegd bij {$_POST['to']}</td></tr>\n";
}
}
}
    print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	<form method="post"><table>
	<tr><td width=250>Aan:</td>  <td><input type="text" name="to" value="{$_REQUEST['to']}"></td></tr>
	<tr><td width=300><input type="submit" name="amount1" value="1000" style="width: 100px;"><input type="submit" name="amount2" value="2000" style="width: 100px;"><input type="submit" name="amount3" value="3000" style="width: 100px;"></tr></td>
	</table></form>
  </td></tr>
ENDHTML;
}
else if($_GET['p'] == "donate") {
    print "  <tr><td class=\"subTitle\"><b>Admin - Donate</b></td></tr>\n";
    if(isset($_POST['to'])) {
      if(preg_match('/^[0-9]+$/',$_POST['amount'])) {
        if($member = mysql_fetch_object(mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_POST['to']}'"))) {
          mysql_query("UPDATE `[users]` SET `bank`=`bank`+{$_POST['amount']} WHERE `login`='{$member->login}'");
          mysql_query("UPDATE `[users]` SET `clicks`=`clicks`+{$_POST['clicks']} WHERE `login`='{$member->login}'");
          mysql_query("UPDATE `[users]` SET `attack`=`attack`+{$_POST['attack']} WHERE `login`='{$member->login}'");
          mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`+{$_POST['belcredits']} WHERE `login`='{$member->login}'");
          mysql_query("UPDATE `[users]` SET `paying`=`paying`+{$_POST['paying']} WHERE `login`='{$member->login}'");
          mysql_query("INSERT INTO `[logs]`(`time`,`IP`,`login`,`person`,`code`,`area`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','** Criminals **','{$member->login}',{$_POST['amount']},'donate')");
          print "  <tr><td class=\"mainTxt\">Er is \${$_POST['amount']},- aan {$member->login} gedoneerd en ook zijn er: {$_POST['clicks']} clicks gegeven + {$_POST['attack']}  attack power en {$_POST['defence']}  defence en {$_POST['paying']} betaald account dagen en {$_POST['belcredits']} belcredits</td></tr>\n";
        }
      }
    }

    print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	<form method="post"><table>
	<tr><td width=100>Aan:</td>  <td><input type="text" name="to" value="{$_REQUEST['to']}"></td></tr>
	<tr><td width=100>Bedrag:</td>  <td><input type="text" name="amount"></td></tr>
	<tr><td width=100>Clicks:</td>  <td><input type="text" name="clicks"></td></tr>

	<tr><td></td>  <td align="right"><input type="submit" value="Doneer" style="width: 75px;"></td></tr>
	</table></form>
  </td></tr>
ENDHTML;
  }
 else if($_GET['p'] == "stats") {
    print "  <tr><td class=\"subTitle\"><b>Admin - Statistics</b></td></tr>\n";
  $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `activated`=1");
  $members				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT * FROM `[data]` WHERE `id`=1");
  $dat					= mysql_fetch_object($dbres);
  $totalmoney			=$data->bought*0.52;
  print "Totaal aantal keer geld opgewaardeerd:<b> {$dat->bought}</b><br>";
  print "Totaal geldbedrag in de pot:<b> ${$totalmoney}</b><br>";
  print "Totaal aantal members:<b> $members </b> <br>";

// Geld top 5
  $begin = ($_GET['p'] >= 0) ? $_GET['p']*30 : 0;
  print "<b>Rijkste vijf spelers:</b>";
$dbres = mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`cash`,`bank`,`type`,`level` FROM `[users]` WHERE `activated`=1 ORDER BY cash+bank DESC,`login` ASC LIMIT $begin,5");

$user = $_SESSION['login'];

for($j=$begin+1; $info = mysql_fetch_object($dbres); $j++) 
{
// ????
$login = ($info->showonline == 0 && $data->level == 0x80 && $_GET['s'] == "online") ? "{$info->login} *" : $info->login;

// onthoud admins dikgedrukt en met *, als betreffende user dat is
$login = ($info->level & 0x80) ? "<b>$login *</b>" : $login;

// maak een array met typen
$type = Array("","Drugsdealer","Wetenschapper","Politie");

// onthoud betreffende type
$type = $type[$info->type];

// rond berekening van power af op gehele waarde en onthoud deze van de betreffende user
$power = round(($info->attack+$info->defence)/2);

// money is bank+cash waarde van betreffende user
$money = $info->cash+$info->bank;

// toon een rij met de kolommen: nummer, loginnaam, type, money en power van de user met nummer $j
print <<<ENDHTML
<tr><td align="center" class="mainTxt" width=20>$j</td>
<td class="mainTxt"><a href="../profile.php?x={$info->login}">$login</a></td>
<td align="center" class="mainTxt" width=100>$$money</td>
</tr>
ENDHTML;
}

// Power top 5
$begin = ($_GET['p'] >= 0) ? $_GET['p']*30 : 0;
  print "<b>Sterkste vijf spelers:</b>";
$dbres = mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`cash`,`bank`,`type`,`level` FROM `[users]` WHERE `activated`=1 ORDER BY cash+bank DESC,`login` ASC LIMIT $begin,5");

$user = $_SESSION['login'];

for($j=$begin+1; $info = mysql_fetch_object($dbres); $j++) 
{
// ????
$login = ($info->showonline == 0 && $data->level == 0x80 && $_GET['s'] == "online") ? "{$info->login} *" : $info->login;

// onthoud admins dikgedrukt en met *, als betreffende user dat is
$login = ($info->level & 0x80) ? "<b>$login *</b>" : $login;

// maak een array met typen
$type = Array("","Gangster","F.B.I","Pooier");

// onthoud betreffende type
$type = $type[$info->type];

// rond berekening van power af op gehele waarde en onthoud deze van de betreffende user
$power = round(($info->attack+$info->defence)/2);

// money is bank+cash waarde van betreffende user
$money = $info->cash+$info->bank;

// toon een rij met de kolommen: nummer, loginnaam, type, money en power van de user met nummer $j
print <<<ENDHTML
<tr><td align="center" class="mainTxt" width=20>$j</td>
<td class="mainTxt"><a href="../profile.php?x={$info->login}">$login</a></td>
<td align="center" class="mainTxt" width=100>$power</td>
</tr>
ENDHTML;
}

// Cocaine top 5
$begin = ($_GET['p'] >= 0) ? $_GET['p']*30 : 0;
  print "<b>Meeste Cocaine top 5:</b>";
$dbres = mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`cocaine`,`attack`,`defence`,`clicks`,`cash`,`bank`,`type`,`level` FROM `[users]` WHERE `activated`=1 ORDER BY cocaine DESC,`login` ASC LIMIT $begin,5");

$user = $_SESSION['login'];

for($j=$begin+1; $info = mysql_fetch_object($dbres); $j++) 
{
// ????
$login = ($info->showonline == 0 && $data->level == 0x80 && $_GET['s'] == "online") ? "{$info->login} *" : $info->login;

// onthoud admins dikgedrukt en met *, als betreffende user dat is
$login = ($info->level & 0x80) ? "<b>$login *</b>" : $login;

// maak een array met typen
$type = Array("","Gangster","F.B.I","Pooier");

// onthoud betreffende type
$type = $type[$info->type];

// rond berekening van power af op gehele waarde en onthoud deze van de betreffende user
$power = round(($info->attack+$info->defence)/2);

// money is bank+cash waarde van betreffende user
$money = $info->cash+$info->bank;

$cocaine		=$info->cocaine;
// toon een rij met de kolommen: nummer, loginnaam, type, money en power van de user met nummer $j
print <<<ENDHTML
<tr><td align="center" class="mainTxt" width=20>$j</td>
<td class="mainTxt"><a href="../profile.php?x={$info->login}">$login</a></td>
<td align="center" class="mainTxt" width=100>$cocaine</td>
</tr>
ENDHTML;
}
}
  else if($_GET['p'] == "del") {
    $dbres				=  mysql_query("SELECT `login`,`level` FROM `[users]` WHERE `login`='{$_GET['x']}'");
    if($x = mysql_fetch_object($dbres)) {
      if($x->level & 0x80)
        print "  <tr><td class=\"subTitle\"><b>Delete user</b></td></tr>\n  <tr><td class=\"mainTxt\">Je kan een admin niet verwijderen</td></tr>\n";
      else if(isset($_POST['delete'])) {
        mysql_query("DELETE FROM `[users]` WHERE `login`='{$x->login}'");
        mysql_query("DELETE FROM `[temp]` WHERE `login`='{$x->login}'");
        mysql_query("DELETE FROM `[logs]` WHERE `login`='{$x->login}' AND `area`='hqIP'");
        if($clan = mysql_fetch_object(mysql_query("SELECT `name` FROM `[clans]` WHERE `owner`='{$x->login}'"))) {
          mysql_query("DELETE FROM `[clans]` WHERE `name`='{$clan->name}'");
          mysql_query("UPDATE `[users]` SET `clan`='',`clanlevel`=0 WHERE `clan`='{$clan->name}'");
        }
        print "  <tr><td class=\"subTitle\"><b>Delete user</b></td></tr>\n  <tr><td class=\"mainTxt\">{$x->login} is verwijderd</td></tr>\n<script language=\"javascript\">setTimeout('window.close()',500)</script>";
      }
      else {
        print <<<ENDHTML
  <tr><td class="subTitle"><b>Delete user</b></td></tr>
  <tr><td class="mainTxt" align="center">
	<form method="post" action="admin.php?p=del&x={$x->login}">
	Weet je zeker dat je <b>{$x->login}</b> wilt verwijderen?<br><br>
	<input type="submit" name="delete" value="Ja" style="width: 100px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="button" name="cancel" value="Nee" style="width: 100px;" onClick="window.close()">
	</form>
  </td></tr>
ENDHTML;
      }
    }
  }
  else if($_GET['p'] == "reset") {
    $dbres				= mysql_query("SELECT `id`,`login`,`pass`,`level`,`IP`,`email`,`type`,`clan`,`clanlevel`,`activated`,`blocklist` FROM `[users]` WHERE `login`='{$_GET['x']}'");
    if($x = mysql_fetch_object($dbres)) {
      if(isset($_POST['reset'])) {
        mysql_query("DELETE FROM `[users]` WHERE `login`='{$x->login}'");
        mysql_query("DELETE FROM `[temp]` WHERE `login`='{$x->login}'");
        mysql_query("DELETE FROM `[logs]` WHERE `login`='{$x->login}' AND `area`='hqIP'");
        mysql_query("INSERT INTO `[users]`(`id`,`signup`,`login`,`pass`,`level`,`IP`,`email`,`type`,`clan`,`clanlevel`,`blocklist`,`activated`) values('{$x->id}',NOW(),'{$x->login}','{$x->pass}','{$x->level}','{$x->IP}','{$x->email}','{$x->type}','{$x->clan}','{$x->clanlevel}','{$x->blocklist}',1)");
        print "  <tr><td class=\"subTitle\"><b>Reset user</b></td></tr>\n  <tr><td class=\"mainTxt\">{$x->login} is gereset</td></tr>\n<script language=\"javascript\">setTimeout('window.close()',500)</script>";
      }
      else {
        print <<<ENDHTML
  <tr><td class="subTitle"><b>Reset user</b></td></tr>
  <tr><td class="mainTxt" align="center">
	<form method="post" action="admin.php?p=reset&x={$x->login}">
	Weet je zeker dat je <b>{$x->login}</b> wilt resetten?<br><br>
	<input type="submit" name="reset" value="Ja" style="width: 100px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="button" name="cancel" value="Nee" style="width: 100px;" onClick="window.close()">
	</form>
  </td></tr>
ENDHTML;
      }
    }
  }
  else if($_GET['p'] == "resetall") {
    $dbres				= mysql_query("SELECT `id`,`login`,`pass`,`level`,`IP`,`email`,`type`,`clan`,`clanlevel`,`activated`,`blocklist` FROM `[users]` WHERE `login`='{$_GET['x']}'");
    if($x = mysql_fetch_object($dbres)) {
      if(isset($_POST['reset'])) {
        mysql_query("DELETE FROM `[users]`");
        mysql_query("DELETE FROM `[temp]`");
        mysql_query("DELETE FROM `[logs]` AND `area`='hqIP'");
        mysql_query("INSERT INTO `[users]`(`id`,`signup`,`login`,`pass`,`level`,`IP`,`email`,`type`,`clan`,`clanlevel`,`blocklist`,`activated`,`opw`,`dls`) values('{$x->id}',NOW(),'{$x->login}','{$x->pass}','{$x->level}','{$x->IP}','{$x->email}','{$x->type}','{$x->clan}','{$x->clanlevel}','{$x->blocklist}',1,'{$x->opw}','{$x->dls}'");
        print "  <tr><td class=\"subTitle\"><b>Reset user</b></td></tr>\n  <tr><td class=\"mainTxt\">{$x->login} is gereset</td></tr>\n<script language=\"javascript\">setTimeout('window.close()',500)</script>";
      }
      else {
        print <<<ENDHTML
  <tr><td class="subTitle"><b>Reset iedereen</b></td></tr>
  <tr><td class="mainTxt" align="center">
	<form method="post" action="admin.php?p=resetall">
	Weet je zeker dat je iedereen wilt resetten?<br><br>
	<input type="submit" name="reset" value="Ja" style="width: 100px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="button" name="cancel" value="Nee" style="width: 100px;" onClick="window.close()">
	</form>
  </td></tr>
ENDHTML;
      }
    }
  }
   
/* ------------------------- */ ?>
</table>

</body>


</html>