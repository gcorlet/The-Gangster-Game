<?php
ob_start();
include("../_include-config.php");
	if(! check_login()) { 
	exit;
	}

  if($data->login != $admin1 && $data->login != $admin2 && $data->hulpadmin != 1)
  {
  exit;
  }

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body bgproperties="fixed">
<form method="post">
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">Admin - Anti bot</td>
	</tr>

<?php

	if(isset($_POST['submit'])){
	$dbres	=	mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['login']}' AND `level`!='0' AND `level`!='-2' AND `level`!='-1'");
		if($user = mysql_fetch_object($dbres)){
		mysql_query("UPDATE `[users]` SET `bot`='1' WHERE `login`='{$user->login}'");
		echo "<tr><td width=\"600\" class=\"mainTxt\" align=\"center\" colspan=\"2\">You have checked {$user->login} for a bot.</td></tr>";
		}
	}

?>
	<tr>
		<td width="600" class="mainTxt" align="center">
		<table width="70%" align="center">
			<tr>
				<td width="50%">
				Name:
				</td>
				<td width="50%">
				<input type="text" name="login" maxlenght="16">
				</td>
			</tr>
			<tr>
				<td width="50%">&nbsp;
				
				</td>
				<td width="50%">
				<input type="submit" value="Search" name="submit">
				</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td class="subtitle" colspan="2">&nbsp;</td>
	</tr>
</table>
</form>
</body>
</html>




<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>