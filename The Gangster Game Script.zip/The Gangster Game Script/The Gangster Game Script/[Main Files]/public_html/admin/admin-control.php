<?php
ob_start();
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }
  
if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

//update layout
if( mysql_query("UPDATE instellingen SET layout='".mysql_escape_string($_POST['layout'])."' WHERE id=1") ) {
    echo "Layout verandert!";
} else {
    echo "Foutje: ". mysql_error();
}

}//einde verwerking

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
<body bgproperties="fixed">
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">
		<b>Instellingen</b>
		</td>
	</tr>
	<tr>
		<td width="600" class="mainTxt" align="center">
		<table width="70%" cellpadding="0" cellspacing="0">
	
			<tr>
				<td width="80%">
				<a href="admin-sitetitel.php">Website Title:</a><br>
				</td>
				<td width="10%">
				
				</td>
				<td width="10%">
				<?php echo $page->sitetitle; ?>
				</td>
			</tr>

			<tr>
				<td width="80%">
				<a href="admin-helppagina.php">Helpdesk Management:</a><br>
				</td>
				<td width="10%">
				
				</td>
				<td width="10%">
				Check
				</td>

			<tr>
				<td width="80%">
				<a href="tools.php">Cleanup Tools:</a><br>
				</td>
				<td width="10%">
				
				</td>
				<td width="10%">
				Check
				</td>

		</table>
		</td>
	</tr>
</table>

</body>
</html>




<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>