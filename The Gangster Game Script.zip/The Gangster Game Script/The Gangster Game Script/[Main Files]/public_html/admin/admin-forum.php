<?php
ob_start();
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2 && $data->hulpadmin != 1)
  {
  exit;
  }

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
<body bgproperties="fixed">
<form method="post">
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="3">
		<b>Clear Forum Posts</b>
		</td>
	</tr>
<table width=400>
<center>
<tr><td> Here You can Clear All Forum Messages [Topics and Replys] by a single person.</td></tr></table>
<?php

	if(isset($_POST['submit'])){
	$dbres	=	mysql_query("SELECT * FROM `[forum_topics]` WHERE `login`='{$_POST['login']}'");
		while($topic = mysql_fetch_object($dbres)){
		mysql_query("DELETE FROM `[forum_topics]` WHERE `id`='{$topic->id}'");
		mysql_query("UPDATE FROM `topic` SET `replays`=`replays`-'1' WHERE `id`='{$topic->topic_id}'");
		}

	mysql_query("DELETE FROM `topic` WHERE `login`='{$_POST['login']}'");

	echo "<tr><td class=\"Maintxt\" align=\"center\" width=\"600\">You have removed all of {$_POST['login']}'s topics!</td></tr>";
	
	
	
	
	$dbres	=	mysql_query("SELECT * FROM `[foum_replys]` WHERE `login`='{$_POST['login']}'");
		while($topic = mysql_fetch_object($dbres)){
		mysql_query("DELETE FROM `[foum_replys]` WHERE `id`='{$topic->id}'");
		mysql_query("UPDATE FROM `topic` SET `replays`=`replays`-'1' WHERE `id`='{$topic->topic_id}'");
		}

	mysql_query("DELETE FROM `topic` WHERE `login`='{$_POST['login']}'");

	echo "<tr><td class=\"Maintxt\" align=\"center\" width=\"600\">You have removed all of {$_POST['login']}'s replies!</td></tr>";
	} else {


?>


	<tr>
		<td class="Maintxt" align="center" width="150"><input type="text" name="login" width="50" maxlength="16"></td>
		<td class="Maintxt" align="center" width="300">Remove All Forum Posts</td>
		<td class="Maintxt" align="center" width="150"><input name="submit" type="submit" value="Remove Posts" width="100"></td>
	</tr>
</table>
</form>








<?php

	}

?>

</table>
</body>
</html>




<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>