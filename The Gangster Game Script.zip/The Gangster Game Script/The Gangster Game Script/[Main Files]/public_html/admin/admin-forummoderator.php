<?php
ob_start();
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }

  mysql_query("UPDATE `gebruiker` SET `online`=NOW() WHERE `login`='{$data->login}'"); 


/* ------------------------- */ ?> 
<html>  
<head> 
 
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head> 



<head> 
 

</head> 
<table width=100%>
<tr><td class="subTitle"><b>Forum Options</b></td></tr>
<tr><td class="mainTxt" "align="center">
<body style="; margin: 0px;"> 
<center> 
<FORM METHOD=post ACTION=""> 
<b>User Name:</b><br> 
<INPUT name="admin" type="text" VALUE="Username" maxlength="16" style="width: 150;"><center> 
<INPUT name="submit3" type="submit" VALUE="Ban from the forum">  
<br></FORM> 


</td>
</center> 


<?PHP 
echo " 

</body> 
</font> 
</html>"; 
?> 

<?PHP 
if (isset($_POST['submit3'])) { 
$insert = "UPDATE `[users]` SET `forumstatus`= 'Verbannen' WHERE `login` = '$admin'"; 
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error()); 
echo "<font color=red><b>You have banned {$admin} from the forum</b></font>"; 
exit; 
} 
?>
</body> 
</html> 




<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>