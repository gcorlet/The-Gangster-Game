<?php
ob_start();
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2 && $data->hulpadmin != 1)
  {
  exit;
  }

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
<body bgproperties="fixed">

<?php

	if(isset($_POST['submit'])){

?>

<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">Admin - Mass E-mail</td>
	</tr>
	<tr>
		<td width="600" class="mainTxt" align="center">

<?php

	$dbres		=	mysql_query("SELECT * FROM `help` WHERE `soort`='{$_POST['subject']}'");
	$controlle	=	mysql_num_rows($dbres);
		if($controlle != 0){
		mysql_query("UPDATE `help` SET `help`='{$_POST['message']}' WHERE `soort`='{$_POST['subject']}'");
		echo "Help Page Edited.<meta http-equiv=\"refresh\" content=\"3\">";
		} else {
		mysql_query("INSERT INTO `help`(`soort`,`help`) VALUES('{$_POST['subject']}','{$_POST['message']}')");
		echo "Help Page Added.<meta http-equiv=\"refresh\" content=\"3\">";
		}

?>

		</td>
	</tr>
</table>

<?php

	exit;
	} if($_GET['actie'] == "delete"){

?>

<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">Admin - Mass e-mail</td>
	</tr>
	<tr>
		<td width="600" class="mainTxt" align="center">

<?php

	mysql_query("DELETE FROM `help` WHERE `id`='{$_GET['id']}'");
	echo "Help pPage Removed.<meta http-equiv=\"refresh\" content=\"3\">";

?>

		</td>
	</tr>
</table>

<?php

	exit;
	}

$dbres	=	mysql_query("SELECT * FROM `help` WHERE `soort`='{$_GET['soort']}'");
$help	=	mysql_fetch_object($dbres);

?>

<form name="form1" method="POST" onSubmit="return submitForm(this.SEND);">
<table align="center" width="600">
	<tr>
		<td class="subtitle" colspan="2">
		<b>Help Page Added</b>
		</td>
	</tr>
	<tr>
		<td class="mainTxt" width="50%">Subject</td>
		<td class="mainTxt" width="50%"><input type="text" name="subject" value="<?php echo $help->soort; ?>" maxlength=10 size="40"></td>
	</tr>
	<tr>
		<td class="maintxt" align="center" colspan="2"><textarea name="message" cols=65 rows=10><?php echo $help->help; ?></textarea></td>
	</tr>
	<tr>
		<td class="maintxt" width="100%" colspan="2" align="center"><input type="submit" name="submit" value="Submit" style="width: 200;"></td>
	</tr>
</table>
</form>
<br>
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">
		<b>Help Page's</b>
		</td>
	</tr>
	<tr>
		<td>
		<table width=100%>
			<tr>
				<td class="subTitle" style="letter-spacing: normal;" align="center" width=90%>
				<b>Name</b>
				</td>
				<td class="subTitle" style="letter-spacing: normal;" align="center" width=10%>
				<b>Delete</b>
				</td>
			</tr>

<?php

$dbres		=	mysql_query("SELECT * FROM `help`");
	while($help = mysql_fetch_object($dbres)){
?>

			<tr onMouseOver="this.style.backgroundColor='#6F5E4A';" onMouseOut="this.style.backgroundColor='#4B3D32';" style="background-color: #4B3D32;">
				<td align="center" class="justborderS" width="90%"><a href="admin-helppagina.php?soort=<?php echo $help->soort; ?>"><?php echo $help->soort; ?></a></td>
				<td align="center" class="justborderS" width="10%"><a href="admin-helppagina.php?actie=delete&id=<?php echo $help->id; ?>"><img src="../images/overige/icons/light_delete.jpg" border=0 width="16" height="16"></a></td>
			</tr>

<?php

	}

?>

		</table>
		</td>
	</tr>
</table>
</body>
</html>




<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>