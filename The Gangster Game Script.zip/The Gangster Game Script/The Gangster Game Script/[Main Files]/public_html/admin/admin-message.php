<?php
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->admin == 1 && $data->login != $admin1 )
  {
  exit;
  }

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
<body bgproperties="fixed">

<form method="post">
<table width="600" align="center">
	<tr>
		<td colspan="3" align="center" class="subTitle"><strong>Criminelen berichten</strong></td>
	</tr>
	<tr>
		<td class="Maintxt" align="center" width="150"><input type="text" name="login" width="50" maxlength="16"></td>
		<td class="Maintxt" align="center" width="300"><select name="rang" class="form_select"><option value="van">Van</option><option value="naar" >Naar</option><option value="50" >LAATSTE 50 BERICHTEN</option></select></td>
		<td class="Maintxt" align="center" width="150"><input name="submit" type="submit" value="Zoek die rat..." width="100"></td>
	</tr>
</table>
</form>

<?php

if($_GET['p'] == "read"){

		if(isset($_POST['Verwijder'])){
		$id		=	htmlspecialchars($_POST['id']);
		$dbres		=	mysql_query("SELECT * FROM `berichten` WHERE `id`='$id'");
		$message	=	mysql_fetch_object($dbres);
			if($message->naar == $data->login){
			mysql_query("UPDATE `berichten` SET `delete1`='1' WHERE `id`='$id'");
			} else {
			mysql_query("UPDATE `berichten` SET `delete2`='1' WHERE `id`='$id'");
			}
		echo "<br><table align=\"center\" width=\"600\"><tr><td class=\"subTitle\" colspan=\"3\"><b>Email - {$message->titel}</b></td></tr><tr><td class=\"mainTxt\" colspan=\"3\"><table><tr><td width=\"20\" valign=\"top\"><img src=\"images/overige/icons/light_comment.jpg\" height=\"16\" width=\"16\" alt=\"Opmerking\" /></td><td>Het bericht is succesvol verwijdert.</td></tr></td></tr></table></td></tr><tr><td class=\"subtitle\" colspan=\"3\">&nbsp;</td></tr></table>";
		} else {
		$id	=	htmlspecialchars($_GET['id']);
		$dbres	=	mysql_query("SELECT * FROM `berichten` WHERE `id`='$id'");
			if($message = mysql_fetch_object($dbres)){

				if($message->naar == $data->login){
				mysql_query("UPDATE `berichten` SET `read`='1' WHERE `id`='$id'");
				}

				if($message->read == 1){
				$read	=	"Ja";
				} else {
				$read	=	"Nee";
				}
?>

<br>
<table align="center" width="600">
	<tr>
		<td class="subtitle" colspan="2" width="600">
		<b>Email - <?php echo $message->titel; ?></b>
		</td>
	</tr>
	<tr>
		<td class="mainTxt" width="300">Van</td>
		<td class="mainTxt" width="300"><a href="speler-profiel.php?x=<?php echo $message->van; ?>"><?php echo $message->van; ?></a></td>
	</tr>
	<tr>
		<td class="mainTxt" width="300">Naar</td>
		<td class="mainTxt" width="300"><a href="speler-profiel.php?x=<?php echo $message->naar; ?>"><?php echo $message->naar; ?></a></td>
	</tr>

<?php if($message->van == $data->login){ ?>
	<tr>
		<td class="mainTxt" width="300">Gelezen</td>
		<td class="mainTxt" width="300"><?php echo $read; ?></td>
	</tr>
<?php } ?>
	<tr>
		<td class="mainTxt" width="300">Onderwerp</td>
		<td class="mainTxt" width="300"><?php echo $message->titel; ?></td>
	</tr>
	<tr>
		<td class="mainTxt" width="300">Datum</td>
		<td class="mainTxt" width="300"><?php echo $message->tijd; ?></td>
	</tr>
	<tr>
		<td class="maintxt" colspan="2" width="600"><?php echo ubb($message->bericht); ?><br></td>
	</tr>
	<tr>
		<td align="left" colspan="2">
		<table>
			<tr>
				<?php if($message->van != $data->login){ ?>
				<td align="left">
				<form action="internet-email.php?p=new" onSubmit="return submitForm(this.Antwoord);">
				<input type="hidden" name="p" value="new">
				<input type="hidden" name="to" value="<?php echo $message->van; ?>">
				<input type="hidden" name="subject" value="<?php $message->titel = str_replace("Re:","", $message->titel); ?>Re: <?php echo $message->titel; ?>">
				<input type="submit" name="Antwoord" value="Antwoord" style="width: 100; background: #4B3D32;">
				</form>
				</td> 
				<?php } ?>
				<td align="left" width="100">
				<form action="internet-email.php?p=read" method="post" onSubmit="return submitForm(this.Verwijder);">
				<input type="hidden" name="id" value="<?php echo $id; ?>">
				<input type="submit" name="Verwijder" value="Verwijder" style="width: 100; background: #4B3D32;">
				</form>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

<?php

			}
		}
	} else if(isset($_POST['submit'])){
		if($_POST['rang'] == "naar"){

?>


<table align="center" width="600">
	<tr>
		<td class="subtitle" colspan="4">
		<b>Postvak in - Alle emails</b>
		</td>
	</tr>
	<tr>
		<td class="subtitle" width="250"><b><div align="left">&nbsp;Onderwerp</div></b></td>
		<td class="subtitle" align="center" width="150"><b>Afzender</b></td>
		<td class="subtitle" align="center" width="200"><b>Datum</b></td>
	</tr>

<?php

		$dbres	=	mysql_query("SELECT * FROM `berichten` WHERE `naar`='{$_POST['login']}' ORDER BY `id` DESC");

			while($bericht = mysql_fetch_object($dbres)){

?>

	<tr>
		<td class="mainTxt" width="250"><a href="internet-email.php?p=read&id=<?php echo $bericht->id; ?>"><?php if($bericht->read == 0){ echo "<b>"; } ?><?php echo $bericht->titel; ?></a></td>
		<td class="mainTxt" align="center" width="150"><a href="speler-profiel.php?x=<?php echo $bericht->van; ?>"><?php echo $bericht->van; ?></a></td>
		<td class="mainTxt" align="center" width="200"><?php echo $bericht->tijd; ?></td>
	</tr>

<?php
			}

?>

	<tr>
		<td colspan="4" class="subtitle">&nbsp;</td>
	</tr>		
</table>

<?php

		} else if($_POST['rang'] == "50"){

?>


<table align="center" width="600">
	<tr>
		<td class="subtitle" colspan="4">
		<b>Postvak in - Alle emails</b>
		</td>
	</tr>
	<tr>
		<td class="subtitle" width="250"><b><div align="left">&nbsp;Onderwerp</div></b></td>
		<td class="subtitle" align="center" width="150"><b>Afzender</b></td>
		<td class="subtitle" align="center" width="200"><b>Datum</b></td>
	</tr>

<?php

		$dbres	=	mysql_query("SELECT * FROM `berichten` ORDER BY `id` DESC LIMIT 50");

			while($bericht = mysql_fetch_object($dbres)){

?>

	<tr>
		<td class="mainTxt" width="250"><a href="internet-email.php?p=read&id=<?php echo $bericht->id; ?>"><?php if($bericht->read == 0){ echo "<b>"; } ?><?php echo $bericht->titel; ?></a></td>
		<td class="mainTxt" align="center" width="150"><a href="speler-profiel.php?x=<?php echo $bericht->van; ?>"><?php echo $bericht->van; ?></a></td>
		<td class="mainTxt" align="center" width="200"><?php echo $bericht->tijd; ?></td>
	</tr>

<?php
			}

?>

	<tr>
		<td colspan="4" class="subtitle">&nbsp;</td>
	</tr>		
</table>

<?php

		} else {

?>


<table align="center" width="600">
	<tr>
		<td class="subtitle" colspan="4">
		<b>Postvak uit - Alle emails</b>
		</td>
	</tr>
	<tr>
		<td class="subtitle" width="250"><b><div align="left">&nbsp;Onderwerp</div></b></td>
		<td class="subtitle" align="center" width="150"><b>Ontvanger</b></td>
		<td class="subtitle" align="center" width="200"><b>Datum</b></td>
	</tr>

<?php

		$dbres	=	mysql_query("SELECT * FROM `berichten` WHERE `van`='{$_POST['login']}' ORDER BY `id` DESC");

			while($bericht = mysql_fetch_object($dbres)){

?>

	<tr>
		<td class="mainTxt" width="250"><a href="internet-email.php?p=read&id=<?php echo $bericht->id; ?>"><?php if($bericht->read == 0){ echo "<b>"; } ?><?php echo $bericht->titel; ?></a></td>
		<td class="mainTxt" align="center" width="150"><a href="speler-profiel.php?x=<?php echo $bericht->naar; ?>"><?php echo $bericht->naar; ?></a></td>
		<td class="mainTxt" align="center" width="200"><?php echo $bericht->tijd; ?></td>
	</tr>

<?php
			}

?>

	<tr>
		<td colspan="4" class="subtitle">&nbsp;</td>
	</tr>		
</table>

<?php

		}

	}

?>

</body>
</html>




<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>