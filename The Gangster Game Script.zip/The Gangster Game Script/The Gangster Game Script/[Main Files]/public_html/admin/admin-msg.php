<?php
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->admin == 1 && $data->login != $admin1 )
  {
  exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>


<body>
<table width=100%>
<?php /* ------------------------- */

  if($_GET['p'] == "massmsg") {
    print "  <tr><td class=\"subTitle\"><b>Admin - Mass Message</b></td></tr>\n";
    if(isset($_POST['message'])) {
      $dbres				= mysql_query("SELECT * FROM `[temp]` WHERE `id`='{$_POST['id']}' AND `code`='{$_POST['code']}' AND `area`='message'");
      if(($check = mysql_fetch_object($dbres)) && $check->IP == $clientIP) {
        $dbres				= mysql_query("SELECT `login` FROM `[users]` WHERE `Mobieltje`=1");
        while($member = mysql_fetch_object($dbres)) {
          $_POST['subject']		= preg_replace('/</','&#60;',$_POST['subject']);
          $_POST['message']		= preg_replace('/</','&#60;',$_POST['message']);

          mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}',Info, Dark-Step','{$member->login}','{$_POST['subject']}','{$_POST['message']}')");
          mysql_query("DELETE FROM `[temp]` WHERE `id`='{$_POST['id']}' AND `code`='{$_POST['code']}' AND `area`='message'");
        }
      }
      print "  <tr><td class=\"mainTxt\">Message send</td></tr>\n";
    }

    $code				= rand(100000,999999);
    mysql_query("INSERT INTO `[temp]`(login,IP,code,area,time) values('{$data->login}','$clientIP','$code','message',NOW())");
    $id					= mysql_insert_id();

    print <<<ENDHTML
  <tr><td class="mainTxt">
	<form name="form1" method="POST" action="admin.php?p=massmsg"><table>
	<input type="hidden" name="id" value="$id">
	<input type="hidden" name="code" value="$code">
	<tr><td width=100>From:</td>		<td>** TGG Admins **</td></tr>
	<tr><td width=100>Subject:</td>	<td><input type="text" name="subject" value="{$_REQUEST['subject']}" maxlength=25></td></tr>
	<tr><td width=100 valign="top">Message:</td>
						<td><textarea name="message" cols=40 rows=10>{$_REQUEST['message']}</textarea></td></tr>
	<tr><td width=100></td>			<td align="right"><input type="submit" name="submit" value="Send"></td></tr>
  </td></tr>
ENDHTML;
  }
  else if($_GET['p'] == "adminmsg") {
    print "  <tr><td class=\"subTitle\"><b>Admin - Message</b></td></tr>\n";
    if(isset($_POST['to'],$_POST['message'])) {
      $dbres				= mysql_query("SELECT * FROM `[temp]` WHERE `id`='{$_POST['id']}' AND `code`='{$_POST['code']}' AND `area`='message'");
      if(($check = mysql_fetch_object($dbres)) && $check->IP == $clientIP) {
        $dbres				= mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_POST['to']}'");
        $info				= mysql_fetch_object($dbres);
        if($info == false)
          print "  <tr><td class=\"mainTxt\">'{$_POST['to']}' don't excist</td></tr>\n";
        else {
          $_POST['subject']		= preg_replace('/</','&#60;',$_POST['subject']);
          $_POST['message']		= preg_replace('/</','&#60;',$_POST['message']);

          mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','** {$data->login} **','{$info->login}','{$_POST['subject']}','{$_POST['message']}')");
          mysql_query("DELETE FROM `[temp]` WHERE `id`='{$_POST['id']}' AND `code`='{$_POST['code']}' AND `area`='message'");
          print "  <tr><td class=\"mainTxt\">Message send</td></tr>\n";
        }
      }
    }

    $code				= rand(100000,999999);
    mysql_query("INSERT INTO `[temp]`(login,IP,code,area,time) values('{$data->login}','$clientIP','$code','message',NOW())");
    $id					= mysql_insert_id();

    print <<<ENDHTML
  <tr><td class="mainTxt">
	<form name="form1" method="POST" action="admin.php?p=adminmsg"><table>
	<input type="hidden" name="id" value="$id">
	<input type="hidden" name="code" value="$code">
	<tr><td width=100>From:</td>		<td>** {$data->login} **</td></tr>
	<tr><td width=100>To:</td>		<td><input type="text" name="to" value="{$_REQUEST['to']}" maxlength=16></td></tr>
	<tr><td width=100>Subject:</td>	<td><input type="text" name="subject" value="{$_REQUEST['subject']}" maxlength=25></td></tr>
	<tr><td width=100 valign="top">Message:</td>
						<td><textarea name="message" cols=40 rows=10>{$_REQUEST['message']}</textarea></td></tr>
	<tr><td width=100></td>			<td align="right"><input type="submit" name="submit" value="Send"></td></tr>
  </td></tr>
ENDHTML;
  }
   
/* ------------------------- */ ?>
</table>

</body>

</html>