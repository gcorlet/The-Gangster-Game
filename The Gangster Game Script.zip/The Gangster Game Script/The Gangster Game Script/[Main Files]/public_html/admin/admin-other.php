<?php /* ------------------------- */
  $UPDATE_DB                                = 1;
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if(! ($data->login == $admin1))
if(! ($data->login == $admin2))
if(! ($data->hulpadmin == 1))

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
  <table width=100%>
    <tr><td class="subTitle"><b>Donate Car/VIP</b></td></tr>
    <tr><td class="mainTxt" "align="center">
<center>


<table width=100%>
    <tr><td class="mainTxt">
<?php
	// Gegevens
	$soort    = "18";
	$snelheid = "100";
	$land     = "1";
	$owner    = $_POST['gebruiker'];

	
	// Insert Into
    $query  = "INSERT INTO `[auto]` (soort, snelheid, land, owner, tekoop) "; 
    $query .= "VALUES ('$soort', '$snelheid', '$land', '$owner', '$tekoop');"; 
    $result = mysql_query($query) or die ( "FOUT: " . mysql_error()); 
?>
<INPUT name="dfdfd" type="dfdft" VALUE="Donate Car"><br><br>
<form method="POST">
	<input type="text" name="gebruiker" size="20"><input type="submit" value=" ADD ">
</form>
</td></tr>
</table>

<table width=100%>
    <tr><td class="mainTxt">
<?php
	// Gegevens
	$owner    = $_POST['gebruiker3'];

	
	// Insert Into

              
    $query  = "UPDATE `[users]` SET `vip`=`vip`+'30' WHERE `login`='$owner'";
 
    $result = mysql_query($query) or die ( "FOUT: " . mysql_error()); 
?>
<INPUT name="dfdfd" type="dfdft" VALUE="30 Days VIP"><br><br>
<form method="POST">
	<input type="text" name="gebruiker3" size="20"><input type="submit" value=" ADD ">
</form>
</td></tr>
</table>