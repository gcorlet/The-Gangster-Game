<?php
ob_start();
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }
  
if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

//update layout
if( mysql_query("UPDATE instellingen SET sitetitle='".mysql_escape_string($_POST['sitetitle'])."' WHERE id=1") ) {
    echo "The SIte Name has been changed. To see the current changes, refresh your page or press F5.";
} else {
    echo "Error: ". mysql_error();
}

}//einde verwerking

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
<body bgproperties="fixed">
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">

		<b>Extra panel</b>
		</td>
	</tr>
	<tr>
		<td width="600" class="mainTxt" align="center">








<?php

	if(isset($_POST['submit4'])){

	} else if(isset($_POST['submit5'])){
		if($_POST['type3'] == 1){
		mysql_query("INSERT INTO `admin`(`login`,`level`) VALUES('{$_POST['login']}','3')");
		mysql_query("UPDATE `gebruiker` SET `level`='3',`memberdays`='00-00-0000 00:00:00' WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into an admin.";
		} else if($_POST['type3'] == 2){
		mysql_query("INSERT INTO `admin`(`login`,`level`) VALUES('{$_POST['login']}','2')");
		mysql_query("UPDATE `gebruiker` SET `hulpadmin`='1',`memberdays`='00-00-0000 00:00:00' WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into a Help Admin.";
		} else if($_POST['type3'] == 3){
		mysql_query("INSERT INTO `admin`(`login`,`level`) VALUES('{$_POST['login']}','1')");
		mysql_query("UPDATE `gebruiker` SET `level`='3',`memberdays`='00-00-0000 00:00:00' WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into a moderator.";
		} else if($_POST['type3'] == 4){
		mysql_query("DELETE FROM `admin` WHERE `login`='{$_POST['login']}'");
		mysql_query("UPDATE `gebruiker` SET `level`='2',`dagen`=`dagen`+'21',`memberdays`=NOW() WHERE `login`='{$_POST['login']}'");
		echo "You have made{$_POST['login']} into paying member status.";
		} else if($_POST['type3'] == 5){
		mysql_query("DELETE FROM `admin` WHERE `login`='{$_POST['login']}'");
		mysql_query("UPDATE `gebruiker` SET `hulpadmin`='0',`memberdays`='00-00-0000 00:00:00' WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into a normal member.";
		}
	} else if(isset($_POST['submit6'])){

	} else {

?>

		<form method="post">
		<table width="70%">
			<tr>
				<td width="50%">
				Enter Your Desired Site Name:
				</td>
				<td width="50%">
				<form method="post">
				<input type="text" name="sitetitle" maxlenght="25">
				</td>
			</tr>
			<tr>
				<td width="50%">
				</td>
				<td width="50%">
				<input type="submit" value="Set Changes"></form>
				</td>
			</tr>

		</table>
		</form>

<?php

	}

?>

		</td>
	</tr>
</table>

</body>
</html>





<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>