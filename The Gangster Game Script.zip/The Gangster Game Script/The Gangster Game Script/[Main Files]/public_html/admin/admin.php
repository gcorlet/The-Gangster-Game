<?php /* ------------------------- */

  $page					= $_GET['p'];
  if($page == "donate" || $page == "del" || $page == "reset")
    include("admin-basic.php");
  else if($page == "massmsg" || $page == "adminmsg")
    include("admin-msg.php");
  else if($page == "multi" || $page == "search")
    include("admin-search.php");
  else if($page == "stats")
    include("admin-userinfo.php");
  else if($page == "donate1")
    include("admin-basic1.php");
  else if($page == "massemail")
    include("mass-email.php");
  else if($page == "multi")
    include("admin-search.php");
   
/* ------------------------- */ ?>