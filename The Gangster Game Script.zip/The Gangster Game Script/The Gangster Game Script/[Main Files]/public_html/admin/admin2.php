<?php /* ------------------------- */

  $OMNILOG				= 1;include("_include-config.php");



    if(! ($data->login == cerv ))
    exit;

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo ($_COOKIE['v'] == 2) ? "<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css" : "<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"; ?>">

</head>


<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Admin Opties</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Selecteer een admin optie</option>
<option value=\"admin-mollie.php\">Bel Systeem</option>
<option value=\"admin-klikmissie.php\">Klik Missie</option>
<option value=\"adminstats.php\">Stats</option>
<option value=\"ticketadmin.php\">Tickets</option>
<option value=\"massmail.php\">Massa Mail</option>
<option value=\"maakhulpadmin.php\">Maak Hulpadmin</option>
<option value=\"admin-cms.php\">Teksten Beheer</option>
<option value=\"admin-helppagina.php\">Helpdesk</option>
<option value=\"tools.php\">Tools</option>
<option value=\"admin.php?p=donate\">Doneren</option>
<option value=\"admin-dubbel.php\">Dubbel IP Check</option>
<option value=\"admin.php?p=adminmsg\">Massa Bericht</option>
<option value=\"admin.php?p=search\">Zoeken</option>
<option value=\"forummaken.php\">Forum Moderator</option>
<option value=\"admin-forum.php\">Forum Beheer</option>
<option value=\"hulpadminstats.php\">Extra Stats</option>
<option value=\"afhalen.php\">Straffen</option>
<option value=\"banacc.php\">Verbannen</option>
<option value=\"veranderip.php\">Verander IP</option>
<option value=\"admin-backup.php\">Backup</option>
<option value=\"reset.php\">Reset</option>
</select>
</table>
";
}
?> 

<BODY onLoad="movein()">
<table width=100%>
<?php /* ------------------------- */
error_reporting(E_ALL); 
print "
  <tr><td class=subTitle><b>Db Change</b></td></tr>
 <tr><td class=\"mainTxt\">
	<form method=\"post\" action=\"adminmen.php\"><table align=\"center\">
	  <tr><td width=100>Naam:</td>		<td><input type=\"text\" name=\"char\" maxlength=16 style=\"width: 150;\"></td></tr>	
	  <tr><td></td><td align=\"right\"><input type=\"submit\" name=\"submit1\" style=\"width: 100;\" value=\"Zoek\"></td></tr>
	</table></form>
  </td></tr>
"
  ?>
  </table>
  </body>
  </html>