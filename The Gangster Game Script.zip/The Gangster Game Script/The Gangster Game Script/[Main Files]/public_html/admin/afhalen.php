<?php /* ------------------------- */

  $UPDATE_DB                                = 1;
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }
  
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>

<html>
<head>
<title><?=$title; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>
<body style="; margin: 0px;">
  <table width=100%>
    <tr><td class="subTitle"><b>Admin - Penalties</b></td></tr>
    <tr><td class="mainTxt" "align="center">
<center>
<FORM METHOD=post ACTION="">
Who?:<br>
<INPUT name="aan" type="text" VALUE="" maxlength="16" style="width: 125;"><br>
Amount:<br>
<INPUT name="hoeveel" type="text" VALUE="" maxlength="16" style="width: 100;"><br><br>
What will you penalize??<br>
<center>
<INPUT name="submit1" type="submit" VALUE="Cash">
<INPUT name="submit2" type="submit" VALUE="Bank$">
<INPUT name="submit3" type="submit" VALUE="Power">
<INPUT name="submit4" type="submit" VALUE="Reset Everyones Cash to 500">
<br></FORM>
</center>
<?PHP
echo "

</body>
</font>
</html>";
?>

<?PHP
if (isset($_POST['submit1'])) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-$hoeveel WHERE `login` = '$aan'");
    print <<<ENDHTML

<html>


<head>
<title><?=$title; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have removed $$hoeveel from $aan!
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
    exit;
}
?>
<?PHP
if (isset($_POST['submit2'])) {
mysql_query("UPDATE `[users]` SET `bank`=`bank`-$hoeveel WHERE `login` = '$aan'");
    print <<<ENDHTML
<html>


<head>
<title><?=$title; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have removed $$hoeveel from $aan's bank.
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
    exit;
}
?>
<?PHP
if (isset($_POST['submit3'])) {
mysql_query("UPDATE `[users]` SET `attack`=`attack`-$hoeveel,`defence`=`defence`-$hoeveel WHERE `login` = '$aan'");
    print <<<ENDHTML
<html>


<head>
<title><?=$title; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have removed $hoeveel power from $aan.
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
    exit;
}
?>
<?PHP
if (isset($_POST['submit4'])) {
mysql_query("UPDATE `[users]` SET `bank`='500',`cash`='500'");
    print <<<ENDHTML
<html>


<head>
<title><?=$title; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have set all players cash to 500 and all cash in the banks to 500.
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
    exit;
}
?>
</tr></td>
</body>