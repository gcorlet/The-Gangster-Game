<?php /* ------------------------- */

  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2 && $data->hulpadmin != 1)
  {
print "  <tr><td class=\"mainTxt\"><center><font color=red><b>Lol, oprotten</b></font></td></tr>\n";
exit;
}

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">


</head>

  
<table width=100%>

  <center>
   <tr><td class="subTitle" width=500><b>Donatie's</b></td></tr>
<td width="250" class="mainTxt"><b>Verzonden</b></td>

<tr><td width="250" class="mainTxt"><b>tijd</b></td><td width="250" class="mainTxt"><b>naar</b></td><td width="250" class="mainTxt"><b>hoeveel</b></td></tr>
<?
$gegevens = mysql_query("SELECT * FROM `[logs]` WHERE `login`='". $_GET["b"] ."'And `area`='donate' ") or die(mysql_error());
while($rij = mysql_fetch_object($gegevens)) { 

echo("
<td width=\"250\" class=\"mainTxt\">$rij->time</td>
<td width=\"250\" class=\"mainTxt\"><a href=\"profile.php?x=$rij->person\"><b>$rij->person</a></td>
<td width=\"250\" class=\"mainTxt\">$rij->code</td>
</tr>
"); 
} 
?>
<td width="250" class="mainTxt"><b>Ontvangen</b></td>
<tr><td width="250" class="mainTxt"><b>tijd</b></td><td width="250" class="mainTxt"><b>van</b></td><td width="250" class="mainTxt"><b>hoeveel</b></td></tr>
<?
$gegevens = mysql_query("SELECT * FROM `[logs]` WHERE `person`='". $_GET["b"] ."'And `area`='donate' ") or die(mysql_error());
while($rij = mysql_fetch_object($gegevens)) { 

echo("
<td width=\"250\" class=\"mainTxt\">$rij->time</td>
<td width=\"250\" class=\"mainTxt\"><a href=\"profile.php?x=$rij->login\"><b>$rij->login</a></td>
<td width=\"250\" class=\"mainTxt\">$rij->code</td>
</tr>
"); 
} 
?>

</table></center>
</body>
</html>