<?php /* ------------------------- */ 

  include("../_include-config.php"); 
  if(! check_login()) { 
    header("Location: ../login.php"); 
    exit; 
  } 

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'"); 


/* ------------------------- */ ?> 
<html>  
<head> 
 
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head> 



<head> 
 

</head> 
<table width=100%>
<tr><td class="subTitle"><b>Forum Opties</b></td></tr>
<tr><td class="mainTxt" "align="center">
<body style="; margin: 0px;"> 
<center> 
<FORM METHOD=post ACTION=""> 
<b>Gebruikersnaam:</b><br> 
<INPUT name="admin" type="text" VALUE="Gebruikersnaam" maxlength="16" style="width: 150;"><center> 
<INPUT name="submit1" type="submit" VALUE="Maak Moderator">  
<INPUT name="submit2" type="submit" VALUE="Maak Normaal">  
<INPUT name="submit3" type="submit" VALUE="Ban van forum">  
<br></FORM> </td>
</center> 
<?PHP 
echo " 

</body> 
</font> 
</html>"; 
?> 

<?PHP 
if (isset($_POST['submit1'])) { 
$insert = "UPDATE `[users]` SET `forumstatus` = 'gwsp1' WHERE `login` = '$admin'"; 
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error()); 
echo "<b><font color=green> {$admin} is forum moderator</font></b>"; 
exit; 
} 
?> 
<?PHP 
if (isset($_POST['submit2'])) { 
$insert = "UPDATE `[users]` SET `forumstatus` = '' WHERE `login` = '$admin'"; 
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error()); 
echo "<font color=red><b> {$admin} weer normaal</b></font>"; 
exit; 
} 
?> 
<?PHP 
if (isset($_POST['submit3'])) { 
$insert = "UPDATE `[users]` SET `forumstatus`= 'verbannen' WHERE `login` = '$admin'"; 
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error()); 
echo "<font color=red><b>Je hebt {$admin} banned</b></font>"; 
exit; 
} 
?>
</body> 
</html> 