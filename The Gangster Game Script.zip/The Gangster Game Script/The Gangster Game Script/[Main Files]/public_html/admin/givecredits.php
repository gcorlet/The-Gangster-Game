<?php /* ------------------------- */


  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }

$dbres	=	mysql_query("SELECT * FROM `spel_statestieken` WHERE `id`='1'");
$link	=	mysql_fetch_object($dbres);

$dbres1		=	mysql_query("SELECT * FROM `[users]` WHERE `level`='2'");
$rows1		=	mysql_num_rows($dbres1);
$dbres2		=	mysql_query("SELECT * FROM `[users]` WHERE `level`='-2'");
$rows2		=	mysql_num_rows($dbres2);
$dbres3		=	mysql_query("SELECT * FROM `[users]`");
$rows3		=	mysql_num_rows($dbres3);
$dbres4		=	mysql_query("SELECT * FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 86400");
$rows4		=	mysql_num_rows($dbres4);
$dbres5		=	mysql_query("SELECT * FROM `[users]` WHERE `level`='-1'");
$rows5		=	mysql_num_rows($dbres5);
$dbres1		=	mysql_query("SELECT * FROM `[users]` WHERE `sex`='Man'");
$rows6		=	mysql_num_rows($dbres1);
$spelers	=	$rows3;
$levend		=	$spelers-$rows2;
$levendp	=	round((100/$spelers)*$levend);
$man		=	$rows6;
$manp		=	round((100/$spelers)*$man);
$vrouw		=	$spelers-$rows6;
$vrouwp		=	round((100/$spelers)*$vrouw);
$dood		=	$rows2;
$doodp		=	round((100/$spelers)*$dood);
$ban		=	$rows5;
$banp		=	round((100/$spelers)*$ban);
$online		=	$rows4;
$onlinep	=	round((100/$spelers)*$online);
$betalend	=	$rows1;
$betalendp	=	round((100/$spelers)*$betalend);
$dbres		=	mysql_query("SELECT * FROM `betalingen` WHERE `soort`='Bellen'");
$betaal1	=	mysql_num_rows($dbres);
$dbres		=	mysql_query("SELECT * FROM `betalingen` WHERE `soort`='Ideal'");
$betaal2	=	mysql_num_rows($dbres);

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
<body bgproperties="fixed">

<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">
		<b>Admin -  Credits</b>
		</td>
	</tr>
	<tr>
		<td width="600" class="mainTxt" align="center">

<?php

	if(isset($_POST['submit4'])){

	} else if(isset($_POST['submit5'])){
		if($_POST['level'] == 1){
		mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`+'50' WHERE `login`='{$_POST['login']}'");
		echo "You have given {$_POST['login']} 50 Credits.";
		} else if($_POST['level'] == 2){
		mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`+'150' WHERE `login`='{$_POST['login']}'");
		echo "You have given {$_POST['login']} 150 Credits.";
		} else if($_POST['level'] == 3){
		mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`+'250' WHERE `login`='{$_POST['login']}'");
		echo "You have given {$_POST['login']} 250 Credits.";
		} else if($_POST['level'] == 4){
		mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`+'550' WHERE `login`='{$_POST['login']}'");
		echo "You have given {$_POST['login']} 550 Credits.";
		} else if($_POST['level'] == 5){
		mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`+'1000' WHERE `login`='{$_POST['login']}'");
		echo "You have given {$_POST['login']} 1000 Credits.";
		}
	} else if(isset($_POST['submit6'])){

	} else {

?>

		<form method="post">
		<table width="70%">
			<tr>
				<td width="50%">
				Enter Players Name:
				</td>
				<td width="50%">
				<input type="text" value="<?php echo $_GET['login']; ?>" name="login" style="width:150" maxlenght="16">
				</td>
			</tr>
            
 			<tr>
				<td width="50%">
				Credits Amount:
				</td>
				<td width="50%">
				<select name="level" style="width:150">
                                 <option value="1">50 Credits</option>
				<option value="2">150 Credits</option>
                                   <option value="3">250 Credits</option>
                                   <option value="4">550 Credits</option>
				<option value="5">1000 Credits</option>
				</select>
				</td>
			</tr>
        
			<tr>
				<td width="50%">
				</td>
				<td width="50%">
				<input type="submit" name="submit5" value="Give Credits" style="width:150">
				</td>
			</tr>           
            
             
 			<tr>
				<td width="50%">&nbsp;
				
				</td>
				<td width="50%">&nbsp;
				
				</td>
			</tr>
                          

			
		</table>
		</form>

<?php
	}

?>


	
</table>
</body>
</html>





<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>