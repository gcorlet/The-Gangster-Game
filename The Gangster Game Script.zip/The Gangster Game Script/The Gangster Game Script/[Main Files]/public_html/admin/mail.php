<?php
ob_start();
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2 && $data->login != botchecker)
  {
  exit;
  }

?>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

<?
$sql=mysql_query("SELECT email FROM `[users]` ");
while($arr=mysql_fetch_array($sql)) {
echo $arr['email'] . '<br/>';
} 
?>


