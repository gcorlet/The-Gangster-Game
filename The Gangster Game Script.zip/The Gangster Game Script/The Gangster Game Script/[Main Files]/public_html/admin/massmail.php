


<?php

  set_time_limit(0);
  include('../_include-config.php');

  
  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }
 
  
  if (isset($_POST['mailing'])) 
  {

    $rMember = mysql_query("SELECT login, email FROM `[users]`");
    while ($aMember = mysql_fetch_assoc($rMember)) 
    {

      $sBericht = str_replace('{naam}', $aMember['login'], $_POST['mailing']);

      @mail($aMember['email'], $_POST['titel'], $sBericht, 'From: [Extreme Mobster] <norelpy@mail.com>');
      echo 'Sent!!..';

    }

  }
  else
  {


?>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<table align="center" width=100%>
  <tr><td class="subTitle">Mass Email - Sent to all Members</b></td></tr>



  <tr><td class="mainTxt">
<form method="post" action="" name="">
Subject: <input type="text" name="titel" value="<? echo $title ?> Email Subject">
Email:<br>
<textarea cols=40 rows=10 name="mailing">
Dear {naam} 



</textarea><p />

<input type="submit" value="Send Email" name="submit">

</form>
</table>
<?
if($_GET['killed'])
{
mysql_query("UPDATE `[users]` SET `vermoord`='0' WHERE `login`='naamnaarkeuze'");
}
?>


<?php

  }
  
  mysql_close($db);

?>
