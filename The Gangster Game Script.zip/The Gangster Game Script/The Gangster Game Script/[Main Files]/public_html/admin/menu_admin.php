<?php
ob_start();
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->admin == 1 && $data->login != $admin1 )
  {
  exit;
  }
  
if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {

//update layout
if( mysql_query("UPDATE send SET mollieaccept='".mysql_escape_string($_POST['mollieaccept'])."' WHERE id=1") ) {
    echo "Mollie settings have changed.";
} else {
    echo "Foutje: ". mysql_error();
}

}//einde verwerking

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

<?
if(! isset($_GET['id']))
{

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>All Administrator Options</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\" class='btn btn-info'>Select an option</option>
<option value=\"admin-control.php\" class='btn btn-info'>Game Settings</option>
<option value=\"givecredits.php\" class='btn btn-info'>Player Credits</option>
<option value=\"ticketadmin.php\" class='btn btn-info'>Support Tickets</option>>
<option value=\"massmail.php\" class='btn btn-info'>Mass E-Mail</option>
<option value=\"maakhulpadmin.php\" class='btn btn-info'>Make Admin</option>
<option value=\"afhalen.php\" class='btn btn-info'>Penalize</option>
<option value=\"admin-dubbel.php\" class='btn btn-info'>Double IP Check</option>
<option value=\"admin-forum.php\" class='btn btn-info'>Clear Forum</option>
<option value=\"reset.php\" class='btn btn-info'>Reset</option>
</select>
</table>
";
}
?>



<table align="center" cellpadding="2" cellspacing="0" width="100%">
	<tbody><tr>
		<td class="subtitle">Most Popular Options</td>
	</tr>

	<tr>
		<td class="mainTxt" align="center">
			<table align="center">
				<tbody><tr>
					
					<td align="center" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="Detective" src="../images/icons/application_edit.png" height="16" width="16"></td>
								<td width="142"><a href="admin-control.php" class="btn btn-info">Game Settings</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="right" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img src="../images/icons/usergo.png" height="16"></td>
								<td width="142"><a href="ticketadmin.php" class='btn btn-info'>Suport Tickets</a></td>
							</tr>
						</tbody></table>
					</td>
				</tr>

				<tr>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img alt="Detective" src="../images/icons/lightning.png" height="16" width="16"></td>
								<td width="142"><a href="maakhulpadmin.php">Make Admin</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="center" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="BF" src="../images/icons/email_go.png" height="16" width="16"></td>
								<td width="142"><a href="massmail.php" class='btn btn-info'>Mass Email</a></td>
							</tr>
						</tbody></table>
					</td>
					
				</tr>













			</tbody></table>
		</td>
	</tr>
</tbody></table>
<br>
<table align="center" cellpadding="2" cellspacing="0" width="100%">
	<tbody><tr>
		<td class="subTitle" colspan="2"><b> Usefull Information</b></td>
	</tr>

<?


 $select = mysql_query("SELECT * FROM leden WHERE id=".$_SESSION['loginid']." ");
 $list   = mysql_fetch_assoc($select);

  $gebruikersnaam  = $list['naam'];
 	$voornaam		     = $list['voornaam'];
	$achternaam	     = $list['achternaam'];
	$emailadres	     = $list['emailadres'];
	$ipadres				 = $list['ipadres'];
	


 $query = mysql_query("SELECT * FROM `[users]` WHERE gameid=".$_SESSION['loginid']."");
?>


	<tr>
		<td class="mainTxt" colspan="2" width="600">

Tips Tricks<br /><br />
<br>
Welcome to The Gangster Game Script Tips n Tricks. First off, Thank You for purchasing our script, and we hope you enjoy it!
<br>
<br>
<br>
Firstly...
<br>

<u><b>...Making Cash Through The Script</b></u><br /><br />
It is very easy to make cash through this game script.<BR />
All you need to do is set up an account with http://www.123ticket.com or http://www.paypal.com is the first step. Please read the menual for the configuration settings.
 <BR /><BR />
 
 <u><b>Changing the Game Settings</b></u><br /><br />
A single file operates the changing of afew but the most important game information. Such has cleaning tools, Game name, database backup.
You can access this page by vlivking the `Game Information` option, or click this direct link below.<BR />
<a href="admin-control.php"><b>Click Here to change Game Settings</b></a>
 <BR /><BR />
 
 <u><b>Making Helper Admins</b></u><br /><br />
Allocate people who you wish to have admin, helper admin., to help you run your game.<BR />
You can do this by clicking the `Make HelpAdmin` option, or click the link below to go directly to it.
<BR />
<a href="maakhulpadmin.php"><b>Click Here to Make a HelperAdmin</b></a>
 <BR /><BR />

<u><b>Getting Your own Domain Name</b></u><br /><br />
The domain name is the www. in the browser. The address you type in to get to a designated website. <BR />
You can either purchase a .com or .co.uk, .net, etc for a small amount of money. You can find many websites that sell domains,
just search it in a search engine. <BR />
<BR />
Or if your short on cash, you can order a free one. Its not a .com, but it does the trick!<br>
Heres a list of a view sites which do free domains:<br /><br />

<a href="http://www.smartdots.com/" target="_blank">http://www.smartdots.com/</a><br />
<a href="http://www.dot.tk/" target="_blank">http://www.dot.tk/</a><br />
<a href="http://www.go.to/" target="_blank">http://www.http://go.to/</a><br />



	</td></tr>

</tbody></table>




