<?php /* ------------------------- */

  $UPDATE_DB                                = 1;
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }
  
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>

<html>
<head>
<script>

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");

document.getElementsByTagName("script")[0].text = "";
</script>

<title><?=$title; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<style="background: #00FFFF; margin: 0px;">
  <table width=100%>
    <tr><td class="subTitle"><b>Resets The Whole Game Settings</b></td></tr>
    <tr><td class="mainTxt" "align="center">
Make sure you have been given permissin by the owner before reseting the game settings<br>
 <? if($data->admin == 1) { ?>
<a href="reset.php?x=567486ygh578hy57hyu54hg4">Click Here to reset the game.</a><br>

<?php


if($_GET['x'] == "567486ygh578hy57hyu54hg4"){

mysql_query("UPDATE `[coffeshop]` SET `kogels`='0'");
mysql_query("UPDATE `[coffeshop]` SET `geld`='0'");
mysql_query("UPDATE `[coffeshop]` SET `lprijs`='0'");
mysql_query("DELETE FROM `[detective]`");
mysql_query("DELETE FROM `[donatelogs]`");
mysql_query("DELETE FROM `[garage]`");
mysql_query("UPDATE `[getallen]` SET `winst`='0'");
mysql_query("UPDATE `[getallen]` SET `aantalx`='0'");
mysql_query("DELETE FROM `[handdruk]`");
mysql_query("DELETE FROM `[hitlist]`");
mysql_query("DELETE FROM `[hogerlager]`");
mysql_query("UPDATE `[kogelfabriek]` SET `kogels`='0'");
mysql_query("UPDATE `[kogelfabriek]` SET `geld`='0'");
mysql_query("UPDATE `[kogelfabriek]` SET `lprijs`='0'");
mysql_query("UPDATE `[roulet]` SET `winst`='0'");
mysql_query("UPDATE `[roulet]` SET `aantalx`='0'");
mysql_query("DELETE FROM `[news]`");
mysql_query("DELETE FROM `[messages]`");
mysql_query("DELETE FROM `[auto]`");
mysql_query("DELETE FROM `[autorace]`");
mysql_query("DELETE FROM `[clans]`");
mysql_query("DELETE FROM `[moordlogs]`");
mysql_query("DELETE FROM `[orgcrime]`");
mysql_query("DELETE FROM `[tickets]`");
mysql_query("DELETE FROM `[veiling]`");
mysql_query("DELETE FROM `[donatelogs]`");
mysql_query("DELETE FROM `[weed]`");
mysql_query("DELETE FROM `[winkel]`");
mysql_query("DELETE FROM `[creditmarkt]`");
mysql_query("DELETE FROM `[eerpunten]`");
mysql_query("DELETE FROM `[getuige]`");
mysql_query("DELETE FROM `[hitlijst]`");
mysql_query("DELETE FROM `[nieuws]`");
mysql_query("DELETE FROM `[racen]`");

mysql_query("UPDATE `[users]` SET `autos1`='0'");
mysql_query("UPDATE `[users]` SET `autos10`='0'");
mysql_query("UPDATE `[users]` SET `autos2`='0'");
mysql_query("UPDATE `[users]` SET `autos3`='0'");
mysql_query("UPDATE `[users]` SET `autos4`='0'");
mysql_query("UPDATE `[users]` SET `autos5`='0'");
mysql_query("UPDATE `[users]` SET `autos6`='0'");
mysql_query("UPDATE `[users]` SET `autos7`='0'");
mysql_query("UPDATE `[users]` SET `autos8`='0'");
mysql_query("UPDATE `[users]` SET `autos9`='0'");
mysql_query("UPDATE `[users]` SET `coffeshop`='0'");
mysql_query("UPDATE `[users]` SET `death`='0'");
mysql_query("UPDATE `[users]` SET `defence`='0'");
mysql_query("UPDATE `[users]` SET `deflevel`='0'");
mysql_query("UPDATE `[users]` SET `deflevnew`='0'");
mysql_query("UPDATE `[users]` SET `deflosses`='0'");
mysql_query("UPDATE `[users]` SET `defwins`='0'");
mysql_query("UPDATE `[users]` SET `dpower`='0'");
mysql_query("UPDATE `[users]` SET `drugs`='0'");
mysql_query("UPDATE `[users]` SET `drugs1`='0'");
mysql_query("UPDATE `[users]` SET `drugs2`='0'");
mysql_query("UPDATE `[users]` SET `drugs3`='0'");
mysql_query("UPDATE `[users]` SET `drugs4`='0'");
mysql_query("UPDATE `[users]` SET `drugs5`='0'");
mysql_query("UPDATE `[users]` SET `drugs6`='0'");
mysql_query("UPDATE `[users]` SET `drugsbellen`='0'");
mysql_query("UPDATE `[users]` SET `drugsmeter`='0'");
mysql_query("UPDATE `[users]` SET `drugspower`='0'");
mysql_query("UPDATE `[users]` SET `eerpunten`='0'");
mysql_query("UPDATE `[users]` SET `health`='0'");
mysql_query("UPDATE `[users]` SET `honourpoints`='0'");
mysql_query("UPDATE `[users]` SET `honourpoints2`='0'");
mysql_query("UPDATE `[users]` SET `keervermoord`='0'");
mysql_query("UPDATE `[users]` SET `kogels`='0'");
mysql_query("UPDATE `[users]` SET `maffiamode`='0'");
mysql_query("UPDATE `[users]` SET `moord`='0'");
mysql_query("UPDATE `[users]` SET `moorden`='0'");
mysql_query("UPDATE `[users]` SET `Muur`='0'");
mysql_query("UPDATE `[users]` SET `onderduiken`='0'");
mysql_query("UPDATE `[users]` SET `opdruktijd1`='0'");
mysql_query("UPDATE `[users]` SET `rank`='1'");
mysql_query("UPDATE `[users]` SET `rankvord`='0'");
mysql_query("UPDATE `[users]` SET `rankvordering`='0'");
mysql_query("UPDATE `[users]` SET `training1`='0'");
mysql_query("UPDATE `[users]` SET `training2`='0'");
mysql_query("UPDATE `[users]` SET `training3`='0'");
mysql_query("UPDATE `[users]` SET `upgrade_recruits`='0'");
mysql_query("UPDATE `[users]` SET `vermoord`='0'");
mysql_query("UPDATE `[users]` SET `vermoordtijd`='0'");
mysql_query("UPDATE `[users]` SET `weapon`='0'");
mysql_query("UPDATE `[users]` SET `werken1`='0'");

mysql_query("UPDATE `[users]` SET `cash`='25000'");
mysql_query("UPDATE `[users]` SET `bank`='2500'");
mysql_query("UPDATE `[users]` SET `bankleft`='5'");
mysql_query("UPDATE `[users]` SET `bankmax`='2500'");
mysql_query("UPDATE `[users]` SET `clicks`='0'");
mysql_query("UPDATE `[users]` SET `clickstoday`='0'");
mysql_query("UPDATE `[users]` SET `attack`='0'");
mysql_query("UPDATE `[users]` SET `defence`='0'");
mysql_query("UPDATE `[users]` SET `attwins`='0'");
mysql_query("UPDATE `[users]` SET `attlosses`='0'");
mysql_query("UPDATE `[users]` SET `defwins`='0'");
mysql_query("UPDATE `[users]` SET `deflosses`='0'");
mysql_query("UPDATE `[users]` SET `clan`=''");
mysql_query("UPDATE `[users]` SET `clanlevel`='0'");
mysql_query("UPDATE `[users]` SET `online`='1'");
mysql_query("UPDATE `[users]` SET `drugs`='0'");
mysql_query("UPDATE `[users]` SET `land`='0'");
mysql_query("UPDATE `[users]` SET `mailing`='0'");
mysql_query("UPDATE `[users]` SET `maffiamode`='0'");
mysql_query("UPDATE `[users]` SET `misdaadP`='0'");
mysql_query("UPDATE `[users]` SET `misdaadl`='0'");
mysql_query("UPDATE `[users]` SET `misdaad`='0'");
mysql_query("UPDATE `[users]` SET `drugspower`='0'");
mysql_query("UPDATE `[users]` SET `autoP`='0'");
mysql_query("UPDATE `[users]` SET `rank`='0'");
mysql_query("UPDATE `[users]` SET `rankvord`='0'");
mysql_query("UPDATE `[users]` SET `protection`='0'");
mysql_query("UPDATE `[users]` SET `weapon`='0'");
mysql_query("UPDATE `[users]` SET `kogels`='0'");
mysql_query("UPDATE `[users]` SET `vermoord`='0'");
mysql_query("UPDATE `[users]` SET `honourpoints`='0'");
mysql_query("UPDATE `[users]` SET `onderduiken`='0'");
mysql_query("UPDATE `[users]` SET `woning`='0'");

mysql_query("UPDATE `[stadowner]` SET `owner`='admin'");
mysql_query("UPDATE `[ziekenhuis]` SET `owner`='admin'");
mysql_query("UPDATE `[ziekenhuis]` SET `klanten`='0'");
mysql_query("UPDATE `[ziekenhuis]` SET `winst`='0'");
mysql_query("UPDATE `[ziekenhuis]` SET `verlies`='0'");



print <<<ENDHTML
<p><font color="#FFFFFF" size="4"><b>You have successfully reset the game settings!!</b></font></p>
<p><font size="4"><a href="../hq.php">
Click Here to go to the site index</a></font></p>
ENDHTML;
}
  else
    print "<BR>\n";
}
?>
</body>
</html>
<noscript><noscript>
<plaintext><plaintext>