<?php 


  include('../_include-config.php');

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }
  
 $sql = mysql_query("SELECT * FROM `[users]` WHERE `online`='00-00-0000 00:00'");
 $taak = mysql_num_rows($sql);

 $sql3 = mysql_query("SELECT * FROM `[users]` WHERE `vip`='1'");
 $vip = mysql_num_rows($sql3); 

 $sql2 = mysql_query("SELECT * FROM `[users]` WHERE `attack`+`defence` < 500");
 $slecht = mysql_num_rows($sql2);
?>

<html>
<head>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>




</head>

</font>

<table align=center width=100%>
  <tr><td class=subTitle><font color="#000000"><b>Admin Stats</b></font></td></tr>
  <tr><td class=mainTxt>

<b><?php echo $taak; ?> </b>leden zijn nog nooit ingelogd
<br>
<b><?php echo $vip; ?> </b> leden zijn V.I.P
<br>
<b><?php echo $slecht; ?> </b>leden hebben minder power dan 500
<br>
<br>
<b><a href="spelerstats.php?x=1">klik hier</a></b> om alle leden te verwijderen die nooit zijn ingelogd
<br>
<b><a href="spelerstats.php?x=2">klik hier</a></b> om alle leden te verwijderen met minder dan 500 power
</tr>
</table>

<?PHP

 if($_GET['x'] =="1")
 {
   echo 'ok, gedaan';
   mysql_query("DELETE FROM `[users]` WHERE `online`='00-00-0000 00:00'");
 }

?>