<?php /* ------------------------- */

  $OMNILOG				= 1;
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }


  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }


  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>


<head>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>
<body>


<BODY onLoad="movein()">
<?php

if($_GET['bekijk']){
print'<table width="90%" border=1 align="center">
<tr><td class="subTitle" width="30%">Date<td class="subTitle" width="40%">Subject <td class="subTitle" width="30%">Message';
$mijntickets = mysql_query("SELECT * FROM tickets");
while($mijnticket = mysql_fetch_object($mijntickets)){
print '<tr><td class="mainTxt" width="30%">'.$mijnticket->datum.'<td class="mainTxt" width="40%">'.$mijnticket->onderwerp.' ( '.$mijnticket->afzender.' )<td class="mainTxt" width="30%"><a href="ticketadmin.php?bekijk=ja&&show='.$mijnticket->id.'"> Message </a>';
}
print '</table>';

if($_GET['show']){
print "";
$showen = mysql_query("SELECT * FROM tickets WHERE id='{$_GET['show']}'");
$showa = mysql_fetch_object($showen);

print '<table width="90%" border=1 align="center"><tr><td class="subTitle">
Message<tr><td class="mainTxt">'.$showa->bericht.'</table> ';

print '<table width="90%" border=1 align="center"><tr><td class="subTitle">
Reply
<tr><td class="mainTxt">'.$showa->antwoord.' </table>';

}

exit;
}





$tickets = mysql_query("SELECT * FROM `tickets` WHERE antwoord='' ORDER BY `datum` DESC");
print '<table width="90%" border=1 align="center">';
print '<tr><td class="subTitle" width="20%">Subject<td class="subTitle" width="20%">Date<td class="subTitle" width="20%"> From <td class="subTitle" width="20%"> Offencive Player <td class="subTitle" width="20%"> Option';
while($ticket = mysql_fetch_object($tickets)){


if($ticket->antwoord == ""){
$bold = '<b>';
$bold1 = '</b>';
}

if($ticket->ban == "on"){
$image = '<img src="_.bmp">';
}

print '<tr><td class="MainTxt" width="20%">'.$image.'<a href="ticketadmin.php?edit='.$ticket->id.'">'.$ticket->onderwerp.'<td class="MainTxt" width="20%">'.$ticket->datum.'<td class="MainTxt" width="20%">'.$ticket->afzender.'<td class="MainTxt" width="20%">'.$ticket->naam.'<td class="mainTxt" width="20%">'.$ticket->optie.'';

}
print '</table>';

if($_GET['edit']){
$antwoorden = mysql_query("SELECT * FROM tickets WHERE id='{$_GET['edit']}'");
$antwoord = mysql_fetch_object($antwoorden);
print '<table width="90%" align="center" border="1"><tr><td class="mainTxt">'.$antwoord->bericht.'
<tr><td class="mainTxt">
<form method="post">
<textarea cols=40 rows=10 name="antwoor">
</textarea><br>
<input type="submit" name="antwoord" value="Reply">
</form>
</table>
';
if($_POST['antwoord']){
print 'You have replied to the ticket';
             mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$page->sitetitle','{$antwoord->afzender}','Ticket','Enter your reply in here!')");
$antwoor = $_POST['antwoor'];
mysql_query("UPDATE `tickets` SET ban='off',antwoord='$antwoor' WHERE id='$antwoord->id'");
}
}
print '<table width="90%" border=1 align="center"><tr><td class="mainTxt"><a href="ticketadmin.php?bekijk=ja" >Click Here to view all messages</a> </table>';
print '<table width="90%" border=1 align="center"><tr><td class="mainTxt"><a href="veranderstatus.php" ></a> </table>';




?>
</body>
</html>
