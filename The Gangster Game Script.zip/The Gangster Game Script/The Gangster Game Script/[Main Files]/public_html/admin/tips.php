<?php
ob_start();
  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }

?>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

Tips en trucks<br /><br />

<u><b>Geld Verdienen Met Uw Site</b></u><br /><br />
Om echt geld te verdienen voor iedere bellende speler moet u eerst<BR />
uw Mollie ID invullen.<BR />
<a href="admin-mollie.php"><b>Klik hier om direct uw Mollie ID in te vullen en bekijk de handleiding</b></a>
 <BR /><BR />
 
 <u><b>Verander De Game Naam</b></u><br /><br />
Maak uw game persoonlijker en wijzig nu direct uw game naam.<BR />
<a href="admin-sitetitel.php"><b>Klik hier om direct uw game naam te wijzigen</b></a>
 <BR /><BR />
 
 <u><b>Maak Een Hulpadmin Aan</b></u><br /><br />
Geef een vriend of vriendin administrator rechten zodat die u kunt helpen met uw game.<BR />
Een hulpadmin heeft niet tot alles toegang. U kunt ook u zelf hulpadmin maken om te<BR />
kijken welke rechten een hulpadmin heeft<BR />
<a href="maakhulpadmin.php"><b>Klik hier om direct iemand hulpadmin te maken</b></a>
 <BR /><BR />

<u><b>Subdomein aanmaken</b></u><br /><br />
Om gratis een eigen domein naam op te zetten welke goed onthouden kan worden door <BR />
uw spelers, kunt u een subdomein ( of meerdere ) opzetten <BR /><BR />

Om uw site een kortere naam te geven zoals bijvoorbeeld: www.uwnaam.tk <BR />
doet u het volgende<br /><br />

Kies een van de onderstaande websites. Volg de stappen en registreer direct uw <BR />
eigen subdomein voor uw website. Dit is stap 1 naar een professionele crimegame<br /><br />

<a href="http://www.joynic.com/" target="_blank">http://www.joynic.com/</a><br />
<a href="http://www.smartdots.com/" target="_blank">http://www.smartdots.com/</a><br />
<a href="http://www.dot.tk/" target="_blank">http://www.dot.tk/</a><br />
<a href="http://www.go.to/" target="_blank">http://www.http://go.to/</a><br />
<a href="http://www.webalias.com" target="_blank">http://www.webalias.com</a><br />
<a href="http://www.freedomain.co.nr/" target="_blank">http://www.freedomain.co.nr/</a><br />
<a href="http://www.freeurl.com" target="_blank">http://www.freeurl.com</a><br />

<BR /><BR />
<u><b>Website promotie</b></u><br /><br />
Om uw website bij zoveel mogelijk zoekmachines aan te melden hebben wij voor <BR />
u een zo groot mogelijk aanbod aanmeld websites en programma's verzameld. Door<BR />
uw website bij zoekmachines aan te melden vergroot u het aantal bezoekers voor <BR />
uw website. Om uw site aan te melden op een zoekmachine gaat u naar 1 van de <BR />
onderstaande websites.<br /><br />

Nederlands talig<br /><br />

<a href="http://members.home.nl/zennipman/promoot.html" target="_blank">http://members.home.nl/zennipman/promoot.html</a><br /><br />

Engels talig <br /><br />

<a href="http://www.addurlfree.com/" target="_blank">http://www.addurlfree.com/</a><br />
<a href="http://www.google.com/addurl/?continue=/addurl" target="_blank">http://www.google.com/addurl/?continue=/addurl</a><br /><br />

U kunt tevens gebruik maken van software om uw website gratis aan te melden. <BR />
Hiervoor dient u een geschikt submit programma te downloaden. Enkele gratis programma's vindt u op:<br /><br />

<a href="http://www.download.com/3120-20_4-0.html?tg=dl-20&qt=url%20submit&tag=srch" target="_blank">http://www.download.com/3120-20_4-0.html?tg=dl-20&qt=url%20submit&tag=srch</a>




