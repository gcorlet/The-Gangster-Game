<?php 

  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }


?>
<?PHP
if($_POST['message23']){
echo 'Remove all Messages';
mysql_query("DELETE FROM `[messages]`");
}
?>
<?PHP
if($_POST['message22']){
echo 'Remove All read Messages';
mysql_query("DELETE FROM `[messages]` WHERE `read`='1'");
}
?>
<?PHP
if($_POST['message24']){
echo 'Remove All Messages in Outbox';
mysql_query("DELETE FROM `[messages]` WHERE `outbox`='1'");
}
?>
<?PHP
if($_POST['kutus']){
echo 'Optimize User Table';
 mysql_query("OPTIMIZE TABLE `[users]`");
}
?>
<?PHP
if($_POST['ber']){
echo 'Optimize Messages Table';
 mysql_query("OPTIMIZE TABLE `[messages]`");
}
?>
<?PHP
if($_POST['optimalclans']){
echo 'Optimize Clan Table';
 mysql_query("OPTIMIZE TABLE `[clans]`");
}
?>
<html>
<head>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 


</head>

  <table width=100%>
    <tr><td class="subTitle"><b>Tools</b></td></tr>
    <tr><td class="mainTxt" "align="center">
<center>
<FORM METHOD=post ACTION="">
<b><font face="Verdana" size="2"><font color=orange>Welcome to the tools page!<br>
</font></b><br>
<center>
<tr><td class="MainTxt"><center><INPUT style="width: 230;" name="kutus" style="width: 230;"type="submit" size=200 VALUE="Optimize [users] Table"></center></td></tr>
<tr><td class="MainTxt"><center><INPUT name="optimalclans" type="submit" style="width: 230;" size=200 VALUE="Optimize [clans] Table"></center></td></tr>
<tr><td class="MainTxt"><center><INPUT name="ber" size=200 style="width: 230;" type="submit" size=200 VALUE="Optimize [messages] Table"></center></td></tr>
<tr><td class="MainTxt"><center><INPUT name="eer" type="submit"  style="width: 230;" VALUE="Give Honour Points" width=30%></center></td></tr>
<tr><td class="MainTxt"><center><INPUT name="submit4" type="submit" style="width: 230;" VALUE="Remove Temp Files"></center></td></tr>
<tr><td class="MainTxt"><center><INPUT name="message23" type="submit"  style="width: 230;"  VALUE="Remove all Messages"></center></td></tr>
<tr><td class="MainTxt"><center><INPUT name="message22" type="submit" style="width: 230;" VALUE="Remove all READ Messages"></center></td></tr>
<tr><td class="MainTxt"><center><INPUT name="submit7" type="submit" style="width: 230;" VALUE="Remove Attack Logs" width=30%></center></td></tr>
<tr><td class="MainTxt"><center><INPUT name="submit8" type="submit" style="width: 230;" VALUE="Remove Donate Logs" width=30%></center></td></tr>
<br></FORM>
</center>
<?PHP
echo "

</body>
</font>
</html>";
?>

<?PHP
if (isset($_POST['submit1'])) {
$insert = "UPDATE `[users]` SET `activated` = '1'";
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error());
    print <<<ENDHTML


<html>


<head>

<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>Activate anyone who has not already been activated!!!
	</center>
    </td></tr>
  </table>
</body>

</html>
<noscript><noscript><plaintext><plaintext>
ENDHTML;
    exit;
}
?>
<?PHP
if (isset($_POST['loterij'])) {
include('../lottrek.php');
    print <<<ENDHTML


<html>


<head>

<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>The lottery has been Drawn!
	</center>
    </td></tr>
  </table>
</body>

</html>
<noscript><noscript><plaintext><plaintext>
ENDHTML;
    exit;
}
?>
<?PHP
if(isset($_POST['eer'])) {
if($data->rank ==0){
 $aantal = 0;
 }
 if($data->rank ==1){
 $aantal = 0;
 }
 if($data->rank ==2){
 $aantal = 0;
 }
 if($data->rank ==3){
 $aantal = 2;
 }
 if($data->rank ==4){
 $aantal = 3;
 }
 if($data->rank ==5){
 $aantal = 5;
 }
 if($data->rank ==6){
 $aantal = 7;
 }
 if($data->rank ==7){
 $aantal = 9;
 }
 if($data->rank ==8){
 $aantal = 10;
 }
 if($data->rank ==9){
 $aantal = 11;
 }
 if($data->rank ==10){
 $aantal = 13;
 }
 if($data->rank ==11){
 $aantal = 15;
 }
 if($data->rank ==12){
 $aantal = 20;
 }
 if($data->rank ==13){
 $aantal = 25;
 }
 if($data->rank ==14){
 $aantal = 30;
 }
 if($data->rank ==15){
 $aantal = 35;
 }
 if($data->rank ==16){
 $aantal = 40;
 }
 if($data->rank ==17){
 $aantal = 45;
 }
 if($data->rank ==18){
 $aantal = 50;
 }
 if($data->rank ==19){
 $aantal = 60;
 }
 else {
 $aantal = 75;

 mysql_query("UPDATE `[users]` SET `honourpoints`=`honourpoints`+'75'");
    print <<<ENDHTML


<html>


<head>

<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>Honours Given
	</center>
    </td></tr>
  </table>
</body>

</html>
<noscript><noscript><plaintext><plaintext>
ENDHTML;
    exit;
}
?>

<?PHP
if (isset($_POST['submit2'])) {
$insert = "DELETE FROM `[messages]`";
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error());
    print <<<ENDHTML


<html>


<head>

<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have removed the messages.
	</center>
    </td></tr>
  </table>
</body>

</html>
<noscript><noscript><plaintext><plaintext>
ENDHTML;
    exit;
}
?>
<?PHP
if($POST['message22']){
echo 'Jaja gedaan';
mysql_query("DELETE FROM `[messages]` WHERE `read`='1'");
?>
<?PHP
if(isset($_POST['submit22'])) {
$insert = "DELETE FROM `[messages]` WHERE `read`='1'";
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error());
echo '<html>
<head>
<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">
</head>
  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have removed all read messages
</html>
';
exit;
}
?>
<?PHP
if (isset($_POST['submit3'])) {
$insert = "DELETE FROM `[logs]`";
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error());
    print <<<ENDHTML


<html>


<head>

<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have deleted all the logs
	</center>
    </td></tr>
  </table>
</body>

</html>
<noscript><noscript><plaintext><plaintext>
ENDHTML;
    exit;
}
}
?>
<?PHP
if (isset($_POST['submit4'])) {
$insert = "DELETE FROM `[temp]`";
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error());
    print <<<ENDHTML


<html>


<head>

<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have deleted the Temp Files.
	</center>
    </td></tr>
  </table>
</body>

</html>
<noscript><noscript><plaintext><plaintext>
ENDHTML;
    exit;
}
?>
<?PHP
if (isset($_POST['submit8'])) {
$insert = "DELETE FROM `[donatelogs]`";
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error());
    print <<<ENDHTML


<html>


<head>

<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have removed the donation logs
	</center>
    </td></tr>
  </table>
</body>

</html>
<noscript><noscript><plaintext><plaintext>
ENDHTML;
    exit;
}
?>
<?PHP
if (isset($_POST['submit7'])) {
$insert = "DELETE FROM `[logs]`";
$insert_now = mysql_query($insert) or die("FOUT : " . mysql_error());
    print <<<ENDHTML


<html>


<head>

<link rel="stylesheet" type="text/css" href="../images/template/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have removed the attack logs
	</center>
    </td></tr>
  </table>
</body>

</html>
<noscript><noscript><plaintext><plaintext>
ENDHTML;
    exit;
}
}
?>
</tr></td>
<noscript><noscript><plaintext><plaintext>
</body>