<?php
error_reporting(0);

  $OMNILOG				= 1;
  include("_include-jail.php");
      include("_include-gevangenis.php");
  if(! check_login) {
    header("Location: login.php");
    exit;
    
  }
  
// bezoekers statistieken
$pagename = "Vliegveld";

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
  
$aStaten = array(1 => "Netherlands","France","Cuba","Russia","Australia","USA", "Germany", "Belgium", "England", "Ireland");

/* ------------------------- */ ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>
<body style="background-color:#1a1919;">
<table width=60% align=center style=background-color: transparent; border: 0px;>
<?php /* ------------------------- */

 $rResource = mysql_query("SELECT *,UNIX_TIMESTAMP(`rtijd`) AS `rtijd`,0 FROM `[users]` WHERE `login`='".$_SESSION['login']."'");	
 $aRow = mysql_fetch_object($rResource);  
 if($aRow->rtijd + $aRow->rtijden > time())
	{
	$verschil = date("H:i:s",($aRow->rtijd + $aRow->rtijden - time() - 3600));


echo '

	<table cellspacing="1" cellpadding="2" align="center" width=60%>
	<tr><td class="subtitle"colspan="8" align=center><b>Customs Authorities</b></td></tr>
	<tr><td class="maintxt" align="center">
	<br>
	 <p align="center">Your travel time has not finnished</p>
	<p align="center">&nbsp;</p>
	<p align="center">When the timer hits 15.00.00, you can travel again -  <B> '.$verschil.'</B> </p>
	</table>

';

	}
else
	{ 

$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee); 
 

		if($aRow->gevangenis + $aRow->gevangenistijd > time())	{
		$verschil = date("H:i:s",($aRow->gevangenis + $aRow->gevangenistijd - time() - 3600));
		echo '
		<tr><td class="mainTxt" align="center"><p><b>You are sent to prison</b></p>
		<p>&nbsp;</p>
		<p><b>You will be released in<B>'.$verschil.'</B> seconds </b></p></td></tr></table>';
		}
	else
		{
		if($_SERVER['REQUEST_METHOD'] == 'POST')
			{
if($_POST['code2'] != $_POST['codenn']) {
print "<tr><td class=subTitle><b>Travel</b></td></tr>";
print "<tr><td class=mainTxt align=center>The code is incorrect!</td></tr>";

}
	elseif($_POST['iReis'] < '0')
			{ print " <tr><td class=mainTxt colspan=3><font color=red></font></td></tr>"; }
			elseif($_POST['iReis'] > '10')
				{ echo 'No valid country given.'; }
			elseif(!eregi('[0-9]{1}',$_POST['iReis']) || $_POST['iReis'] > count($aStaten))
				{ echo 'No valid country given.'; }
			elseif($data->cash <5000)
				{ echo 'Not enough money!'; }				
						else
				{

				$sQueryUpdate = "UPDATE `[users]` SET `land` = ".$_POST['iReis'].", `cash` = `cash`-5000,`rtijd` = NOW(),`rtijden`= 1800 WHERE `login` = '".$data->login."'";
				if(!@mysql_query($sQueryUpdate)){

				 echo 'Trying to travel abroad has failed!'; 
						}

				else
					{
					?>
					<table cellspacing="1" cellpadding="2" align="center" width=60%>
					<tr><td class='subtitle' align=center><b>Welcome</b></td></tr>
					<tr><td  class='maintxt'><center>

					<p align="center">You have flown to another country.</p><br>
					<p align="center">Welcome to <b><?= $aStaten[$_POST['iReis']]; ?></b></p><br>
					<?php
					}
				}
			}
		else
			{
		
			?>
			<form method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
<table width='60%' cellpadding='2' cellspacing='1' align='center' >
				<tr>
					<td class=subtitle colspan="5" align="center"><b>Travel</b></td>
					
				</tr>
<tr>
<td class="mainTxt" colspan="4">Flights cost <b>5.000</b>,you can fly every half an hour.</td>
</tr>
				<tr>
					<td class=maintxt align=center><b>Land</b></td>
					<td class=maintxt align=center><b>President</b></td>
                                        <td class=maintxt align=center><b>Citezens</b></td>
					<td class=maintxt align=center><b>Selection</b></td>
				</tr>
			<?php
			foreach($aStaten as $iKey => $sValue)
				{
				$sQuery = "SELECT COUNT(`id`) FROM `[users]` WHERE `land` = ".$iKey; 
				$iCount = mysql_result(mysql_query($sQuery),0);
		  $dbres                = mysql_query("SELECT * FROM `[stadowner]` WHERE `land` = '$iKey'");
    $aantal                = mysql_fetch_object($dbres);
			 if($aantal->owner == "") {
	$presi  = None;
  } else {
 	$presi = $aantal->owner;
  }

				?>
				<tr>
					<td class=maintxt><?= $sValue;  ?></td>
					<td class=maintxt><?= $presi ; ?></td>
<td class=maintxt><?= $iCount; ?>
					<td class=maintxt align="center"><input type="radio" class="btn btn-info" name="iReis" value="<?= $iKey; ?>" /></td>
                                                                                
				</tr>
				<?php
				}
			?>



                         <?php
			foreach($aStaten as $iKey => $sValue)
				{
				$sQuery = "SELECT COUNT(`id`) FROM `[users]` WHERE `land` = ".$iKey; 
				$iCount = mysql_result(mysql_query($sQuery),0);
				?>
				
				<?php
				}
			?>
			<tr>
<tr><td class="mainTxt" colspan="4" align="center"><input name="code2" type="hidden" class="btn btn-info" value="<? echo $codene; ?>"><input name="codecheck" type="hidden" value="<? echo $codechecker; ?>"><img alt="Anti-Bot Beveiliging" src="coden.php?security=<? echo $codee; ?>" style="position: relative; top: 4;">  <- Put this code, in here -> <input name="codenn" class="btn btn-info" maxlength="4" size="5" valign="center"></td></tr>
<tr><td class="mainTxt" colspan="4" align="center"><input class="btn btn-info" type="submit" value="Travel"></td></tr>

			</tr>
		</table>
		</form>
		<?php
		}
	}
}
mysql_close();
?>
</body>
</html>