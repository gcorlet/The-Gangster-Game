<?php
error_reporting(0);

  $OMNILOG                = 1; 
  include("_include-jail.php"); 
      include("_include-gevangenis.php");
  if(! check_login()) { 
    header("Location: login.php"); 
    exit; 
  }

  
$kansfiat       = rand(1, 10);
$kansford       = rand(1, 20);
$kanscitroen    = rand(1, 30);
$kansmaserati   = rand(1, 40);
$kansferrari    = rand(1, 50);  

$profiat			= rand(20, 40);
$proford			= rand(15, 30);
$procitroen		    = rand(10, 20);
$promaserati		= rand(8, 15);
$proferrari		    = rand(5, 10);



 if($data->overval == 0){
    print <<<ENDHTML




<html>
<head>

<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>


<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<center><table width=50%>
    <tr><td class="subTitle"><b>Assault</b></td></tr>
    <tr><td class="mainTxt">
	<center>You have assaulted a store already this hour<BR>Try again soon
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
    exit;
    }
	
	
	
	
	
	
	
	if (isset($_POST['submitfiat'])) {
	if($kansfiat != 5){
    print <<<ENDHTML
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

  <table width=50%>
    <tr><td class="subTitle"><b>Mac Donalds</b></td></tr>
    <tr><td class="mainTxt">
	<center>It all went wrong, you have been arrested and put into prison for 2 minutes. You also lost 2% of your energy.
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='120' WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `overval`='0' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `energie`=`energie`-2 WHERE `login`='{$data->login}'");
    exit;
    }}
	
	
	
	
	
	if (isset($_POST['submitford'])) {
	if($kansford != 5){
    print <<<ENDHTML
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

  <table width=50%>
    <tr><td class="subTitle"><b>Supermarket</b></td></tr>
    <tr><td class="mainTxt">
	<center>FUCK! The cops have got you now. Prison for 4 minutes. And you lost 4% energy.
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='240' WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `overval`='0' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `energie`=`energie`-4 WHERE `login`='{$data->login}'");
    exit;
    }}
	
	
	
	
	
	
	
	
	if (isset($_POST['submitcitroen'])) {
	if($kanscitroen != 5){
    print <<<ENDHTML
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
  <table width=50%>
    <tr><td class="subTitle"><b>The Media Market</b></td></tr>
    <tr><td class="mainTxt">
	<center>It was not successful. You lost 6% of your energy, and are now banged up in prsion for 6 minutes..
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='360' WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `overval`='0' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `energie`=`energie`-6 WHERE `login`='{$data->login}'");
    exit;
    }}




/* ------------------------- */ ?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

<?
 print <<<ENDHTML

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 


<table align="center" width=40%>
  <tr><td class="subTitle"><b>Assault on Mac Donalds</b></td></tr>
  <tr><td class="mainTxt">

	<center><center>
 <FORM METHOD=post ACTION="">


<h5>An Assault on MaC Donalds will get you: <br>
$50,000,- in the bank if your successful.<br>
2 Minutes in prison if you fail.<br>
You can only assault once an every hour.</h5>

<INPUT name="submitfiat" type="submit" VALUE="Assault Mac Donalds"></p>
    </td></td>
  </tr>




<center><center>
<table align="center" width=40%>
  <tr><td class="subTitle"><b>Assault on the Supermarket</b></td></tr>
  <tr><td class="mainTxt">
<center><center>
<h5>An Assault on the SuperMarket will get you: <br>
$100,000,- in the bank if your successful.<br>
4 Minutes in prison if you fail.<br>
You can only assault once an every hour.</h5>
<INPUT name="submitford" type="submit" VALUE="Assault the Supermarket"></p>
    </td>
  </tr>
  </table></table>


<table align="center" width=40%>
  <tr><td class="subTitle"><b>Assault on the Media Market</b></td></tr>
  <tr><td class="mainTxt">
<center><center>
<h5>An Assault on The Media Market will get you: <br>
$150,000,- in the bank if your successful.<br>
6 Minutes in prison if you fail.<br>
You can only assult once an every hour.</h5><center>
<INPUT name="submitcitroen" type="submit" VALUE="Assault on the Media Market"></p>
  </tr>
  </table>
 	</table>
  </td></tr>

ENDHTML;
?>
<?PHP


if (isset($_POST['submitfiat'])) {
mysql_query("UPDATE `[users]` SET `overval`='0' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'50000' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=140%>
    <tr><td class="subTitle"><b>Mac Donald Success!</b></td></tr>
    <tr><td class="mainTxt">
	<center>You see the police arrive, but you flee just in time.<br>
	You have succeeded in the Mac Donalds Assault,  50.000,- has gone into your bank. </center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
exit;
}
?>
<?PHP
if (isset($_POST['submitford'])) {
mysql_query("UPDATE `[users]` SET `overval`='0' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'100000' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=40%>
    <tr><td class="subTitle"><b>Supermarket Success!</b></td></tr>
    <tr><td class="mainTxt">
	<center>You see the police arrive, but you flee just in time.<br>
	You have succeeded in the SperMarket Assault,  100.000,- has gone into your bank.  </center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
exit;
}
?>
<?PHP
if (isset($_POST['submitcitroen'])) {
mysql_query("UPDATE `[users]` SET `overval`='0' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'150000' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=40%>
    <tr><td class="subTitle"><b>Media Market Success!</b></td></tr>
    <tr><td class="mainTxt">
	<center>You see the police arrive, but you flee just in time.<br>
	You have succeeded in the Media Market Assault,  150.000,- has gone into your bank.  </center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
exit;
}
?>


</body>