<?php
error_reporting(0);

  include("_include-config.php");
    include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

 $code = rand(1,111333777);

/* ------------------------- */ ?>
<html>


<head>
<title></title>
</head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<table width=100%>
  <tr><td class="subTitle"><b>Attack</b></td></tr>
<?php /* ------------------------- */

	$boksen1           = mysql_query("SELECT *,UNIX_TIMESTAMP(`werken`) AS `werken`,0 FROM `[users]` WHERE `login`='$data->login'");
	$boksen            = mysql_fetch_object($boksen1);
	$tijdverschil1        = $boksen->werken-time() - 12500; 
    $tijdverschil        = date("i:s", "$tijdverschil1"); 
	if($boksen->werken + $boksen->werken1 > time()){
	print "<tr><td class=\"mainTxt\" align=\"center\">You cannot attack for another $tijdverschil seconds, as you are working.</td></tr>";
	}
	elseif(round($data->signup/3600-time()/3600) + 12 <= 0) {
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`attlosses`,`attwins`,`deflosses`,`defwins`,`cash`,`type`,`clan`,`avaurl` FROM `[users]` WHERE `login`='{$_GET['x']}'");
    if($def = mysql_fetch_object($dbres)) {
      if($def->login == $data->login)
        print "  <tr><td class=\"mainTxt\">You stand and take aim... You shoot yourself in the foot... Well you cant miss more than that! Fuckin idiot!.</td></tr>\n";
      else if($def->maffiamode ==1)
        print "  <tr><td class=\"mainTxt\"><center><img src=images/item-bodyguard.gif height=200 width=200><img src=images/item-bodyguard.gif height=200 width=200><img src=images/item-bodyguard.gif height=200 width=200></center><br><font color=red><b>$def->login is currently under the protection of the Mafia!!</b></font> </td></tr>\n";
else if($def->type == 3 && $data->type == 3)
        print "  <tr><td class=\"mainTxt\">Agents may not attack eachother</td></tr>\n";
      else if($def->clan == $data->clan && $def->clan != "")
        print "  <tr><td class=\"mainTxt\">You cannot attack Gang Members</td></tr>\n";
      else if(round($def->signup/3600-time()/3600) + 12 > 0)
        print "  <tr><td class=\"mainTxt\">{$def->login} is under protectiong</td></tr>\n";
      else {
        $dbres				= mysql_query("SELECT * FROM `[logs]` WHERE `login`='{$data->login}' AND `person`='{$def->login}' AND FLOOR(UNIX_TIMESTAMP(`time`)/(60*60*24))=FLOOR(UNIX_TIMESTAMP(NOW())/(60*60*24)) AND `area`='attack'");
        if(($numattacks = mysql_num_rows($dbres)+1) <= 99999999999999999999999999999999999) {
          $dbres			= mysql_query("SELECT * FROM `[logs]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`time`) < -1 AND `login`='{$data->login}' AND `area`='attack'");
          if(mysql_num_rows($dbres) == 0) {
            mysql_query("SELECT GET_LOCK('attack_{$def->login}',25)");
            $result			= (($data->attack+$data->clicks*5)*rand(90,115) >= ($def->defence+$def->clicks*5)*rand(90,115)) ? 1 : 0;
            $money			= ($result == 1) ? (int)($def->cash*rand(40,75)/100) : (int)($data->cash*rand(25,40)/100);
            $text			= ($result == 1) ? Array("You have won","won") : Array("You lose.","lost");
    if($money < 0){
echo '<table width=100%><tr><td class=Maintxt>He pulls a knife and places it against your throat....a puddle of piss appears on the floor<br /><br />He decides to let your sorry ass go';
exit;
}

print <<<ENDHTML

<table align=center width=100%>
  <tr>
    <td class="subTitle">{$data->login}</td>
    <td class="subTitle">vs</td>
    <td class="subTitle">{$def->login}</td>
  </tr>
  <tr>
    <td class="mainTxt"><center><img border="0" src="{$data->avaurl}" width="231" height="221"></center></td>
    <td class="mainTxt">VS</td>
    <td class="mainTxt"><center><img border="0" src="{$def->avaurl}" width="231" height="221"></center></td>
  </tr>
</table>
ENDHTML;

            $forwardedFor		= ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['HTTP_CLIENT_IP'];
            $forwardedFor		= preg_replace('/, .+/','',$forwardedFor);
            mysql_query("INSERT INTO `[logs]`(`time`,`IP`,`forwardedFor`,`login`,`person`,`code`,`area`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','{$data->login}','{$def->login}',($money << 1) | $result,'attack')");
            if($result == 1) {
              mysql_query("UPDATE `[users]` SET `cash`=". ($def->cash-$money) .",`deflosses`=". ($def->deflosses+1) ." WHERE `login`='{$def->login}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'ATTACK','{$def->login}','Attacked','$data->login has attacked you and stolen some of your cash')");
              $data->cash		+= $money;
              $data->attwins++;
              mysql_query("UPDATE `[users]` SET `cash`={$data->cash},`attwins`={$data->attwins} WHERE `login`='{$data->login}'");
           
 }
            else {
              $data->cash		-= $money;
              $data->attlosses++;
              mysql_query("UPDATE `[users]` SET `cash`={$data->cash},`attlosses`={$data->attlosses} WHERE `login`='{$data->login}'");
              mysql_query("UPDATE `[users]` SET `cash`=". ($def->cash+$money) .",`defwins`=". ($def->defwins+1) ." WHERE `login`='{$def->login}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`,`outbox`) values(NOW(),'ATTACK','{$def->login}','Attacked','$data->login has attacked you and you prevailed!! Congratulations!',0)");
            }

    print <<<ENDHTML
<html>


<head>
<title></title>


</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You run at {$def->login} and... {$text[0]}<br>You have {$text[1]} $money...</td></tr>\n
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
            mysql_query("SELECT RELEASE_LOCK('attack_{$def->login}')");
          }
          else {
            $type			= Array("","junkies","klonen","agenten","Terroristen","Gangsters");
            $type			= $type[$data->type];
            $avatar		= $avatar[$data->avatar];
            print "  <tr><td class=\"mainTxt\">$type is still tired from the previous attack...</td></tr>\n";
          }
        }
        else
          print "  <tr><td class=\"mainTxt\">You have attacked {$def->login} 5x this hour...</td></tr>\n";
      }
    }
  }
  else
    print "  <tr><td class=\"mainTxt\">You cannot attack anybody when you stand under protection</td></tr>\n";

/* ------------------------- */ ?>

</table>

</body>
</html><table width=100%>
<tr><td class=Maintxt>
<a href="javascript:history.go(-1)">Back</a>
</tr></td>