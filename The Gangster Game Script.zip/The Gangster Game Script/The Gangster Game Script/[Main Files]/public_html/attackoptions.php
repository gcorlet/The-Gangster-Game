<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack System</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\" class='btn btn-info'>Select an Attack Option</option>
<option value=\"bulletfactory.php\" class='btn btn-info'>Bullet Factory</option>
<option value=\"hospital.php\" class='btn btn-info'>Hospital</option>
<option value=\"attackexp.php\" class='btn btn-info'>Attack Experience</option>
<option value=\"killtrain.php\" class='btn btn-info'>Weapons Training</option>
<option value=\"detectives.php\" class='btn btn-info'>Detective</option>
<option value=\"ckiller.php\" class='btn btn-info'>Murder</option>
<option value=\"hirebodyguard.php\" class='btn btn-info'>Go into Hiding</option>
<option value=\"hitlist.php\" class='btn btn-info'>Hitlist</option>
</select>
</table>
";
}
?> 

<BODY onLoad="movein()">

<body style=" margin: 0px;">
<table align="center" width=100%>
  <tr><td class="subTitle"><b>Attack</b></td></tr>
  <tr><td class="mainTxt"><center>The attack system is ready<BR><BR>Attack Information:<BR>If you are murdered, you cannot play for 2 hours and all the money you have goes to your attacker<br>You can always hire protection for yourself<br> A detective will investigate someone for you<br>You can place someone on the hitlist for a certain ammount of cash<br>Your murder and weapons experience will increase if you murder someone<br> Less bullets willl be needed the higher the experience<br></b>
  </td></tr>
</table>

</body>


</html>