<?php
error_reporting(0);

  $UPDATE_DB				= 1;
  include("_include-config.php");
    include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW(),`page`='Auto Store' WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>
<head>

<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>


<table align=center width=580>
  <tr><td class=mainTxt align=center>




 
<?


if($_GET['b'] == 1) {


	$query = mysql_query("SELECT * FROM `[garage]` WHERE `owner`='$data->login'");			
	$autos2 = mysql_num_rows($query);
	if($data->betaal == 255) {
		$max = 99999;
	}
	else {
		$max = 99999;
	}
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$autos = $_POST['a1']+$autos2;
		$autos4 = $_POST['a1']+$data->autos1;
		$guns = $_POST['a1'];
		$prijs = round($_POST['a1']*10000);
		$aantalautos = round($_POST['a1']*1);
		$aantal	= round($max+$_POST['a1']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You have already bought 20 seat's in total<br> Please return tomorrow!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You can no longer purchase any more cars...<br> until you clear some space in your garage.</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos1`=`autos1`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('1','0','$data->login','$data->land','100','Seat')");
		}
			print "You have bought {$_POST['a1']} Seat('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$autos = $_POST['a2']+$autos2;
		$autos4 = $_POST['a3']+$data->autos2;
		$guns = $_POST['a2'];
		$prijs = round($_POST['a2']*20000);
		$aantalautos = round($_POST['a2']*1);
		$aantal	= round($max+$_POST['a2']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You have already purchased 20 Opel's<br>
Please return tomorrow!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant purchase any more cars..<br>
Please come back tomorrow</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos2`=`autos2`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('2','0','$data->login','$data->land','100','Opel')");
		}
			print "You have bought {$_POST['a2']} Opel('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['3']) && preg_match('/^[0-9]+$/',$_POST['a3'])) {
		$autos = $_POST['a3']+$autos2;
		$autos4 = $_POST['a3']+$data->autos3;
		$guns = $_POST['a3'];
		$prijs = round($_POST['a3']*30000);
		$aantalautos = round($_POST['a3']*1);
		$aantal	= round($max+$_POST['a3']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You have already purchased 20 Nissan's <br> Please return tomorrow!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant buy any more cars<br> Because your garage is full</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos3`=`autos3`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('3','0','$data->login','$data->land','100','Nissan')");
		}
			print "You have bought {$_POST['a3']} Nissan('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['4']) && preg_match('/^[0-9]+$/',$_POST['a4'])) {
		$autos = $_POST['a4']+$autos2;
		$autos4 = $_POST['a4']+$data->autos4;
		$guns = $_POST['a4'];
		$prijs = round($_POST['a4']*40000);
		$aantalautos = round($_POST['a4']*1);
		$aantal	= round($max+$_POST['a4']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You have already bought 20 Fiat's<br> Please return tomorrow!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant buy any more cars<br> Because you have filled up your garage</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos4`=`autos4`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheidauto) values('4','0','$data->login','$data->land','100','Fiat')");
		}
			print "You have bough {$_POST['a4']} Fiat('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['5']) && preg_match('/^[0-9]+$/',$_POST['a5'])) {
		$autos = $_POST['a5']+$autos2;
		$autos4 = $_POST['a5']+$data->autos5;
		$guns = $_POST['a5'];
		$prijs = round($_POST['a5']*50000);
		$aantalautos = round($_POST['a5']*1);
		$aantal	= round($max+$_POST['a5']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You cant purchase any more this type of car because you already have 20!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant purchase anymore cars because your garage is full!</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos5`=`autos5`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('5','0','$data->login','$data->land','100','Ford')");
		}
			print "You have bought {$_POST['a5']} Ford('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['6']) && preg_match('/^[0-9]+$/',$_POST['a6'])) {
		$autos = $_POST['a6']+$autos2;
		$autos4 = $_POST['a6']+$data->autos6;
		$guns = $_POST['a6'];
		$prijs = round($_POST['a6']*60000);
		$aantalautos = round($_POST['a6']*1);
		$aantal	= round($max+$_POST['a6']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You cant purchase any more this type of car because you already have 20!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant purchase anymore mini's because your garage is full!</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos6`=`autos6`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('6','0','$data->login','$data->land','100','Mini')");
		}
			print "You have bought {$_POST['a6']} Mini('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['8']) && preg_match('/^[0-9]+$/',$_POST['a8'])) {
		$autos = $_POST['a8']+$autos2;
		$autos4 = $_POST['a8']+$data->autos8;
		$guns = $_POST['a8'];
		$prijs = round($_POST['a8']*70000);
		$aantalautos = round($_POST['a8']*1);
		$aantal	= round($max+$_POST['a8']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You cant purchase any more this type of car because you already have 20!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant purchase anymore Honda's because your garage is full!</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos8`=`autos8`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('8','0','$data->login','$data->land','100','Honda')");
		}
			print "You have bought {$_POST['a8']} Honda('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['7']) && preg_match('/^[0-9]+$/',$_POST['a7'])) {
		$autos = $_POST['a7']+$autos2;
		$autos4 = $_POST['a7']+$data->autos7;
		$guns = $_POST['a7'];
		$prijs = round($_POST['a7']*80000);
		$aantalautos = round($_POST['a7']*1);
		$aantal	= round($max+$_POST['a7']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You already own 20 Mercedes CLK DTM's!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant purchase anymore cars because your garage is full</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos7`=`autos7`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('7','0','$data->login','$data->land','100','Mercedes CLK')");
		}
			print "You have purchased {$_POST['a7']} Mercedes CLK DTM('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['9']) && preg_match('/^[0-9]+$/',$_POST['a9'])) {
		$autos = $_POST['a9']+$autos2;
		$autos4 = $_POST['a9']+$data->autos9;
		$guns = $_POST['a9'];
		$prijs = round($_POST['a9']*90000);
		$aantalautos = round($_POST['a9']*1);
		$aantal	= round($max+$_POST['a9']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You already own 20 Smart Cars!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant purchase anymore cars because your garage is full!</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos9`=`autos9`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('9','0','$data->login','$data->land','100','SmartCar')");
		}
			print "You have bought {$_POST['a9']} SmartCar('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}

	if(isset($_POST['10']) && preg_match('/^[0-9]+$/',$_POST['a10'])) {
		$autos = $_POST['a10']+$autos2;
		$autos4 = $_POST['a10']+$data->autos10;
		$guns = $_POST['a10'];
		$prijs = round($_POST['a10']*100000);
		$aantalautos = round($_POST['a10']*1);
		$aantal	= round($max+$_POST['a10']);
		$type1 = array("","Gangsters");
		$type  = $type1[$data->type];
		if($autos4 > 20) {
		print "<font color=yellow>You already own 20 Volkswagen's!</font>.\n";
		}
		elseif($max <= $autos) {
		print "<font color=yellow>You cant purchase anymore cars because your garage is full!</font>.\n";
		}
		elseif($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`autos10`=`autos10`+$aantalautos WHERE `login`='$data->login'");
		for($j=1;$j<($guns+1);$j++) {
			mysql_query("INSERT INTO `[garage]`(soort,schade,owner,land,snelheid,auto) values('10','0','$data->login','$data->land','100','Volkswagen')");
		}
			print "You have bought {$_POST['a10']} Volkswagen('s).<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<center><b><font color=red>Here you can purchase a maximum of 20 of each type of car<BR>
If you want a special type of car, you need to get stealing Mr.Gangster Sir!.</font></b></center>
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Seat</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Seat.gif" width="207" height="154"></a></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">10.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos1}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a1" maxlength="2" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="1" value=" Flash the Cash "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Opel</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Opel.gif" width="207" height="154"></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">20.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos2}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="2" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Flash the Cash "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Nissan</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Nissan.gif" width="207" height="154"></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">30.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos3}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a3" maxlength="2" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="3" value=" Flash the Cash"></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Fiat</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Fiat.gif" width="207" height="154"></a></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">40.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos4}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info"  name="a4" maxlength="2" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="4" value=" Flash the Cash"></td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Ford</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Ford.gif" width="207" height="154"></a></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">50.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos5}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a5" maxlength="2" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="5" value=" Flash the Cash"></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Mini</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Mini.gif" width="207" height="154"></a></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">60.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos6}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a6" maxlength="2" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="6" value=" Flash the Cash"></td>
				</tr>
			</table>
		</td>
	</tr>
	
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Mercedes CLK DTM</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Mercedes.gif" width="207" height="154"></a></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">80.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos7}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a7" maxlength="2" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="7" value=" Flash the Cash"></td>
				</tr>
			</table>
		</td>
<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Honda</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Honda.gif" width="207" height="154"></a></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">70.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos8}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" name="a8" class="btn btn-info" maxlength="2" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="8" value=" Flash the Cash"></td>
				</tr>
			</table>
		</td>
	

		
<tr>
	
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>SmartCar</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Smart.gif" width="207" height="154"></a></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">90.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos9}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a9" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="9" value=" Flash the Cash"></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Volkswagen</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/autos/Volkswagen.gif" width="207" height="154"></a></td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">100.000,-</td>
				</tr>
				<tr>
					<td width="100">You have:</td>
					<td width="100">{$data->autos10}</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" name="a10" class="btn btn-info" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="10" value=" Flash the Cash"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
ENDHTML;
}
elseif($_GET['b'] == 6 && $data->betaal != '255') {
print <<<ENDHTML
</td></tr>
<tr><td>
<center><font color=yellow><b>You dont have a Paid Account.</b></font></center>
ENDHTML;
}
elseif($_GET['b'] == 7 && $data->betaal != '255') {
print <<<ENDHTML
</td></tr>
<tr><td>
<center><font color=yellow><b>You dont have a Paid Account.</b></font></center>
ENDHTML;
}
print <<<ENDHTML
</td></tr>
<tr><td>
<table align=center width=580>
  <tr><td class=subTitle><b>Car Dealer</b></td></tr>
  <tr><td class=mainTxt>
	<li><a href="autostore.php?b=1">Car's<br></li></a>
	</tr></td>

</table>
</tr></td>
</table>


ENDHTML;
?></body></html>