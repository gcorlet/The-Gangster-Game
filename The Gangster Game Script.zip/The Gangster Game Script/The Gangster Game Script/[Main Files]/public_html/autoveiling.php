<?php
error_reporting(0);

  $OMNILOG                                = 1; 
  include("_include-config.php"); 
    include("_include-gevangenis.php");

?> 

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<head>
<table width=100%><tr><td class="subTitle"><b>Auction Sale</b></td></tr>
<?php




if(isset($_GET['x'])) {
   $dbres			= mysql_query("SELECT * FROM `[autoveiling]` WHERE `id`='{$_GET['x']}' ");
          $veiling				= mysql_fetch_object($dbres);
 
	$garage        = mysql_query("SELECT * FROM `[garage]` WHERE `id`='$veiling->bel'");
	$garage        = mysql_fetch_object($garage);
$auto = Array('','Seat','Opel','Nissan','Fiat','Ford','Mini','Mercedes','Honda','Smart','Volkswagen','Lotus','Bmw','Dodge','Jeep','Pontiac','------','Eagle','CHrysler','Porsche','Jaguar','Viper','Ferarri','');
$soortauto = $auto[$garage->soort];
if(isset($_POST['bied']) &&  preg_match('/^[0-9]+$/',$_POST['bieden'])) {
          $_POST['bieden'] = htmlspecialchars($_POST['bieden']);
          $_POST['bieden'] = substr($_POST['bieden'],0,11);
$bieden           = $_POST['bieden'];
$oud		=	$veiling->bod;

if($bieden > $data->bank){
 print "<tr><td class=\"mainTxt\">You dont have that much cash in the bank.</td></tr>\n";
exit;
} 

if($bieden <  $oud+100 ){
 print "<tr><td class=\"mainTxt\">You must offer atleast 100 more than the previous offer.</td></tr>\n";
exit;
} 

mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$oud' WHERE `login`='$oudl'");
mysql_query("INSERT INTO `[autoveilinglogs]`(`date`,`bod`,`door`,`id`) values(NOW(),'$bieden','$data->login','$veiling->id')");

mysql_query("UPDATE `[autoveiling]` SET `date`=NOW(),`bod`='$bieden',`door`='$data->login' WHERE `id`='$veiling->id'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`-'$bieden' WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\">Je hebt $bieden geboden.</td></tr>\n";
exit;
}


if(isset($_POST['verwijder'])) {
$oud		=	$veiling->bod;
$oudl		=	$veiling->door;
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$oud' WHERE `login`='$oudl'");
mysql_query("UPDATE `[garage]` SET `owner`='$data->login' WHERE `id`='$veiling->bel'");
	mysql_query("DELETE FROM `[autoveiling]` WHERE `id`='$veiling->id'");
	mysql_query("DELETE FROM `[autoveilinglogs]` WHERE `id`='$veiling->id'");
print "<tr><td class=\"mainTxt\">You have removed your $soortauto from the acution.</td></tr>\n";
exit;
}
if(isset($_POST['verkoop'])) {
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$veiling->bod' WHERE `login`='$data->login'");
mysql_query("UPDATE `[garage]` SET `owner`='$veiling->door' WHERE `id`='$veiling->bel'");
mysql_query("DELETE FROM `[autoveiling]` WHERE `id`='$veiling->id'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`,`outbox`) values(NOW(),'** SOLD **','{$veiling->door}','SOLD','$data->login has sold the $soortauto to you!. ',0)");
  	mysql_query("DELETE FROM `[autoveilinglogs]` WHERE `id`='$veiling->id'");       

print "<tr><td class=\"mainTxt\">You have sold your $soorauto for $veiling->door.</td></tr>\n";
exit;
}


print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	<table>
	<tr><td colspan="2" width="300" align="center"><img src="images/autos/{$soortauto}.gif" width="200" height="150" border="1"></td></tr>
	<tr><td width=200>Owner:</td>		<td align="right" width="100"><a href="profile.php?x=$veiling->naam">$veiling->naam</a></td></tr>
	<tr><td width=200>Car:</td>			<td align="right" width="100">$soortauto</td></tr>
	<tr><td width=200>Car Damage:</td>		<td align="right" width="100">{$garage->schade}%</td></tr>
	<tr><td width=200>Up for Sale Since:</td>	<td align="right" width="100">{$veiling->date2}</td></tr>
ENDHTML;
print"</table></table>";
if($veiling->text != ""){ 

print <<<ENDHTML
<table width=100%><tr><td class="subTitle"> Info</td>	</tr>
<tr><td class="mainTxt" align="center">{$veiling->text}</td></table>	
ENDHTML;
}


print <<<ENDHTML

<table width=100%>
<td class="subTitle" align="center" width=33%> Player</td><td class="subTitle" align="center" width=33%>Offer</td><td class="subTitle" align=center width=33%>Date</td></tr>
ENDHTML;

	$select23 = mysql_query("SELECT * FROM `[autoveilinglogs]`WHERE id=$veiling->id  ORDER BY date DESC LIMIT 5");
	while($list = mysql_fetch_object($select23)) {

print <<<ENDHTML


 <td class="mainTxt" align="center" width=33%> <a href='profile.php?x=$list->door'>$list->door</a></td> <td class="mainTxt" align="center" width=33%> $list->bod</td>
<td class="mainTxt" align="center" width=33%> $list->date</td></tr>

ENDHTML;
}
if($veiling->door == ""){
print"</table><table width=100%><tr><td class=mainTxt>There are no offers yet on that car</td></tr></table>";
}

if($data->login != $veiling->naam && $data->login != $veiling->door){
$bod = $veiling->bod+100;
print <<<ENDHTML

<table width=100%><tr><td class="subTitle"> Offer:</td></tr><form method="post">
<tr><td class="mainTxt" align="center"> <input id="bieden" name="bieden" maxlength="11" value="$bod"><input style="width: 100;" type="submit" name="bied" value="Offer"></td>	</tr>
</form>
ENDHTML;
}
if($data->login == $veiling->naam){
print <<<ENDHTML
<table width=100%><tr><td class="subTitle"> Options</td></tr>
ENDHTML;

print <<<ENDHTML
<tr><td class="mainTxt" align="center"><form method="post">
<input type="submit" name="verwijder" style="width: 400;" value="Remove your offer for $soortauto">
</form>
ENDHTML;

$tijd	=	time() + 3600;
if($veiling->door != "" ){
print <<<ENDHTML
<form method="post"><input type="submit" name="verkoop" style="width: 400;" value="Sell $soortauto for the offer of $veiling->door. Voor $veiling->bod">
</form></td></tr>
ENDHTML;
}



}
exit;
}

if(isset($_GET['A'])) {
$auto = Array('','Seat','Opel','Nissan','Fiat','Ford','Mini','Mercedes','Honda','Smart','Volkswagen','Lotus','Bmw','Dodge','Jeep','Pontiac','------','Eagle','CHrysler','Porsche','Jaguar','Viper','Ferarri','');
$soortauto = $auto[$_GET['A']];
    $select = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 1 AND id != '0'");
    $aantal = mysql_num_rows($select);
    $select2 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 2 AND id != '0'");
    $aantal2 = mysql_num_rows($select2);
    $select3 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 3 AND id != '0'");
    $aantal3 = mysql_num_rows($select3);
    $select4 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 4 AND id != '0'");
    $aantal4 = mysql_num_rows($select4);
	$select5 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 5 AND id != '0'");
    $aantal5 = mysql_num_rows($select5);
	$select6 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 6 AND id != '0'");
    $aantal6 = mysql_num_rows($select6);
	$select7 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 7 AND id != '0'");
    $aantal7 = mysql_num_rows($select7);
    $select8 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 8 AND id != '0'");
    $aantal8 = mysql_num_rows($select8);
    $select9 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 9 AND id != '0'");
    $aantal9 = mysql_num_rows($select9);
    $select10 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 10 AND id != '0'");
    $aantal10= mysql_num_rows($select10);
    $select11 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 11 AND id != '0'");
    $aantal11 = mysql_num_rows($select11);
    $select12 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 12 AND id != '0'");
    $aantal12 = mysql_num_rows($select12);
    $select13 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 13 AND id != '0'");
    $aantal13 = mysql_num_rows($select13);
    $select14 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 14 AND id != '0'");
    $aantal14 = mysql_num_rows($select14);
    $select15 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 15 AND id != '0'");
    $aantal15 = mysql_num_rows($select15);
    $select16 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 16 AND id != '0'");
    $aantal16 = mysql_num_rows($select16);
    $select17 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 17 AND id != '0'");
    $aantal17 = mysql_num_rows($select17);
    $select18 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 18 AND id != '0'");
    $aantal18 = mysql_num_rows($select18);
    $select19 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 19 AND id != '0'");
    $aantal19 = mysql_num_rows($select19);
    $select20 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 20 AND id != '0'");
    $aantal20 = mysql_num_rows($select20);
    $select21 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 21 AND id != '0'");
    $aantal21 = mysql_num_rows($select21);
    $select22 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 22 AND id != '0'");
    $aantal22 = mysql_num_rows($select22);
print <<<ENDHTML

  <tr><td class="mainTxt">
<table width="100%"  border="0" cellspacing="2" cellpadding="2">
    <tr valign="top">

    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=1"><center><b>Seat</b></a></td>
    <td width="20%"><b>$aantal</b></td>
    <td width="20%"><a href="autoveiling.php?A=12"><center><b>BMW</b></a></td>
    <td width="20%"><b>$aantal12</b></td>
        <td width="10%"></td>
    </tr>
    <tr valign="top">
  
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=2"><center><b>Opel</a></td>
    <td width="20%"><b>$aantal2</b></td>
    <td width="20%"><a href="autoveiling.php?A=13"><center><b>Dodge</a></td>
    <td width="20%"><b>$aantal13</b></td>
        <td width="10%"></td>
    </tr>
    <tr valign="top">
  
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=3"><center><b>Nissan</a></td>
    <td width="20%"><b>$aantal3</b></td>
    <td width="20%"><a href="autoveiling.php?A=14"><center><b>Jeep</a></td>
    <td width="20%"><b>$aantal14</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
     
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=4"><center><b>Fiat</a></td>
    <td width="20%"><b>$aantal4</b></td>
    <td width="20%"><a href="autoveiling.php?A=15"><center><b>Pontiac</a></td>
    <td width="20%"><b>$aantal15</b></td>
        <td width="10%"></td>
    </tr>  
      <tr valign="top">
 
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=5"><center><b>Ford</a></td>
    <td width="20%"><b>$aantal5</b></td>
    <td width="20%"><a href="autoveiling.php?A=16"><center><b>----</a></td>
    <td width="20%"><b>$aantal16</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">

    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=6"><center><b>Mini</a></td>
    <td width="20%"><b>$aantal6</b></td>
    <td width="20%"><a href="autoveiling.php?A=17"><center><b>Eagle</a></td>
    <td width="20%"><b>$aantal17</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
  
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=8"><center><b>Honda</a></td>
    <td width="20%"><b>$aantal8</b></td>
    <td width="20%"><a href="autoveiling.php?A=18"><center><b>Chrysler</a></td>
    <td width="20%"><b>$aantal18</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
   
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=7"><center><b>Mercedes</a></td>
    <td width="20%"><b>$aantal7</b></td>
    <td width="20%"><a href="autoveiling.php?A=19"><center><b>Porsche</a></td>
    <td width="20%"><b>$aantal19</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">

    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=9"><center><b>Smart</a></td>
    <td width="20%"><b>$aantal9</b></td>
    <td width="20%"><a href="autoveiling.php?A=20"><center><b>Jaguar</a></td>
    <td width="20%"><b>$aantal20</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
    
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=10"><center><b>Volkswagen</a></td>
    <td width="20%"><b>$aantal10</b></td>
    <td width="20%"><a href="autoveiling.php?A=21"><center><b>Viper</a></td>
    <td width="20%"><b>$aantal21</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
  
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=11"><center><b>Lotus</a></td>
    <td width="20%"><b>$aantal11</b></td>
    <td width="20%"><a href="autoveiling.php?A=22"><center><b>Ferarri</a></td>
    <td width="20%"><b>$aantal22</b></td>
        <td width="10%"></td>
    </tr></td></table></table>
<table align=center width=100%>
  <tr>        <td class=subTitle>
<b>$soortauto</b>

</td></tr>

</table>
<table align=center width=100%>


  <tr>        <td class=subTitle>
        Who</td>
        <td class=subTitle>
        Cars Damage</td>
                <td class=subTitle>
        Current Offer</td>
                 <td class=subTitle>
        Your offer</td>
      </tr>



ENDHTML;


	$garage1  = mysql_query("SELECT * FROM `[autoveiling]` WHERE `soort`='{$_GET['A']}' ");
		while($veiling = mysql_fetch_object($garage1))
            
{



	$garage        = mysql_query("SELECT * FROM `[garage]` WHERE `id`='$veiling->bel'");
	$garage        = mysql_fetch_object($garage);


print <<<ENDHTML
	<form method="post">
        <td  align=center class=mainTxt><a href="profile.php?x=$veiling->naam">$veiling->naam</a></td>
                <td align=center class=mainTxt>$garage->schade%</td>

                <td  align=center class=mainTxt>$veiling->bod</td>
 <td  align=center class=mainTxt><a href="autoveiling.php?x=$veiling->id"><b>Offer/info</b></a></td>
</tr>
        


    
ENDHTML;
}
}

else{

if(isset($_POST['submit']) &&  preg_match('/^[0-9]+$/',$_POST['bel'])) {

     $_POST['inzet'] = substr($_POST['inzet'],0,11);
 $prijs              = $_POST['prijs'];
$bel           = $_POST['bel'];
$info           = $_POST['info'];



$dbres				= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='$data->login' AND `id`='$bel'");
while($rij = mysql_fetch_object($dbres)) {
$id1             = mysql_query("SELECT * FROM `[garage]` WHERE `id`='$bel'");
$id1             = mysql_num_rows($id1);
if($id1->bezig = 1){
 print "<tr><table align=center width=100%><td class=\"mainTxt\">Car is currently unavailable.</td></table></tr>\n";
exit;
}    
if($id1 ==0){
print "<tr><table align=center width=100%><td class=\"mainTxt\">This car is not yours.</td></table></tr>";
exit;
}

$auto = Array('','Seat','Opel','Nissan','Fiat','Ford','Mini','Mercedes','Honda','Smart','Volkswagen','Lotus','Bmw','Dodge','Jeep','Pontiac','------','Eagle','CHrysler','Porsche','Jaguar','Viper','Ferarri','Ford Shelby GT500','Mitsubishi Eclipse GT','Audi Le Mans quattro','Jaguar XK','Lamborghini Gallardo');
$soortauto = $auto[$rij->soort];
 


	$dbres = mysql_query("SELECT `naam` FROM `[autoveiling]` WHERE `naam`='$data->login' AND `soort`='$rij->soort'");
    $logincheck = mysql_fetch_object($dbres);
    $logincheck1 = mysql_num_rows($dbres);
    if ($logincheck1 >0){
	print " <table width=100%><tr><td class=mainTxt><tr><td class=mainTxt>You have received a $soortauto from the auction! </tr></td> ";
	exit;} 
if($rij->soort >= 23){
print "<tr><td class=\"mainTxt\">$soortauto did not sell in the auction.</td></table></tr>\n";
exit;}


mysql_query("INSERT INTO `[autoveiling]` (date2,naam,bel,text,soort) values(NOW(),'$data->login','$bel','$info','$rij->soort')");
mysql_query("UPDATE `[garage]` SET `owner`='veiling' WHERE `id`='$bel'");
print "<tr><td class=\"mainTxt\">Your $soortauto was placed on auction.</td></table></tr>\n";
exit;
}
}


    $select = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 1 AND id != '0'");
    $aantal = mysql_num_rows($select);
    $select2 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 2 AND id != '0'");
    $aantal2 = mysql_num_rows($select2);
    $select3 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 3 AND id != '0'");
    $aantal3 = mysql_num_rows($select3);
    $select4 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 4 AND id != '0'");
    $aantal4 = mysql_num_rows($select4);
	$select5 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 5 AND id != '0'");
    $aantal5 = mysql_num_rows($select5);
	$select6 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 6 AND id != '0'");
    $aantal6 = mysql_num_rows($select6);
	$select7 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 7 AND id != '0'");
    $aantal7 = mysql_num_rows($select7);
    $select8 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 8 AND id != '0'");
    $aantal8 = mysql_num_rows($select8);
    $select9 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 9 AND id != '0'");
    $aantal9 = mysql_num_rows($select9);
    $select10 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 10 AND id != '0'");
    $aantal10= mysql_num_rows($select10);
    $select11 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 11 AND id != '0'");
    $aantal11 = mysql_num_rows($select11);
    $select12 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 12 AND id != '0'");
    $aantal12 = mysql_num_rows($select12);
    $select13 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 13 AND id != '0'");
    $aantal13 = mysql_num_rows($select13);
    $select14 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 14 AND id != '0'");
    $aantal14 = mysql_num_rows($select14);
    $select15 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 15 AND id != '0'");
    $aantal15 = mysql_num_rows($select15);
    $select16 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 16 AND id != '0'");
    $aantal16 = mysql_num_rows($select16);
    $select17 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 17 AND id != '0'");
    $aantal17 = mysql_num_rows($select17);
    $select18 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 18 AND id != '0'");
    $aantal18 = mysql_num_rows($select18);
    $select19 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 19 AND id != '0'");
    $aantal19 = mysql_num_rows($select19);
    $select20 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 20 AND id != '0'");
    $aantal20 = mysql_num_rows($select20);
    $select21 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 21 AND id != '0'");
    $aantal21 = mysql_num_rows($select21);
    $select22 = mysql_query("SELECT * FROM `[autoveiling]` WHERE soort= 22 AND id != '0'");
    $aantal22 = mysql_num_rows($select22);
print <<<ENDHTML

  <tr><td class="mainTxt">
<table width="100%"  border="0" cellspacing="2" cellpadding="2">
    <tr valign="top">

    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=1"><center><b>Seat</b></a></td>
    <td width="20%"><b>$aantal</b></td>
    <td width="20%"><a href="autoveiling.php?A=12"><center><b>BMW</b></a></td>
    <td width="20%"><b>$aantal12</b></td>
        <td width="10%"></td>
    </tr>
    <tr valign="top">
  
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=2"><center><b>Opel</a></td>
    <td width="20%"><b>$aantal2</b></td>
    <td width="20%"><a href="autoveiling.php?A=13"><center><b>Dodge</a></td>
    <td width="20%"><b>$aantal13</b></td>
        <td width="10%"></td>
    </tr>
    <tr valign="top">
  
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=3"><center><b>Nissan</a></td>
    <td width="20%"><b>$aantal3</b></td>
    <td width="20%"><a href="autoveiling.php?A=14"><center><b>Jeep</a></td>
    <td width="20%"><b>$aantal14</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
     
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=4"><center><b>Fiat</a></td>
    <td width="20%"><b>$aantal4</b></td>
    <td width="20%"><a href="autoveiling.php?A=15"><center><b>Pontiac</a></td>
    <td width="20%"><b>$aantal15</b></td>
        <td width="10%"></td>
    </tr>  
      <tr valign="top">
 
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=5"><center><b>Ford</a></td>
    <td width="20%"><b>$aantal5</b></td>
    <td width="20%"><a href="autoveiling.php?A=16"><center><b>------</a></td>
    <td width="20%"><b>$aantal16</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">

    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=6"><center><b>Mini</a></td>
    <td width="20%"><b>$aantal6</b></td>
    <td width="20%"><a href="autoveiling.php?A=17"><center><b>Eagle</a></td>
    <td width="20%"><b>$aantal17</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
  
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=8"><center><b>Honda</a></td>
    <td width="20%"><b>$aantal8</b></td>
    <td width="20%"><a href="autoveiling.php?A=18"><center><b>Chrysler</a></td>
    <td width="20%"><b>$aantal18</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
   
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=7"><center><b>Mercedes</a></td>
    <td width="20%"><b>$aantal7</b></td>
    <td width="20%"><a href="autoveiling.php?A=19"><center><b>Porsche</a></td>
    <td width="20%"><b>$aantal19</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">

    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=9"><center><b>Smart</a></td>
    <td width="20%"><b>$aantal9</b></td>
    <td width="20%"><a href="autoveiling.php?A=20"><center><b>Jaguar</a></td>
    <td width="20%"><b>$aantal20</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
    
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=10"><center><b>Volkswagen</a></td>
    <td width="20%"><b>$aantal10</b></td>
    <td width="20%"><a href="autoveiling.php?A=21"><center><b>Viper</a></td>
    <td width="20%"><b>$aantal21</b></td>
        <td width="10%"></td>
    </tr>
        <tr valign="top">
  
    <td width="10%"></td> 
   <td width="20%"><a href="autoveiling.php?A=11"><center><b>Lotus</a></td>
    <td width="20%"><b>$aantal11</b></td>
    <td width="20%"><a href="autoveiling.php?A=22"><center><b>Ferarri</a></td>
    <td width="20%"><b>$aantal22</b></td>
        <td width="10%"></td>
    </tr>
</td></table></table>
<table width="100%">
<td class="subTitle">
<b>Place Car on Auction</b>
</td></tr>

<td class="mainTxt">
	<form method="post">
Car id:<br> 
    <input id="id" name="bel" maxlength="11"  value="$id123">     <br> 
    Info:<br> 
<textarea name="info" cols=30 rows=10></textarea>     <br>
<input type="submit" name="submit" value="Place Auction Sale">
</form> 

</table>

<table width="100%">
<td class="mainTxt"><b><center>
You have $data->cash.
ENDHTML;


}
?> 