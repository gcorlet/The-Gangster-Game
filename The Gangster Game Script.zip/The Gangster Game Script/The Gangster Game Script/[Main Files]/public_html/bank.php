<?php
error_reporting(0);

  $OMNILOG				= 1;
  include("_include-config.php");
    include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

$ontvanger1                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['to']}'");
$ontvanger			= mysql_num_rows($ontvanger1); 

/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>


<body style="background-color:#1a1919;">
<table width=100%>
  <tr><td class="subTitle"><b>Bank</b></td></tr>
<tr><td class="mainTxt" align="center"><table width="300"><td align="left"><img src="images/icons/light_money.jpg"> <a href="?x=pinstort">Cash Flow</a></td><td align="right"><img src="images/icons/light_money.jpg"> <a href="?x=overschrijven">Transfer</a></td></table></td></tr>
<?php /* ------------------------- */
$bankmax = number_format($data->bankmax, 0, '.' , '.');
$cash = number_format($data->cash, 0, '.' , '.');
$bank = number_format($data->bank, 0, '.' , '.');
$amount = number_format($_POST['amount'], 0, '.' , '.');
      $rente                                                                       =round($data->bank*0.01);
$rente = number_format($data->bank*0.01, 0, '.' , '.');
$renteba = number_format($data->bank*0.2, 0, '.' , '.');
  if(isset($_POST['out']) && preg_match('/^[0-9]+$/',$_POST['amount'])) {
    if($_POST['amount'] <= $data->bank) {
      $data->cash			+= $_POST['amount'];
      $data->bank			-= $_POST['amount'];
      mysql_query("UPDATE `[users]` SET `bank`={$data->bank},`cash`={$data->cash} WHERE `login`='{$data->login}'");
        print "        <tr><td class=\"mainTxt\" align=\"center\"> <b>$amount</b> has been withdrawn from your bank account. </td></tr>\n";
    }
    else
      print "  <tr><td class=\"mainTxt\">This ammount is larger than the cash in the bank account.</td></tr>\n";
  }
  else if(isset($_POST['in']) && preg_match('/^[0-9]+$/',$_POST['amount'])) {
    if($_POST['amount'] <= $data->cash) {
      if($_POST['amount'] <= $data->bankmax) {
        if($data->bankleft > 0) {
          $data->cash			-= $_POST['amount'];
          $data->bank			+= $_POST['amount'];
          $data->bankleft--;
          mysql_query("UPDATE `[users]` SET `bank`={$data->bank},`cash`={$data->cash},`bankleft`={$data->bankleft} WHERE `login`='{$data->login}'");
        print "        <tr><td class=\"mainTxt\" align=\"center\"> <b>$amount</b> has been deposited into your bank account.</td></tr>\n";
        }
        else
          print "  <tr><td class=\"mainTxt\">You can no longer pay today, sorry.</td></tr>\n";
      }
      else
        print "  <tr><td class=\"mainTxt\"></td></tr>\n";
    }
    else
      print "  <tr><td class=\"mainTxt\">You dont have that kind of money.</td></tr>\n";
  }
if($_GET['x'] == "pinstort") {
  print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	You can still deposit  {$data->bankleft}x  (max. {$bankmax} Each Time)
	<table align="center">
	  <tr><td width=100>Cash:</td>	<td align="right">{$cash}</td></tr>
	  <tr><td width=100>Cash In Bank:</td>	<td align="right">{$bank}</td></tr>
	  <tr><td width=100>Interest:</td>	<td align="right">$rente</td></tr>
	</table>
	<form method="post"><table align="center">
	  <tr><td align="center"><input type="text" class="btn btn-info" name="amount" maxlength="10" style="width:150px; Color:white";  required="required">-
		<input type="submit" class="btn btn-info" name="out"  value="Out" style="width: 100;">
		<input type="submit" class="btn btn-info" name="in" value="In"  style="width: 100;"></td></tr>
	</table></form>
  </td></tr>
ENDHTML;
} else if($_GET['x'] == "overschrijven") {

    print "  <tr><td class=\"subTitle\"><b>Cash Transfers</b></td></tr>\n";
    if(isset($_POST['to'])) {
      if(preg_match('/^[0-9]+$/',$_POST['amount'])) {
	if($ontvanger < 1) {
          print "  <tr><td class=\"mainTxt\">The name you entered is not correct.</td></tr>\n";
}
         else if($_POST['amount'] <= $data->cash) {
      $data->cash-= $_POST['amount'];
      mysql_query("UPDATE `[users]` SET `cash`={$data->cash},`cash`={$data->cash} WHERE `login`='{$data->login}'");
        if($member = mysql_fetch_object(mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_POST['to']}'"))) {
          mysql_query("UPDATE `[users]` SET `cash`=`cash`+{$_POST['amount']} WHERE `login`='{$member->login}'");
          mysql_query("INSERT INTO `[logs]`(`time`,`IP`,`login`,`person`,`code`,`area`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','{$data->login}','{$member->login}',{$_POST['amount']},'donate')");
          print "  <tr><td class=\"mainTxt\">Er is {$_POST['amount']},- aan {$member->login} overgemaakt</td></tr>\n";
        }

      }
else
          print "  <tr><td class=\"mainTxt\">You dont have enough cash to transfer.</td></tr>\n";

    }
  }

    print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	<form method="post"><table>
	<tr><td width=100>To Whom:</td>  <td><input type="text" name="to" value="{$_REQUEST['to']}"></td></tr>
	<tr><td width=100>Ammount:</td>  <td><input type="text" name="amount" maxlength="7"></td></tr>
	<tr><td></td>  <td align="right"><input type="submit" value="Send" style="width: 75px;"></td></tr>
	</table></form>
  </td></tr>
ENDHTML;
if ($data->clan != "" ){
 print <<<ENDHTML
<tr><td class="subTitle"><b>Gang Donate</b></td></tr>
  <tr><td class="mainTxt" align="center">
        <form method="post" action="clandonate.php"><table align="center">
          <tr><td width=60>To Whom:</td>  <td>{$data->clan}</td></tr>
                <tr><td width=60>Ammount:</td>  <td><input type="text" name="amount" maxlength="11" onkeypress="onlyNumeric(arguments[0])" value="$don"></td></tr>
                <tr><td></td>  <td align="right"><input type="submit" name="submit" value="Donate"  style="width: 100;"></td></tr>
        </table></form>
  </td></tr>
ENDHTML;
}
}
/* ------------------------- */ ?>
</body>
</html>