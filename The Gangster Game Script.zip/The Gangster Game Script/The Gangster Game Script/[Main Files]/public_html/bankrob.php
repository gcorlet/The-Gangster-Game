<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }
    $dbres         = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'"); 
    $data				= mysql_fetch_object($dbres);
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    $dbres         = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'"); 
    $data				= mysql_fetch_object($dbres);

// 
    	$dbres2         = mysql_query("SELECT * FROM `[bankoverval]` WHERE `land`='{$data->land}'");  
    	$dezebank				= mysql_fetch_object($dbres2);
	$bank12		= mysql_query("SELECT * FROM `[bankoverval]` WHERE `land`='1'");
	$bank1		= mysql_fetch_object($bank12);
	$bank22		= mysql_query("SELECT * FROM `[bankoverval]` WHERE `land`='2'");
	$bank2		= mysql_fetch_object($bank22);
	$bank32		= mysql_query("SELECT * FROM `[bankoverval]` WHERE `land`='3'");
	$bank3		= mysql_fetch_object($bank32);
	$bank42		= mysql_query("SELECT * FROM `[bankoverval]` WHERE `land`='4'");
	$bank4		= mysql_fetch_object($bank42);
	$bank52		= mysql_query("SELECT * FROM `[bankoverval]` WHERE `land`='5'");
	$bank5		= mysql_fetch_object($bank52);
	$bank62		= mysql_query("SELECT * FROM `[bankoverval]` WHERE `land`='6'");
	$bank6		= mysql_fetch_object($bank62);
$kans = round($_POST['inzet']/50000);
$getal = rand(1, 100)

/* ------------------------- */ ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 5px;">

<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Robbery</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/robpicture.jpg border=0></center>
</td>

<?
if($data->bankpogingen == 2) {
?>
<table align="center" width="100%">
<tr><td class="subTitle" colspan="2">Bank Robbery</td></tr>
<tr><td class="mainTxt" colspan="2" align="center">You have tried 2 times today to Rob the Bank<br> Come back tomorrow</td></tr>
<tr><td class="subTitle" colspan="2">Statistics</td></tr>
<tr><td class="mainTxt" width=50% align="center">Netherlands</td><td class="mainTxt" align="center">;<?=$bank1->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">France</td><td class="mainTxt" align="center">;<?=$bank2->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Cuba</td><td class="mainTxt" align="center">;<?=$bank3->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Russia</td><td class="mainTxt" align="center">;<?=$bank4->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Australia</td><td class="mainTxt" align="center">;<?=$bank5->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">USA</td><td class="mainTxt" align="center">;<?=$bank6->geld?></td></tr>

<tr><td class="mainTxt" width=50% align="center">Germany</td><td class="mainTxt" align="center">;<?=$bank3->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Belgium</td><td class="mainTxt" align="center">;<?=$bank4->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">England</td><td class="mainTxt" align="center">;<?=$bank5->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Ireland</td><td class="mainTxt" align="center">;<?=$bank6->geld?></td></tr>

</table>
<?
exit;
}
?>

<?
	if(!isset($_POST['overval'])){
?>
<table align="center" width=100%>
<tr><td class="subTitle" colspan=2><b>Bank Robbery</b></td></tr>
<tr><td class="mainTxt" colspan=2>
<li>What is Bank Robbery?</li><br>
Enter the ammount you wish to rob from the bank, and if successful you will get that amount.
<br>
No negative numbers and no 0.
<br>
The money will appear in your bank account the moment you see the word success.
</td></tr>
<tr><td class="mainTxt" colspan=2>
<form method="POST">
Amount to Rob: <input type="text" name="inzet" value="0" maxlength="19">
<input type="submit" <link rel="stylesheet" type="text/css" href="css/bootstrap.css"> value="ROB!" name="overval">
</form>
</td></tr>
<tr><td class="mainTxt" width=50%>You cash ammount: <?=$data->cash?></td><td class="mainTxt" width=50%>Cash in the bank of your country: <?=$dezebank->geld?></td></tr>
<tr><td class="subTitle" colspan=2><b>All Countries</b></td></tr>
<tr><td class="mainTxt" width=50% align="center">Netherlands</td><td class="mainTxt" align="center"><?=$bank1->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">France</td><td class="mainTxt" align="center"><?=$bank2->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Cuba</td><td class="mainTxt" align="center"><?=$bank3->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Russia</td><td class="mainTxt" align="center"><?=$bank4->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Australia</td><td class="mainTxt" align="center"><?=$bank5->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">USA</td><td class="mainTxt" align="center"><?=$bank6->geld?></td></tr>

<tr><td class="mainTxt" width=50% align="center">Germany</td><td class="mainTxt" align="center"><?=$bank3->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Belgium</td><td class="mainTxt" align="center"><?=$bank4->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">England</td><td class="mainTxt" align="center"><?=$bank5->geld?></td></tr>
<tr><td class="mainTxt" width=50% align="center">Ireland</td><td class="mainTxt" align="center"><?=$bank6->geld?></td></tr>

</table>
<?
}
if(isset($_POST['overval'])){
$winst = $dezebank->geld; 
if($_POST['inzet'] <= 0) {
print "<table width=100% align=\"center\"><tr><td class=\"subTitle\"><b>Bank Robbery</b></td></tr><tr><td class=\"mainTxt\" align=\"center\">You must enter something. <a href=bankrob.php class='btn btn-info'>Go Back!</a></td></tr></table>";
}
else if($data->cash < $_POST['inzet']) {
print "<table width=100% align=\"center\"><tr><td class=\"subTitle\"><b>Bank Robbery</b></td></tr><tr><td class=\"mainTxt\" align=\"center\">You dont have enough cash. <a href=bankrob.php class='btn btn-info'>Go Back!</a></td></tr></table>";
}
else if(!preg_match('/^[0-9]{1,15}$/',$_POST['inzet'])) {
print "  <table width=100% align=\"center\"><tr><td class=\"subTitle\"><b>Bank Robbery</b></td></tr><tr><td class=\"mainTxt\" align=\"center\">Fill in only numbers <a href=bankrob.php class='btn btn-info'>Go Back!</td></tr></table>\n";
}
else if($kans > $getal) {
print "<table width=100% align=\"center\"><tr><td class=\"subTitle\"><b>Bank Robbery</b></td></tr><tr><td class=\"mainTxt\" align=\"center\">Congratulations! You have robbed ;$dezebank->geld ! It has been put into your bank account. <a href=bankrob.php class='btn btn-info'>Go Back!</a></td></tr></table>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-{$_POST['inzet']},`bank`=`bank`+$winst,`bankpogingen`=`bankpogingen`+1 WHERE `login`='$data->login'");
mysql_query("UPDATE `[bankoverval]` SET `geld`='10000000' WHERE `land`='$data->land'");
}
else if($kans < $getal) {
print "<table width=100% align=\"center\"><tr><td class=\"subTitle\"><b>Bank Robbery</b></td></tr><tr><td class=\"mainTxt\" align=\"center\">Bad Luck. You Failed. <a href=bankrob.php class='btn btn-info'>Go Back!</a></td></tr></table>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-{$_POST['inzet']},`bankpogingen`=`bankpogingen`+1 WHERE `login`='$data->login'");
mysql_query("UPDATE `[bankoverval]` SET `geld`=`geld`+{$_POST['inzet']} WHERE `land`='$data->land'");
}
}
?>
</body>
</html>