<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> ,
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<script> 
getal=0; 
url='bcrimes.php'; // 
function load() 
{ 
if(getal==0) 
{ 
window.location=url; 
} 
else { 
getal+=1; 
tabel.width=getal; 
text.innerHTML=getal+"%"; 
setTimeout("load()","100"); 
} 
} 
setTimeout("load()","100"); 
</script> 
Loading... 
<div id=text></div> 
<table cellpadding=0 cellspacing=0 width=102 style="border:1 solid black"> 
<tr><td align=left> 
<table cellpadding=0 cellspacing=0 bgcolor=#0000CC height=11 id=tabel> 
<tr><td></tr></td></table></tr></td></table>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
  <table width=100%>
    <tr><td class="subTitle"><b>Crime</b></td></tr>
    <tr><td class="mainTxt">
	<center>
	</center>
    </td></tr>
  </table>
</body>

</html>


   
<?
 if($data->rankvord >= 100){
 mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`-100,`rank`=`rank`+1 WHERE `login`='{$_SESSION['login']}'");
print <<<ENDHTML

?>




<head>


<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</head>
<script> 
getal=0; 
url='bcrimes.php; // 
function load() 
{ 
if(getal==100) 
{ 
window.location=url; 
} 
else { 
getal+=1; 
tabel.width=getal; 
text.innerHTML=getal+"%"; 
setTimeout("load()","100"); 
} 
} 
setTimeout("load()","100"); 
</script> 
Loading... 
<div id=text></div> 
<table cellpadding=0 cellspacing=0 width=102 style="border:1 solid black"> 
<tr><td align=left> 
<table cellpadding=0 cellspacing=0 bgcolor=#0000CC height=11 id=tabel> 
<tr><td></tr></td></table></tr></td></table>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
  <table width=100%>
    <tr><td class="subTitle"><b>Crime</b></td></tr>
    <tr><td class="mainTxt">
	<center>Your rank has gone up 1 !!
	</center>
    </td></tr>
  </table>
</body>




</html>



ENDHTML;
    exit;
    }
?>