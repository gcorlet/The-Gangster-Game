<?php
error_reporting(0);

include("_include-config.php");
    include("_include-gevangenis.php");
  mysql_query("UPDATE `[users]` SET `lpv`=NOW(),`page`='BlackJack' WHERE `login`='{$data->login}'");
?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"><style type="text/css">
</style>
</head>
<?
if($_POST['nietchatten']){
mysql_query("UPDATE `[users]` SET `chatten`='1' WHERE `login`='$data->login'");
} elseif($_POST['welchatten']){
mysql_query("UPDATE `[users]` SET `chatten`='0' WHERE `login`='$data->login'");
}
echo '<table align="center" width=100%> 
<tr><td class="subTitle"><b>Black Jack (multiplayer)</b></td></tr>'; 

if (empty($_SESSION['blackjack_multi']) AND isset($_GET['stapin'])) { 
    if ($data->cash >= 1500) { 
        $iStapIn = intval($_GET['stapin']); 
        unset($_SESSION['bj_kaarten']); 
        unset($_SESSION['bj_kaarten_plaatjes']); 
         
        if ($iStapIn == 0) { 
            @mysql_query('UPDATE `[users]` SET cash = cash-1500 WHERE id = '.$data->id); 
            @mysql_query('INSERT INTO multiblackjack (player1) VALUES ("'.$data->login.'")'); 
            $_SESSION['blackjack_multi'] = @mysql_insert_id(); 
        } 
        else { 
            $rSpel = @mysql_query('SELECT player1,player2,player3,player4,gestart FROM multiblackjack WHERE id = '.$iStapIn); 
             
            if (@mysql_num_rows($rSpel)) { 
                $aSpel = @mysql_fetch_assoc($rSpel); 
                 
                if ($aSpel['player1'] == $data->login) { 
                    $iPlayer = 1; 
                    $_SESSION['blackjack_multi'] = $iStapIn; 
                } 
                elseif ($aSpel['player2'] == $data->login) { 
                    $iPlayer = 2; 
                    $_SESSION['blackjack_multi'] = $iStapIn; 
                } 
                elseif ($aSpel['player3'] == $data->login) { 
                    $iPlayer = 3; 
                    $_SESSION['blackjack_multi'] = $iStapIn; 
                } 
                elseif ($aSpel['player4'] == $data->login) { 
                    $iPlayer = 4; 
                    $_SESSION['blackjack_multi'] = $iStapIn; 
                } 
                else { 
                    if ($aSpel['gestart'] == 0) { 
                        if (empty($aSpel['player2'])) { 
                            @mysql_query('UPDATE `[users]` SET cash = cash-1500 WHERE id = '.$data->id); 
                            @mysql_query('UPDATE multiblackjack SET player2 = "'.$data->login.'" WHERE id = '.$iStapIn); 
                            $_SESSION['blackjack_multi'] = $iStapIn; 
                        } 
                        elseif (empty($aSpel['player3'])) { 
                            @mysql_query('UPDATE `[users]` SET cash = cash-1500 WHERE id = '.$data->id); 
                            @mysql_query('UPDATE multiblackjack SET player3 = "'.$data->login.'" WHERE id = '.$iStapIn); 
                            $_SESSION['blackjack_multi'] = $iStapIn; 
                        } 
                        elseif (empty($aSpel['player4'])) { 
                            @mysql_query('UPDATE `[users]` SET cash = cash-1500 WHERE id = '.$data->id); 
                            @mysql_query('UPDATE multiblackjack SET player4 = "'.$data->login.'", gestart = '.time().' WHERE id = '.$iStapIn); 
                            $_SESSION['blackjack_multi'] = $iStapIn; 
                        } 
                        else { 
                            echo '<tr><td class="mainTxt" style="font-weight:bold; color: red;">Het spel heeft al 4 spelers!</td></tr>'; 
                        } 
                    } 
                    else { 
                        // spel is al gestart 
                        echo '<tr><td class="mainTxt" style="font-weight:bold; color: red;">Ze zijn al begonnen zonder jouw :-)</td></tr>'; 
                    } 
                } 
            } 
            else { 
                // bestaat niet 
                echo '<tr><td class="mainTxt" style="font-weight:bold; color: red;">Dit spel bestaat niet (meer).</td></tr>'; 
            } 
        } 
    } 
    else { 
        echo '<tr><td class="mainTxt" style="font-weight:bold; color: red;">Je hebt niet genoeg geld!</td></tr>'; 
    } 
} 
elseif (isset($_GET['stapuit'])) { 
    $rSpel = @mysql_query('SELECT player1,player2,player3,player4,gestart FROM multiblackjack WHERE id = '.$_SESSION['blackjack_multi']); 
     
    if (@mysql_num_rows($rSpel)) { 
        $aSpel = @mysql_fetch_assoc($rSpel); 
        if ($aSpel['gestart'] == 0) { 
            if ($aSpel['player1'] == $data->login) { 
                @mysql_query('DELETE FROM multiblackjack WHERE id = '.$_SESSION['blackjack_multi']); 
            } 
            elseif ($aSpel['player2'] == $data->login) { 
                if (empty($aSpel['player4']) AND empty($aSpel['player3'])) { 
                    @mysql_query('UPDATE multiblackjack SET player3="" WHERE id = '.$_SESSION['blackjack_multi']); 
                } 
                elseif ($aSpel['player3'] != '' AND empty($aSpel['player4'])) { 
                    @mysql_query('UPDATE multiblackjack SET player2=player3, player3="" WHERE id = '.$_SESSION['blackjack_multi']); 
                } 
                else { 
                    @mysql_query('UPDATE multiblackjack SET player2=player4, player4="" WHERE id = '.$_SESSION['blackjack_multi']); 
                }     
            } 
            elseif ($aSpel['player3'] == $data->login) { 
                if (empty($aSpel['player4'])) { 
                    @mysql_query('UPDATE multiblackjack SET player3="" WHERE id = '.$_SESSION['blackjack_multi']); 
                } 
                else { 
                    @mysql_query('UPDATE multiblackjack SET player3=player4, player4="" WHERE id = '.$_SESSION['blackjack_multi']); 
                }                 
            } 
            else { 
                @mysql_query('UPDATE multiblackjack SET player4="" WHERE id = '.$_SESSION['blackjack_multi']); 
            } 
            unset($_SESSION['blackjack_multi']); 
        } 
    } 
    else { 
        unset($_SESSION['blackjack_multi']); 
    }     
} 

if (isset($_SESSION['blackjack_multi'])) { 
     
    $rSpel = @mysql_query('SELECT tijd1,tijd2,tijd3,tijd4,score4,score3,score2,score1,player1,player2,player3,player4,gestart FROM multiblackjack WHERE id = '.$_SESSION['blackjack_multi']); 
    if (@mysql_num_rows($rSpel)) { 
        $aSpel = @mysql_fetch_assoc($rSpel); 
         
        if (isset($_GET['start']) AND $_GET['start'] == $aSpel['id']){ 
            @mysql_query('UPDATE multiblackjack SET gestart = '.time().' WHERE id = '.$_SESSION['blackjack_multi']); 
            header('Location: bjmulti.php'); 
        } 
         
        function nieuweKaart() { 
			$iKaart 	= rand(1,13);
			$iSoort 	= rand(1,4);
			$aSoort 	= array('','Hearts','Spades','Diamonds','Clubs');
			$aKaart 	= array('','2','3','4','5','6','7','8','9','10','j','q','k','a');
			$aWaarde 	= array('','2','3','4','5','6','7','8','9','10','10','10','10','11');		
             
            return Array($aSoort[$iSoort].'/'.strtolower($aKaart[$iKaart]),$aWaarde[$iKaart]); 
        } 
         
        function totaleWaarde ($aKaarten) { 
			$aWaarde 	= array('','2','3','4','5','6','7','8','9','10','10','10','10','11');		
            $iTotaleWaarde    = 0; 
            $iAzen             = 0; 
             
            foreach ($aKaarten as $iKaart) { 
                $iTotaleWaarde += $aWaarde[$iKaart]; 
                if ($aWaarde[$iKaart] == 11) $iAzen++; 
            } 
             
            while ($iAzen > 0 AND $iTotaleWaarde > 21) { 
                $iTotaleWaarde -= 10; 
                $iAzen--; 
            } 
             
            RETURN $iTotaleWaarde; 
        } 
         
        if ($aSpel['gestart'] == 0) { 
            $aSpelers = Array($aSpel['player1']); 
            if (!empty($aSpel['player2'])) { 
                $aSpelers[] = $aSpel['player2']; 
            } 
            if (!empty($aSpel['player3'])) { 
                $aSpelers[] = $aSpel['player3']; 
            } 
            if (!empty($aSpel['player4'])) { 
                $aSpelers[] = $aSpel['player4']; 
            } 
            $aSpel['spelers'] = implode(', ',$aSpelers); 
             
            echo '<tr><td class="mainTxt">'; 
            if ($aSpel['player1'] == $data->login) { 
                if (count($aSpelers) > 1) { 
                    echo 'The next player is already playing with: '.$aSpel['spelers'].'<p>'; 
                    echo '<a href="bjmulti.php?start='.$aSpel['id'].'">Start The Game</a> of <a href="bjmulti.php?stapuit=1">Stop The Game</a>'; 
                } 
                else { 
                    echo 'The next player is already playing with: '.$aSpel['spelers'].' <br><a href="bjmulti.php?stapuit=1">Stop Playing</a><p>'; 
                } 
            } 
            else { 
                echo 'The next player is already playing with: '.$aSpel['spelers'].'<p>Wait until the game is started by '.$aSpel['player1'].' of <a href="bjmulti.php?stapuit=1">Step Out The Game</a>.'; 
            } 
            echo '</td></tr>'; 
             
            ?><script language='JavaScript'> 
            <!-- 
            function refresh () { 
                location.href = "bjmulti.php"; 
            } 
            setTimeout("refresh();",5000); 
            //--> 
            </script><? 
        } 
        else { 
            if (($aSpel['player1'] == $data->login AND $aSpel['tijd1'] == 0) OR ($aSpel['player2'] == $data->login AND $aSpel['tijd2'] == 0) OR ($aSpel['player3'] == $data->login AND $aSpel['tijd3'] == 0) OR ($aSpel['player4'] == $data->login AND $aSpel['tijd4'] == 0)) { 
                if ($aSpel['player1'] == $data->login) { 
                    $iPlayer = 1; 
                } 
                elseif ($aSpel['player2'] == $data->login) { 
                    $iPlayer = 2; 
                } 
                elseif ($aSpel['player3'] == $data->login) { 
                    $iPlayer = 3; 
                } 
                else { 
                    $iPlayer = 4; 
                } 
                 
                echo '<tr><td class="mainTxt">'; 
                echo 'The game has started. Beware thbat if your not ready within 1 minute, you lose any money you entered.<br /> <br />'; 
                 
                // nieuwe kaart 
                if (isset($_SESSION['bj_kaarten']) AND isset($_GET['kaart']) AND $_GET['kaart'] == 'new') { 
                    list($sPlaatje,$iWaarde) = nieuweKaart(); 
                    $_SESSION['bj_kaarten'][]             = $iWaarde; 
                    $_SESSION['bj_kaarten_plaatjes'][]     = $sPlaatje; 
                } 
                // stoppen 
                elseif (isset($_SESSION['bj_kaarten']) AND isset($_GET['kaart']) AND $_GET['kaart'] == 'stop') { 
                    @mysql_query('UPDATE multiblackjack SET score'.$iPlayer.' = '.array_sum($_SESSION['bj_kaarten']).', tijd'.$iPlayer.' = "'.time().'" WHERE id = '.$_SESSION['blackjack_multi']); 
                    echo '<p>You have a score of '.array_sum($_SESSION['bj_kaarten']).', hopefully this is a winning hand!'; 
                    ?><script language='JavaScript'> 
                    <!-- 
                    function refresh () { 
                        location.href = "bjmulti.php"; 
                    } 
                    setTimeout("refresh();",2500); 
                    //--> 
                    </script><? 
                } 
                // eerste kaart 
                else { 
                    list($sPlaatje,$iWaarde) = nieuweKaart(); 
                    $_SESSION['bj_kaarten'][0]                 = $iWaarde; 
                    $_SESSION['bj_kaarten_plaatjes'][0]     = $sPlaatje; 
                } 
                 
                // kaarten weergeven 
                echo '<hr>'; 
                foreach ($_SESSION['bj_kaarten_plaatjes'] as $sPlaatje) { 
                    echo '<img src="kaarten/'.$sPlaatje.'.jpg"> '; 
                } 
                echo '<hr>'; 
                 
                if (totaleWaarde($_SESSION['bj_kaarten']) > 21) { 
                    @mysql_query('UPDATE multiblackjack SET tijd'.$iPlayer.' = "'.time().'" WHERE id = '.$_SESSION['blackjack_multi']); 
                    echo '<p>You have lost.'; 
                    ?><script language='JavaScript'> 
                    <!-- 
                    function refresh () { 
                        location.href = "bjmulti.php"; 
                    } 
                    setTimeout("refresh();",2500); 
                    //--> 
                    </script><? 
                } 
                elseif (totalewaarde($_SESSION['bj_kaarten']) == 21) { 
                    @mysql_query('UPDATE multiblackjack SET tijd'.$iPlayer.' = "'.time().'", score'.$iPlayer.' = 21 WHERE id = '.$_SESSION['blackjack_multi']); 
                    echo '<p>You have 21.'; 
                    ?><script language='JavaScript'> 
                    <!-- 
                    function refresh () { 
                        location.href = "bjmulti.php"; 
                    } 
                    setTimeout("refresh();",2500); 
                    //--> 
                    </script><? 
                } 
                else { 
                    echo '<br> <br><a href="bjmulti.php?kaart=new">Hit Me</a> - <a href="bjmulti.php?kaart=stop">Stand</a>'; 
                } 
                 
                 
                echo '</td></tr>'; 
            } 
            else { 
                if (($aSpel['tijd1'] > 0 AND $aSpel['tijd2'] > 0 AND (empty($aSpel['player3']) OR $aSpel['tijd3'] > 0) AND (empty($aSpel['player4']) OR $aSpel['tijd4'] > 0)) OR $aSpel['gestart'] < (time()-60)) { 
                    $iHoogsteScore     = 0; 
                    $sBesteSpeler     = ''; 
                    $iHoogsteTijd     = 0; 
                     
                    for ($i=0;$i<5;$i++) { 
                        if ($aSpel['score'.$i] >= $iHoogsteScore AND $aSpel['score'.$i] < 22) { 
                            if ($aSpel['score'.$i] == $iHoogsteScore) { 
                                if ($aSpel['tijd'.$i] < $iHoogsteTijd) { 
                                    $iHoogsteScore = $aSpel['score'.$i]; 
                                    $iHoogsteTijd = $aSpel['tijd'.$i]; 
                                    $sBesteSpeler = $aSpel['player'.$i]; 
                                } 
                            } 
                            else { 
                                $iHoogsteScore = $aSpel['score'.$i]; 
                                $iHoogsteTijd = $aSpel['tijd'.$i]; 
                                $sBesteSpeler = $aSpel['player'.$i]; 
                            } 
                        } 
                    } 
                     
                    if ($sBesteSpeler != '') { 
                        $iSpelers = 2; 
                        if (!empty($aSpel['player3'])) { 
                            $iSpelers++; 
                        } 
                        if (!empty($aSpel['player4'])) { 
                            $iSpelers++; 
                        } 
                         
                        $iGeld = round(0.9*($iSpelers*1500)); 
                        if ($aSpel['player1'] == $data->login) {     
                            @mysql_query('UPDATE `[users]` SET cash=cash+'.$iGeld.' WHERE login = "'.$sBesteSpeler.'"'); 
                        } 
                        echo '<tr><td class="mainTxt">The Winning Player is: '.$sBesteSpeler.' (with a score of '.$iHoogsteScore.'). '.$sBesteSpeler.' has won  '.$iGeld.'.<p><a href="bjmulti.php">Return to Game</a></td></tr>'; 
                    } 
                    else { 
                        echo '<tr><td class="mainTxt">There is no winner this round, everyone bust.<p><a href="bjmulti.php">Return to Game</a></td></tr>'; 
                    } 
                     
                    unset($_SESSION['bj_kaarten']); 
                    unset($_SESSION['blackjack_multi']); 
                } 
                else { 
                    echo '<tr><td>Finish washing other players. The round will be over in less than 1 minute!</td></tr>'; 
                    ?><script language='JavaScript'> 
                    <!-- 
                    function refresh () { 
                        location.href = "bjmulti.php"; 
                    } 
                    setTimeout("refresh();",5000); 
                    //--> 
                    </script><? 
                } 
            } 
        } 
    } 
    else { 
        // bestaat niet 
        echo '<tr><td class="mainTxt" style="font-weight:bold; color: red;">This game doesnt exist.</td></tr>'; 
        unset($_SESSION['blackjack_multi']); 
        ?><script language='JavaScript'> 
        <!-- 
        function refresh () { 
            location.href = "bjmulti.php"; 
        } 
        setTimeout("refresh();",1000); 
        //--> 
        </script><? 
    } 
} 
else { 
    echo '<tr><td class="mainTxt">Welcome to the BlackJack Multiplayer Room. In this game you can play alongside 3 other players.
You can either start a game in which you have control and need to get people to play or just let them join. Or join a game, in which you much enter ;1,500
to pot in. Each player has to do this, including the game starter. The winner of the round will get 90% of this total. So for example if you had a full table with 4 players,
the winner would win 5,400.
 (at 4 players you will win 5.400,-)<br> <br>'; 

    echo '<table class="noBorder" width=500><tr style="font-weight: bold;"><td width=50>#</td><td width=250>Players</td><td width=75>Started</td><td width=125>Join </td></tr>'; 
    $rSpellen = @mysql_query('SELECT id,player1,player2,player3,player4,gestart FROM multiblackjack WHERE gestart = 0 ORDER BY id DESC'); 
    while ($aSpel = @mysql_fetch_assoc($rSpellen)) { 
        $aJaOfNee = Array('ja','nee'); 
         
        $aSpelers[] = $aSpel['player1']; 
        if (!empty($aSpel['player2'])) { 
            $aSpelers[] = $aSpel['player2']; 
        } 
        if (!empty($aSpel['player3'])) { 
            $aSpelers[] = $aSpel['player3']; 
        } 
        if (!empty($aSpel['player4'])) { 
            $aSpelers[] = $aSpel['player4']; 
        } 
        $aSpel['spelers'] = implode(', ',$aSpelers); 
         
        if ($aSpel['gestart'] > 1) { 
            $aSpel['instappen'] = 'The Game Has Already Started'; 
        } 
        else { 
            $aSpel['instappen'] = '<a href="bjmulti.php?stapin='.$aSpel['id'].'">Step In</a>'; 
        } 
         
        if ($aSpel['gestart'] == 0) { 
            $aSpel['gestart'] = 'No'; 
        } 
        else { 
            $aSpel['gestart'] = 'Yes'; 
        } 
         
        echo '<tr><td>'.$aSpel['id'].'</td><td>'.$aSpel['spelers'].'</td><td>'.$aSpel['gestart'].'</td><td>'.$aSpel['instappen'].'</td></tr>'; 
    } 
    echo '</table>'; 
     
    echo '<p><a href="bjmulti.php?stapin=0">Start Your Own Game (Also Put In 1,500)</a>'; 
    echo '</td></tr>'; 
} 

echo '</table>'; 
?> 
<? if($data->chatten == 0){ ?>
<form method="POST">
</form>
<? } else{ ?>
<form method="POST">
</form>
<? } ?>

<? if($data->chatten == 1){ ?>
<center>&nbsp;</center><? } ?>
</body>
</html>