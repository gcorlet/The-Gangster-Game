<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }


mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

$cashhh = number_format($data->cash,0,",",".");



/* ------------------------- */ ?>
<html>



<head> 
<title></title> 
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel='stylesheet' type='text/css' href='css/bootstrap.css'>
</head>
<body style="margin: 0px;">

<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Blackjack Casino</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/bbpicture.jpg border=0></center>
</td>

<?PHP
  
	
	$casino       = mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='$data->land'");
	$casino       = mysql_fetch_object($casino);

if($casino->vw > 0){
$vw = number_format($casino->vw,0,",",".");
$bjwinst = "<font color=green>\$$vw</font>";
}
if($casino->vw == 0){
$vw = number_format($vw,0,",",".");
$bjwinst = "\$$casino->vw";
}
if($casino->vw < 0){
$vw = number_format($casino->vw,0,",",".");
$bjwinst = "<font color=red>\$$vw</font>";
}
if($casino->owner ==$data->login){
print"</table>";
}

echo "<table width=90% align=center>
<td class=\"subTitle\" colspan=2><b>Blackjack</b></td></tr>";

if($data->login == $casino->owner){

if(isset($_POST['VA'])){
echo "<table width=\"100%\">";
if($_POST['inzet'] <1000)
{
print "<tr><td class=\"mainTxt\" width=\"100%\">The maximum bet allowed is \$1.000 </td></tr>";
}
elseif($_POST['inzet'] >10000000)
{
print"<tr><td class=\"mainTxt\" width=\"100%\">That bet is to hight, the maximum bet is \$10.000.000</td></tr>";
}
else
{
$inzet    = $_POST['inzet'];
mysql_query("UPDATE `[casinoo]` SET `maximum`='$inzet' WHERE `land`='$data->land' AND `spel`='3'");
$inzett = number_format($inzet,0,",",".");
print "<tr><td class=\"mainTxt\" width=\"100%\">The maximum bet has been changed to \$$inzett.</td></tr>";
}
}

$winst = number_format($casino->vw, 0, ",", ".");
$casinobank = number_format($casino->casinobank, 0, ",", ".");

if(!isset($_POST['stort']) && !isset($_POST['afhalen']) ){
print <<<ENDHTML
  <table width=100%>
<tr><td class="mainTxt"  width="48%">
<form method="POST">
You have made $bjwinst profit from the Blackjack-Table.<br><br>
Cash in the Casino-Bank: $$casinobank <br>
Cash on You : $$cashhh<br><br>

<form action=blackjack.php method=post>
<input type=hidden class='btn btn-info' name=casino value=>Maximum inzet <input type=text class='btn btn-info' name=inzet value=$casino->maximum><input type=submit class='btn btn-info' name=VA value="Update!"></form>
<font color=red>Need to borrow Cash in the Casino loses next hands as its short on cash!</font><br><br>
<form action=blackjack.php method=post>
Transfering cash in and out of the casinobank:<br>$ <input type=text class='btn btn-iunfo' name=bedrag><br><Br>
<input type=submit class='btn btn-info' name=stort value="Put into the CasinoBank"><input type=submit class='btn btn-info' name=afhalen value="Take out of the Casino Bank"></form>
ENDHTML;
}


if(isset($_POST['stort'])){
if(! preg_match('/^[0-9]{0,15}$/',$_POST['bedrag'])){
print "<tr><td class=\"mainTxt\"><font color=red>Invalid Input</td></tr>";
}
  $geld = $_POST['bedrag'];
  if($geld >$data->cash){
  print"  <table width=100%><tr><td class=mainTxt>You dont have enough cash.</td></tr>";
  }elseif($geld <1){
  print"  <table width=100%><tr><td class=mainTxt>Lead everything in <i>Normaal</I> .</td></tr>";
  }elseif($geld >1111111111111111){
  $helft = $geld/2;
  print"<tr><td class=mainTxt><br>Sorry, this number is to large, try entering \$$helft of the money, then the same again.</td></tr>";
  }else{
  mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$geld' WHERE `login`='{$data->login}'");
  mysql_query("UPDATE `[casinoo]` SET `casinobank`=`casinobank`+'$geld' WHERE `owner`='{$data->login}' AND `land`='$data->land' AND `spel`='3'");
  $casinobank4 = $casino->casinobank+$bedrag;
  $casinobank4 = number_format($casinobank4, 0, ",", ".");
$geld2 = number_format($geld,0,",",".");
    print <<<ENDHTML
  <table width=100%>
<tr><td class=mainTxt>You have \$$geld2 in the CasinoBank.</td></tr>
<tr><td class="mainTxt"  width="48%">
<form method="POST">
You have made $bjwinst profit from the Blackjack-Table.<br><br>
Cash in the de Casino-Bank: $$casinobank <br>
Cash on You : $$cashhh<br><br>

<form action=blackjack.php method=post>
<input type=hidden name=casino class='btn btn-info' value='Maximum Amount'> <input type=text name=inzet value=$casino->maximum><input type=submit class='btn btn-info' name=VA value="Update!"></form>
<font color=red>Borrowed money from some players means that if they lose, the state owes the casinoBank some cash!</font><br><br>
<form action=blackjack.php method=post>
 Transfer cash in and out of the casinobank:<br>$ <input type=text class='btn btn-info' name=bedrag><br><br>
<input type=submit class='btn btn-info' name=stort value="Put in the casinobank"><input type=submit class='btn btn-info' name=afhalen value="Take from the casinobank">
ENDHTML;
   unset($_POST['stort']);
  
  }
  }
  if(isset($_POST['afhalen'])) {
  $geld = $_POST['bedrag'];
if(! preg_match('/^[0-9]{0,15}$/',$_POST['bedrag'])){
print "<tr><td class=\"mainTxt\"><font color=red>Onjuiste invoer</td></tr>";
exit;
}
  elseif($geld >$casino->casinobank){
  print" <table width=100%><tr><td class=mainTxt>You dont have enough cash in the casinobank.</td></tr>";
  }elseif($geld <1){
  print" <table width=100%><tr><td class=mainTxt>Lead everything in <i>Normaal</I>.</td></tr>";
  }else{
  $geld = $_POST['bedrag'];
  mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$geld' WHERE `login`='{$data->login}'");
  mysql_query("UPDATE `[casinoo]` SET `casinobank`=`casinobank`-'$geld' WHERE `owner`='{$data->login}' AND `land`='$data->land' AND `spel`='3'");
  $casinobank3 = $casino->casinobank-$bedrag;
  $casinobank3 = number_format($casinobank3, 0, ",", ".");
$geld2 = number_format($geld,0,",",".");
  print <<<ENDHTML
  <table width=100%>
<tr><td class=maintxt>You have taken \$$geld2 from the casinobank</td></tr>
<tr><td class="mainTxt" width="48%">
<form method="POST">
You have made $bjwinst profit on the Blackjack-Table.<br><br>
Cash in the Casino-Bank: $$casinobank <br>
Cash on You : $$cashhh<br><br>

<form action=blackjack.php method=post>
<input type=hidden name=casino value=>Maximum inzet <input type=text name=inzet class='btn btn-info' value=$casino->maximum><input type=submit class='btn btn-info' name=VA value="Update!"></form>
<font color=red>Borrowed money from some players means that if they lose, the state owes the casinoBank some cash!</font><br><br>
<form action=blackjack.php method=post>
 Transfer cash in and out of the casinobank:<br>$ <input type=text name=bedrag><br><br>
<input type=submit name=stort btn btn-info' value="Put in the casinobank"><input type=submit class="btn btn-info" name=afhalen value="Take from the casinobank"></form>
ENDHTML;
  unset($_POST['afhalen']);
  print"</td></tr>"; }
}}else{

if(isset($_POST['start'])){
if(! preg_match('/^[0-9]{0,15}$/',$_POST['inzet'])){
print"<font color=red>Invalid Input</font>"; 
exit;
}
}

$geldover =$data->cash+$inzet;
$eigenaar =ucfirst($casino->owner);
if($eigenaar =="Obay"){
print"<tr><td class=mainTxt><b>The BlackJack Table is currently in Obey Status!<br>This means you cannot play at the moment</b></td></tr>";
exit;
}
else{
  $dbres				= mysql_query("SELECT maximum FROM `[casinoo]` WHERE `land`='$data->land' AND `spel`='3'");
  $max				= mysql_fetch_object($dbres);
$inzett = number_format($inzet,0,",",".");
$maximum = number_format($max->maximum,0,",",".");
$min = number_format($max->maximum/10,0,",",".");

if($inzet > $max->maximum)
{
print"<tr><td class=mainTxt>You put in \$$inzett whilst the maximum bet \$$maximum .</td></tr>";
exit;
}

$inzet = $_POST['inzet'];

$picurl = "images/gokken/blackjack/"; //
$ext = ".jpg"; // 
if(isset($_POST['start']) && preg_match('/[0-9]{1,15}/',$_POST['inzet'])) {
$_POST['inzet'] = str_replace('+',"impossible",$_POST['inzet']);
$_POST['inzet'] = str_replace('-',"impossible",$_POST['inzet']);
if(! preg_match('/^[0-9]{0,15}$/',$_POST['inzet'])){ print"<tr><td class=mainTxt><font color=red>Incorrect input</font>"; exit();}
else{$inzet = $_POST['inzet'];
if($inzet >$data->cash){ print"<tr><td class=mainTxt>You dont have enough cash</td></tr>"; exit; }
if($max->maximum/10 > $inzet)
{
print"<tr><td class=mainTxt>The bet is bigger than the minimum bet allowed which is\${$min}.</td></tr>";
exit();
}
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$inzet' WHERE `login`='{$data->login}'"); 
mysql_query("UPDATE `[casinoo]` SET `casinobank`=`casinobank`+'$inzet' WHERE `land`='$data->land' AND `spel`='3'");
mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`+'$inzet' WHERE `spel`='3' AND `land`='$data->land'");
mysql_query("DELETE FROM `blackjack` WHERE `login`='data->login'");
        $winst = ($inzet * 3);
        $getal = rand(1,13);
        $soort = rand(1,4);
        $getal2 = rand(1,13);
        $soort2 = rand(1,4);
        if($soort == 1) {$soort = "harten";}
        if($soort == 2) {$soort = "schoppen";}
        if($soort == 3) {$soort = "ruiten";}
        if($soort == 4) {$soort = "klaveren";}
        if($soort2 == 1) {$soort2 = "harten";}
        if($soort2 == 2) {$soort2 = "schoppen";}
        if($soort2 == 3) {$soort2 = "ruiten";}
        if($soort2 == 4) {$soort2 = "klaveren";}
        $geta = $getal;
        $geta2 = $getal2;
        if($getal == 11) {$geta = "boer"; $getal = 10;}
        if($getal == 12) {$geta = "vrouw"; $getal = 10;}
        if($getal == 13) {$geta = "koning"; $getal = 10;}
        if($getal == 1) {$geta = "aas"; $getal = 11; $aas = 1;}
        if($getal2 == 11) {$geta2 = "boer"; $getal2 = 10;}
        if($getal2 == 12) {$geta2 = "vrouw"; $getal2 = 10;}
        if($getal2 == 13) {$geta2 = "koning"; $getal2 = 10;}
        if($getal2 == 1) {$geta2 = "aas"; $getal2 = 11; $aas = ($aas + 1);}
        $picture = "<img src=".$picurl.$soort.$geta.$ext.">";
        $picture2 = "<img src=".$picurl.$soort2.$geta2.$ext.">";
        $pictures = $picture." &nbsp;&nbsp; ".$picture2;
        $pictured = "<img src=".$picurl.$soortd.$getad.$ext.">";
$winsttt = number_format($winst,0,",",".");
    $dealer = $vorige->dealer;
        if(($getal + $getal2) == 21) {
        $som = ($getal + $getal2);
		mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$winst'+'$inzet' WHERE `login`='{$data->login}'"); 	
		  mysql_query("UPDATE `[casinoo]` SET `casinobank`=`casinobank`-'$winst'-'$inzet' WHERE `land`='$data->land' AND `spel`='3'");	
		  mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`-'$winst'-'$inzet' WHERE `spel`='3' AND `land`='$data->land'");
echo "	<tr><td width=100 align=center valign=top class=maintxt>Computer<br>($dealer)</td><td colspan=2 align=left class=maintxt>$pictured
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt>You have been dealt a $soort $geta and a $soort2 $geta2. Blackjack! You have won \$$winsttt .</td></tr><tr><td colspan=3 align=cente class=maintxt>Cash on You : $$cashhh</td></tr></table></form>
</body>";
}
        else {
        $som = ($getal + $getal2);
        if($aas > 0) {$som2 = $som-10;}
        $getald = rand(1,13);
        $soortd = rand(1,4);
        if($soortd == 1) {$soortd = "harten";}
        if($soortd == 2) {$soortd = "schoppen";}
        if($soortd == 3) {$soortd = "ruiten";}
        if($soortd == 4) {$soortd = "klaveren";}
        $getad = $getald;
        if($getald == 11) {$getad = "boer"; $getald = 10;}
        if($getald == 12) {$getad = "vrouw"; $getald = 10;}
        if($getald == 13) {$getad = "koning"; $getald = 10;}
        if($getald == 1) {$getad = "aas"; $getald = 11;}
        $pictured = "<img src=".$picurl.$soortd.$getad.$ext.">";
        mysql_query("INSERT INTO `blackjack`(`login`,`inzet`,`kaart`,`kaartpic`,`aas`,`dealer`,`dealerpic`) values('{$data->login}','{$inzet}','{$som}','{$pictures}','{$aas}','{$getald}','{$pictured}')") or die (mysql_error());
        if($aas > 0) {
echo "<tr><td width=100 align=cente class=maintxt>Computer<br>(?)</td><td colspan=2 align=left class=maintxt><img src='images/gokken/blackjack/closed.gif'>&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/gokken/blackjack/closed.gif'>
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt>You have been dealt an ACE, which value do you wish to to take form as?<br><form method='post'><input type='submit' name='aas' value='1'> &nbsp;&nbsp; <input type='submit' name='aas2' value='11'></form></td></tr></table></form>
</body>";
 exit;}
echo "	<tr><td width=100 align=center valign=top class=maintxt>Computer<br>(?)</td><td colspan=2 align=left class=maintxt><img src='images/gokken/blackjack/closed.gif'>&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/gokken/blackjack/closed.gif'>
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</td></tr>
<tr><td colspan=3 align=center class=maintxt><form method='post'><input type='submit' class='btn btn-info' name='nieuw' value='Hit'> &nbsp;&nbsp; <input type='submit' class='btn btn-info' name='stop' value='Stand'></td></tr><tr><td colspan=3 align=center class=maintxt>Cash on You : $$cashhh</td></tr></table></form>
</body>";

       } }
} 
elseif($_POST['nieuw']) {
session_start(); 
    $dbres = mysql_query("SELECT * FROM `blackjack` WHERE `login`='{$data->login}'") or die (mysql_error());
    $vorige = mysql_fetch_object($dbres);
    $winst = (2*$vorige->inzet);
    $inzet = $vorige->inzet;
    $getal = rand(1,13);
    $soort = rand(1,4);
    if($soort == 1) {$soort = "harten";}
    if($soort == 2) {$soort = "schoppen";}
    if($soort == 3) {$soort = "ruiten";}
    if($soort == 4) {$soort = "klaveren";}
    $geta = $getal;
    if($getal == 11) {$geta = "boer"; $getal = 10;}
    if($getal == 12) {$geta = "vrouw"; $getal = 10;}
    if($getal == 13) {$geta = "koning"; $getal = 10;}
    if($getal == 1) {$geta = "aas"; $getal = 11; $aas = 1;}
    $som = ($vorige->kaart + $getal);
    $so = ($vorige->kaart + 1);
    $picture = "<img src=".$picurl.$soort.$geta.$ext.">";
    $pictures = $vorige->kaartpic." &nbsp;&nbsp; ".$picture;
    $pictured = $vorige->dealerpic;
    if($getal == 11) {$som2 = "of $so";}
    mysql_query("UPDATE `blackjack` SET `aas`='{$aas}',`kaart`='{$som}',`kaartpic`='{$pictures}' WHERE `login`='{$data->login}'") or die (mysql_error());
    if($aas > 0) {
echo "<tr><td width=100 align=center valign=top class=maintxt>Computer<br>(?)</td><td colspan=2 align=left class=maintxt><img src='images/gokken/blackjack/closed.gif'>&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/gokken/blackjack/closed.gif'>
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt>You have been dealt an ACE, which value do you wish to have?<form method='post'><input type='submit' class='btn btn-info' name='aas' value='1'> &nbsp;&nbsp; <input type='submit' classs='btn btn-info' name='aas2' value='11'></form></td></tr></table></form>
</body>";
exit; 
}
    if($som > 21) {
    $dealer = $vorige->dealer;
$inzett = number_format($vorige->inzet,0,",",".");
echo "<tr><td width=100 align=center valign=top class=maintxt>Computer<br>($dealer)</td><td colspan=2 align=left class=maintxt>$pictured
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt>You have a score of $som. You have lost. You lost \$$inzett .<br><br><a href=blackjack.php>Play Again</a></td></tr></table></form>
</body>";
    mysql_query("DELETE FROM `blackjack` WHERE `login`='{$data->login}'");
    exit;
    }
echo "	<tr><td width=100 align=center valign=top class=maintxt>Computer<br>(?)</td><td colspan=2 align=left class=maintxt><img src='images/gokken/blackjack/closed.gif'>&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/gokken/blackjack/closed.gif'>
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt><form method='post'><input type='submit' class='btn btn-info' name='nieuw' value='Hit'> &nbsp;&nbsp; <input type='submit' class='btn btn-info' name='stop' value='Stand'></td></tr><tr><td colspan=3 align=center class=maintxt>Cash on You : $$cashhh</td></tr></table></form>
</body>";
}
elseif($_POST['aas']) {
session_start(); 
    $dbres = mysql_query("SELECT * FROM `blackjack` WHERE `login`='{$data->login}'") or die (mysql_error());
    $vorige = mysql_fetch_object($dbres);
    $pictures = $vorige->kaartpic;
    $pictured = $vorige->dealerpic;
    $i=0;
    while ($i < $vorige->aas){
    $som = ($vorige->kaart - 10);
    $i++;
    }
    mysql_query("UPDATE `blackjack` SET `aas`='0',`kaart`='{$som}' WHERE `login`='{$data->login}'") or die (mysql_error());
echo "	<tr><td width=100 align=center valign=top class=maintxt>Computer<br>(?)</td><td colspan=2 align=left class=maintxt><img src='images/gokken/blackjack/closed.gif'>&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/gokken/blackjack/closed.gif'>
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt><form method='post'><input type='submit' class='btn btn-info' name='nieuw' value='Hit'> &nbsp;&nbsp; <input type='submit' class='btn btn-info' name='stop' value='Stand'></td></tr><tr><td colspan=3 align=center class=maintxt>Cash on You : $$cashhh</td></tr></table></form>
</body>";
}
elseif($_POST['aas2']) {
session_start(); 
    $dbres = mysql_query("SELECT * FROM `blackjack` WHERE `login`='{$data->login}'") or die (mysql_error());
    $vorige = mysql_fetch_object($dbres);
    $som = $vorige->kaart;
    $pictures = $vorige->kaartpic;
    $pictured = $vorige->dealerpic;
    mysql_query("UPDATE `blackjack` SET `aas`='0' WHERE `login`='{$data->login}'") or die (mysql_error());
echo "  	<tr><td width=100 align=center valign=top class=maintxt>Computer<br>(?)</td><td colspan=2 align=left class=maintxt><img src='images/gokken/blackjack/closed.gif'>&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/gokken/blackjack/closed.gif'>
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt><form method='post'><input type='submit' class='btn btn-info' name='nieuw' value='Hit'> &nbsp;&nbsp; <input type='submit' class='btn btn-info' name='stop' value='Stand'></td></tr><tr><td colspan=3 align=center class=maintxt>Cash on You : $$cashhh</td></tr></table></form>
</body>";
}
elseif($_POST['stop']) {
session_start(); 
    $dbres = mysql_query("SELECT * FROM `blackjack` WHERE `login`='{$data->login}'") or die (mysql_error());
    $vorige = mysql_fetch_object($dbres);
    $som = $vorige->kaart;
    $pictures = $vorige->kaartpic;
    $pictured = $vorige->dealerpic;
    $dealer = $vorige->dealer;
    if($som > 21) {
$inzett = number_format($vorige->inzet,0,",",".");
echo " <tr><td width=100 align=center valign=top class=maintxt>Computer<br>($dealer)</td><td colspan=2 align=left class=maintxt>$pictured
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt><br>You have lost. You lose \$$inzett to the casino.<br><br><a href=blackjack.php>Play Again</a></table></form>
</body>";
    mysql_query("DELETE FROM `blackjack` WHERE `login`='{$data->login}'");
    exit;
    }
    $dealer = $vorige->dealer;
    $getal = rand(1,13);
    $soort = rand(1,4);
    if($soort == 1) {$soort = "harten";}
    if($soort == 2) {$soort = "schoppen";}
    if($soort == 3) {$soort = "ruiten";}
    if($soort == 4) {$soort = "klaveren";}
    $geta = $getal;
    if($getal == 11) {$geta = "boer"; $getal = 10;}
    if($getal == 12) {$geta = "vrouw"; $getal = 10;}
    if($getal == 13) {$geta = "koning"; $getal = 10;}
    if($getal == 1) {$geta = "aas"; $getal = 11; $aas = 1;}
    $picture = "<img src=".$picurl.$soort.$geta.$ext.">";
    $pictured = $pictured." &nbsp;&nbsp; ".$picture;
    $somd = ($dealer + $getal);
    if($somd > 21 && $aas == 1) {$dealer = ($dealer + 1); $aas = 0;}
    else {$dealer = $somd;}
    while ($dealer < $som){
    $getal = rand(1,13);
    $soort = rand(1,4);
    if($soort == 1) {$soort = "harten";}
    if($soort == 2) {$soort = "schoppen";}
    if($soort == 3) {$soort = "ruiten";}
    if($soort == 4) {$soort = "klaveren";}
    $geta = $getal;
    if($getal == 11) {$geta = "boer"; $getal = 10;}
    if($getal == 12) {$geta = "vrouw"; $getal = 10;}
    if($getal == 13) {$geta = "koning"; $getal = 10;}
    if($getal == 1) {$geta = "aas"; $getal = 11; $aas = 1;}
    $picture = "<img src=".$picurl.$soort.$geta.$ext.">";
    $pictured = $pictured." &nbsp;&nbsp; ".$picture;
    $somd = ($dealer + $getal);
    if($somd > 21 && $aas == 1) {$dealer = ($dealer + 1); $aas = 0;}
    else {$dealer = $somd;}
    }
    $winst = (2*$vorige->inzet);
$inzett = number_format($vorige->inzet,0,",",".");
    $inzet = ($vorige->inzet);
    if($dealer > 21){
	if($casino->casinobank-$inzet <0){
mysql_query("UPDATE `[casinoo]` SET `casinobank`='0' WHERE `spel`='3' AND `land`='$data->land'");
mysql_query("UPDATE `[casinoo]` SET `vw`='0' WHERE `spel`='3' AND `land`='$data->land'");
mysql_query("UPDATE `[casinoo]` SET `maximum`='0' WHERE `spel`='3' AND `land`='$data->land'");
mysql_query("UPDATE `[casinoo]` SET `owner`='{$data->login}' WHERE `land`='$data->land' AND `spel`='3'");
print "<tr><td class=mainTxt align=center>The owner of the casino cannot afford to pay you your winnings.<br> Therefore... Congratulations! Your now a proud owner of a BlackJack Casino</td></tr>";
exit();}
	mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$inzet'+'$inzet' WHERE `login`='{$data->login}'"); 
	mysql_query("UPDATE `[casinoo]` SET `casinobank`=`casinobank`-'$inzet'-'$inzet'  WHERE `land`='$data->land' AND `spel`='3'");	
	mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`-'$inzet'-'$inzet'  WHERE `spel`='3' AND `land`='$data->land'");
echo "<tr><td width=100 align=center valign=top class=maintxt>Computer<br>($dealer)</td><td colspan=2 align=left class=maintxt>$pictured
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<td colspan=3 align=center class=maintxt><br>You have won! You win \$$inzett .<br><br><a href=blackjack.php>Play Again</a></table></form>
</body>";
}
    elseif($dealer < $som) {mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$inzet'+'$inzet'  WHERE `login`='{$data->login}'");
	  mysql_query("UPDATE `[casinoo]` SET `casinobank`=`casinobank`-'$inzet'-'$inzet'  WHERE `land`='$data->land' AND `spel`='3'");	
	  mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`-'$inzet'-'$inzet'  WHERE `spel`='3' AND `land`='$data->land'");	
echo "<tr><td width=100 align=center valign=top class=maintxt>Computer<br>($dealer)</td><td colspan=2 align=left class=maintxt>$pictured
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt><br>You have won! You win \$$inzett .<br><br><a href=blackjack.php class='btn btn-info'>Play Again</a></table></form>
</body>";
 }
    elseif($dealer > $som){ echo "
		<tr><td width=100 align=center valign=top class=maintxt>Computer<br>($dealer)</td><td colspan=2 align=left class=maintxt>$pictured
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt><br>You have lost. You lose \$$inzett to the casino.<br><br><a href=blackjack.php class='btn btn-info'>Play Again</a></table></form>
</body>";}
    elseif($dealer == $som){
	mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$inzet' WHERE `login`='{$data->login}'"); 
	mysql_query("UPDATE `[casinoo]` SET `casinobank`=`casinobank`-'$inzet'  WHERE `land`='$data->land' AND `spel`='3'");	
	mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`-'$inzet'  WHERE `spel`='3' AND `land`='$data->land'");
echo " <tr><td width=100 align=center valign=top class=maintxt>Computer<br>($dealer)</td><td colspan=2 align=left class=maintxt>$pictured
</td></tr>
<tr><td width=100 align=center valign=top class=maintxt><b> You :</b> <br>($som)</td><td colspan=2 align=left class=maintxt>$pictures &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr>
<tr><td colspan=3 align=center class=maintxt><br>You and the dealer have drawn the same score. You have won nothing, but you have also lost nothing.<br><br><a href=blackjack.php class='btn btn-info'>Play Again</a></table></form>
</body>";
}
    mysql_query("DELETE FROM `blackjack` WHERE `login`='{$data->login}'");
}
else {$cas = mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='$data->land'");
$cas = mysql_fetch_object($cas);
$owner = ucfirst($cas->owner);
$max = number_format($cas->maximum, 0, ",", ".");
$min = number_format($cas->maximum/10, 0, ",", ".");
echo "
<form method='post'> 
<tr><td class=mainTxt><table align=\"center\"> 
<tr><td width=150>Owner: </td><td>$owner</td></tr> 
<tr><td width=150>Maximum Bet: </td><td>\$$max</td></tr> 
<tr><td width=150>Minimum Bet: </td><td>\$$min</td></tr> 
<tr><td width=150>Bet: </td><td><input type=text class='btn btn-info' name=inzet></td></tr>
<tr><td width=150></td></tr>
<tr><td align=center colspan=2>  <input type=submit class='btn btn-info' name=start value=Play!></td></tr>
</table></td></tr></form>";
echo "<tr><td class=subTitle><b>Explanation</b></td></tr>
  <tr><td class=mainTxt>
The idea of BlackJack is the get a score of 21 using the cards..<br>
If you go over 21 you lose.<br>
If you are dealt an ACE, you can choose yourself whether you want it to stand as a 1 or 11 in value.<br>
But... You dont have to reach 21 everytime to win. You need to have a higher score than the other person, lower than 21, or infact the number 21.
If you lose, you lose the money you bet with. If you win, you double the ammount you bet.<br>
If you get a score of 21 with two cards, this is called BlackJack! And you will win 3 times the amount you original bet.<br>

  </td></tr>";
}}}
?></font></center></body>
</table>

</html> 

<?PHP

// 

mysql_close();

// 
?>