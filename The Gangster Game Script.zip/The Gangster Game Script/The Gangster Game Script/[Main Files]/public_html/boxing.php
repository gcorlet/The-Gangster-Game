<?php
error_reporting(0);

  include("_include-jail.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>

<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<head>

<body>

<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Fight Now</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/boxingpicture.jpg border=0></center>
</td>

<table width=100%>
<tr><td class="subTitle" colspan="2"><b>Boxing Battles</b></td></tr>
<tr><td width="50%" align="center" valign="top">
<table width="90%">
<?php
  
	$boksen1           = mysql_query("SELECT *,UNIX_TIMESTAMP(`opdruktijd`) AS `opdruktijd`,0 FROM `[users]` WHERE `login`='$data->login'");
	$boksen            = mysql_fetch_object($boksen1);
	
	if(!isset($_POST['B'])){
print <<<ENDHTML
<tr><td class="subTitle" colspan="3"><b>Practise Battles</b></td></tr>
<tr><td class="subTitle"><b>Type</b></td><td class="subTitle"><b>Rest</b></td><td class="subTitle"><b>Gain</b></td></tr>
<form method="POST">
<tr><td class="mainTxt"><input type="radio" class="btn btn-info" value="1" name="B1" id="1"><label name="a1" for="1"> Do a 5 minutes practise battle.</label></td><td class="mainTxt"> (2 Minutes rest time)</td><td class="mainTxt">3</td></tr>
<tr><td class="mainTxt"><input type="radio" class="btn btn-info" name="B1" value="2" id="2"><label name="a1" for="2"> Do a 15 minutes practise battle.</label></td><td class="mainTxt"> (5 Minutes rest time)</td><td class="mainTxt">7</td></tr>
<tr><td class="mainTxt"><input type="radio" class="btn btn-info" name="B1" value="3" id="3"><label name="a1" for="3"> Do a 25 minutes practise battle.</label></td><td class="mainTxt"> (10 Minutes rest time)</td><td class="mainTxt">13</td></tr>
<tr><td class="mainTxt" align="right" colspan="3"><input type="submit" class="btn btn-info" value="Fight!" name="B"></td></tr>
</form>
ENDHTML;

	}

if(isset($_POST['B'])){
	if($boksen->opdruktijd + $boksen->opdruktijd1 > time()){
	print "<tr><td class=\"mainTxt\" align=\"center\">You need to rest before you can do a practise battle again.</td></tr>";
	}
	else{
	$b1         = $_POST['B1'];
	
if($b1 == 1){
mysql_query("UPDATE `[users]` SET `opdruktijd1`='120', `opdruktijd`=NOW() WHERE `login`='$data->login'");
}
elseif($b1 == 2){
mysql_query("UPDATE `[users]` SET `opdruktijd1`='300', `opdruktijd`=NOW() WHERE `login`='$data->login'");
}
elseif($b1 == 3){
mysql_query("UPDATE `[users]` SET `opdruktijd1`='600', `opdruktijd`=NOW() WHERE `login`='$data->login'");
}

if($b1 == 1){
print "<tr><td class=\"mainTxt\">You did a practise battle of 5 minutes. You need to rest for 2 minutes before you can start a new practise battle. </td></tr>";
mysql_query("UPDATE `[users]` SET `strength`=`strength`+'3' WHERE `login`='$data->login'");
}
elseif($b1 == 2){
print "<tr><td class=\"mainTxt\">You did a practise battle of 15 minutes. You need to rest for 5 minutes before you can start a new practise battle. </td></tr>";
mysql_query("UPDATE `[users]` SET `strength`=`strength`+'7' WHERE `login`='$data->login'");
}
elseif($b1 == 3){
print "<tr><td class=\"mainTxt\">You did a practise battle of 25 minutes. You need to rest for 10 minutes before you can start a new practise battle. </td></tr>";
mysql_query("UPDATE `[users]` SET `strength`=`strength`+'13' WHERE `login`='$data->login'");
}

	}	
	}

	?>
</table></td></tr>
<tr><td width="50%" align="center" valign="top">
<?php
	if(isset($_POST['AC']) && isset($_POST['id'])){
	$id           = $_POST['id'];
	$members1     = mysql_query("SELECT * FROM `[handdruk]` WHERE `id`='$id'");
	$members      = mysql_fetch_object($members1);
	$naam1        = mysql_query("SELECT * FROM `[users]` WHERE `login`='$members->naam'");
	$naam         = mysql_fetch_object($naam1);

	print "<table width=\"100%\"><tr><td class=\"mainTxt\" align=\"center\">";
	if($data->land != $members->land){
	print "<font color=red>* You need to be in the same Country as $members->naam.</font>";
	}
	elseif($data->cash < $members->inzet){
	print "<font color=red>* You haven't got enough money!</font>";
	}
	elseif($data->login == $members->naam){
	print "<font color=red>* You cannot wrestle yourself!</font>";
	}
	elseif($data->strength == $naam->strength){
	$getal      = rand(1,2);

if($getal == 1){
	print "You were stronger than your opponent and won! You won \$$members->inzet!";
	mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$members->inzet' WHERE `login`='$data->login'");
	mysql_query("UPDATE `[users]` SET `won`=`won`+'1' WHERE `login`='$data->login'");
	mysql_query("UPDATE `[users]` SET `lost`=`lost`+'1' WHERE `login`='$naam->login'");
	mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'$members->naam','$members->naam','Boxing Battle','You <b>lost</b> the Box Battle.')");
	mysql_query("DELETE FROM `[handdruk]` WHERE `id`='$id'");
}
else{
	print "Your opponent was stronger than you and won. You lost \$$members->inzet!";
	mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$members->inzet'*'2' WHERE `login`='$naam->login'");
	mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$members->inzet' WHERE `login`='$data->login'");
	mysql_query("UPDATE `[users]` SET `won`=`won`+'1' WHERE `login`='$naam->login'");
	mysql_query("UPDATE `[users]` SET `lost`=`lost`+'1' WHERE `login`='$data->login'");
	mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'$members->naam','$members->naam','Boxing Battle','You <B>won</B> the Box Battle.')");
	mysql_query("DELETE FROM `[handdruk]` WHERE `id`='$id'");
}
	}
	elseif($data->strength > $naam->strength){
	print "You were stronger than your opponent and won! You won \$$members->inzet!";
	mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$members->inzet' WHERE `login`='$data->login'");
	mysql_query("UPDATE `[users]` SET `won`=`won`+'1' WHERE `login`='$data->login'");
	mysql_query("UPDATE `[users]` SET `lost`=`lost`+'1' WHERE `login`='$naam->login'");
	mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'$members->naam','$members->naam','Boxing Battle','You <b>lost</b> the Box Battle.')");
	mysql_query("DELETE FROM `[handdruk]` WHERE `id`='$id'");
	}
	else{
	print "Your opponent was stronger than you and won. You lost \$$members->inzet!";
	mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$members->inzet'*'2' WHERE `login`='$naam->login'");
	mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$members->inzet' WHERE `login`='$data->login'");
	mysql_query("UPDATE `[users]` SET `won`=`won`+'1' WHERE `login`='$naam->login'");
	mysql_query("UPDATE `[users]` SET `lost`=`lost`+'1' WHERE `login`='$data->login'");
	mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'$members->naam','$members->naam','Boxing Battle','You <B>won</B> the Box Battle.')");
	mysql_query("DELETE FROM `[handdruk]` WHERE `id`='$id'");
	}

	print "</td></tr></table>";
	}

	$members1       = mysql_query("SELECT * FROM `[handdruk]`");

	print "<table width=\"90%\"><tr><td><form method=\"post\">";
	print "	<table width=\"100%\"><tr><td width=5 class=\"subTitle\">&nbsp;</td>  <td align=\"center\" width=150 class=\"subTitle\"><b>Country:</b></td>  <td align=\"center\" class=\"subTitle\"><b>Name:</b></td>  <td align=\"center\" width=90 class=\"subTitle\"><b>Bet:</b></td></tr>";

	while($members = mysql_fetch_object($members1)){
	$user1		= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$members->naam}'");
	$user		= mysql_fetch_object($user1);
	$inzet		= number_format($members->inzet,0);
	print " <tr><td width=5><input type=\"radio\" name=\"id\" value=\"{$members->id}\"></td>  <td class=\"mainTxt\">{$members->land}</td>  <td class=\"mainTxt\"><A href=\"profile.php?x=$members->naam\">{$members->naam}</a> ({$user->won}:{$user->lost})</td>  <td class=\"mainTxt\"><b>\${$inzet}</b></td>  </tr>";
	}

	print " </table><input type=\"submit\" value=\"Start the battle!\" class=\"btn btn-info\" name=\"AC\"></form></td></tr>";
  print <<<ENDHTML
</td></tr></table>
<tr><td colspan="2"><table width="90%" align="center">
	<tr><td class="subTitle" align="center" colspan="3"><b>
	<form method="POST">
	&nbsp;Create Battle</b></td></tr>
<tr><td class="mainTxt" align="center" colspan="3">Current Strength: $data->strength<br>
Wins/Losses Ratio: $data->won:$data->lost<br>

	<p>Bet:<input type="text" class="btn btn-info" name="Inzet" maxlength="9"></p>
	<p><input type="submit" class="btn btn-info" value="Start!" name="OK"></p>
</form></td></tr>
ENDHTML;

if(isset($_POST['OK']) && preg_match('/^[0-9]{1,15}$/',$_POST['Inzet'])){
$inzet    = $_POST['Inzet'];

if($inzet == "" || $inzet < 100){
print "* Your bet must be higher then $100.";
}
elseif($inzet > $data->cash){
print "* You haven't got enough money!";
}
else{
print "<table width=100%><tr><td class=mainTxt>You started a new battle, you must wait untill someone dare to fight you!</font></td></tr></table>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$inzet' WHERE `login`='$data->login'");
mysql_query("INSERT INTO `[handdruk]` (naam,inzet,wanneer,land) values('$data->login','$inzet',NOW(),'$data->land')");
}
}

	?></table></td></tr>
</body>
</html>