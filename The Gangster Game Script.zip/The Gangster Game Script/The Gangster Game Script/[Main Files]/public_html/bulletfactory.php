<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
header("Location: login.php");
exit;
}

/* ------------------------- */ ?>
<html>


<head>

<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">
<table width='90%' cellpadding='2' cellspacing='1' align='center' >
<?PHP
  $dbres                = mysql_query("SELECT * FROM `[users]` WHERE `login`='$data->login'");
    $data                = mysql_fetch_object($dbres);

  $dbres                = mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory'");
    $aantal                = mysql_fetch_object($dbres);

if($aantal->owner =='1'){
print"
<table align=center width=87%>
<tr><td class=subTitle>Buy Bullet Factory</td></tr>
<tr><td class=mainTxt align=center>The bullet factory has no owner</td></tr>
<tr><td class=mainTxt align=center>
<a href='buybf.php' class='btn btn-info'>Click Here to purchase the bullet factory</a>
</td></tr>
</table>
";
} else {

$ownerr = ($aantal->owner == "unowned") ? "<b><a href=\"takebf.php\" class='btn btn-info'>Take Over!</a></b>" : "<a href=\"profile.php?x={$aantal->owner}\" class='btn btn-info'>$aantal->owner</a>";
$owner = ($aantal->owner == "test") ? "<font color=white>Property of the Country</font>" : "$ownerr";

$active = ($aantal->active >= "1") ? "<font color=green>Making Bullets</font>" : "<font color=red>Not active</font>";

if (isset($_POST['buy'])) {
       $amount = $_POST['amount'];
       $genoegcash = round($aantal->price*$amount);
       if($genoegcash <= $data->cash) {
if($aantal->amount >= $amount) {
if($data->login == $aantal->owner){
print"<font color=red>* This is your own factory</font>";
exit;}
		if(!preg_match('/^[0-9]{1,10}$/',$_POST['amount'])){
    echo "<font color=red>* error!</font>"; exit;}
if($amount > 0) {
mysql_query("UPDATE `[users]` set `kogels`=`kogels`+'$amount', `cash`=`cash`-'$genoegcash' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` set `bank`=`bank`+'$genoegcash' WHERE `login`='$aantal->owner'");
mysql_query("UPDATE `[buildings]` set `amount`=`amount`-{$amount}, `profit`=`profit`+{$genoegcash} WHERE `type`='bulletfactory' AND `city`='$data->land'");
echo "<tr><td class=maintxt>You have bought $amount bullets.</td></tr>";

} else {
echo "<font color=red>* Invalid Input!</font>";
}

} else {
echo "<font color=red>* The bulletfactory doesnt have that many bullets!</font>";
}
} else {
echo "<font color=red>* You dont have enough cash!</font>";
}
}
?>
<html>
<table width='50%' cellpadding='2' cellspacing='1' align='center' >
<tr><td class="subtitle" colspan=2><center><b>Bullet Factory</b></center></td></tr>
<tr><td class="maintxt" colspan=2 align="center">Bullets are very important and need for attacks!<br><br>The owner of this bullet factory is <b><? echo $owner; ?></b> and has<b><? echo $aantal->amount; ?></b> bullets. The price per bullet is <b>$<? echo $aantal->price; ?></b>.<br>
At the moment the Bullet Factory is: <b><? echo $active; ?></b>.</td></tr>
	<form method="POST"  action="">
	<tr>
	<td colspan=2 class=subtitle align=center>Buy Bullets</td>
	</tr>
	<tr>
	<td class="maintxt" 2>Number of bullets:&nbsp;&nbsp;<input type=text name=amount size=6>&nbsp;&nbsp;<input type="submit" class='btn btn-info' value="Buy!" name="buy"></td>
	</tr>
	</table>
	</form>

</center>
<?

if ($data->login == $aantal->owner){
  $activate				= ($aantal->active == 1) ? "Stop the Factory" : "Start the Factory";
    print <<<ENDHTML
<form method="POST" action=""><br><br>
<table width='50%' cellpadding='2' cellspacing='1' align='center' >
    <tr><td class=subtitle colspan=4 align=center><b>Bullet Factory</b></td></tr>
    <tr><td class=maintxt colspan=4>
    <center>
Give to Someone:<br>
<input type="text" name="newowner" size="20" maxlength="20">&nbsp;&nbsp;<input type="submit" name="giveto" value="Give!"></center>

<tr><td class=subtitle colspan=4 align=center>Price:</td></tr>
<tr><td class=maintxt colspan=4>New Price:&nbsp;&nbsp;<input type="text" class='btn btn-info' name="newprice" size="3" maxlength="5" value="$aantal->price">&nbsp;&nbsp;<input type="submit" class='btn btn-info' name="setnewprice" value="Change!">&nbsp;&nbsp;&nbsp;&nbsp;Current profit is: <b>$aantal->profit</b></td></tr>
		


		
		
		<tr><td class="subtitle">&nbsp;</td><td class="subtitle">Amount</td><td class="subtitle">Quality Factory/td><td class="subtitle">Price</td></tr>
		<tr><td class="maintxt" align="center"><input type="radio" class='btn btn-info' name="bphour" value="0"></td><td class="maintxt">0</td><td class="maintxt">Stop</td class="maintxt"><td class=maintxt>0</td></tr>
		<tr><td class="maintxt" align="center"><input type="radio" class='btn btn-info' name="bphour" value="25"></td><td class="maintxt">10000</td><td class="maintxt">Start</td class="maintxt"><td class="maintxt">2.500.000.</td></tr>
	   <tr><td colspan="3" class="maintxt">If the bullet factory is turned on, it will process 10000 bullets.</td><td class="maintxt" align="rightr"><input type="submit" name="setbph" class='btn btn-info' value="Done!" style="width: 50;"></td></tr>
	</table></form>


ENDHTML;

if (isset($_POST['drop'])){
if ($data->login == $aantal->owner){
mysql_query("UPDATE `[buildings]` SET `owner`='' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[buildings]` SET `profit`='0' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[buildings]` SET `amount`='0' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[buildings]` SET `price`='2500' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[buildings]` SET `active`='0' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("INSERT INTO `[logs]`(login,IP,code,area,time) values('$login','$IP','0','Drop BF',NOW())");
echo "* You have dropped the bullet factory";
}
else {
echo "* This bullet factory does not belong to you!";
}
}

$newowner = $_POST['newowner'];
if (isset($_POST['giveto']) && $data->login == $aantal->owner){
$dbres = mysql_query("SELECT `login` FROM `[users]` WHERE `login`='$newowner'");
$logincheck = mysql_num_rows($dbres);
$new = mysql_fetch_object($dbres);
if ($logincheck >= 1){
mysql_query("UPDATE `[buildings]` SET `owner`='$new->login' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[buildings]` SET `profit`='0' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[buildings]` SET `amount`='0' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[buildings]` SET `price`='2500' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[buildings]` SET `active`='0' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("INSERT INTO `[logs]`(login,IP,code,area,time) values('$login','$IP','0','Give Bullet Factory',NOW())");
echo "You gave the bullet factory to $newowner!";
}
else {
echo "* Invalid username!";
}
}
if (isset($_POST['setnewprice'])){
if (preg_match('/^[0-9]{1,7}$/',$_POST['newprice']) && $data->login == $aantal->owner){
$newprice = $_POST['newprice'];
if($newprice <100){ echo " The minimum price is 100 "; exit; }
if($newprice >2500){ echo " The maximum price is 2,500 "; exit; }
mysql_query("UPDATE `[buildings]` SET `price`='$newprice' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("INSERT INTO `[logs]`(login,IP,code,area,time) values('$login','$IP','$newprice','Set new Bullet price',NOW())");
echo "Je veranderde de prijs naar <b>\$$newprice</b>!";
}
else {
echo "* Invalid amount of cash!";
}
}
if (isset($_POST['storten'])){
$storten2 = $_POST['stort'];
if($storten2 < $data->cash){ echo "You dont have enough cash!"; exit; }
mysql_query("UPDATE `[buildings]` SET `profit`=`profit`+'$storten2' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$storten2' WHERE `login`='$data->login'");
echo "<tr><td class=maintxt align=center>You have bought <b>\$storten2</b>!";
} 
if (isset($_POST['setbph'])){
$newbph = $_POST['bphour'];
mysql_query("UPDATE `[buildings]` SET `active`='$newbph' WHERE `type`='bulletfactory' AND `city`='$data->land'");
mysql_query("INSERT INTO `[logs]`(login,IP,code,area,time) values('$login','$IP','$newbph','Set new BPH',NOW())");
echo "action successful!";
}
}
}
?>
</body>
</html> 
<? mysql_close($mysql); ?>