<?php
error_reporting(0);

include("_include-config.php");
  include("_include-gevangenis.php");
?>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<table width="85%" align="center"> 
<tr><td class="subTitle" colspan="4" style="text-align: center;">Business's</td></tr>
<tr>
	<td class="mainTxt" colspan="4">
	Here you have all the business's which currently run in the game and can be taken under the wing of any member.
	</td>
</tr>
</table>
<?
    $Netherlands2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='1'");
    $Netherlands				= mysql_fetch_object($Netherlands2);

    $France2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='2'");
    $France				= mysql_fetch_object($France2);

    $Cuba2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='3'");
    $Cuba				= mysql_fetch_object($Cuba2);

    $Russia2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='4'");
    $Russia				= mysql_fetch_object($Russia2);

    $Australia2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='5'");
    $Australia				= mysql_fetch_object($Australia2);

    $USA2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='6'");
    $USA					= mysql_fetch_object($USA2);

$Germany2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='7'");
    $Germany					= mysql_fetch_object($Germany2);

$Belgium2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='8'");
    $Belgium					= mysql_fetch_object($Belgium2);


$England2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='9'");
    $England					= mysql_fetch_object($England2);


$Ireland2				= mysql_query("SELECT * FROM `[stadowner]` WHERE `land`='10'");
    $Ireland					= mysql_fetch_object($Ireland2);




$landowner1 = $Netherlands->owner;
$landowner2 = $France->owner;
$landowner3 = $Cuba->owner;
$landowner4 = $Russia->owner;
$landowner5 = $Australia->owner;
$landowner6 = $USA->owner;
$landowner7 = $Germany->owner;
$landowner8 = $Belgium->owner;
$landowner9 = $England->owner;
$landowner10 = $Ireland->owner;

if($landowner1 == "") {
$landowner1 = Nobody;
}
if($landowner2 == "") {
$landowner2 = Nobody;
}
if($landowner3 == "") {
$landowner3 = Nobody;
}
if($landowner4 == "") {
$landowner4 = Nobody;
}
if($landowner5 == "") {
$landowner5 = Nobody;
}
if($landowner6 == "") {
$landowner6 = Nobody;
}
if($landowner7 == "") {
$landowner7 = Nobody;
}
if($landowner8 == "") {
$landowner8 = Nobody;
}
if($landowner9 == "") {
$landowner9 = Nobody;
}
if($landowner10 == "") {
$landowner10 = Nobody;
}

?>
<table width="85%" align="center"> 
<tr>
	<td class="subTitle" colspan="2" style="text-align: center;">President</td>
</tr>
<tr> 
	<td width="50%" class="mainTxt"><b>Land</b></td>
	<td width="50%" class="mainTxt"><b>President</b></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/1.png"> Amsterdam, Netherlands</td>
<td class="mainTxt"><?=$landowner1?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/2.png"> Paris, France</td>
<td class="mainTxt"><?=$landowner2?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/3.png"> Havana, Cuba</td>
<td class="mainTxt"><?=$landowner3?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/4.png"> Moscow, Russia</td>
<td class="mainTxt"><?=$landowner4?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/5.png"> Sydney, Australia</td>
<td class="mainTxt"><?=$landowner5?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/6.png"> New York, USA</td>
<td class="mainTxt"><?=$landowner6?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/7.png"> Berlin, Germany</td>
<td class="mainTxt"><?=$landowner7?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/8.png"> Brussels, Belgium</td>
<td class="mainTxt"><?=$landowner8?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/9.png"> London, England</td>
<td class="mainTxt"><?=$landowner9?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/10.png"> Dublin, Ireland</td>
<td class="mainTxt"><?=$landowner10?></td>
</tr>
</table>
<?
    $kfNetherlands2				= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='1'");
    $kfNetherlands				= mysql_fetch_object($kfNetherlands2);

    $kfFrance2				= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='2'");
    $kfFrance				= mysql_fetch_object($kfFrance2);

    $kfCuba2					= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='3'");
    $kfCuba					= mysql_fetch_object($kfCuba2);

    $kfRussia2					= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='4'");
    $kfRussia					= mysql_fetch_object($kfRussia2);

    $kfAustralia2				= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='5'");
    $kfAustralia				= mysql_fetch_object($kfAustralia2);

    $kfUSA2					= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='6'");
    $kfUSA					= mysql_fetch_object($kfUSA2);


    $kfGermany2					= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='7'");
    $kfGermany					= mysql_fetch_object($kfGermany2);

 $kfBelgium2					= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='8'");
    $kfBelgium					= mysql_fetch_object($kfBelgium2);


 $kfEngland2					= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='9'");
    $kfEngland					= mysql_fetch_object($kfEngland2);

 $kfIreland2					= mysql_query("SELECT * FROM `[buildings]` WHERE `type`='bulletfactory' AND `city`='10'");
    $kfIreland					= mysql_fetch_object($kfIreland2);





$kfowner1 = $kfNetherlands->owner;
$kfowner2 = $kfFrance->owner;
$kfowner3 = $kfCuba->owner;
$kfowner4 = $kfRussia->owner;
$kfowner5 = $kfAustralia->owner;
$kfowner6 = $kfUSA->owner;
$kfowner7 = $kfGermany->owner;
$kfowner8 = $kfBelgium->owner;
$kfowner9 = $kfEngland->owner;
$kfowner10 = $kfIreland->owner;

if($kfowner1 == "") {
$kfowner1 = Nobody;
}
if($kfowner2 == "") {
$kfowner2 = Nobody;
}
if($kfowner3 == "") {
$kfowner3 = Nobody;
}
if($kfowner4 == "") {
$kfowner4 = Nobody;
}
if($kfowner5 == "") {
$kfowner5 = Nobody;
}
if($kfowner6 == "") {
$kfowner6 = Nobody;
}
if($kfowner7 == "") {
$kfowner7 = Nobody;
}
if($kfowner8 == "") {
$kfowner8 = Nobody;
}
if($kfowner9 == "") {
$kfowner9 = Nobody;
}
if($kfowner10 == "") {
$kfowner10 = Nobody;
}







?>
<table width="85%" align="center"> 
<tr>
	<td class="subTitle" colspan="3" style="text-align: center;">Bullet Factory</td>
</tr>
<tr> 
	<td width="33%" class="mainTxt"><b>Land</b></td>
	<td width="33%" class="mainTxt"><b>Profit/Loss</b></td>
	<td width="33%" class="mainTxt"><b>Owner</b></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/1.png"> Amsterdam, Netherlands</td>
	<td class="mainTxt">
	<?php
	if($kfNetherlands->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfNetherlands->profit;
	}
	else if($kfNetherlands->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfNetherlands->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfNetherlands->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner1?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/2.png"> Paris, France</td>
	<td class="mainTxt">
	<?php
	if($kfFrance->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfFrance->profit;
	}
	else if($kfFrance->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfFrance->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfFrance->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner2?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/3.png"> Havana, Cuba</td>
	<td class="mainTxt">
	<?php
	if($kfCuba->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfCuba->profit;
	}
	else if($kfCuba->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfCuba->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfCuba->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner3?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/4.png"> Moscow, Russia</td>
	<td class="mainTxt">
	<?php
	if($kfRussia->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfRussia->profit;
	}
	else if($kfRussia->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfRussia->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfRussia->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner4?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/5.png"> Sydney, Australi�</td>
	<td class="mainTxt">
	<?php
	if($kfAustralia->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfAustralia->profit;
	}
	else if($kfAustralia->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfAustralia->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfAustralia->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner5?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/6.png"> New York, USA</td>
	<td class="mainTxt">
	<?php
	if($kfUSA->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfUSA->profit;
	}
	else if($kfUSA->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfUSA->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfUSA->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner6?></td>
</tr>



<tr>
<td class="mainTxt"><img src="images/flags/7.png"> Berlin, Germany</td>
	<td class="mainTxt">
	<?php
	if($kfGermany->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfGermany->profit;
	}
	else if($kfGermany->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfGermany->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfGermany->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner7?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/8.png"> Brussels, Belgium</td>
	<td class="mainTxt">
	<?php
	if($kfBelgium->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfBelgium->profit;
	}
	else if($kfBelgium->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfBelgium->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfBelgium->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner8?></td>
</tr>

<tr>
<td class="mainTxt"><img src="images/flags/9.png"> London, England</td>
	<td class="mainTxt">
	<?php
	if($kfEngland->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $kfEngland->profit;
	}
	else if($kfEngland->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $kfEngland->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $kfEngland->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner9?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/10.png"> Dublin, Ireland</td>
	<td class="mainTxt">
	<?php
	if($kfIreland->profit < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0" /> '. $kfIreland->profit;
	}
	else if($kfIreland->profit == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"/> '. $kfIreland->profit;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0" /> '. $kfIreland->profit;
	}
	?></td>
<td class="mainTxt"><?=$kfowner10?></td>
</tr>








</table>
<?
    $zhNetherlands2				= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='1'");
    $zhNetherlands				= mysql_fetch_object($zhNetherlands2);

    $zhFrance2				= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='2'");
    $zhFrance				= mysql_fetch_object($zhFrance2);

    $zhCuba2					= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='3'");
    $zhCuba					= mysql_fetch_object($zhCuba2);

    $zhRussia2					= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='4'");
    $zhRussia					= mysql_fetch_object($zhRussia2);

    $zhAustralia2				= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='5'");
    $zhAustralia				= mysql_fetch_object($zhAustralia2);

    $zhUSA2					= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='6'");
    $zhUSA					= mysql_fetch_object($zhUSA2);


    $kfGermany2					= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='7'");
    $kfGermany					= mysql_fetch_object($zhGermany2);

 $kfBelgium2					= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='8'");
    $kfBelgium					= mysql_fetch_object($zhBelgium2);


 $kfEngland2					= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='9'");
    $kfEngland					= mysql_fetch_object($zhEngland2);

 $kfIreland2					= mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='10'");
    $kfIreland					= mysql_fetch_object($zhIreland2);






$zhowner1 = $zhNetherlands->owner;
$zhowner2 = $zhFrance->owner;
$zhowner3 = $zhCuba->owner;
$zhowner4 = $zhRussia->owner;
$zhowner5 = $zhAustralia->owner;
$zhowner6 = $zhUSA->owner;
$zhowner7 = $zhGermany->owner;
$zhowner8 = $zhBelgium->owner;
$zhowner9 = $zhEngland->owner;
$zhowner10 = $zhIreland->owner;

if($zhowner1 == "") {
$zhowner1 = Nobody;
}
if($zhowner2 == "") {
$zhowner2 = Nobody;
}
if($zhowner3 == "") {
$zhowner3 = Nobody;
}
if($zhowner4 == "") {
$zhowner4 = Nobody;
}
if($zhowner5 == "") {
$zhowner5 = Nobody;
}
if($zhowner6 == "") {
$zhowner6 = Nobody;
}
if($zhowner7 == "") {
$zhowner7 = Nobody;
}
if($zhowner8 == "") {
$zhowner8 = Nobody;
}
if($zhowner9 == "") {
$zhowner9 = Nobody;
}
if($zhowner10 == "") {
$zhowner10 = Nobody;
}











$winst1 = $zhNetherlands->winst-$zhNetherlands->verlies;
$winst2 = $zhFrance->winst-$France->verlies;
$winst3 = $zhCuba->winst-$Cuba->verlies;
$winst4 = $zhRussia->winst-$Russia->verlies;
$winst5 = $zhAustralia->winst-$Australia->verlies;
$winst6 = $zhUSA->winst-$USA->verlies;
$winst7 = $zhGermany->winst-$Germany->verlies;
$winst8 = $zhBelgium->winst-$Belgium->verlies;
$winst9 = $zhEngland->winst-$England->verlies;
$winst10 = $zhIreland->winst-$Ireland->verlies;

?>
<table width="85%" align="center"> 
<tr>
	<td class="subTitle" colspan="3" style="text-align: center;">Hospital</td>
</tr>
<tr> 
	<td width="33%" class="mainTxt"><b>Land</b></td>
	<td width="33%" class="mainTxt"><b>Profit/Loss</b></td>
	<td width="33%" class="mainTxt"><b>Owner</b></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/1.png"> Amsterdam, Netherlands</td>
	<td class="mainTxt">
	<?php
	if($winst1 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst1;
	}
	else if($winst1 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst1;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst1;
	}
	?></td>
<td class="mainTxt"><?=$zhNetherlands->owner?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/2.png"> Paris, France</td>
	<td class="mainTxt">
	<?php
	if($winst2 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst2;
	}
	else if($winst2 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst2;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst2;
	}
	?></td>
<td class="mainTxt"><?=$zhFrance->owner?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/3.png"> Havana, Cuba</td>
	<td class="mainTxt">
	<?php
	if($winst3 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst3;
	}
	else if($winst3 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst3;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst3;
	}
	?></td>
<td class="mainTxt"><?=$zhCuba->owner?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/4.png"> Moscow, Russia</td>
	<td class="mainTxt">
	<?php
	if($winst4 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst4;
	}
	else if($winst4 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst4;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst4;
	}
	?></td>
<td class="mainTxt"><?=$zhRussia->owner?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/5.png"> Sydney, Australi�</td>
	<td class="mainTxt">
	<?php
	if($winst5 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst5;
	}
	else if($winst5 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst5;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst5;
	}
	?></td>
<td class="mainTxt"><?=$zhAustralia->owner?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/6.png"> New York, USA</td>
	<td class="mainTxt">
	<?php
	if($winst6 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst6;
	}
	else if($winst6 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst6;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst6;
	}
	?></td>
<td class="mainTxt"><?=$zhUSA->owner?></td>
</tr>


<tr>
<td class="mainTxt"><img src="images/flags/7.png"> Berlin, Germany</td>
	<td class="mainTxt">
	<?php
	if($winst7 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst7;
	}
	else if($winst7 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst7;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst7;
	}
	?></td>
<td class="mainTxt"><?=$zhGermany->owner?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/8.png"> Brussels, Belgium</td>
	<td class="mainTxt">
	<?php
	if($winst8 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst8;
	}
	else if($winst8 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst8;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst8;
	}
	?></td>
<td class="mainTxt"><?=$zhBelgium->owner?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/9.png"> London, England</td>
	<td class="mainTxt">
	<?php
	if($winst9 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst9;
	}
	else if($winst9 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst9;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst9;
	}
	?></td>
<td class="mainTxt"><?=$zhEngland->owner?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/10.png"> Dublin, Ireland</td>
	<td class="mainTxt">
	<?php
	if($winst10 < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $winst10;
	}
	else if($winst10 == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $winst10;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $winst10;
	}
	?></td>
<td class="mainTxt"><?=$zhIreland->owner?></td>
</tr>







</table>
<?
    $rlNetherlands2				= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='1'");
    $rlNetherlands				= mysql_fetch_object($rlNetherlands2);

    $rlFrance2				= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='2'");
    $rlFrance				= mysql_fetch_object($rlFrance2);

    $rlCuba2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='3'");
    $rlCuba					= mysql_fetch_object($rlCuba2);

    $rlRussia2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='4'");
    $rlRussia					= mysql_fetch_object($rlRussia2);

    $rlAustralia2				= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='5'");
    $rlAustralia				= mysql_fetch_object($rlAustralia2);

    $rlUSA2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='6'");
    $rlUSA					= mysql_fetch_object($rlUSA2);

 $rlGermany2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='7'");
    $rlGermany					= mysql_fetch_object($rlGermany2);

    $rlBelgium2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='8'");
    $rlBelgium					= mysql_fetch_object($rlBelgium2);

    $rlEngland2				= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='9'");
    $rlEngland				= mysql_fetch_object($rlEngland2);

    $rlIreland2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='10'");
    $rlIreland					= mysql_fetch_object($rlIreland2);












$rlowner1 = $rlNetherlands->owner;
$rlowner2 = $rlFrance->owner;
$rlowner3 = $rlCuba->owner;
$rlowner4 = $rlRussia->owner;
$rlowner5 = $rlAustralia->owner;
$rlowner6 = $rlUSA->owner;
$rlowner7 = $rlGermany->owner;
$rlowner8 = $rlBelgium->owner;
$rlowner9 = $rlEngland->owner;
$rlowner10 = $rlIreland->owner;

if($rlowner1 == "") {
$rlowner1 = Nobody;
}
if($rlowner2 == "") {
$rlowner2 = Nobody;
}
if($rlowner3 == "") {
$rlowner3 = Nobody;
}
if($rlowner4 == "") {
$rlowner4 = Nobody;
}
if($rlowner5 == "") {
$rlowner5 = Nobody;
}
if($rlowner6 == "") {
$rlowner6 = Nobody;
}
if($rlowner7 == "") {
$rlowner7 = Nobody;
}
if($rlowner8 == "") {
$rlowner8 = Nobody;
}
if($rlowner9 == "") {
$rlowner9 = Nobody;
}
if($rlowner10 == "") {
$rlowner10 = Nobody;
}

?>
<table width="85%" align="center"> 
<tr>
	<td class="subTitle" colspan="3" style="text-align: center;">Roulette</td>
</tr>
<tr> 
	<td width="33%" class="mainTxt"><b>Land</b></td>
	<td width="33%" class="mainTxt"><b>Profit/Loss</b></td>
	<td width="33%" class="mainTxt"><b>Owner</b></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/1.png"> Amsterdam, Netherlands</td>
	<td class="mainTxt">
	<?php
	if($rlNetherlands->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlNetherlands->vw;
	}
	else if($rlNetherlands->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlNetherlands->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlNetherlands->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner1?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/2.png"> Paris, France</td>
	<td class="mainTxt">
	<?php
	if($rlFrance->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlFrance->vw;
	}
	else if($rlFrance->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlFrance->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlFrance->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner2?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/3.png"> Havana, Cuba</td>
	<td class="mainTxt">
	<?php
	if($rlCuba->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlCuba->vw;
	}
	else if($rlCuba->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlCuba->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlCuba->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner3?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/4.png"> Moscow, Russia</td>
	<td class="mainTxt">
	<?php
	if($rlRussia->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlRussia->vw;
	}
	else if($rlRussia->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlRussia->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlRussia->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner4?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/5.png"> Sydney, Australi�</td>
	<td class="mainTxt">
	<?php
	if($rlAustralia->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlAustralia->vw;
	}
	else if($rlAustralia->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlAustralia->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlAustralia->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner5?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/6.png"> New York, USA</td>
	<td class="mainTxt">
	<?php
	if($rlUSA->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlUSA->vw;
	}
	else if($rlUSA->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlUSA->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlUSA->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner6?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/7.png"> Berlin, Germany</td>
	<td class="mainTxt">
	<?php
	if($rlGermany->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlGermany->vw;
	}
	else if($rlGermany->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlGermany->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlGermany->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner7?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/8.png"> Brussels, Belgium</td>
	<td class="mainTxt">
	<?php
	if($rlBelgium->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlBelgium->vw;
	}
	else if($rlBelgium->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlBelgium->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlBelgium->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner8?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/9.png"> London, England</td>
	<td class="mainTxt">
	<?php
	if($rlEngland->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlEngland->vw;
	}
	else if($rlEngland->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlEngland->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlEngland->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner9?></td>
</tr>

<tr>
<td class="mainTxt"><img src="images/flags/10.png"> Dublin, Ireland</td>
	<td class="mainTxt">
	<?php
	if($rlIreland->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $rlIreland->vw;
	}
	else if($rlIreland->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $rlIreland->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $rlIreland->vw;
	}
	?></td>
<td class="mainTxt"><?=$rlowner10?></td>
</tr>
























</table>
<?
    $nsNetherlands2				= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='1'");
    $nsNetherlands				= mysql_fetch_object($nsNetherlands2);

    $nsFrance2				= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='2'");
    $nsFrance				= mysql_fetch_object($nsFrance2);

    $nsCuba2					= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='3'");
    $nsCuba					= mysql_fetch_object($nsCuba2);

    $nsRussia2					= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='4'");
    $nsRussia					= mysql_fetch_object($nsRussia2);

    $nsAustralia2				= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='5'");
    $nsAustralia				= mysql_fetch_object($nsAustralia2);

    $nsUSA2					= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='6'");
    $nsUSA					= mysql_fetch_object($nsUSA2);

   $nsGermany2					= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='7'");
    $nsGermany					= mysql_fetch_object($nsGermany2);

    $nsBelgium2					= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='8'");
    $nsBelgium					= mysql_fetch_object($nsBelgium2);

    $nsEngland2				= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='9'");
    $nsEngland				= mysql_fetch_object($nsEngland2);

    $nsIreland2					= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='10'");
    $nsIreland					= mysql_fetch_object($nsIreland2);





$nsowner1 = $nsNetherlands->owner;
$nsowner2 = $nsFrance->owner;
$nsowner3 = $nsCuba->owner;
$nsowner4 = $nsRussia->owner;
$nsowner5 = $nsAustralia->owner;
$nsowner6 = $nsUSA->owner;
$nsowner7 = $nsGermany->owner;
$nsowner8 = $nsBelgium->owner;
$nsowner9 = $nsEngland->owner;
$nsowner10 = $nsIreland->owner;

if($nsowner1 == "") {
$nsowner1 = Nobody;
}
if($nsowner2 == "") {
$nsowner2 = Nobody;
}
if($nsowner3 == "") {
$nsowner3 = Nobody;
}
if($nsowner4 == "") {
$nsowner4 = Nobody;
}
if($nsowner5 == "") {
$nsowner5 = Nobody;
}
if($nsowner6 == "") {
$nsowner6 = Nobody;
}
if($nsowner7 == "") {
$nsowner7 = Nobody;
}

if($nsowner8 == "") {
$nsowner8 = Nobody;
}

if($nsowner9 == "") {
$nsowner9 = Nobody;
}

if($nsowner10 == "") {
$nsowner10 = Nobody;
}


?>
<table width="85%" align="center"> 
<tr>
	<td class="subTitle" colspan="3" style="text-align: center;">Numbers Game</td>
</tr>
<tr> 
	<td width="33%" class="mainTxt"><b>Land</b></td>
	<td width="33%" class="mainTxt"><b>Profits/Loss</b></td>
	<td width="33%" class="mainTxt"><b>Owner</b></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/1.png"> Amsterdam, Netherlands</td>
	<td class="mainTxt">
	<?php
	if($nsNetherlands->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsNetherlands->vw;
	}
	else if($nsNetherlands->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsNetherlands->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsNetherlands->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner1?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/2.png"> Paris, France</td>
	<td class="mainTxt">
	<?php
	if($nsFrance->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsFrance->vw;
	}
	else if($nsFrance->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsFrance->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsFrance->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner2?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/3.png"> Havana, Cuba</td>
	<td class="mainTxt">
	<?php
	if($nsCuba->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsCuba->vw;
	}
	else if($nsCuba->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsCuba->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsCuba->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner3?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/4.png"> Moscow, Russia</td>
	<td class="mainTxt">
	<?php
	if($nsRussia->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsryskabd->vw;
	}
	else if($nsRussia->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsRussia->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsRussia->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner4?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/5.png"> Sydney, Australi�</td>
	<td class="mainTxt">
	<?php
	if($nsAustralia->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsAustralia->vw;
	}
	else if($nsAustralia->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsAustralia->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsAustralia->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner5?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/6.png"> New York, USA</td>
	<td class="mainTxt">
	<?php
	if($nsUSA->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsUSA->vw;
	}
	else if($nsUSA->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsUSA->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsUSA->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner6?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/7.png"> Berlin, Germany</td>
	<td class="mainTxt">
	<?php
	if($nsGermany->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsGermany->vw;
	}
	else if($nsGermany->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsGermany->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsGermany->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner7?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/8.png"> Brussels, Belgium</td>
	<td class="mainTxt">
	<?php
	if($nsBelgium->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsBelgium->vw;
	}
	else if($nsBelgium->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsBelgium->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsBelgium->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner8?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/9.png"> London, England</td>
	<td class="mainTxt">
	<?php
	if($nsEngland->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsEngland->vw;
	}
	else if($nsEngland->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsEngland->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsEngland->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner9?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/10.png"> Dublin, Ireland</td>
	<td class="mainTxt">
	<?php
	if($nsIreland->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $nsIreland->vw;
	}
	else if($nsIreland->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $nsIreland->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $nsIreland->vw;
	}
	?></td>
<td class="mainTxt"><?=$nsowner10?></td>
</tr>










</table>
<?
    $bjNetherlands2				= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='1'");
    $bjNetherlands				= mysql_fetch_object($bjNetherlands2);

    $bjFrance2				= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='2'");
    $bjFrance				= mysql_fetch_object($bjFrance2);

    $bjCuba2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='3'");
    $bjCuba					= mysql_fetch_object($bjCuba2);

    $bjRussia2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='4'");
    $bjRussia					= mysql_fetch_object($bjRussia2);

    $bjAustralia2				= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='5'");
    $bjAustralia				= mysql_fetch_object($bjAustralia2);

    $bjUSA2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='6'");
    $bjUSA					= mysql_fetch_object($bjUSA2);

  $bjGermany2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='7'");
    $bjGermany					= mysql_fetch_object($bjGermany2);

    $bjBelgium2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='8'");
    $bjBelgium					= mysql_fetch_object($bjBelgium2);

    $bjEngland2				= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='9'");
    $bjEngland				= mysql_fetch_object($bjEngland2);

    $bjIreland2					= mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='3' AND `land`='10'");
    $bjIreland					= mysql_fetch_object($bjIreland2);












$bjowner1 = $bjNetherlands->owner;
$bjowner2 = $bjFrance->owner;
$bjowner3 = $bjCuba->owner;
$bjowner4 = $bjRussia->owner;
$bjowner5 = $bjAustralia->owner;
$bjowner6 = $bjUSA->owner;
$bjowner7 = $bjGermany->owner;
$bjowner8 = $bjBelgium->owner;
$bjowner9 = $bjEngland->owner;
$bjowner10 = $bjIreland->owner;

if($bjowner1 == "") {
$bjowner1 = Nobody;
}
if($bjowner2 == "") {
$bjowner2 = Nobody;
}
if($bjowner3 == "") {
$bjowner3 = Nobody;
}
if($bjowner4 == "") {
$bjowner4 = Nobody;
}
if($bjowner5 == "") {
$bjowner5 = Nobody;
}
if($bjowner6 == "") {
$bjowner6 = Nobody;
}
if($bjowner7 == "") {
$bjowner7 = Nobody;
}
if($bjowner8 == "") {
$bjowner8 = Nobody;
}
if($bjowner9 == "") {
$bjowner9 = Nobody;
}
if($bjowner10 == "") {
$bjowner10 = Nobody;
}










?>
<table width="85%" align="center"> 
<tr>
	<td class="subTitle" colspan="3" style="text-align: center;">Blackjack</td>
</tr>
<tr> 
	<td width="33%" class="mainTxt"><b>Land</b></td>
	<td width="33%" class="mainTxt"><b>Profit/Loss</b></td>
	<td width="33%" class="mainTxt"><b>Owner</b></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/1.png"> Amsterdam, Netherlands</td>
	<td class="mainTxt">
	<?php
	if($bjNetherlands->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjNetherlands->vw;
	}
	else if($bjNetherlands->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjNetherlands->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjNetherlands->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner1?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/2.png"> Paris, France</td>
	<td class="mainTxt">
	<?php
	if($bjFrance->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjFrance->vw;
	}
	else if($bjFrance->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjFrance->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjFrance->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner2?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/3.png"> Havana, Cuba</td>
	<td class="mainTxt">
	<?php
	if($bjCuba->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjCuba->vw;
	}
	else if($bjCuba->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjCuba->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjCuba->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner3?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/4.png"> Moscow, Russia</td>
	<td class="mainTxt">
	<?php
	if($bjRussia->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjRussia->vw;
	}
	else if($bjRussia->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjRussia->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjRussia->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner4?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/5.png"> Sydney, Australi�</td>
	<td class="mainTxt">
	<?php
	if($bjAustralia->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjAustralia->vw;
	}
	else if($bjAustralia->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjAustralia->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjAustralia->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner5?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/6.png"> New York, USA</td>
	<td class="mainTxt">
	<?php
	if($bjUSA->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjUSA->vw;
	}
	else if($bjUSA->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjUSA->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjUSA->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner6?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/7.png"> Berlin, Germany</td>
	<td class="mainTxt">
	<?php
	if($bjGermany->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjGermany->vw;
	}
	else if($bjGermany->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjGermany->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjGermany->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner7?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/8.png"> Brussels, Belgium</td>
	<td class="mainTxt">
	<?php
	if($bjBelgium->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjBelgium->vw;
	}
	else if($bjBelgium->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjBelgium->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjBelgium->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner8?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/9.png"> London, England</td>
	<td class="mainTxt">
	<?php
	if($bjEngland->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjEngland->vw;
	}
	else if($bjEngland->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjEngland->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjEngland->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner9?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/10.png"> Dublin, Ireland</td>
	<td class="mainTxt">
	<?php
	if($bjIreland->vw < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $bjIreland->vw;
	}
	else if($bjIreland->vw == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $bjIreland->vw;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $bjIreland->vw;
	}
	?></td>
<td class="mainTxt"><?=$bjowner10?></td>
</tr>








</table>
<?
    $pkNetherlands2				= mysql_query("SELECT * FROM `[poker]` WHERE `land`='1'");
    $pkNetherlands				= mysql_fetch_object($pkNetherlands2);

    $pkFrance2				= mysql_query("SELECT * FROM `[poker]` WHERE `land`='2'");
    $pkFrance				= mysql_fetch_object($pkFrance2);

    $pkCuba2					= mysql_query("SELECT * FROM `[poker]` WHERE `land`='3'");
    $pkCuba					= mysql_fetch_object($pkCuba2);

    $pkRussia2					= mysql_query("SELECT * FROM `[poker]` WHERE `land`='4'");
    $pkRussia					= mysql_fetch_object($pkRussia2);

    $pkAustralia2				= mysql_query("SELECT * FROM `[poker]` WHERE `land`='5'");
    $pkAustralia				= mysql_fetch_object($pkAustralia2);

    $pkUSA2					= mysql_query("SELECT * FROM `[poker]` WHERE `land`='6'");
    $pkUSA					= mysql_fetch_object($pkUSA2);

  $pkGermany2					= mysql_query("SELECT * FROM `[poker]` WHERE `land`='7'");
    $pkGermany					= mysql_fetch_object($pkGermany2);

    $pkBelgium2					= mysql_query("SELECT * FROM `[poker]` WHERE `land`='8'");
    $pkBelgium					= mysql_fetch_object($pkBelgium2);

    $pkEngland2				= mysql_query("SELECT * FROM `[poker]` WHERE `land`='9'");
    $pkEngland				= mysql_fetch_object($pkEngland2);

    $pkIreland2					= mysql_query("SELECT * FROM `[poker]` WHERE `land`='10'");
    $pkIreland					= mysql_fetch_object($pkIreland2);








$pkowner1 = $pkNetherlands->owner;
$pkowner2 = $pkFrance->owner;
$pkowner3 = $pkCuba->owner;
$pkowner4 = $pkRussia->owner;
$pkowner5 = $pkAustralia->owner;
$pkowner6 = $pkUSA->owner;
$pkowner7 = $pkGermany->owner;
$pkowner8 = $pkBelgium->owner;
$pkowner9 = $pkEngland->owner;
$pkowner10 = $pkIreland->owner;

if($pkowner1 == "") {
$pkowner1 = Nobody;
}
if($pkowner2 == "") {
$pkowner2 = Nobody;
}
if($pkowner3 == "") {
$pkowner3 = Nobody;
}
if($pkowner4 == "") {
$pkowner4 = Nobody;
}
if($pkowner5 == "") {
$pkowner5 = Nobody;
}
if($pkowner6 == "") {
$pkowner6 = Nobody;
}
if($pkowner7 == "") {
$pkowner7 = Nobody;
}
if($pkowner8 == "") {
$pkowner8 = Nobody;
}
if($pkowner9 == "") {
$pkowner9 = Nobody;
}
if($pkowner10 == "") {
$pkowner10 = Nobody;
}

?>
<table width="85%" align="center"> 
<tr>
	<td class="subTitle" colspan="3" style="text-align: center;">Poker</td>
</tr>
<tr> 
	<td width="33%" class="mainTxt"><b>Land</b></td>
	<td width="33%" class="mainTxt"><b>Profit/Loss</b></td>
	<td width="33%" class="mainTxt"><b>Owner</b></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/1.png"> Amsterdam, Netherlands</td>
	<td class="mainTxt">
	<?php
	if($pkNetherlands->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkNetherlands->winst;
	}
	else if($pkNetherlands->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkNetherlands->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkNetherlands->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner1?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/2.png"> Paris, France</td>
	<td class="mainTxt">
	<?php
	if($pkFrance->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkFrance->winst;
	}
	else if($pkFrance->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkFrance->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkFrance->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner2?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/3.png"> Havana, Cuba</td>
	<td class="mainTxt">
	<?php
	if($pkCuba->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkCuba->winst;
	}
	else if($pkCuba->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkCuba->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkCuba->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner3?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/4.png"> Moscow, Russia</td>
	<td class="mainTxt">
	<?php
	if($pkRussia->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkRussia->winst;
	}
	else if($pkRussia->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkRussia->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkRussia->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner4?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/5.png"> Sydney, Australi�</td>
	<td class="mainTxt">
	<?php
	if($pkAustralia->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkAustralia->winst;
	}
	else if($pkAustralia->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkAustralia->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkAustralia->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner5?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/6.png"> New York, USA</td>
	<td class="mainTxt">
	<?php
	if($pkUSA->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkUSA->winst;
	}
	else if($pkUSA->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkUSA->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkUSA->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner6?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/7.png"> Berlin, Germany</td>
	<td class="mainTxt">
	<?php
	if($pkGermany->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkGermany->winst;
	}
	else if($pkGermany->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkGermany->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkGermany->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner7?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/8.png"> Brussels, Belgium</td>
	<td class="mainTxt">
	<?php
	if($pkBelgium->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkBelgium->winst;
	}
	else if($pkBelgium->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkBelgium->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkBelgium->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner8?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/9.png"> London, England</td>
	<td class="mainTxt">
	<?php
	if($pkEngland->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkEngland->winst;
	}
	else if($pkEngland->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkEngland->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkEngland->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner9?></td>
</tr>
<tr>
<td class="mainTxt"><img src="images/flags/10.png"> Dublin, Ireland</td>
	<td class="mainTxt">
	<?php
	if($pkIreland->winst < 0)
	{
		echo '<img src="./images/icons/down.gif" border="0"  /> '. $pkIreland->winst;
	}
	else if($pkIreland->winst == 0)
	{
		echo '<img src="./images/icons/0.gif" border="0"  /> '. $pkIreland->winst;
	}
	else
	{
		echo '<img src="./images/icons/up.gif" border="0"  /> '. $pkIreland->winst;
	}
	?></td>
<td class="mainTxt"><?=$pkowner10?></td>
</tr>










</table>






<?
    $knNetherlands2				= mysql_query("SELECT * FROM `[keno]` WHERE `land`='1'");
    $knNetherlands				= mysql_fetch_object($knNetherlands2);

    $knFrance2				= mysql_query("SELECT * FROM `[keno]` WHERE `land`='2'");
    $knFrance				= mysql_fetch_object($knFrance2);

    $knCuba2					= mysql_query("SELECT * FROM `[keno]` WHERE `land`='3'");
    $knCuba					= mysql_fetch_object($knCuba2);

    $knRussia2					= mysql_query("SELECT * FROM `[keno]` WHERE `land`='4'");
    $knRussia					= mysql_fetch_object($knRussia2);

    $knAustralia2				= mysql_query("SELECT * FROM `[keno]` WHERE `land`='5'");
    $knAustralia				= mysql_fetch_object($knAustralia2);

    $knUSA2					= mysql_query("SELECT * FROM `[keno]` WHERE `land`='6'");
    $knUSA					= mysql_fetch_object($knUSA2);

    $knGermany2					= mysql_query("SELECT * FROM `[keno]` WHERE `land`='7'");
    $knGermany					= mysql_fetch_object($knGermany2);

    $knBelgium2					= mysql_query("SELECT * FROM `[keno]` WHERE `land`='8'");
    $knBelgium					= mysql_fetch_object($knBelgium2);

    $knEngland2				= mysql_query("SELECT * FROM `[keno]` WHERE `land`='9'");
    $knEngland				= mysql_fetch_object($knEngland2);

    $knIreland2					= mysql_query("SELECT * FROM `[keno]` WHERE `land`='10'");
    $knIreland					= mysql_fetch_object($knIreland2);







$knowner1 = $knNetherlands->owner;
$knowner2 = $knFrance->owner;
$knowner3 = $knCuba->owner;
$knowner4 = $knRussia->owner;
$knowner5 = $knAustralia->owner;
$knowner6 = $knUSA->owner;
$knowner7 = $knGermany->owner;
$knowner8 = $knBelgium->owner;
$knowner9 = $knEngland->owner;
$knowner10 = $knIreland->owner;

if($knowner1 == "") {
$knowner1 = Nobody;
}
if($knowner2 == "") {
$knowner2 = Nobody;
}
if($knowner3 == "") {
$knowner3 = Nobody;
}
if($knowner4 == "") {
$knowner4 = Nobody;
}
if($knowner5 == "") {
$knowner5 = Nobody;
}
if($knowner6 == "") {
$knowner6 = Nobody;
}
if($knowner7 == "") {
$knowner7 = Nobody;
}
if($knowne8 == "") {
$knowner8 = Nobody;
}
if($knowner9 == "") {
$knowner9 = Nobody;
}
if($knowner10 == "") {
$knowner10 = Nobody;
}

?>

</head>
</html>
