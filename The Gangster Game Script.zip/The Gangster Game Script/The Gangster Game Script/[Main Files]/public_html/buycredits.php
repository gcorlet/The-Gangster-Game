<?php
error_reporting(0);

define("Gangster_Game", true);
?>
<?php 

  include("_include-config.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
</td>
</td>
</td></tr>




<tr>

<td class=mainTxt width="208"> <form action="https://www.paypal.com/cgi-bin/webscr" target="_blank" method="post">
  <td align="center"> 
<input type="hidden" name="cmd" value="_xclick"> 
<input type="hidden" name="business" value="<? echo $paypal;?>"> 
<input type="hidden" name="item_name" value="1500 Game Credits"> 
<input type="hidden" name="item_number" value="1500 Game Credits"> 
<input type="hidden" name="amount" value="10.00">
<input type="hidden" name="no_shipping" value="1"> 
<input type="hidden" name="no_note" value="1"> 
<input type="hidden" name="currency_code" value="USD"> 
<input type="hidden" name="notify_url" value="<? echo $sitelink;?>/success.php"> 
<input type="hidden" name="return" value="<? echo $sitelink;?>/success.php"> 
<input type="hidden" name="cancel_return" value="<? echo $sitelink;?>">
<td class=mainTxt width="199">


<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Buy Credits with Paypal</b></td>
<table  width=100%>
<td class="mainTxt">

<img border=0 src=images/overige/paypal.jpg border=0><BR><BR>

You can purchase <b>1500</b> Game Credits via Paypal. The price is $10.00 and you will receive your credits automatically after the payment is sent. <br><br> If you send an E-Check, this will take a few days to clear and you wont receive your credits automatically.
<br>
<br>
<b>WARNING: You need to Click "Return to Merchant" Button after you have sent the payment, otherwise your credits wont be credited to your account!</b>
<br><br>

<input type="submit" border="0" class="btn btn-info" name="submit" value="Purchase"> </b><BR><BR>
</td>
 </form>
 </b>
</td>


</tr>


</td>


<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Buy Credits with your Phone</b></td>
<table  width=100%>
<td class="mainTxt">You can purchase <b>100</b> Game Credits via your Phone. You will receive your credits automatically after the payment is sent. <br><br> 


<!--  START CHANGE PHONE PAYMENT SCRIPT 123TICKET.COM  -->

<iframe name="123TicketIframe" src="http://www.123ticket.com/Public_IA/iframe/payzone.php?IDS=29738&IDD=38316&login=5093027&brokerid=&extlogin=&my_var_p=&my_var_1=&my_var_2=&my_var_3=&my_var_4=&my_var_5=&ret_pin=1&target=_blank" BGCOLOR="white" width=403 height=320 marginWidth=0 marginHeight=0  frameBorder=0 scrolling="no"></iframe>

<!--  END CHANGE PHONE PAYMENT SCRIPT 123TICKET.COM  -->
</td>

 </b>
</td>