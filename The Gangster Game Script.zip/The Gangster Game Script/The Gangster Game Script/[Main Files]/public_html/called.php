<?php
error_reporting(0);
 
  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }
  

   mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>



<!--  123TICKET SCRIPT TO PROTECT YOUR PAYZONE AREA -->
<noscript>
<meta http-equiv="Refresh" content="0;URL=http://www.123ticket.com/Public_IA/check/error_code.php?IDS=29738&IDD=38316">
</noscript>
<script language="Javascript" src="http://www.123ticket.com/Public_IA/check/chk.php?IDS=29738&IDD=38316"></script>
<!--  END : 123TICKET SCRIPT -->

<head>

<body bgcolor="#990000">
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
 
 
<BR><BR><center>

<img src="images/overige/betaald.jpg" width="600" height="215">

</center>

 
<?php

mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`+'100' WHERE `login`='".$_SESSION['login']."' LIMIT 1");

 
?>
<BR><BR>
<?PHP




echo " 



 <tr><td class=\"mainTxt\" align=\"left\"><font color=green><b><center>Success!</b></font>

<br>
<br>
Congratulations and thank you for purchasing VIP Credits.<br>
Please dont hesitate to contact an admin incase of any problems, thank you. You may now close this window.
</td></tr>";
exit;


?>