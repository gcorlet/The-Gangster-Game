<?php
error_reporting(0);

  include("_include-jail.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>

<title></title>
<link href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>">
<head>


<table width=350>
<?
if ($data->page == "Banned") {
print "<font class=admin><center><b>You Have Been Banned From The Bar!</b></font></center><br>";
exit;
}
  mysql_query("UPDATE `[users]` SET `lpv`=NOW(),`page`='Chat' WHERE `login`='{$data->login}'");
?>
<?php
      if(isset($_POST['msg'])) {
		$msg = $_POST['msg'];
		$c = explode(" ",$msg);
		$msg = strip_tags($msg);
		$msg = str_replace(":<","<img src=images/chatsmilies/back.gif>",$msg);
		$msg = str_replace(":d","<img src=images/chatsmilies/bigsmile.gif>",$msg);
		$msg = str_replace(":'(","<img src=images/chatsmilies/cry.gif>",$msg);
		$msg = str_replace(":>","<img src=images/chatsmilies/forward.gif>",$msg);
		$msg = str_replace(":(","<img src=images/chatsmilies/frown.gif>",$msg);
		$msg = str_replace(":frus:","<img src=images/chatsmilies/frustrated.gif>",$msg);
		$msg = str_replace(":@","<img src=images/chatsmilies/mad.gif>",$msg);
		$msg = str_replace(":pause:","<img src=images/chatsmilies/pause.gif>",$msg);
		$msg = str_replace(":play:","<img src=images/chatsmilies/play.gif>",$msg);
		$msg = str_replace(":)","<img src=images/chatsmilies/smile.gif>",$msg);
		$msg = str_replace(":stop:","<img src=images/chatsmilies/stop.gif>",$msg);
		$msg = str_replace(":o","<img src=images/chatsmilies/suprised.gif>",$msg);
		$msg = str_replace(":p","<img src=images/chatsmilies/tongue.gif>",$msg);
		$msg = str_replace("[b]","<b>",$msg);
		$msg = str_replace("[u]","<u>",$msg);
		$msg = str_replace("[i]","<i>",$msg);
		$msg = str_replace("[s]","<s>",$msg);
		$msg = str_replace("[/b]","</b>",$msg);
		$msg = str_replace("[/u]","</u>",$msg);
		$msg = str_replace("[/i]","</i>",$msg);
		$msg = str_replace("[/s]","</s>",$msg);
		$msg = str_replace("[code]","<font face=\"courier new\" class=normal>",$msg);
		$msg = str_replace("[/code]","</font>",$msg);
		$config = mysql_fetch_object(mysql_query("select * from `chat_config` where `id`='1'"));
		if ($config->silence == N || $data->chatrank == Admin) {
			if (($c[0] == "/whisper") && ($c[1]) && ($c[2])) {
				$whisper = str_replace("$c[0]","",$msg);
				$whisper = str_replace("$c[1]","",$whisper);
		
			} elseif ($c[0] == "/silence" && $data->chatrank == Admin) {
				mysql_query("update `chat_config` set `silence`='Y' where `id`='1'");
				mysql_query("insert into `chat` (user,chat) values('<font class=event>SilentMode 'ON'</font>','$data->login has turned SilentMode ON.')");
			} elseif ($c[0] == "/unsilence" && $data->chatrank == Admin) {
				mysql_query("update `chat_config` set `silence`='N' where `id`='1'");
				mysql_query("insert into `chat` (user,chat) values('<font class=event>SilentMode 'OFF'</font>','$data->login has turned SilentMode OFF.')");
			} elseif ($c[0] == "/adminsay" && $c[1] && $data->chatrank == Admin) {
				$adminsay = str_replace("$c[0]","",$msg);
				mysql_query("insert into `chat` (user,chat) values ('<font class=admin>$data->login</font>','<font class=admin>$adminsay</font>')");
			} elseif ($c[0] == "/addadmin" && $c[1] && $data->chatrank == Admin) {
				mysql_query("insert into `chat` (user,chat) values('<font class=event>Admin</font>','$c[1] is now an Admin.')");
				mysql_query("update `[users]` set `chatrank`='Admin' where `login`='$c[1]'");
			} elseif ($c[0] == "/deladmin" && $c[1] && $data->chatrank == Admin) {
				mysql_query("insert into chat (user,chat) values('<font class=event>Admin</font>','$c[1] is no longer an Admin.')");
				mysql_query("update `[users]` set `chatrank`='Member' where `login`='$c[1]'");
			} elseif ($c[0] == "/kick" && $c[1] && $data->chatrank == Admin) {
				mysql_query("update `[users]` set `page`='Kicked' where `login`='$c[1]'");
				mysql_query("insert into chat (user,chat) values('<font class=event>Admin</font>','$c[1] has been kicked.')");
			} elseif ($c[0] == "/ban" && $c[1] && $data->chatrank == Admin) {
				mysql_query("update `[users]` set `page`='Banned' where `login`='$c[1]'");
				mysql_query("insert into chat (user,chat) values('<font class=event>Admin</font>','$c[1] has been banned from The Bar.')");
			} elseif ($c[0] == "/unban" && $c[1] && $data->chatrank == Admin) {
				mysql_query("update `[users]` set `page`='Unbanned' where `login`='$c[1]'");
				mysql_query("insert into chat (user,chat) values('<font class=event>Admin</font>','$c[1] has been unbanned.')");
			} elseif ($c[0] == "/me" && $c[1]) {
				$action = str_replace("$c[0]","",$msg);
				mysql_query("insert into `chat` (user,chat) values('<font class=me>Action</font>','<font class=me><i>$data->login $action</i></font>')");
			} else {
				if ($data->chatrank == Admin) {

$today = date("F j, Y, g:i a");
					$user = "<font class=normal>[ $today ][</font> <font class=admin>$data->login </font><font class=normal>]";
				} else {
					$user = "<font class=normal>$data->login</font>";
				}

				mysql_query("insert into `chat` (user,chat) values('$user','$msg</b></u></s></i>')");
			}
		}
	}
?>
		
<tr><td height=100%>
	<?php
	$hup = $_GET['hup']; print "<iframe src=chatmsgs.php?userid=$data->login&hup=$hup align=center name=iframe id=iframe frameborder=1 width=615 height=390 allowtransparency=false></iframe>"; ?>
</td></tr>
<form method=post>
<tr><td align=center>
	[<a href=chat.php>Refresh</a>] <textarea cols=40 rows=10 name=msg> </textarea>  <input type=submit value=Chat>
</td></tr>
</form>
</table>