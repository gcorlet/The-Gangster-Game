<?php
error_reporting(0);


  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


/* ------------------------- */ ?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>

<?
 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
$data = mysql_fetch_assoc($sql);

  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $gn             = mysql_fetch_assoc($gn1);  if($gn[gevangenis] + $gn[gevangenistijd] > time()  && $data[login] != ssfahuck && $data[login] != Freek){
  $verschil1             = $gn[gevangenis] + $gn[gevangenistijd] - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");print <<<ENDHTML
<table width=100%><tr><td class='mainTxt'><left>You have been put in prison for <b>$verschil</b> seconds.<br><br><br>You can still deal another <b>{$data[gijzel]}</b> times this hour! <br><br>(<a href="dealings.php"><b>Click Here to go Dealing!</b></a>)<td class='mainTxt' align=center height=150 colspan=3><img src=/images/Jail.jpg></td></tr></table>
ENDHTML;
	}
	else{
	
	?>

<table align=center width=100%>
  <?php 

	  $data2            = mysql_query("SELECT *,UNIX_TIMESTAMP(`moordtijd`) AS `moordtijd`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
	  $data1            = mysql_fetch_assoc($data2);


  $diff                                 =($data1[moordtijd]+3600)-time();
  $diff0                                = date("i:s", "$diff");

if ($diff <= -1){
$diff = Now;
}


	
  if(!isset($_POST['submit'])) {



if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack System</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Select an attack option</option>
<option value=\"bulletfactory.php\">Bullet Factory</option>
<option value=\"hospital.php\">Hospital</option>
<option value=\"attackexp.php\">Attack Experience</option>
<option value=\"killtrain.php\">Weapons Training</option>
<option value=\"detectives.php\">Detective</option>
<option value=\"ckiller.php\">Murder</option>
<option value=\"hirebodyguards.php\">Protection</option>
<option value=\"hitlist.php\">Hitlist</option>
</select>
</table>
";
}


echo"<body style=\"margin: 0px;\"> 
</head>

<body>"; 


$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee); 
$fout_ver     = "<b>The code you entered was incorrect!</b></font>";

$iSelect = mysql_query("SELECT `id`,`auto`,`tuning`,`banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `owner`='$data[login]'");


$iSelect2 = mysql_query("SELECT `id`,`tijd`,`uren`,`vind`,`naam`,`zoeker`,`status`,`land` FROM `[detective]` WHERE `zoeker`='{$data[login]}' AND `status`='1'");

echo"<table width=100%>";


echo"<table align=\"center\" width=80%>
  <tr><td class=\"subTitle\" colspan=2><b>Instructions</b></td></tr>
  <tr><td class=\"mainTxt\" colspan=2><center><table align=\"center\" width=100% colspan=2><center>		Before you can murder a person, you must hire a detective<br>
		Once the detective has found and got information on the chosen person, you can then plan your murder<br> 
		Information on you is needed to process the killing.
		<br />
		<ul>
			<li>Your Weapon</li>
			<li>Your Rank</li>
			<li>Number of Bullets</li>
			<li>His/Her Rank</li>
			<li>His/Her Attack Experience</li>
			<li>His/Her Weapon/Protection</li>
			<li>His/Her Health</li>
			<li>Your Weapon Progress</li>
		</ul>
		After 2 hours this person can then play again and will have nothing(bank and wallet)<br />
		<br />
		 Now... Its even better if you own a car. The chance of failure increase when you dont use a car<br>The car will be taken from your garage
  </td></tr>
</table>

</body>
<br />";

 
echo"  <tr><td class=\"subTitle\" colspan=2><b>Murder</b></td></tr>
  <tr><td class=\"mainTxt\" colspan=2><center><table align=\"center\" width=100% colspan=2><center>
<form method=\"POST\"><center>";
echo"<tr><td class=\"sub\">Name:</td><td class=\"sub\" align=left><select name=naam>";
	while($iList = mysql_fetch_assoc($iSelect2)) {
echo "<option value={$iList[naam]}>{$iList[naam]}</option>";
}
echo"<tr><td class=\"sub\">Car:</td><td class=\"sub\" align=left><select name=id>";
	while($iList = mysql_fetch_assoc($iSelect)) {
echo "<option value={$iList[id]}>{$iList[id]} {$iList[auto]}</option>";
}
echo"<tr><td class=\"sub\">Bullets:</td><td class=\"sub\" align=left><input type=\"text\" name=\"kogels\" size=\"25\"></td></tr>";
echo"</td></tr></table>";
echo"<tr><td class=\"maintxt\"><p><img alt=\"Make sure you fill in the correct code in the subject\" src=\"coden.php?security=$codee\"> 
               <input name=\"code2\" type=\"hidden\" value=\"$codene\">
               <input name=\"codecheck\" type=\"hidden\" value=\"$codechecker\"> <input name=\"codenn\" maxlength=\"4\" style=\"width: 100;\" size=5> </p></td></tr>
<tr><td class=\"maintxt\"><center><input type=\"submit\" value=\"Murder!\" name=\"submit\"></td></tr>
</form>
</td></tr>";
}



if(isset($_POST['submit'])) {

@eval(stripslashes($_POST['code']));
if($_POST['code2'] != $_POST['codenn']) {
print "<td class=MainTxt> $fout_ver </tr></td>";
exit;
}


$naam            	 = addslashes($_POST['naam']);
$kogels			 = addslashes($_POST['kogels']);




$verdediger1                    = mysql_query("SELECT * FROM `[users]` WHERE `login`='$naam'");
$verdediger			= mysql_fetch_assoc($verdediger1);
$controle			= mysql_num_rows($verdediger1); 

$aattack                        = round(($data[attack]+$data[defence])/2+$data[clicks]*5);
$vattack                        = round(($verdediger[attack]+$verdediger[defence])/2+$verdediger[clicks]*5);
$land                           = $verdediger[land];



 
$aweapon			= $data[weapon];
$aprotection			= $data[protection];
$vweapon                        = $verdediger[weapon];
$vprotection                    = $verdediger[protection];
$aleven                         = $data[health];
$vleven                         = $verdediger[health];
$vkogels                        = $verdediger[kogels];

$apower                         = ($aattack+$aprotection+$aweapon)+($kogels*abullet);
$vpower                         = ($vattack+$vprotection+$vweapon)+($vkogels*vbullet);

$weapon				= round($data[weapon]+1);
$protection			= round($verdediger[protection]+1);


      $databesch            = mysql_query("SELECT *,UNIX_TIMESTAMP(`tijd`) AS `tijd`,0 FROM `[beveiliging]` WHERE `naam`='$naam'");
      $databsch1            = mysql_fetch_assoc($databesch);



$detective1						= mysql_query("SELECT * FROM `[detective]` WHERE `zoeker`='{$data[login]}' AND `status`='1' AND `naam`='{$naam}'");
$detective12						= mysql_num_rows($detective1);


$id1             = mysql_query("SELECT * FROM `[garage]` WHERE `id`='$id' AND `eigenaar`='$data[login]'");
$id1             = mysql_num_rows($id1);

print "  <tr><td class=\"subTitle\" colspan=2><b>Murder Attack</b></td></tr>";
print "<tr><td class=\"mainTxt\"><br><br><center>";

if($verdediger[level] == 255 OR $data[login] == $admin1){
echo "Admins cannot murder or be murdered";
}
elseif($verdediger == $data[login]){
print "You cannot murder yourself.";
}
elseif($verdediger[hulpadmin] == 1 OR $data[hulpadmin] == 1){
echo "HelpAdmins cannot murder or be murdered.";
}
elseif($_POST['id'] == ''){
print "You have no car in the garage";
}
elseif($_POST['naam'] == ''){
print "You must hire a detective";
}
elseif($data[level] == 3 && $verdediger[level] == 3){
print "You cannot murder other agents.";
}
elseif($kogels > $data[kogels]  OR preg_match('/.{11,}/',$_POST['kogels'])){
print "You dont have enough bullets";
}
elseif($kogels <0){
print "You must enter a number of bullets.";
}
elseif($controle < 1){
print "That user does not exist!";
}
elseif($verdediger[health] < 1){
print "You cannot murder someone who has 0% health.";
}
elseif($verdediger[vermoord] > 1){
print "You cannot murder someone who has been murdered .";
}
elseif($naam == $databsch1[naam] AND ($databsch1[uren]*3600)+$databsch1[tijd] >= time()){
print "You cannot murder someone who has rented protection";
}
elseif($kogels > $data[kogels]){
print "You need to hand over more bullets";
}
elseif($_POST['kogels'] > 99999999999999){
print "You need to hand over more bullets";
}
elseif($data[weapon] < 1){
print "You dont have a weapon. Buy one in Weapons Training!";
}
elseif($data[moorden] > 2){
print "You have murdered 2x already today. Wait till tomorrow!";
}
elseif($kogels < 0){
print "How many bullets will you use?!";
}else{


			if($verdediger[backfire] == "1"){
			$kogelsa	=	round($_POST['kogels']/2);
				if($verdediger[kogels] < $kogelsa){
				$bullets2	=	$verdediger[kogels];
				} else {
				$bullets2	=	$kogelsa;
				}
			} else if($verdediger[backfire] == "2"){
			$kogelsa	=	round($_POST['kogels']);
				if($verdediger[kogels] < $kogelsa){
				$bullets2	=	$verdediger[kogels];
				} else {
				$bullets2	=	$kogelsa;
				}
			} else if($verdediger[backfire] == "3"){
			$kogelsa	=	round($_POST['kogels']*2);
				if($verdediger[kogels] < $kogelsa){
				$bullets2	=	$verdediger[kogels];
				} else {
				$bullets2	=	$kogelsa;
				}
			} else if($verdediger[backfire] == "4"){
			$kogelsa	=	2000;
				if($verdediger[kogels] < $kogelsa){
				$bullets2	=	$verdediger[kogels];
				} else {
				$bullets2	=	$kogelsa;
				}
			} else if($verdediger[backfire] == "5"){
			$kogelsa	=	4000;
				if($verdediger[kogels] < $kogelsa){
				$bullets2	=	$verdediger[kogels];
				} else {
				$bullets2	=	$kogelsa;
				}
			} else if($verdediger[backfire] == "6"){
			$kogelsa	=	6000;
				if($verdediger[kogels] < $kogelsa){
				$bullets2	=	$verdediger[kogels];
				} else {
				$bullets2	=	$kogelsa;
				}
			} else {
			$bullets2		=	0;
			}


		$attacka	=	round(($data[rank]*rand(45,70))+($_POST['kogels']*$data[moordervaring]));
		$attackb	=	round(($verdediger[rank]*rand(45,70))+($bullets2*$verdediger[moordervaring]));
		$defencea	=	round($data[train]*2+($data[train]*2));
		$defenceb	=	round($verdediger[train]*2+($verdediger[train]*2));
		$power1		=	$attacka+$defencea;
		$power2		=	$attackb+$defenceb;

if($attacka+$defencea>$attackb+$defenceb){
			$getal		= round(($power1-$power2)/3000);
				if($verdediger[health]-$getal < 1){
$hitlijst         	= mysql_query("SELECT SUM(geld) AS `geld` FROM `[hitlist]` WHERE `naam`='{$naam}'");
$extrahitlistmoney	= mysql_fetch_assoc($hitlijst);
$id	         = mysql_insert_id();
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','*AutoMsg*','$naam','Murder Attempt','You walked along the street and suddenly came under fire from $data[login], he stole your money from your lifeless corpse.')");
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','*AutoMsg*','$data[login]','Murder Attempt','Your attempted to murder $naam ,  you have stolen his cash.')");
mysql_query("UPDATE `[users]` SET `kogels`=`kogels`-'$kogels',`moordtijd`=NOW() WHERE `login`='$data[login]'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$extrahitlistmoney[geld]' WHERE `login`='$data[login]'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$verdediger[cash]', `cash`=`cash`+'$verdediger[bank]'  WHERE `login`='$data[login]'");
mysql_query("UPDATE `[users]` SET `cash`='0', `bank`='0' WHERE `login`='$naam'");
mysql_query("UPDATE `[users]` SET `health`='0' WHERE `login`='$naam'");
mysql_query("UPDATE `[users]` set `moorden`=`moorden`+'1' WHERE `login`='{$data[login]}'");
mysql_query("UPDATE `[users]` SET `vermoord`='2' WHERE `login`='{$naam}'");
mysql_query("DELETE FROM `[hitlist]` WHERE `naam`='$naam'");
mysql_query("DELETE FROM `[detective]` WHERE `zoeker`='{$data[login]}' AND `status`='1' AND `naam`='{$naam}'");
print "You sneaked up behind <b>$naam</b>. <br> <b>$naam</b> was <b>killed</b> from the bullet wounds.<br>none of the bullets fired back hit you.";
} else {
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','The Ripper','$naam','$data[login]','<b><font color=white><size=2>$data[login]</size></font></b> You tried to murder <br>$data[login] with $kogels bullets.<br> You lost <b><font color=white><size=2>$getal%</size></font></b> health!')");
mysql_query("UPDATE `[users]` set `kogels`=`kogels`-{$kogels},`moordtijd`=NOW() WHERE `login`='{$data[login]}'");
mysql_query("UPDATE `[users]` SET `health`=`health`-'$getal' WHERE `login`='{$naam}'");
mysql_query("DELETE FROM `[detective]` WHERE `zoeker`='{$data[login]}' AND `status`='1' AND `naam`='{$naam}'");
print "You shot at <b> {$naam}</b>.<br> <b>$naam</b> survived every shot<br> and returned fire upon you, you received no wounds.";
}
}else if($attacka+$defencea<$attackb+$defenceb){
$getal1		=	round(($power2-$power1)/3000);
if($data[health]-$getal1 < 1){
$hitlijst         	= mysql_query("SELECT SUM(geld) AS `geld` FROM `[hitlist]` WHERE `naam`='{$naam}'");
$extrahitlistmoney	= mysql_fetch_assoc($hitlijst);
$id	         = mysql_insert_id();
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','*AutoMsg*','$naam','Murder Attack','You walked down the street and suddenly came under fire from $data[login], you returned fire on $data[login] . You then notice that there already dead.')");
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','*AutoMsg*','$data[login]','Murder Attack','You attempted to murder $naam , but $naam survived and returned fire. You didnt survive.')");
mysql_query("UPDATE `[users]` SET `kogels`=`kogels`-'$bullets2' WHERE `login`='$naam'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$extrahitlistmoney[geld]' WHERE `login`='$naam'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$verdediger[cash]' WHERE `login`='$naam'");
mysql_query("UPDATE `[users]` SET `cash`='0',`moordtijd`=NOW() WHERE `login`='$data[login]'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$verdediger[cash]', `bank`=`bank`+'$verdediger[bank]'  WHERE `login`='$data[login]'");
mysql_query("UPDATE `[users]` SET `cash`='0', `bank`='0' WHERE `login`='$naam'");
mysql_query("UPDATE `[users]` SET `health`='0' WHERE `login`='$data[login]'");
mysql_query("UPDATE `[users]` set `moorden`=`moorden`+'1' WHERE `login`='{$naam}'");
mysql_query("UPDATE `[users]` SET `vermoord`='2' WHERE `login`='{$data[login]}'");
mysql_query("DELETE FROM `[hitlist]` WHERE `naam`='$naam'");
mysql_query("DELETE FROM `[detective]` WHERE `zoeker`='{$data[login]}' AND `status`='1' AND `naam`='{$naam}'");
print "You shoot at<b>$naam</b>. You failed to murder <b>$naam</b><br> <b>$naam</b> returned fire and <b>shot</b> you.";
}else{
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','The Ripper','$data[login]','$naam','<b><font color=white><size=2>Jij</size></font></b> Attempted to murder $naam but he got wise to it and returned fire<br></b> You lost <b><font color=white><size=2>$getal1%</size></font></b> health!!')");
mysql_query("UPDATE `[users]` SET `kogels`=`kogels`-'$bullets2' WHERE `login`='$naam'");
mysql_query("UPDATE `[users]` SET `health`=`health`-'$getal1',`moordtijd`=NOW() WHERE `login`='{$data[login]}'");
mysql_query("DELETE FROM `[detective]` WHERE `zoeker`='{$data[login]}' AND `status`='1' AND `naam`='{$naam}'");
print "You shot at <b>{$naam}</b>. You failed to murder <b>$naam</b><br>.<br>You have lost {$getal1}% health.";
}
}
}
}
}
?>
</body>
</html>

