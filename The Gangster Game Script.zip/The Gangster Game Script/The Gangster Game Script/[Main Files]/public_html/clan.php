<?php
error_reporting(0);

  $OMNILOG				= 1;
  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>

<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<table width=100%>
<?php /* ------------------------- */

  if(isset($_GET['x'])) {
    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$_GET['x']}'");
    if($clan = mysql_fetch_object($dbres)) {
		$info			= $clan->info ;
 $info		= preg_replace("/\[b\]/", "<b>", $info);
        $info		= preg_replace("/\[\/b\]/", "</b>", $info);
 $info		= preg_replace("/\[u\]/", "<u>", $info);
        $info		= preg_replace("/\[\/u\]/", "</u>", $info);
 $info		= preg_replace("/\[i\]/", "<i>", $info);
        $info		= preg_replace("/\[\/i\]/", "</i>", $info);
 $info		= preg_replace('/(http:\/\/\S+)/','<a href="$1" target=\"_blank\">$1</a>',$info);
        $info		= preg_replace('/\n/',"<br>\n",$info);
      
         $info      = eregi_replace("\\[color=([^\\[]*)\\]([^\\[]*)\\[/color\\]","<font color=\"\\1\">\\2</font>",$info);
         
         $info		= str_replace(":D", "<img src=\"images/smilies/icon_biggrin.gif\">",  $info);
         $info		= str_replace(":frown", "<img src=\"images/smilies/icon_frown.gif\">",  $info);
         $info		= str_replace("(6)", "<img src=\"images/smilies/icon_twisted.gif\">",  $info);
         $info		= str_replace(":junkie", "<img src=\"images/smilies/inon_question.gif\">",  $info);
         $info		= str_replace(":mrgreen", "<img src=\"images/smilies/icon_mrgreen.gif\">",  $info);
         $info		= str_replace(":appl", "<img src=\"images/smilies/applaus.gif\">",  $info);
         $info		= str_replace(":p", "<img src=\"images/smilies/icon_razz.gif\">",  $info);
         $info		= str_replace(";)", "<img src=\"images/smilies/icon_wink.gif\">",  $info);
         $info		= str_replace(":o", "<img src=\"images/smilies/icon_surprised.gif\">",  $info);
     



      $info			= preg_replace('/\n/',"<br>\n",$info);
      print "  <tr><td class=\"subTitle\"><b>{$clan->name}</b></td></tr>\n";
      
      print "  <tr><td class=\"subClan\" background=\"{$clan->avatarc}\">&nbsp;</td></tr>\n";
      print "  <tr><td class=\"mainTxt\"><i>$info</i></td></tr>\n";
      print "  <tr><td class=\"mainTxt\">\n";
print <<<ENDHTML
<table align="center">
ENDHTML;
      $dbres				= mysql_query("SELECT `attack`,`defence`,`clicks`,`level`,`type` FROM `[users]` WHERE `clan`='{$clan->name}'");
      while($member = mysql_fetch_object($dbres))
      $power				+= round(($member->attack+$member->defence)/2+$member->clicks*5);
      $power				+= ($clan->def_lvl1*3000)/2;
      $power				+= ($clan->homes*1500)/2;
      
      	
$verdienstenuur = $clan->centrale*300;
$verdienstendag = $verdienstenuur*24;
      print "	<tr><td width=150 align=right>Owner</td>			<td width=20 align=center>-</td>	<td width=150 align=left><a href=\"profile.php?x={$clan->owner}\" class='btn btn-info'>{$clan->owner}</a></td></tr>\n";
      print "	<tr><td width=150 align=right>Members</td>			<td width=20 align=center>-</td>	<td width=150 align=left>". (mysql_num_rows($dbres)) ."</td></tr>\n";
      print "	<tr><td width=150 align=right>Members Power</td>			<td width=20 align=center>-</td>	<td width=150 align=left>$power</td></tr>\n";
      print "	<tr><td width=150 align=right>Gang Attack</td>			<td width=20 align=center>-</td>	<td width=150 align=left>{$clan->attack_lvl1}</td></tr>\n";
      print "	<tr><td width=150 align=right>Gang Defence</td>			<td width=20 align=center>-</td>	<td width=150 align=left>{$clan->def_lvl1}</td></tr>\n";      
     print "	<tr><td width=150 align=right>Land</td>				<td width=20 align=center>-</td>	<td width=150 align=left>{$clan->land}m<sup>2</sup></td></tr>\n";
       print "	<tr><td width=150 align=right>Cash Rank</td>			<td width=20 align=center>-</td>	<td width=150 align=left>{$clan->money_lvl1}</td></tr>\n";
print "	<tr><td width=150 align=right>Cash</td>			<td width=20 align=center>-</td>	<td width=150 align=left>{$clan->cash}</td></tr>\n";
      print "	<tr><td width=150 align=right>Bank</td>				<td width=20 align=center>-</td>	<td width=150 align=left>{$clan->bank}</td></tr>\n";
      print "	<tr><td width=150 align=right>A Gang Since</td>			<td width=20 align=center>-</td>	<td width=150 align=left>{$clan->started}</td></tr>\n";
      print "	<tr><td width=150 align=right>Wages per Hour</td>	<td width=20 align=center>-</td>	<td width=150 align=left>$verdienstenuur</td></tr>\n";
      print "	<tr><td width=150 align=right>Wages per Day</td>	<td width=20 align=center>-</td>	<td width=150 align=left>$verdienstendag</td></tr>\n";
      print "	<tr><td width=150 align=right>&nbsp;</td>			<td width=20 align=center>&nbsp;</td>	<td width=150 align=left>&nbsp;</td></tr>\n";
      print "  </td></table></tr>\n";
print "   <tr><td class=\"mainTxt\"><table width=55% align=center>\n";
 print "	<tr><td width=150 align=right><u>PowerStations</u></td>	<td width=20 align=center>-</td>	<td width=150 align=left>$clan->centrale</td></tr>\n";
 print "	<tr><td width=150 align=right><u>Homes</u></td>	<td width=20 align=center>-</td>	<td width=150 align=left>$clan->homes</td></tr>\n";
 print "	<tr><td width=150 align=right><u>Coffee Shops</u></td>	<td width=20 align=center>-</td>	<td width=150 align=left>$clan->coffeeshop</td></tr>\n";
 print "	<tr><td width=150 align=right><u>Oil Rigs</u></td>	<td width=20 align=center>-</td>	<td width=150 align=left>$clan->platform</td></tr>\n";
print "	<tr><td width=150 align=right><u>Drug Labs</u></td>	<td width=20 align=center>-</td>	<td width=150 align=left>$clan->drugslab</td></tr>\n";
      print "  </td></table></tr>\n";

 

$totaala	=	$clan->attwins+$clan->attlosses;
$totaald	=	$clan->defwins+$clan->deflosses;
      print "  <tr><td class=\"mainTxt\"><table width=100% align=center>\n";
      print "	<tr align=center><td width=100 align=right>&nbsp;</td>			<td width=100><b>Won</b></td>				<td width=100><b>Lost</b></a></td>	<td width=100><b>Total</b></td></tr>\n";
      print "	<tr align=center><td width=100 align=right>Attacked:</td>		<td width=100 align=center>{$clan->attwins}</td>		<td width=100 align=center>{$clan->attlosses}</td>	<td width=100 align=center>{$totaala}</td></tr>\n";
      print "	<tr align=center><td width=100 align=right>Defended:</td>		<td width=100 align=center>{$clan->defwins}</td>		<td width=100 align=center>{$clan->deflosses}</td>	<td width=100 align=center>{$totaald}</td></tr>\n";
      print "  </td></table></tr>\n";


      $dbres				= mysql_query("SELECT `name`,`url` FROM `[weapons]` WHERE `area`=8 OR `area`=8+{$clan->type} ORDER BY `area`,`costs`");
      while($weapon = mysql_fetch_object($dbres)) {
        $name				= $weapon->name;
        $type				= Array("Homes"		=> "homes",
						"Wall"		=> "def_lvl1",
                                                "Bunker"	=> "def_lvl4",
						"Coffeeshop"	=> "money_lvl1",
						"Chemical Lab"	=> "money_lvl1",
                                                "Islands"	=> "money_lvl4",
						"Share"	=> "money_lvl1");
        $type				= $type[$weapon->name];
        $lastarea			= $weapon->area;
      }
       
      print "  <tr><td align=\"right\"><table><tr><td class=\"mainTxt\" width=100 align=\"center\"><a href=\"clann.php?p=join&clan={$clan->name}\" class='btn btn-info'>Join</a></td>";
      print "<td class=\"mainTxt\" width=100 align=\"center\"><a href=\"clandonate.php?x={$clan->name}\" class='btn btn-info'>donate</a></td>"; 
      if($data->clanlevel >= 7)
      print "<td class=\"mainTxt\" width=100 align=\"center\"><a href=\"clanwar.php?x={$clan->name}\" class='btn btn-info'>Attack</a></td>";
      print "</tr></table></td></tr>\n  <tr><td><br></td></tr>\n\n";

      print <<<ENDHTML
  <tr><td><table width=100%>
  <tr><td align="center" class="subTitle" width=15><b>#</b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center"><a href="clan.php?x={$clan->name}&s=login" class='btn btn-info'><b>Nick</a></b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=125><a href="clan.php?x={$clan->name}&s=rank" class='btn btn-info'><b>Rank</b></a></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=100><a href="clan.php?x={$clan->name}&s=money" class='btn btn-info'><b>Cash</b></a></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=75><a href="clan.php?x={$clan->name}&s=power" class='btn btn-info'><b>Power</b></a></td></tr>
ENDHTML;

      $begin				= ($_GET['p'] >= 0) ? $_GET['p']*30 : 0;
      if($_GET['s'] == "login")
        $dbres				= mysql_query("SELECT `login`,`level`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$clan->name}' AND `activated`=1 ORDER BY `login` LIMIT $begin,30");
      else if($_GET['s'] == "money")
        $dbres				= mysql_query("SELECT `login`,`level`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$clan->name}' AND `activated`=1 ORDER BY `cash`+`bank` DESC,`login` ASC LIMIT $begin,30");
      else if($_GET['s'] == "power")
         $dbres				= mysql_query("SELECT `login`,`level`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$clan->name}' AND `activated`=1 ORDER BY (`attack`+`defence`)/2+`clicks`*5 DESC,`login` ASC LIMIT $begin,30");
      else
        $dbres				= mysql_query("SELECT `login`,`level`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$clan->name}' AND `activated`=1 ORDER BY `clanlevel` DESC,`login` ASC LIMIT $begin,30");

      for($j=$begin+1; $member = mysql_fetch_object($dbres); $j++) {
        $rank				= Array("","Member","Recruiter","","","","Manager","General","Leader","Owner");
        $rank				= $rank[$member->clanlevel];
        $power				= round(($member->attack+$member->defence)/2+$member->clicks*5);
        $money				= $member->cash+$member->bank;
		$loginnaam			= $member->login;
		$loginnaam2			= $member->login;
		$loginnaam			= ($member->level & 0x80) ? "<font color=orange><b><font color=#EF7539>$loginnaam<font color=orange></b></font>" : $loginnaam;
$loginnaam				= ($member->level == 21) ? "<b><font color=#679C77>$loginnaam</font></b> <img src=\"ster.gif\" width=16 height=15 border=0 =\"Black\">" : $loginnaam;
$loginnaam				= ($member->level == 22) ? "<b><font color=#679C77>$loginnaam</font></b> <img src=\"diamant.gif\" width=14 height=15 border=0 =\"Black\">" : $loginnaam;
$loginnaam				= ($member->level == 23) ? "<b><font color=#679C77>$loginnaam</font></b> <img src=\"goud.gif\" width=14 height=15 border=0 =\"Black\">" : $loginnaam;
    	$loginnaam			= ($member->level == 20) ? "<font color=#679C77><b><font color=#679C77>$loginnaam<font color=black></b></font>" : $loginnaam;
  		$loginnaam	    	= ($member->level == 10) ? "<b><font color=red>$loginnaam</font></b> <img src=\"images/rood.gif\" width=14 height=15 border=0 alt=\"Rood\">" : $loginnaam;
$loginnaam			= ($member->level == 50) ? "<font color=#D1C900><b><font color=#D1C900>$loginnaam<font color=black></b></font>" : $loginnaam;
		      
  print <<<ENDHTML
  <tr><td align="center" class="mainTxt">$j</td>
	<td class="mainTxt"><a href="profile.php?x=$loginnaam2" class='btn btn-info'>$loginnaam</a></td>
	<td align="center" class="mainTxt">$rank</td>
	<td align="center" class="mainTxt">\$$money</td>
	<td align="center" class="mainTxt">$power</td></tr>

ENDHTML;
      }

      $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `clan`='{$clan->name}' AND `activated`=1");
      print "</table>\n\n<table width=100%>\n  <tr><td class=\"mainTxt\" align=\"center\">";
      if(mysql_num_rows($dbres) <= 30)
        print "&#60; 1 &#62;</td></tr></table>\n";
      else {
        if($begin/30 == 0)
          print "&#60;&#60; ";
        else
          print "<a href=\"clan.php?x={$clan->name}&s={$_GET['s']}&p=". ($begin/30-1) ."\">&#60;&#60;</a> ";

        for($i=0; $i<mysql_num_rows($dbres)/30; $i++) {
          print "<a href=\"clan.php?x={$clan->name}&s={$_GET['s']}&p=$i\">". ($i+1) ."</a> ";
        }

        if($begin+30 >= mysql_num_rows($dbres))
          print "&#62;&#62; ";
        else
          print "<a href=\"clan.php?x={$clan->name}&s={$_GET['s']}&p=". ($begin/30+1) ."\">&#62;&#62;</a>";

        print "  </table></td></tr>\n";
      }
    }
  }
  else if($_GET['p'] == "list") {
    print "  <tr><td><table width=100%>\n";
    print "	<tr><td class=\"subTitle\" style=\"letter-spacing: normal;\"><b>Gang</b></td>  <td class=\"subTitle\" style=\"letter-spacing: normal;\" width=125><b>Owner</b></td>  <td class=\"subTitle\" width=75 style=\"letter-spacing: normal;\"><b>Members</b></td>  <td class=\"subTitle\" width=75 style=\"letter-spacing: normal;\"><b>Power</b></td></tr>\n";
    $dbres				= mysql_query("SELECT `name`,`owner`,`type`,`def_lvl1` FROM `[clans]` ORDER BY `type`");
    while($clan = mysql_fetch_object($dbres)) {
      $power				= 0;
      $dbres2				= mysql_query("SELECT `attack`,`defence`,`clicks`,`type` FROM `[users]` WHERE `clan`='{$clan->name}'");
      while($member = mysql_fetch_object($dbres2))
        $power				+= round(($member->attack+$member->defence)/2+$member->clicks*5);
      $power				+= ($clan->def_lvl1*1500)/2;


      $clanpower[$clan->type][$clan->name] = $power;
    }

    $lasttype				= 1;
    foreach($clanpower as $type => $info) {
      if($type != $lasttype)
        print "  <tr><td><br></td></tr>\n";

      arsort($info);
      foreach($info as $name => $power) {
        $dbres				= mysql_query("SELECT `name`,`owner` FROM `[clans]` WHERE `name`='$name'");
        $clan					= mysql_fetch_object($dbres);
        $dbres			= mysql_query("SELECT `id` FROM `[users]` WHERE `clan`='$name'");
        $nummembers				= mysql_num_rows($dbres);
        print "	<tr><td class=\"mainTxt\"><a href=\"?x=$name\" class='btn btn-info'>$name</a></td>  <td class=\"mainTxt\" width=125><a href=\"profile.php?x={$clan->owner}\" class='btn btn-info'>{$clan->owner}</a></td>  <td class=\"mainTxt\" align=\"center\" width=75>$nummembers</td>  <td class=\"mainTxt\" align=\"right\" width=75>$power&nbsp;</td>";
        if($data->clanlevel >= 7)
          print "  <td align=\"center\" class=\"mainTxt\" width=75><a href=\"clanwar.php?x=$name\" class='btn btn-info'>Attack</a></td></tr>\n";

        else
          print "</tr>\n";
        $lasttype				= $type;
      }
    }
    print "  </table></td></tr>\n";
  }
  else if($_GET['p'] == "join") {
    if($data->clanlevel == 0) {
      print "  <tr><td class=\"subTitle\"><b>FOUT</b></td></tr>\n";
      if(isset($_POST['clan'])) {
        $clan					= substr($_POST['clan'],0,32);
        $dbres					= mysql_query("SELECT `name`,`owner`,`type`,`blocklist` FROM `[clans]` WHERE `name`='{$_POST['clan']}'");
        if($clan = mysql_fetch_object($dbres)) {
          if($clan->type == $data->type) {
          if(preg_match("/,{$data->login},/i",$clan->blocklist)){
 print <<<ENDHTML


  <table width=100%>
    <tr><td class="mainTxt">You are no longer in $clan->name gang. 	</center>
    </td></tr>
  </table>
ENDHTML;
    exit;
    }         
            $data->clan				= "{$clan->name}-[recruit]";
            mysql_query("UPDATE `[users]` SET `clan`='{$clan->name}-[recruit]' WHERE `login`='{$data->login}'");
          }

          else {
            $type				= Array("","drugsdealers","weapondealers","agents","Terrorists","Gangsters");
            $type				= $type[$clan->type];
            print "  <tr><td class=\"mainTxt\"></td></tr>\n";
          }
        }
        else
          print "  <tr><td class=\"mainTxt\">That gang does not exist</td></tr>\n";
      }
    }
    else
      print "  <tr><td class=\"mainTxt\">You are already in this gang</td></tr>\n";
  }
  else if($_GET['p'] == "new" && $data->clanlevel == 0) {
    print "  <tr><td class=\"subTitle\"><b>New Gang</b></td></tr>\n";
    if(isset($_POST['name'])) {
      $_POST['name']				= substr($_POST['name'],0,16);
      if(preg_match('/^[a-zA-Z0-9_\-]+$/',$_POST['name'])) {
if($_POST['name'] == ' ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '  ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '   ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '    ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}   
if($_POST['name'] == '     ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
} 
if($_POST['name'] == '      ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '       ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '        ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '         ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '          ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '           ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '            ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
} 
if($_POST['name'] == '             ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
} 
if($_POST['name'] == '              ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '               ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}  
if($_POST['name'] == '                ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}   
        $dbres					= mysql_query("SELECT `name` FROM `[clans]` WHERE `name`='{$_POST['name']}'");
        if(mysql_num_rows($dbres) == 0) {
          $dbres				= mysql_query("SELECT `land` FROM `[clans]`");
          $land					= 0;
          while($clan = mysql_fetch_object($dbres))
            $land				+= $clan->land;

            $data->clan				= $_POST['name'];
            $data->clanlevel			= 9;
            mysql_query("UPDATE `[users]` SET `clan`='{$_POST['name']}',`clanlevel`=9 WHERE `login`='{$data->login}'");
            mysql_query("INSERT INTO `[clans]`(`name`,`owner`,`started`,`type`) values('{$_POST['name']}','{$data->login}',NOW(),$data->type)");
            print "  <tr><td class=\"mainTxt\">The Gang has been made</td></tr>\n<script language=\"javascript\">\nsetTimeout(\"parent.window.location.reload()\",1000)\n</script>\n";
          }
          
        else
          print "  <tr><td class=\"mainTxt\">There is already a gang with that name</td></tr>\n";
      }
      else
        print "  <tr><td class=\"mainTxt\">There may be only numbers, letters,  _ -.</td></tr>\n";
    }
    print "  <tr><td class=\"mainTxt\" align=\"center\"><br><form method=\"post\">Name: <input type=\"text\" class='btn btn-info' name=\"name\" value=\"{$_POST['name']}\" maxlength=16> <input type=\"submit\" class='btn btn-info' value=\"Submit\" style=\"width: 100\"></form><br></td></tr>\n";
  }
  else if($_GET['p'] == "quit" && $data->clanlevel > 0 && $data->clanlevel < 9) {
    print "  <tr><td class=\"subTitle\"><b>Leave the Gang</b></td></tr>\n";
    if(isset($_POST['quit'])) {

  
   $data->clan2				= $data->clan;
      $data->clanlevel				= 0;
    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    if($clan = mysql_fetch_object($dbres)) 

	 $type				= Array("","$clan->centrale","$clan->centrale","$clan->centrale");
$type					=	$type[$clan->type];
$geld2					= Array("","300","300","300");
$geld2					=	$geld2[$clan->type];
$geld					=	$type*$geld2;
$geld5					=	$geld*24;
$geld6					=	$geld5*2;
        if($geld6 >= $data->bank) {

print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	You have $geld6 in the Gang Bank. Therefore you cannot leave the gang.
</td></tr>
ENDHTML;
   exit;
 }
    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    if($clan = mysql_fetch_object($dbres)) 

	 $type				= Array("","$clan->centrale","$clan->centrale","$clan->centrale");
$type					=	$type[$clan->type];
$geld2					= Array("","300","300","300");
$geld2					=	$geld2[$clan->type];
$geld					=	$type*$geld2;
$geld5					=	$geld*24;
$geld6					=	$geld5*2;
$clan->cash			+= $geld6;
$data->bank			-= $geld6;

mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`hoeveel`) values(NOW(),'$data->login','$data->clan','uitgestapt','2')");
mysql_query("UPDATE `[users]` SET `clan`='',`clanlevel`=0,`bank`={$data->bank},`cdonatie`=0  WHERE `login`='{$data->login}'");

       print <<<ENDHTML
  <tr><td class="mainTxt">You have left the gang</td></tr>
<script language="javascript">
setTimeout("parent.window.location.reload()",2000);
</script>
ENDHTML;
    }
    if(isset($_POST['tweedekeer'])) {


$attack2		= $data->attack; 
$attack			=(int)(	$attack2*0.3);
$data->attack	-=$attack;	

mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`hoeveel`) values(NOW(),'$data->login','$data->clan','uitgestapt','1')");
mysql_query("UPDATE `[users]` SET `clan`='',`clanlevel`=0,`attack`={$data->attack} ,`cdonatie`=0 WHERE `login`='{$data->login}'");

       print <<<ENDHTML
  <tr><td class="mainTxt">You have left the gang</td></tr>
<script language="javascript">
setTimeout("parent.window.location.reload()",2000);
</script>
ENDHTML;
    }
    else if(isset($_POST['cancel'])) {
      print <<<ENDHTML
<script language="javascript">
document.location = "hq.php";
</script>
ENDHTML;
    }
    else {
    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='$data->clan'");
   if($clan = mysql_fetch_object($dbres)) 

	 $type				= Array("","$clan->centrale","$clan->centrale","$data->clan");
$type					=	$type[$clan->type];
$geld2					= Array("","300","300","300");
$geld2					=	$geld2[$clan->type];
$geld					=	$type*$geld2;
$geld5					=	$geld*24;
$geld6					=	$geld5*2;
$attack2		= $data->attack; 
$attack			=	(int)($attack2*0.3);
      print <<<ENDHTML
  <tr><td class="mainTxt" align="center"><form method="post">
	Are you certain you wish to quit the gang?<br>
To leave the gang you must pay <b>$geld6</b> at GTC.<br>
Or you hit <b>$attack</b>.<br><br>
	<input type="submit" name="quit" class='btn btn-info' value="Yess I'll Pay." style="width: 100px;">&nbsp;&nbsp;
	<input type="submit" name="tweedekeer" class='btn btn-info' value="Yes ok, give me attack." style="width: 200px;">&nbsp;&nbsp;
	<input type="submit" name="cancel" class='btn btn-info' value="Cancel" style="width: 100px;">
  </form></td></tr>
ENDHTML;
    }
  }
  else if($_GET['p'] == "delete" && $data->clanlevel == 9) {
    print "  <tr><td class=\"subTitle\"><b>Delete Gang</b></td></tr>\n";
    if(isset($_POST['delete'])) {
      $dbres					= mysql_query("SELECT `login` FROM `[users]` WHERE `clan`='{$data->clan}' OR `clan`='{$data->clan}-[recruit]'");
      while($member = mysql_fetch_object($dbres))
mysql_query("UPDATE `[users]` SET `clan`='',`clanlevel`=0 WHERE `clan`='{$data->clan}' OR `clan`='{$data->clan}-[recruit]'");
      mysql_query("DELETE FROM `[clans]` WHERE `name`='{$data->clan}'");
      mysql_query("DELETE FROM `[clanslogs]` WHERE `waar`='{$data->clan}'");
      mysql_query("DELETE FROM `[clanban]` WHERE `clan`='{$data->clan}'");
     mysql_query("DELETE FROM `[forum_topics]` WHERE `clan`='{$data->clan}'");
      $data->clan				= "";
      $data->clanlevel				= 0;
      print <<<ENDHTML
  <tr><td class="mainTxt">The gang has been deleted</td></tr>
<script language="javascript">
setTimeout("parent.window.location.reload()",2000);
</script>
ENDHTML;
    }
    else if(isset($_POST['cancel'])) {
      print <<<ENDHTML
<script language="javascript">
document.location = "hq.php";
</script>
ENDHTML;
    }
    else {
      print <<<ENDHTML
  <tr><td class="mainTxt" align="center"><form method="post">
	Are you sure you want to delete the gang?<br><br>
	<input type="submit" name="delete" class='btn btn-info' value="Yes" style="width: 100px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="submit" name="cancel" class='btn btn-info' value="No, Cancel" style="width: 100px;">
  </form></td></tr>
ENDHTML;
    }
  }

/* ------------------------- */ ?>
</table>

</body>

</html>
<?
mysql_close();
ob_flush();
?>