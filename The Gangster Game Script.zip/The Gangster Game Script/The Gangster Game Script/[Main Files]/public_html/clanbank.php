<?php
error_reporting(0);


 include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<script language="javascript">
    
    function getKeyCode(eventObject)
    {
      if (!eventObject) keyCode = window.event.keyCode; //IE
      else keyCode = eventObject.which;   //Mozilla
      return keyCode;
    }
      
    function onlyNumeric(eventObject)
    {
      keyCode = getKeyCode(eventObject);
      if (((keyCode > 31) && (keyCode < 48)) || ((keyCode > 57) && (keyCode < 127)))
      {
          if (!eventObject) window.event.keyCode = 0; //IE
          else eventObject.preventDefault(); //Mozilla
          return false;
      }
    }
  </script>
</head>


<table width=100%>
     <tr><td class="subTitle"><b>Clan - Bank</b></td></tr>
 <tr><td class="mainTxt"><center><img border=0 src=images/game/bank.jpg border=0></center></td></tr>
<?php /* ------------------------- */

  if($data->clanlevel >= 8 || $data->clanlevel == 6) {

    $dbres				= mysql_query("SELECT `name`,`cash`,`bank`,`bankleft`,`bankmax` FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);
    if(isset($_POST['out']) && preg_match('/^[0-9]+$/',$_POST['amount'])) {
      if($_POST['amount'] <= $clan->bank) {
        $clan->cash			+= $_POST['amount'];
        $clan->bank			-= $_POST['amount'];
$amount			=$_POST['amount'];
        mysql_query("UPDATE `[clans]` SET `bank`={$clan->bank},`cash`={$clan->cash} WHERE `name`='{$clan->name}'");
       mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`wat2`,`hoeveel`) values(NOW(),'$data->login','$data->clan','bank','$amount','1')"); 

}
      else
        print "  <tr><td class=\"mainTxt\">Theres not that amount of cash in the bank</td></tr>\n";
    }
    else if(isset($_POST['in']) && preg_match('/^[0-9]+$/',$_POST['amount'])) {
      if($_POST['amount'] <= $clan->cash) {
        if($_POST['amount'] <= $clan->bankmax) {
          if($clan->bankleft > 0) {
            $clan->cash			-= $_POST['amount'];
            $clan->bank			+= $_POST['amount'];
            $clan->bankleft--;
$amount			=$_POST['amount'];
            mysql_query("UPDATE `[clans]` SET `bank`={$clan->bank},`cash`={$clan->cash},`bankleft`={$clan->bankleft} WHERE `name`='{$clan->name}'");
           mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`wat2`,`hoeveel`) values(NOW(),'$data->login','$data->clan','bank','$amount','2')"); 

}
          else
            print "  <tr><td class=\"mainTxt\">You cant transfer anymore today</td></tr>\n";
        }
        else
          print "  <tr><td class=\"mainTxt\">You can enter \${$clan->bankmax},- each turn</td></tr>\n";
      }
      else
        print "  <tr><td class=\"mainTxt\">You dont have that much cash</td></tr>\n";
    }

    print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	You can transfer {$clan->bankleft}x each day (max. \${$clan->bankmax} each time)
	<table align="center">
	  <tr><td width=100>Cash:</td>	<td align="right">\${$clan->cash}</td></tr>
	  <tr><td width=100>Cas in Bank:</td>	<td align="right">\${$clan->bank}</td></tr>
	</table>
	<form method="post"><table align="center">
	  <tr><td align="center"><input type="text" class='btn btn-info' name="amount" maxlength="11" onkeypress="onlyNumeric(arguments[0])">,- 
		<input type="submit" name="out" class='btn btn-info'  value="Take Out" style="width: 100;">
		<input type="submit" name="in" class='btn btn-info' value="Put In"  style="width: 100;"></td></tr>
	</table></form>
  </td></tr>
ENDHTML;
  }

/* ------------------------- */ ?>
</table>

</body>


</html>
<?
mysql_close();
ob_flush();
?>