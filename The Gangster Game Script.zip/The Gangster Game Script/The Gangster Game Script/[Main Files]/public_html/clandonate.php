<?php
error_reporting(0);

  $OMNILOG				= 1;
 include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>


<head>

<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<script language="javascript">
    
    function getKeyCode(eventObject)
    {
      if (!eventObject) keyCode = window.event.keyCode; //IE
      else keyCode = eventObject.which;   //Mozilla
      return keyCode;
    }
      
    function onlyNumeric(eventObject)
    {
      keyCode = getKeyCode(eventObject);
      if (((keyCode > 31) && (keyCode < 48)) || ((keyCode > 57) && (keyCode < 127)))
      {
          if (!eventObject) window.event.keyCode = 0; //IE
          else eventObject.preventDefault(); //Mozilla
          return false;
      }
    }
  </script>
</head>

<table width=100%>
<?php /* ------------------------- */
  if(round($data->signup/3600-time()/3600) + 12 <= 0) {
    $dbres				= mysql_query("SELECT `cash` FROM `[clans]` WHERE `name`='{$data->clan}'");
    if($to = mysql_fetch_object($dbres)) {
      if(round($to->signup/3600-time()/3600) + 12 <= 0) {
        print "  <tr><td class=\"subTitle\"><b>Doneren</b></td></tr>\n";
        if(isset($_POST['amount']) && preg_match("/^[0-9]+\$/",$_POST['amount']) && $_POST['amount'] > 0) {

          $amount			= $_POST['amount'];
		  	
          if($amount <= $data->cash) {
            $data->cash			-= $amount;
            $to->cash			+= $amount;
            mysql_query("UPDATE `[users]` SET `cash`={$data->cash} WHERE `login`='{$data->login}'");
            mysql_query("UPDATE `[clans]` SET `cash`={$to->cash} WHERE `name`='{$data->clan}'");

            $forwardedFor		= ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['HTTP_CLIENT_IP'];
            $forwardedFor		= preg_replace('/, .+/','',$forwardedFor);
           mysql_query("INSERT INTO `[logs]`(`time`,`IP`,`forwardedFor`,`login`,`person`,`code`,`area`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','{$data->login}','{$data->clan}',$amount,'donate')");
           mysql_query("UPDATE `[users]` SET `cdonatie`= `cdonatie` + $amount WHERE `login`='{$data->login}'");
 print "  <tr><td class=\"mainTxt\">Gang Donation</td></tr>\n";
          }
          else
            print "  <tr><td class=\"mainTxt\">Not enough cash</td></tr>\n";
        }
      }
      else
        print "  <tr><td class=\"mainTxt\">{$to->login} is under protection</td></tr>\n";
    }
	if($data->clan == ""){
		print "  <tr><td class=\"mainTxt\">You are not in this gang</td></tr>\n";
		$disable = 1;
	}
	if($disable != 1){
    print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	<table align="center">
	  <tr><td width=100>Cash:</td>	<td align="right">\${$data->cash}</td></tr>
	</table>
	<form method="post"><table align="center">
	  <tr><td width=60>To:</td>  <td>{$data->clan}</td></tr>
		<tr><td width=60>Amount:</td>  <td>
          <input type="text" name="amount" maxlength="11" onkeypress="onlyNumeric(arguments[0])" size="20"></td></tr>
		<tr><td></td>  <td align="right"><input type="submit" name="submit" value="Donate"  style="width: 100;"></td></tr>
	</table></form>
  </td></tr>
ENDHTML;
	}
  }
  else
    print "  <tr><td class=\"mainTxt\">You cannot donate when you are under protection!</td></tr>\n";

/* ------------------------- */ ?>
</table>

</body>


</html>
<?
mysql_close();
ob_flush();
?>