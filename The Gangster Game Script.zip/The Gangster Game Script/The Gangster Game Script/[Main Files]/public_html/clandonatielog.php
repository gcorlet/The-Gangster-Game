<?php
error_reporting(0);

  $OMNILOG				= 1;
 include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">


</head>
<table width=100%>

  <tr><td class="mainTxt">
  </td></tr>
  


<tr><td  class="subTitle" align="center"><b>Login</b></td><td  class="subTitle" align="center"><b>Donation</b><td  class="subTitle" align="center"><b>Wage Per Hour</b></td></tr>
<?

$gegevens = mysql_query("SELECT * FROM `[users]` WHERE `clan`='{$data->clan}'") or die(mysql_error());
while($rij = mysql_fetch_object($gegevens)) { 
echo("
<td  class=\"mainTxt\">$rij->login</td>
<td  class=\"mainTxt\">$rij->cdonatie</td>
 
"); 

if($rij->aanuit == 1) {
        print <<<ENDHTML
     <td  class="mainTxt">   Yes</td></tr>
ENDHTML;
      }
if($rij->aanuit == 2) {
        print <<<ENDHTML
   <td  class="mainTxt">     No</td></tr>
ENDHTML;
      }
} 
?>


</table></body>
</html>
<?
mysql_close();
ob_flush();
?>