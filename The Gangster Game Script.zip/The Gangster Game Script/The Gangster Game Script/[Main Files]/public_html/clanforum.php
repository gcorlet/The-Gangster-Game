<?php
error_reporting(0);

   include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

if(!$_GET['p']) {
$begin = 0;
}else {
$begin = $_GET['p'];
}

    include("_include-gevangenis.php");
?>

<html>

<head>
<title><?php echo $page->sitetitle; ?></title>


<SCRIPT language=JavaScript>

	function textCounter(field, countfield, maxlimit) {
		if (field.value.length > maxlimit) // if too long...trim it!
		field.value = field.value.substring(0, maxlimit);
		// otherwise, update 'characters left' counter
		else
	countfield.value = maxlimit - field.value.length;
	}

function submitDis(what) {
	what = document.getElementById(what);
	what.disabled = true;
	what.value = "Posting...";
}
</script>
<link href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css" rel="stylesheet" type="text/css">
</head>

<?
if($_GET['topic']) {




        if(isset($_POST['add'])) {
             

 $id                           = $_GET['topic'];
                $bericht         = $_POST['message'];
                $datum                = date("d-m-Y H:i");
                $query  = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['topic']}");
                $lol        = mysql_fetch_object($query);
             
 
                if($data->forum == 1 || $data->forumc == 1) {
                        print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\">You may not set the forum</td></tr></table></tr></td></table></td></tr></table>\n";
                exit;
}
 if($bericht == ""){
	print "   <table width=\"100%\" cellspacing=0><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td class=\"subTitle2\" align=\"left\"><b><img src=\"images/icons/blokje.jpg\"> Forum</b></td></tr><tr><td align=\"center\">Je Moet wel een bericht geven.<br><br><a href=\"javascript:history.go(-1)\">Terug</a></tr></td></tr></td></table></td></tr></table>\n";
exit;
}

   print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You message has been placed.<BR><BR><a href=\"clanforum.php?topic={$_GET['topic']}\">Back</a></td></tr></table></td></tr></table>\n";
                 mysql_query("INSERT INTO `[foum_replys]`(topicid,datum,login,title,text,date) values($id,'$datum','$data->login','RE:','$bericht',NOW())") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
                 mysql_query("UPDATE `[forum_topics]` SET `replys`=`replys`+1,`datum`='$datum',`date1`=NOW() WHERE `id`={$_GET['topic']}") or die("There has been an error. The following went wrong:  <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
                 mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`+1 WHERE `id`={$lol->subid}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
                 mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`+1 WHERE `login`='{$data->login}'") or die("There has been an error. The following went wrong:  <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
        }
        else {
        $query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['topic']}");
        $topic = mysql_fetch_object($query);
        $user_query2 = mysql_query("SELECT  UNIX_TIMESTAMP(`online`) AS `online`,`forumstatus`,`clanlevel`,`login`,`level`,`forumposts`,`avaurl` FROM `[users]` WHERE `login`='{$topic->login}'");
        $user2                = mysql_fetch_object($user_query2);
if ($user2->clanlevel == 1){
$clanrank	= "Member";
}
elseif ($user2->clanlevel == 2){
$clanrank	= "Recruiter";
}
elseif ($user2->clanlevel == 3){
$clanrank	= "Member";
}
elseif ($user2->clanlevel == 4){
$clanrank	= "Member";
}
elseif ($user2->clanlevel == 5){
$clanrank	= "Member";
}
elseif ($user2->clanlevel == 6){
$clanrank	= "Manager";
}
elseif ($user2->clanlevel == 7){
$clanrank	= "General";
}
elseif ($user2->clanlevel == 8){
$clanrank	= "Leader";
}
elseif ($user2->clanlevel == 9){
$clanrank	= "Owner";
}

                                                  if($user2->level >= "255") {
                                        $status = "Admin";
                                }
 elseif($user2->level == "50") {
                                        $status = "Help Admin";
                                }
 elseif($user2->level == "22") {
                                        $status = "Extreme Member";
                                }
 elseif($user2->level == "23") {
                                        $status = "Extreme Member";
                                }
 elseif($user2->level == "21") {
                                        $status = "Extreme Member";
                                } 


  else {
                        $status = "Member";
                }
             if(time() - $user2->online < 300) {
                                        $online2        = "<font color=\"yellow\"><b> Online </b></font>";
                                }
                                else {
                                        $online2 = "<font color=\"red\"><b> Offline </b></font>";
                                }
               $topic->text                 = htmlspecialchars($topic->text);
        $topic->text                 = nl2br($topic->text);
                $topic->text                 = str_replace("[b]", "<b>",$topic->text);
                $topic->text                 = str_replace("[/b]", "</b>",$topic->text);
                $topic->text                 = str_replace("[i]", "<i>",$topic->text);
                   $topic->text		= preg_replace('/criminalwar/',"***",$topic->text);
                $topic->text		= preg_replace('/BULLETSTAR/',"***",$topic->text);


                $topic->text                 = str_replace("[/i]", "</i>",$topic->text);
                $topic->text                 = str_replace("[u]", "<u>",$topic->text);
                $topic->text                 = str_replace("[/u]", "</u>",$topic->text);
        $topic->text                 = eregi_replace("\\[color=([^\\[]*)\\]([^\\[]*)\\[/color\\]","<font color=\"\\1\">\\2</font>",$topic->text);
        $topic->text                 = eregi_replace("\\[email=([^\\[]*)\\]([^\\[]*)\\[/email\\]", "<a href=\"mailto:\\1\">\\2</a>",$topic->text);
        $topic->text                 = eregi_replace("\\[url=([^\\[]*)\\]([^\\[]*)\\[/url\\]","<a href=\"\\1\" target=_blank>\\2</a>",$topic->text);
        $topic->text                 = eregi_replace("\\[img]([^\\[]*)\\[/img\\]","<img src=\"\\1\">",$topic->text);
        $topic->text                = eregi_replace("\\[quote=([^\\[]*)\\]([^\\[]*)\\[/quote\\]","<center><table width=90%><tr><td>Quote:<br><hr color=\"#000000\" size=1 width=100%></td></tr><tr><td><b>\\1 schreef:</b></td></tr><tr><td>\\2</td></tr><tr><td><hr color=\"#000000\" size=1 width=100%></td></tr></table></center>",$topic->text);
        $topic->text                 = eregi_replace("\\[quote]([^\\[]*)\\[/quote\\]","<center><table width=90%><tr><td>Quote:<br><hr color=\"#000000\" size=1 width=100%></td></tr><tr><td>\\1</td></tr><tr><td><hr color=\"#000000\" size=1 width=100%></td></tr></table></center>",$topic->text);
		$topic->text 		= str_replace("(h)", "<img src=\"images/smilies/icon_cool.gif\" border=0>",$topic->text);   
		$topic->text 		= str_replace("(H)", "<img src=\"images/smilies/icon_cool.gif\" border=0>",$topic->text);    
		$topic->text 		= str_replace(":$", "<img src=\"images/smilies/icon_embarassed.gif\" border=0>",$topic->text);    
		$topic->text 		= str_replace(":(", "<img src=\"images/smilies/icon_frown.gif\" border=0>",$topic->text); 
		$topic->text 		= str_replace("(a)", "<img src=\"images/smilies/icon_innocent.gif\" border=0>",$topic->text); 
		$topic->text 		= str_replace("(A)", "<img src=\"images/smilies/icon_innocent.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace("(k)", "<img src=\"images/smilies/icon_kiss.gif\" border=0>",$topic->text);  
		$topic->text 		= str_replace("(K)", "<img src=\"images/smilies/icon_kiss.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":D", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":d", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$topic->text); 
		$topic->text 		= str_replace("(m)", "<img src=\"images/smilies/icon_moneyinmouth.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace("(M)", "<img src=\"images/smilies/icon_moneyinmouth.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":#", "<img src=\"images/smilies/icon_sealed.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":)", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":0", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":o", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":O", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":p", "<img src=\"images/smilies/icon_razz.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":P", "<img src=\"images/smilies/icon_razz.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(";)", "<img src=\"images/smilies/icon_wink.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":@", "<img src=\"images/smilies/icon_yell.gif\" border=0>",$topic->text);

        $topic->text 		= eregi_replace("kut", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("kloten", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("pik", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("penis", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("vagina", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("lul", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("kanker", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("cancer", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("leier", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("fuck", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("f[b][/b]uck", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("fu[b][/b]ck", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("fuc[b][/b]k", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("neuk", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
        $topic->text 		= eregi_replace("anaal", "<img src=\"images/smilies/icon_censored.gif\">", $topic->text );
	
		$loginnaam			= $user2->login;

$loginnaam			= ($user2->level & 0x80) ? "<font color=orange><b>$loginnaam</b></font>" : $loginnaam;
    	$loginnaam			= ($user2->level == 21) ? "<b><font color=#679C77>$loginnaam</font></b> <img src=\"images/ster.gif\" width=14 height=15 border=0 >" : $loginnaam;
		$loginnaam			= ($user2->level == 22) ? "<b><font color=#679C77>$loginnaam</font></b> <img src=\"images/Diamant.gif\" width=14 height=15 border=0 >" : $loginnaam;
    	$loginnaam			= ($user2->level == 20) ? "<font color=#679C77><b><font color=#679C77>$loginnaam<font color=black></b></font>" : $loginnaam;
  		$loginnaam	    	= ($user2->level == 10) ? "<b><font color=red>$loginnaam</font></b> <img src=\"images/rood.gif\" width=14 height=15 border=0 alt=\"Rood\">" : $loginnaam;
$loginnaam			= ($member->user2 == 50) ? "<font color=#D1C900><b>$loginnaam</b></font>" : $loginnaam;
                       print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\" width=\"100%\"><b>Forum</b></td></tr>";



                   $dbres = mysql_query("SELECT * FROM `[foum_replys]` WHERE `topicid`={$_GET['topic']} AND `del`=0");
                        print "<tr><td align=\"right\" class=\"mainTxt\">Go to page|";
                                        for($i=0; $i<mysql_num_rows($dbres)/10; $i++) {
                                                print " <a href=\"clanforum.php?topic={$_GET['topic']}&p={$i}0\">". ($i+1) ."</a> |";
                                        }
      print "  <tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td><table align=\"center\" width=\"100%\" cellspacing=0><tr><td class=\"topTxt\"><table width=\"100%\"><tr><td class=\"subTxt\" colspan=3>&nbsp;&nbsp;<b>$topic->title</b></td></tr><tr><td width=\"110\" valign=\"top\"><b><a href=\"profile.php?x={$topic->login}\">$loginnaam</font></a></b><BR>$clanrank<BR><img border=\"1\" src=\"{$user2->avaurl}\" width=\"120\" height=\"80\"><BR><BR>$online2<BR>Placed On:</td><td width=\"10\"></td><td valign=\"top\">$topic->text</td></tr>\n";
                
                        print "        <tr><td><i>$topic->datum1</i></td><td colspan=2 align=\"right\"></td></tr></table></td></tr>\n";
                   
               if($data->clanlevel >= 8) {
                        print " </td></tr></td><td align=\"center\"><a href=\"clanforum.php?delreply2={$topic->id}\"><b>Delete topic.</b></td></tr>\n";
                }                    
                  


                   $query2 = mysql_query("SELECT * FROM `[foum_replys]` WHERE `topicid`={$_GET['topic']} AND `del`=0 ORDER BY `date` ASC LIMIT $begin,10");
    			 	mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`-'1' WHERE `login`='$user->forumposts'");
    			 	mysql_query("UPDATE `[forum_sub]` SET `topics`=`topics`-'1' WHERE `area`='{$_GET['area']}'");
                while($forum = mysql_fetch_object($query2)) {
                        $user_query = mysql_query("SELECT  UNIX_TIMESTAMP(`online`) AS `online`,`level`,`clanlevel`,`forumstatus`,`login`,`forumposts`,`avaurl` FROM `[users]` WHERE `login`='{$forum->login}'");
                        $user                = mysql_fetch_object($user_query);
                        $forum->text                 = htmlspecialchars($forum->text);
                        $forum->text                 = nl2br($forum->text);
                        $forum->text                 = str_replace("[b]", "<b>",$forum->text);
                        $forum->text                 = str_replace("[/b]", "</b>",$forum->text);
                        $forum->text                 = str_replace("[i]", "<i>",$forum->text);
                        $forum->text                 = str_replace("[/i]", "</i>",$forum->text);
                        $forum->text                 = str_replace("[u]", "<u>",$forum->text);
                        $forum->text                 = str_replace("[/u]", "</u>",$forum->text);
                        $topic->text		= preg_replace('/BULLETSTAR/',"***",$topic->text);
                        $forum->text                 = eregi_replace("\\[color=([^\\[]*)\\]([^\\[]*)\\[/color\\]","<font color=\"\\1\">\\2</font>",$forum->text);
                        $forum->text                 = eregi_replace("\\[email=([^\\[]*)\\]([^\\[]*)\\[/email\\]", "<a href=\"mailto:\\1\">\\2</a>",$forum->text);
                        $forum->text                 = eregi_replace("\\[url=([^\\[]*)\\]([^\\[]*)\\[/url\\]","<a href=\"\\1\" target=_blank>\\2</a>",$forum->text);
                        $forum->text                 = eregi_replace("\\[img]([^\\[]*)\\[/img\\]","<img src=\"\\1\">",$forum->text);
                        $forum->text                = eregi_replace("\\[quote=([^\\[]*)\\]([^\\[]*)\\[/quote\\]","<center><table width=90%><tr><td>Quote:<br><hr color=\"#000000\" size=1 width=100%></td></tr><tr><td><b>\\1 schreef:</b></td></tr><tr><td>\\2</td></tr><tr><td><hr color=\"#000000\" size=1 width=100%></td></tr></table></center>",$forum->text);
                        $forum->text                 = eregi_replace("\\[quote]([^\\[]*)\\[/quote\\]","<center><table width=90%><tr><td>Quote:<br><hr color=\"#000000\" size=1 width=100%></td></tr><tr><td>\\1</td></tr><tr><td><hr color=\"#000000\" size=1 width=100%></td></tr></table></center>",$forum->text);
                      


 $forum->text = str_replace(':D', '<img src="smilies/icon_biggrin.gif">', $forum->text);
 $forum->text		= preg_replace('/:P/',"<img src=\"images\smilies\icon_razz.gif\">",$forum->text);
               $forum->text		= str_replace(":ban", "<img src=\"images/smilies/ban.gif\">", $forum->text);
			$forum->text 		= str_replace("(h)", "<img src=\"images/smilies/icon_cool.gif\" border=0>",$forum->text);   
			$forum->text 		= str_replace("(H)", "<img src=\"images/smilies/icon_cool.gif\" border=0>",$forum->text);    
			$forum->text 		= str_replace(":$", "<img src=\"images/icons/smilies/icon_embarassed.gif\" border=0>",$forum->text);    
			$forum->text 		= str_replace(":(", "<img src=\"images/smilies/icon_frown.gif\" border=0>",$forum->text); 
			$forum->text 		= str_replace("(a)", "<img src=\"images/smilies/icon_innocent.gif\" border=0>",$forum->text); 
			$forum->text 		= str_replace("(A)", "<img src=\"images/smilies/icon_innocent.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace("(k)", "<img src=\"images/smilies/icon_kiss.gif\" border=0>",$forum->text);  
			$forum->text 		= str_replace("(K)", "<img src=\"images/smilies/icon_kiss.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":D", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":d", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$forum->text); 
			$forum->text 		= str_replace("(m)", "<img src=\"images/smilies/icon_moneyinmouth.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace("(M)", "<img src=\"images/smilies/icon_moneyinmouth.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":#", "<img src=\"images/smilies/icon_sealed.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":)", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":0", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":o", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":O", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":p", "<img src=\"images/smilies/icon_razz.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":P", "<img src=\"images/smilies/icon_razz.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(";)", "<img src=\"images/smilies/icon_wink.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":@", "<img src=\"images/smilies/icon_yell.gif\" border=0>",$forum->text);

        $forum->text  		= eregi_replace("kut", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("kloten", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("pik", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("penis", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("vagina", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("lul", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("kanker", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("cancer", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("leier", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("fuck", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("f[b][/b]uck", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("fu[b][/b]ck", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("fuc[b][/b]k", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("neuk", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );
        $forum->text  		= eregi_replace("anaal", "<img src=\"images/smilies/icon_censored.gif\">", $forum->text );        
                         if($user->forumstatus == "default" && $user->forumposts <= 50) {
                                        $status = "Forum Beginner";
                                }
                                elseif($user->forumstatus == "default" && $user->forumposts <= 150) {
                                        $status = "Forum member";
                                }
                                elseif($user->forumstatus == "default" && $user->forumposts > 150) {
                                        $status = "Forum god";
                                }
                                elseif($user->forumstatus == "gwsp1") {
                                        $status = "Super Moderator";
                                }
                                elseif($user->level == "255") {
                                        $status = "Admin";
                                }
 elseif($user->level == "50") {
                                        $status = "Help Admin";
                                }
 elseif($user->level == "22") {
                                        $status = "Extreem Member";
                                }
 elseif($user->level == "23") {
                                        $status = "Extreem Member";
                                }
 elseif($user->level == "21") {
                                        $status = "Extreem Member";
                                }
if ($user->clanlevel == 1){
$clanrank	= "Member";
}
elseif ($user->clanlevel == 2){
$clanrank	= "Recruiter";
}
elseif ($user->clanlevel == 3){
$clanrank	= "Member";
}
elseif ($user->clanlevel == 4){
$clanrank	= "Member";
}
elseif ($user->clanlevel == 5){
$clanrank	= "Member";
}
elseif ($user->clanlevel == 6){
$clanrank	= "Manager";
}
elseif ($user->clanlevel == 7){
$clanrank	= "General";
}
elseif ($user->clanlevel == 8){
$clanrank	= "Leader";
}
elseif ($user->clanlevel == 9){
$clanrank	= "Owner";
}

                                else {
                                        $status = "Member";
                                }
                                if(time() - $user->online < 300) {
                                        $online        = "<font color=\"yellow\"><b> Online </B></font>";
                                }
                                else {
                                        $online = "<font color=\"red\"><b> Offline </b></font>";
                                }
	$loginnaam			= $user->login;

$loginnaam			= ($user->level & 0x80) ? "<font color=orange><b>$loginnaam</b></font>" : $loginnaam;
    	$loginnaam			= ($user->level == 21) ? "<b><font color=#679C77>$loginnaam</font></b> <img src=\"images/ster.gif\" width=14 height=15 border=0 >" : $loginnaam;
		$loginnaam			= ($user->level == 22) ? "<b><font color=#679C77>$loginnaam</font></b> <img src=\"images/Diamant.gif\" width=14 height=15 border=0 >" : $loginnaam;
    	$loginnaam			= ($user->level == 20) ? "<font color=#679C77><b><font color=#679C77>$loginnaam<font color=black></b></font>" : $loginnaam;
  		$loginnaam	    	= ($user->level == 10) ? "<b><font color=red>$loginnaam</font></b> <img src=\"images/rood.gif\" width=14 height=15 border=0 alt=\"Rood\">" : $loginnaam;
$loginnaam			= ($user->level == 50) ? "<font color=#D1C900><b>$loginnaam</b></font>" : $loginnaam;
    

print <<<ENDHTML
           <form method="post">            <tr><td><table><tr><td >&nbsp;&nbsp;<b>$forum->title $topic->title</b></td></tr>
<tr><td width="110" valign="top"><b><a href="profile.php?x={$forum->login}">$loginnaam</font></a></b><br> $clanrank<BR><img border="1" src="{$user->avaurl}" width="120" height="80">
<BR><BR>$online<BR>Placed On:</td><td width="10"></td>
<td  valign=\"top\" >$forum->text</td></tr>
     </form               
                              <tr><td><i>$forum->date</i></td><td colspan=2 align=\"right\"></td></tr></table></td></tr>


ENDHTML;
                   
               if($data->clanlevel >= 8) {
                        print " </td><td align=\"center\"><a href=\"clanforum.php?delreply={$forum->id}\"><b>Delete this message.</b>   </a></td></tr>\n";
                }                    
                  
                }
          

                $dbres = mysql_query("SELECT * FROM `[foum_replys]` WHERE `topicid`={$_GET['topic']} AND `del`=0");
    			 mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`-'1' WHERE `login`='$user->forumposts'");
    			 mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`-'1' WHERE `area`='{$_GET['area']}'");
                        print "<tr><td align=\"right\">Go to Page|";
                                        for($i=0; $i<mysql_num_rows($dbres)/10; $i++) {
                                                print " <a href=\"clanforum.php?topic={$_GET['topic']}&p={$i}0\">". ($i+1) ."</a> |";
                                        }

     
                if($data->forum == 1 || $data->forumc == 1) {
                        print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\">You cannot set the forum.</td></tr></table></tr></td></table></td></tr></table>\n";
                }
                elseif($topic->slotje == 0 && $data->forumstatus == "gwsp1") {
                        print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\"><B>Reply</b></td></tr><form method=\"post\" name=\"form\"><tr><td align=\"center\">\n";


print <<<ENDHTML

	
ENDHTML;
print "	<textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"200\"></textarea><BR><input type=\"submit\" name=\"add\" value=\" Add \">&nbsp;<input type=\"button\" value=\" Page up \" onclick=\"window.location=('#top')\"></td></tr></form><tr><td align=\"center\"><BR><a href=\"clanclanforum?slotje={$topic->id}\">Close Topic</a></td></tr><tr></table></tr></td></table></td></tr></table>\n";
                }

          

 elseif($topic->slotje == 0 && $data->forumstatus == "gwsp2" && $data->forum != 1 || $data->forumc != 1) {
if($data->forum == 1 || $data->forumc == 1) {
                        print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\">You cannot set the forum.</td></tr></table></tr></td></table></td></tr></table>\n";
       

                        print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\"><B>Reply</b></td></tr><form method=\"post\" name=\"form\" ><tr><td align=\"center\">\n";


print <<<ENDHTML


ENDHTML;
print "	
<textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"200\"></textarea><BR><input type=\"submit\" name=\"add\" value=\" Add \">&nbsp;<input type=\"button\" value=\" Page Up \" onclick=\"window.location=('#top')\"></td></tr></form><tr><td align=\"center\"><BR><a href=\"clanclanforum?slotje={$topic->id}\">Close Topic</a></td></tr><tr></table></tr></td></table></td></tr></table>\n";
                }
                else {

                if($data->forum == 1 || $data->forumc == 1) {
                        print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\">You cannot set the forum.</td></tr></table></tr></td></table></td></tr></table>\n";
                exit;
}
                        print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\"><B>Reply</b></td></tr><form method=\"post\" name=\"form\"><tr><td align=\"center\">\n";



print <<<ENDHTML


ENDHTML;
print "	<textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"200\"></textarea><BR><input type=\"submit\" name=\"add\" value=\" Add \">&nbsp;<input type=\"button\" value=\" Page Up \" onclick=\"window.location=('#top')\"></td></tr></form></td></tr></table>\n";
                }
        }
}
} 
elseif($_GET['slotje']) {
        if($data->forumstatus == "gwsp1" || $data->forumstatus == "gwsp2") {
                mysql_query("UPDATE `[forum_topics]` SET `slotje`=1 WHERE `id`={$_GET['slotje']}");
                print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You have placed an end.<BR><BR><a href=\"clanclanforum?topic={$_GET['slotje']}\">Back</a></tr></td></table></td></tr></table>\n";
        }
}
elseif($_GET['delreply']) {
            if($data->clanlevel == "8" || $data->clanlevel == "9") {
                $query = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['delreply']}");
                $reply = mysql_fetch_object($query);
                $query2 = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$reply->topicid}");
                $topic = mysql_fetch_object($query2);
                mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`-1 WHERE `login`='{$reply->login}'");
                mysql_query("UPDATE `[foum_replys]` SET `del`=1 WHERE `id`={$_GET['delreply']}");
                mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`-1 WHERE `id`={$topic->subid}");
                mysql_query("UPDATE `[forum_topics]` SET `replys`=`replys`-1 WHERE `id`={$topic->id}");
                print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Message Successfully removed</tr></td></table></td></tr></table>\n";
        }
}

elseif($_GET['delreply2']) {
        if($data->clanlevel == "8" || $data->clanlevel == "9") {
                $topic_query         = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['delreply2']}");
                $topic                           = mysql_fetch_object($topic_query);
                               $query = mysql_query("SELECT * FROM `[forum_sub]` WHERE `id`={$topic->subid}");
                $reply = mysql_fetch_object($query);

        mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`-{$topic->replys},`topics`=`topics`-1 WHERE `id`={$topic->subid}");
 mysql_query("DELETE FROM `[forum_topics]` WHERE `id`='{$_GET['delreply2']}'");
                print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Topic successfully removed.</tr></td></table></td></tr></table>\n";
        }
}



elseif($_GET['verplaats']) {
        if($data->level == "255" || $data->level == "50") {
                $topic_query         = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['verplaats']}");
                $topic                           = mysql_fetch_object($topic_query);
                $sub_query                 = mysql_query("SELECT * FROM `[forum_sub]` ORDER BY `area` ASC");
                if(isset($_POST['verplaats'])) {
                        mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`-{$topic->replys},`topics`=`topics`-1 WHERE `id`={$topic->subid}");
                        mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`+{$topic->replys},`topics`=`topics`+1 WHERE `id`={$_POST['forum']}");
                        mysql_query("UPDATE `[forum_topics]` SET `subid`={$_POST['forum']} WHERE `id`={$_GET['verplaats']}");
                        print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Moved Topic.</tr></td></table></td></tr></table>\n";
                }
                else {
                        print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\"><b>$topic->title</b><BR><form method=\"post\">Forum:<br><select name=\"forum\">\n";
                        while($sub = mysql_fetch_object($sub_query)) {
                                print "<option value=\"{$sub->id}\">$sub->title</option>";
                        }
                        print "</select> <input type=\"submit\" name=\"verplaats\" value=\" Verplaats \"></form></tr></td></table></td></tr></table>\n";
                }
        }
        else {
                        print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You may not move this topic.</tr></td></table></td></tr></table>\n";
        }
}
elseif($_GET['reageer']) {
        if(isset($_POST['add'])) {
                $id                           = $_GET['reageer'];
                $bericht         = $_POST['message'];
                $datum                = date("d-m-Y H:i");

 if($bericht == ""){
	print "   <table width=\"100%\" cellspacing=0><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td class=\"subTitle2\" align=\"left\"><b><img src=\"images/icons/blokje.jpg\"> Forum</b></td></tr><tr><td align=\"center\">You must give a message.<br><br><a href=\"javascript:history.go(-1)\">Back</a></tr></td></tr></td></table></td></tr></table>\n";
exit;
}

                $query  = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['topic']}");
                print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Your message has been placed.<BR><BR><a href=\"clanclanforum?topic={$_GET['topic']}\">Back</a></td></tr></table></td></tr></table>\n";
                 mysql_query("INSERT INTO `[foum_replys]`(topicid,datum,login,title,text,date) values($id,'$datum','$data->login','RE:','$bericht',NOW())") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
                 mysql_query("UPDATE `[forum_topics]` SET `replys`=`replys`+1,`datum`='$datum',`date1`=NOW() WHERE `id`={$_GET['reageer']}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
                                  mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`+1 WHERE `login`='{$data->login}'") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
        }
        else {
                $query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['reageer']}");
                $topic = mysql_fetch_object($query);
                if($topic->slotje == 0) {
                  if($_GET['quote']) {
                          $quote_query = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['quote']}");
                        $reply = mysql_fetch_object($quote_query);
                        $quote = "[quote={$reply->login}]{$reply->text}[/quote]";
                  }
                  print " <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\"><B>Reply</b></td></tr><form method=\"post\"><tr><td align=\"center\"><textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"10000\">{$quote}</textarea><BR><input type=\"submit\" name=\"add\" value=\" Add \">&nbsp;<input type=\"button\" value=\" Omhoog \" onclick=\"window.location=('#top')\"></td></tr></form></table></tr></td></table>\n";
                }
        }
}
elseif($_GET['newtopic']) {
if(isset($_POST['add'])){

	$tiet = $_POST['title'];
			$mes    = $_POST['message'];
			

 if($tiet == ""){
	print "   <table width=\"100%\" cellspacing=0><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td class=\"subTitle2\" align=\"left\"><b><img src=\"images/icons/blokje.jpg\"> Forum</b></td></tr><tr><td align=\"center\">You must enter a title <br><br><a href=\"javascript:history.go(-1)\">Back</a></tr></td></tr></td></table></td></tr></table>\n";
exit;
}

 if($mes == ""){
		print "    <table width=\"100%\" cellspacing=0><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td class=\"subTitle2\" align=\"left\"><b><img src=\"images/icons/blokje.jpg\"> Forum</b></td></tr><tr><td align=\"center\">You must add a message. <br><br><a href=\"javascript:history.go(-1)\">Back</a></tr></td></tr></td></table></td></tr></table>\n";
exit;
}

if( $data->forum == 1 || $data->forumc == 1) {

	print "    <table width=\"100%\" cellspacing=0><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td class=\"subTitle2\" align=\"left\"><b><img src=\"images/icons/blokje.jpg\"> Forum</b></td></tr><tr><td align=\"center\">You cannot set anything on the forum.<br><br><a href=\"javascript:history.go(-1)\">Back</a></tr></td></tr></td></table></td></tr></table>\n";
exit;
}
$id = intval($_GET['newtopic']);
$titel = htmlspecialchars($_POST['title']);
$bericht = htmlspecialchars($_POST['message']);
$datum = date("d-m-Y H:i");
print "        <table width=\"100%\" cellspacing=0><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td class=\"subTitle2\" align=\"left\"><b><img src=\"images/icons/blokje.jpg\"> Forum</b></td></tr><tr><td align=\"center\">Your message has been posted.<br><br><a href=\"javascript:history.go(-2)\">Back</a></tr></td></tr></td></table></td></tr></table>\n";
mysql_query("INSERT INTO `[forum_topics]`(subid,datum1,login,title,text,clan,date,date1) values(100,'$datum','$data->login','$titel','$bericht','{$data->clan}',NOW(),NOW())") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`+1 WHERE `login`='{$data->login}'") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
}else{
print <<<END
<table width="100%" cellspacing=0>
  <tr><td class="subTitle"  width=\"100%\" ><b>Forum</b></td></tr>
        <tr><td class="mainTxt">
                <table width="100%" align="center">
                        <tr><td class="mainTxt">
                               
                                        <form method="post" name="form">
                                                <tr><td class="subTxt" colspan=3>New topic</td><td width=\"100%"></td></tr>

                                                        <td>Title:</td>
                                                        <td><input type="text" size="20" name="title"></td><td width="100%"></td>
                                                </tr>
                                                <tr>
                                                        <td>Message:

</td>
                                                        <td>
                                                        <textarea rows="15" name="message" cols="50" maxlength="10000"></textarea></td><td width="100%"></td>
                                                </tr>
                                                <tr><td></td><td align="right"><input type="submit" name="add" value="Add"></td><td width="100%"></td><td width="100%"></td></tr>
                                        </form>
                                </table>
                        </tr></td>
                </table>
        </td></tr>
</table>
END;
}
}
elseif($_GET['edittopic']) {
        $query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['edittopic']} AND `login`='{$data->login}'");
        $num = mysql_num_rows($query);
        $topic = mysql_fetch_object($query);
        if($num == 1) {
                if(isset($_POST['change'])) {
                        $titel                 = $_POST['title'];
                        $bericht         = $_POST['message'];
                        $id                           = $_GET['edittopic'];
                        print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Your message has been changed.</tr></td></table></td></tr></table>\n";
                        mysql_query("UPDATE `[forum_topics]` SET `title`='{$titel}',`text`='{$bericht}' WHERE `id`={$id}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
                }
                else {
                        print "        <table width=\"100%\" cellspacing=0>\n";
                        print "                <tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr>\n";
                        print "                <tr><td class=\"mainTxt\">\n";
                        print "                        <table width=\"100%\" align=\"center\">\n";
                        print "                                <tr><td class=\"mainTxt\">\n";
                        print "                                        <table align=\"center\" width=\"100%\"><form method=\"post\">\n";
                        print "                                 <tr><td class=\"subTxt\" colspan=3>Work Topic</td></tr>\n";
                        print "                                 <tr><td>Title:</td><td><input type=\"text\" value=\"$topic->title\" size=\"20\" name=\"title\"></td><td width=\"100%\"></td></tr>\n";
                        print "                                 <tr><td>Message:</td><td><textarea name=\"message\" cols=40 rows=10>$topic->text</textarea></td><td width=\"100%\"></td></tr>\n";
                        print "                                 <tr><td></td><td align=\"right\"><input type=\"submit\" name=\"change\" value=\"Change\"></td><td width=\"100%\"></td></tr>\n";
                        print "                                 </form</table>\n";
                        print "                                </tr></td>\n";
                        print "                        </table>\n";
                        print "                </td></tr>\n";
                        print "        </table>\n";
                }
        }
        else {
                print "        <table width=\"100%\" cellspacing=0>\n";
                print "                <tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr>\n";
                print "                <tr><td class=\"mainTxt\">\n";
                print "                        <table width=\"100%\" align=\"center\">\n";
                print "                                <tr><td align=\"center\">\n";
                print "                                Error!\n";
                print "                                </tr></td>\n";
                print "                        </table>\n";
                print "                </td></tr>\n";
                print "        </table>\n";
        }
}
elseif($_GET['editreply']) {
        $query = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['editreply']} AND `login`='{$data->login}'");
        $num = mysql_num_rows($query);
        $topic = mysql_fetch_object($query);
        if($num == 1) {
                if(isset($_POST['change'])) {
                        $titel                 = $_POST['title'];
                        $bericht         = $_POST['message'];
                        $id                           = $_GET['editreply'];
                        print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Your message has been changed.</tr></td></table></td></tr></table>\n";
                        mysql_query("UPDATE `[foum_replys]` SET `text`='{$bericht}' WHERE `id`={$id}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());

                }
                else {
                        print "        <table width=\"100%\" cellspacing=0>\n";
                        print "                <tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
                        print "                <tr><td class=\"mainTxt\">\n";
                        print "                        <table width=\"100%\" align=\"center\">\n";
                        print "                                <tr><td class=\"mainTxt\">\n";
                        print "                                        <table align=\"center\" width=\"100%\"><form method=\"post\">\n";
                        print "                                 <tr><td class=\"subTxt\" colspan=3>Work Reply</td></tr>\n";
                        print "                                 <tr><td>Message:</td><td><textarea name=\"message\" cols=40 rows=10>$topic->text</textarea></td><td width=\"100%\"></td></tr>\n";
                        print "                                 <tr><td></td><td align=\"right\"><input type=\"submit\" name=\"change\" value=\"Change\"></td><td width=\"100%\"></td></tr>\n";
                        print "                                 </form</table>\n";
                        print "                                </tr></td>\n";
                        print "                        </table>\n";
                        print "                </td></tr>\n";
                        print "        </table>\n";
                }
        }
        elseif($data->forumstatus == "gwsp1" || $data->forumstatus == "gwsp2") {
                $query2 = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['editreply']}");
                $topic2 = mysql_fetch_object($query2);
                if(isset($_POST['change'])) {
                        $titel                 = $_POST['title'];
                        $bericht         = $_POST['message'];
                        $id                           = $_GET['editreply'];
                        print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Your message has been changed.</tr></td></table></td></tr></table>\n";
                        mysql_query("UPDATE `[foum_replys]` SET `text`='{$bericht}' WHERE `id`={$id}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());

                }
                else {
                        print "        <table width=\"100%\" cellspacing=0>\n";
                        print "                <tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
                        print "                <tr><td class=\"mainTxt\">\n";
                        print "                        <table width=\"100%\" align=\"center\">\n";
                        print "                                <tr><td class=\"mainTxt\">\n";
                        print "                                        <table align=\"center\" width=\"100%\"><form method=\"post\">\n";
                        print "                                 <tr><td class=\"subTxt\" colspan=3>Work Reply</td></tr>\n";
                        print "                                 <tr><td>Message:</td><td><textarea name=\"message\" cols=40 rows=10>$topic2->text</textarea></td><td width=\"100%\"></td></tr>\n";
                        print "                                 <tr><td></td><td align=\"right\"><input type=\"submit\" name=\"change\" value=\"Change\"></td><td width=\"100%\"></td></tr>\n";
                        print "                                 </form</table>\n";
                        print "                                </tr></td>\n";
                        print "                        </table>\n";
                        print "                </td></tr>\n";
                        print "        </table>\n";
                }
        }
        else {
                print "        <table width=\"100%\" cellspacing=0>\n";
                print "                <tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
                print "                <tr><td class=\"mainTxt\">\n";
                print "                        <table width=\"100%\" align=\"center\">\n";
                print "                                <tr><td align=\"center\">\n";
                print "                                Error!\n";
                print "                                </tr></td>\n";
                print "                        </table>\n";
                print "                </td></tr>\n";
                print "        </table>\n";
        }
}
elseif($_GET['delreply']) {
        $query = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['delreply']} AND `login`='{$data->login}'");
        $num = mysql_num_rows($query);
        $topic = mysql_fetch_object($query);
        if($num == 1) {
                        $query2 = mysql_query("SELECT * FROM `[foum_topics]` WHERE `id`={$topic->topicid}");
                        $sub = mysql_fetch_object($query2);
                        $id = $_GET['delreply'];
                        print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Your message is removed</tr></td></table></td></tr></table>\n";
                        mysql_query("DELETE FROM `[foum_replys]` WHERE `id`='{$id}'");
                         mysql_query("UPDATE `[forum_topics]` SET `replys`=`replys`-1 WHERE `id`='{$topic->topicid}'");
                         mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`-1 WHERE `id`='{$sub->subid}'") or die("There was an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
        }
        else {
                print "        <table width=\"100%\" cellspacing=0>\n";
                print "                <tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
                print "                <tr><td class=\"mainTxt\">\n";
                print "                        <table width=\"100%\" align=\"center\">\n";
                print "                                <tr><td align=\"center\">\n";
                print "                                Error!\n";
                print "                                </tr></td>\n";
                print "                        </table>\n";
                print "                </td></tr>\n";
                print "        </table>\n";
        }
}
else {
     


      
       

        print "        <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"  width=\"100%\" ><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td><div align=\"left\"><a href=\"clanforum.php?newtopic={$data->clan}\">New Topic</a></div><div align=\"right\">\n";
        print "        </div></td></tr><tr><td align=\"left\"></td></tr><tr><td><table align=\"center\" width=\"100%\"><tr><td width=\"5%\" align=\"left\" class=\"subTitle\" style=\"letter-spacing: normal;\">&nbsp;</td><td align=\"left\" class=\"subTitle\" style=\"letter-spacing: normal;\" class=\"subTitle\" width=\"45%\"><b>Topic</b></td><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"10%\"><b>Started By</b></td><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"10%\"><b>Replies</b></td><td align=\"left\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"30%\"><b>Last Reply</b></td></tr>\n";
        $query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `clan`='{$data->clan}' ORDER BY `date` DESC");
                while($forum = mysql_fetch_object($query)) {
                        if($forum->slotje == 0) {
                                $image = "images/icons/opentopic.gif";
                        }
                        else {
                                $image = "images/icons/closed.gif";
                        }
                        print "        <tr><td width=\"5%\"><img src=\"{$image}\" border=0></td><td width=\"45%\"><a href=\"clanforum.php?topic={$forum->id}\"><b>$forum->title</b></a></td><td align=\"center\" width=\"10%\"><a href=\"profile.php?x={$forum->login}\">$forum->login</a></td><td align=\"center\" width=\"10%\">$forum->replys</td><td width=\"30%\">$forum->datum</td></tr><tr>\n";
                }
        print "        </table></tr></td></table></td></tr></table>\n";
}

?>

<?
mysql_close();
ob_flush();
?>