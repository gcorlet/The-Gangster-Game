<?php
error_reporting(0);

  $_GET['_clan']			= $data->clan;
  $OMNILOG				= 1;
  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  if($data->clanlevel == 9) {
    if(isset($_POST['change_owner']) && $_POST['owner'] != $data->login) {
      $dbres			= mysql_query("SELECT `login`,`level`,`clan` FROM `[users]` WHERE `login`='{$_POST['owner']}'");
      if(($owner = mysql_fetch_object($dbres)) && $owner->clan == $data->clan && $owner->level & 0x01) {
        mysql_query("UPDATE `[users]` SET `clanlevel`=1 WHERE `login`='{$data->login}'");
        mysql_query("UPDATE `[users]` SET `clanlevel`=9 WHERE `login`='{$owner->login}'");
        mysql_query("UPDATE `[clans]` SET `owner`='{$owner->login}' WHERE `name`='{$data->clan}'");
        header("Location: /criminals/clan.php?x={$data->clan}\n");
      }
    }
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>
 
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

</head>

<SCRIPT language=JavaScript>

	function textCounter(field, countfield, maxlimit) {
		if (field.value.length > maxlimit) // if too long...trim it!
		field.value = field.value.substring(0, maxlimit);
		// otherwise, update 'characters left' counter
		else
	countfield.value = maxlimit - field.value.length;
	}

function submitDis(what) {
	what = document.getElementById(what);
	what.disabled = true;
	what.value = "Posting...";
}
</script>
<table width=100%>
<?php /* ------------------------- */

  if($_GET['p'] == "recruits" && ($data->clanlevel >= 8 || $data->clanlevel == 2)) {
    print "  <tr><td class=\"subTitle\"><b>{$data->clan}: Recruits</b></td></tr>\n";
    $dbres				= mysql_query("SELECT `homes` FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);

    $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `clan`='{$data->clan}'");
    $members				= mysql_num_rows($dbres);
    $maxrecruits			= $clan->homes*5 - $members;
			if($maxrecruits > 30)
            {
				$maxrecruits = 30 - $members;
			}
    if(isset($_POST['recruit'])) {
      $dbres				= mysql_query("SELECT `login` FROM `[users]` WHERE `clan`='{$data->clan}-[recruit]'");
      while($recruit = mysql_fetch_object($dbres)) {
        if(isset($_POST[$recruit->login]) && $_POST[$recruit->login] == 1 && $maxrecruits-- > 0){
          mysql_query("UPDATE `[users]` SET `clan`='{$data->clan}',`clanlevel`=1 WHERE `login`='{$recruit->login}'");
mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`wat2`,`hoeveel`) values(NOW(),'$data->login','$data->clan','aang','$recruit->login','1')"); 
}
        else if(isset($_POST[$recruit->login]) && $_POST[$recruit->login] == 0){
          mysql_query("UPDATE `[users]` SET `clan`='',`clanlevel`=0 WHERE `login`='{$recruit->login}'");
mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`wat2`,`hoeveel`) values(NOW(),'$data->login','$data->clan','aann','$recruit->login','1')"); 

}
      }
    }

    print "  <tr><td class=\"mainTxt\">You can still recruit <b>$maxrecruits</b> members</td></tr>\n";
    print "  <tr><td><form method=\"post\"><table width=100%>\n";
    if($members >= 30){
    print <<<ENDHTML
    <html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You may have no more than 30 members in your gang
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
    exit;
    }
print <<<ENDHTML

	<tr><td class="subTitle" style="letter-spacing: normal;" align="center"><a href="clanhq.php?p=recruits&s=login" class='btn btn-info'><b>Nickname</a></b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=75><a href="clanhq.php?p=recruits&s=power" class='btn btn-info'><b>Power</b></a></td></tr>
ENDHTML;


    if($_GET['s'] == "power")
      $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`type` FROM `[users]` WHERE `clan`='{$data->clan}-[recruit]' ORDER BY (`attack`+`defence`)/2+`clicks`*5");
    else
      $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`type` FROM `[users]` WHERE `clan`='{$data->clan}-[recruit]' ORDER BY `login`");
    while($recruit = mysql_fetch_object($dbres)) {
      $power				= round(($recruit->attack+$recruit->defence)/2+$recruit->clicks*5);
      print "	<tr><td class=\"mainTxt\"><a href=\"profile.php?x={$recruit->login}\" class='btn btn-info'>{$recruit->login}</a></td>  <td class=\"mainTxt\">$power</td>  <td width=200><input type=\"radio\" name=\"{$recruit->login}\" value=\"0\" class='btn btn-info'> Reject <input type=\"radio\" name=\"{$recruit->login}\" value=\"1\" class='btn btn-info'> Accept</td></tr>\n";
    }

    print "	<tr><td></td>  <td></td>  <td align=\"center\" width=200><input type=\"submit\" name=\"recruit\" value=\"Ok\" style=\"width: 75\" class='btn btn-info'></td></tr>\n";
    print "  </table></form></td></tr>\n";
  }
  else if($_GET['p'] == "members" && $data->clanlevel >= 8) {
    if(isset($_POST['members'])) {
      $dbres				= mysql_query("SELECT `login` FROM `[users]` WHERE `clan`='{$data->clan}'");
      while($member = mysql_fetch_object($dbres)) {
        if(isset($_POST[$member->login])) {
          if($_POST[$member->login] == 0){
$dbres				= mysql_query("SELECT * FROM `[clanlogs]` WHERE `wie`='{$member->login}' AND `waar`='{$data->clan}' AND  `wat`='KICK'");
   if ( $member->login == $data->login){
    print "  <tr><td class=\"subTitle\"><b>{$data->clan}: Members</b></td></tr>\n";
  print "  <tr><td class=\"mainTxt\" align=\"center\">You cannot kick yourself.</td></tr>\n";
exit;
}
   else if(($numattacks = mysql_num_rows($dbres)+1) >= 3) {
    print "  <tr><td class=\"subTitle\"><b>{$data->clan}: Members</b></td></tr>\n";
  print "  <tr><td class=\"mainTxt\" align=\"center\">$member->login is already kicked from the gang.</td></tr>\n";
exit;
}

  mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`wat2`,`hoeveel`) values(NOW(),'$member->login','$data->clan','KICK','$data->login','0')"); 
 mysql_query("UPDATE `[users]` SET `clan`='',`clanlevel`=0 WHERE `login`='{$member->login}'");
       }
else if($_POST[$member->login] >= 1 && $_POST[$member->login] <= 8)
   mysql_query("UPDATE `[users]` SET `clanlevel`='{$_POST[$member->login]}' WHERE `login`='{$member->login}'");
        }
      }
    }

    print "  <tr><td class=\"subTitle\"><b>{$data->clan}: Members</b></td></tr>\n";
  print "  <tr><td class=\"mainTxt\" align=\"center\">Je kan iemand 2 keer uit de clan kicken.</td></tr>\n";
    if($data->clanlevel == 9) {
      print "  <tr><td align=\"center\"><form method=\"post\">Owner: <select name=\"owner\">\n";
      $dbres				= mysql_query("SELECT `login` FROM `[users]` WHERE `clan`='{$data->clan}' ORDER BY `login`");
      while($member = mysql_fetch_object($dbres)) {
        if($member->login == $data->login)
          print "	<option value=\"{$member->login}\" selected>{$member->login}</option>\n";
        else
          print "	<option value=\"{$member->login}\">{$member->login}</option>\n";
      }
      print "  </select> <input type=\"submit\" name=\"change_owner\" value=\"Update\" class='btn btn-info'></form></td></tr>\n\n";
    }

    print <<<ENDHTML
  <tr><td><form method="post"><table width=100%>
  <tr><td align="center" class="subTitle" width=15><b>#</b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center"><a href="clanhq.php?p=members&s=login" class='btn btn-info'><b>Nickname</a></b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=75><a href="clanhq.php?p=members&s=power" class='btn btn-info'><b>Power</b></a></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=100><a href="clanhq.php?p=members&s=rank" class='btn btn-info'><b>Rank</b></a></td></tr>
ENDHTML;

    if($_GET['s'] == "login")
      $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$data->clan}' AND `activated`=1 ORDER BY `login`");
    else if($_GET['s'] == "power")
      $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$data->clan}' AND `activated`=1 ORDER BY (`attack`+`defence`)/2+`clicks`*5 DESC,`login` ASC");
    else
      $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$data->clan}' AND `activated`=1 ORDER BY `clanlevel` DESC,`login` ASC");

    for($j=1; $member = mysql_fetch_object($dbres); $j++) {
      $rank				= Array("","Member","Recruiter","","","","Manager","General","Leader","Owner");
      ${"select{$member->clanlevel}"}	= " selected";
      $power				= round(($member->attack+$member->defence)/2+$member->clicks*5);

      print <<<ENDHTML
  <tr><td align="center" class="mainTxt">$j</td>
	<td class="mainTxt"><a href="profile.php?x={$member->login}" class='btn btn-info'>{$member->login}</a></td>
	<td align="center" class="mainTxt">$power</td>
	<td align="center" class="mainTxt" width=100>
ENDHTML;
      if($member->clanlevel < 9) {
        print <<<ENDHTML
		<select name="{$member->login}">
		<option value="0" class='btn btn-info'>Remove</option>
		<option value="1"$select1 class='btn btn-info'>Member</option>
		<option value="2"$select2 class='btn btn-info'>Recruiter</option>
		<option value="6"$select6 class='btn btn-info'>Manager</option>
		<option value="7"$select7 class='btn btn-info'>General</option>
		<option value="8"$select8 class='btn btn-info'>Leader</option>
		</select>
	</td></tr>

ENDHTML;
      }
      else
        print "Owner</td></tr>\n";

     ${"select{$member->clanlevel}"} = "";
    }

    print <<<ENDHTML
  <tr><td></td>  <td></td>  <td></td>  <td></td>  <td width=125 align="center"><input type="submit" class='btn btn-info' name="members" value="Update"></td></tr>
</table></form></td></tr>
ENDHTML;
  }
  else if($_GET['p'] == "info" && $data->clanlevel >= 8) {
include("_include-leaderoptions.php");
    $dbres				= mysql_query("SELECT `name`,`info`,`avatarc`,UNIX_TIMESTAMP(`started`) AS `started` FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);

    print "  <tr><td class=\"subTitle\"><b>{$data->clan}: Change Gang Profile</b></td></tr>\n";
    print "  <tr><td class=\"mainTxt\"><a href=\"clan.php?x={$data->clan}\">View Profile</a></td></tr>\n";
 if(isset($_POST['protection']) && $clan->started+24*60*60 > time()) {
    mysql_query("UPDATE `[clans]` SET `started`=FROM_UNIXTIME(UNIX_TIMESTAMP(`started`)-24*60*60-1) WHERE `name`='{$data->clan}'");
 print "  <tr><td class=\"mainTxt\">The Gang is under protection.</td></tr>\n"; 
  exit;
 }

    if(isset($_POST['info'])) {

      $clan->info			= preg_replace('/</','&#60;',substr($_POST['info'],0,500));
      $clan->avatarc			= preg_replace('/</','&#60;',substr($_POST['avatarc'],0,500));
      mysql_query("UPDATE `[clans]` SET `info`='{$clan->info}',`avatarc`='{$clan->avatarc}' WHERE `name`='{$data->clan}'");
mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`hoeveel`) values(NOW(),$data->login','{$data->clan}','info','0')");

      print "  <tr><td class=\"mainTxt\">Gang info has changed</td></tr>\n";
    }



  $protection				= round($clan->started/3600-time()/3600) + 24;
    print <<<ENDHTML
  <tr><td class="mainTxt">	<form name="form1" method="POST" onsubmit="submitDis('submit')"><table>
	<tr><td valign="top" width=100><br>
	<input type="button"  value=" Bold "onClick="document.form1.info.value += ' [b]  TEKST  [/b]'">	<input type="button"  class='btn btn-info' value=" Underline "onClick="document.form1.info.value += ' [u]  TEKST  [/u]'">	<input type="button" class='btn btn-info' value=" Itallic "onClick="document.form1.info.value += ' [i]  TEKST  [/i]'">
</td>  <td><textarea name="info" cols=70 rows=16>{$clan->info}</textarea></td></tr>
        <tr><td width=100>Gang Image: 	</td>	<td><input type="text"  class='btn btn-info' size="70" name="avatarc" value="{$clan->avatarc}"> <br>Width: 600 pixels
- Hight: 120 pixels
<td></tr>
	<tr><td></td>  <td align="left"><input type="submit" class='btn btn-info' value="Update"></td></tr>
  </table></td></tr>
ENDHTML;
 if($protection > 0)
    print "	<tr><td class=\"mainTxt\"><form method=\"post\"><center><i>The gang is under protection for <b>$protection</b> more hours </i><br><br><input type=\"submit\" class='btn btn-info' name=\"protection\" value=\"Clear Gang Protection\"></form></td></tr>

<table witdth=100%>


</table></body>
\n";
  }

/* ------------------------- */ ?>
</table>

</body>


</html>
<?
mysql_close();
ob_flush();
?>