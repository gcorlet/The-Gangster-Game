<?php
error_reporting(0);

  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);
$land = $data->land;
$landover3 = $clan->centrale+$clan->platform+$clan->coffeeshop+$clan->drugslab+$clan->def_lvl1+$clan->homes;
$landover2 = round(100*($landover3));
$landover = $clan->land-$landover2;
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">
<table align="center" width="80%">
<?
if($data->clanlevel < 6 OR $data->clanlevel == 7) {
?>
<tr><td class="mainTxt" align="center">This is for the Owner, Generals and the Leaders of the Gang.</td></tr>
<?
exit;
}
?>
<tr><td class="subTitle" colspan="2">Gang Shop - Buildings</td></tr>
<td align=right><a href="../../clanshop.php"><font color="yellow" size=2>Back to Shop Menu</font></a>
<tr>
<td class="mainTxt" width="50%" align="center"><b>Power Station`s</b></td>
<td class="mainTxt" width="50%" align="center"><b>Oil Rig</b></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;450.000</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;500.000</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Land Needed:</td><td>100 M<sup>2</sup></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Land Needed:</td><td>100 M<sup>2</sup></td></table></td>
</tr>
<tr>
<form method="POST"><td class="mainTxt" width="50%">Amount: <input maxlength="6" type="text" class='btn btn-info' name="aantal1" value="1"> <input type="submit" class='btn btn-info' value="Purchase"></td></form>
<form method="POST"><td class="mainTxt" width="50%">Amount: <input maxlength="6" type="text" class='btn btn-info' name="aantal2" value="1"> <input type="submit" class='btn btn-info' value="Purchase"></td></form>
</tr>
<tr>
<td class="mainTxt" width="50%" align="center"><b>Coffeeshop</b></td>
<td class="mainTxt" width="50%" align="center"><b>Drugslab</b></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;550.000</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;700.000</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Land Needed:</td><td>200 M<sup>2</sup></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Land Needed:</td><td>200 M<sup>2</sup></td></table></td>
</tr>
<tr>
<form method="POST"><td class="mainTxt" width="50%">Amount: <input maxlength="6" type="text" class='btn btn-info' name="aantal3" value="1"> <input type="submit" class='btn btn-info' value="Purchase"></td></form>
<form method="POST"><td class="mainTxt" width="50%">Amount: <input maxlength="6" type="text" class='btn btn-info' name="aantal4" value="1"> <input type="submit" class='btn btn-info' value="Purchase"></td></form>
</tr>
<tr>
<td class="mainTxt" width="50%" align="center"><b>Homes</b></td>

</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;1,250,000</td></table></td>

</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Land Needed:</td><td>250 M<sup>2</sup></td></table></td>

</tr>
<tr>
<form method="POST"><td class="mainTxt" width="50%">Amount: <input maxlength="6" type="text" class='btn btn-info' name="aantal5" value="1"> <input type="submit" class='btn btn-info' value="Purchase"></td></form>

</tr>
<tr><td class="mainTxt">Land Total: <?=$clan->land?></td><td class="mainTxt">Land Used: <?=$landover?></td></tr>
<?
/////////////////
////Centrale////
///////////////
if(isset($_POST['aantal1'])) {
$eraf = round($_POST['aantal1']*450000);
$gelderaf = number_format($eraf, 0, '.' , '.');
$land = round($_POST['aantal1']*100);
if($_POST['aantal1'] == 1) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have bought 1 Power Station.</td></tr>\n";
}
else if($_POST['aantal1']*100 > $landover) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You dont have enough land, you need <b>$land</b>M<sup>2</sup></td></tr>\n";
}
else if($eraf > $clan->cash) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You dont have enough Gang Cash, you need <b>;$eraf</b>.</td></tr>\n";
}
else if(!preg_match('/^[0-9]{1,15}$/',$_POST['aantal1'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">Numbers Only.</td></tr>\n";
}
else {
mysql_query("UPDATE `[clans]` SET `centrale`=`centrale`+'{$_POST['aantal1']}', `cash`=`cash`-'$eraf',`money_lvl1`=`money_lvl1`+1 WHERE `name`='$data->clan'");
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have bought <b>{$_POST['aantal1']}</b> Power Station`s for <b>;$gelderaf</b>.</td></tr>\n";
	}
}
/////////////////
//Olieplatform//
///////////////
if(isset($_POST['aantal2'])) {
$eraf = round($_POST['aantal2']*500000);
$gelderaf = number_format($eraf, 0, '.' , '.');
$land = round($_POST['aantal2']*100);
if($_POST['aantal2'] == 1) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have bought 1 Oil Rig.</td></tr>\n";
}
else if($_POST['aantal2']*100 > $landover) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You dont have enough land, you need <b>$land</b>M<sup>2</sup>.</td></tr>\n";
}
else if($eraf > $clan->cash) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">There isnt enough Gang Cash, you need <b>;$eraf</b>.</td></tr>\n";
}
else if(!preg_match('/^[0-9]{1,15}$/',$_POST['aantal2'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">Numbers Only.</td></tr>\n";
}
else {
mysql_query("UPDATE `[clans]` SET `platform`=`platform`+'{$_POST['aantal2']}', `cash`=`cash`-'$eraf',`money_lvl1`=`money_lvl1`+3 WHERE `name`='$data->clan'");
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have bought <b>{$_POST['aantal2']}</b> Oil Rigs for <b>;$gelderaf</b>.</td></tr>\n";
	}
}
/////////////////
//Coffee Shop///
///////////////
if(isset($_POST['aantal3'])) {
$eraf = round($_POST['aantal3']*550000);
$gelderaf = number_format($eraf, 0, '.' , '.');
$land = round($_POST['aantal3']*200);
if($_POST['aantal3'] == 1) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have bought 1 coffeeshop.</td></tr>\n";
}
else if($_POST['aantal3']*100 > $landover) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">There isnt enough land, you need <b>$land</b>M<sup>2</sup>.</td></tr>\n";
}
else if($eraf > $clan->cash) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You dont have enough Gang Cash, you need <b>;$eraf</b>.</td></tr>\n";
}
else if(!preg_match('/^[0-9]{1,15}$/',$_POST['aantal3'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">Numbers Only.</td></tr>\n";
}
else {
mysql_query("UPDATE `[clans]` SET `coffeeshop`=`coffeeshop`+'{$_POST['aantal3']}', `cash`=`cash`-'$eraf',`money_lvl1`=`money_lvl1`+7 WHERE `name`='$data->clan'");
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have bought <b>{$_POST['aantal3']}</b> Coffee Shops for <b>;$gelderaf</b>.</td></tr>\n";
	}
}
/////////////////
////Drugslab////
///////////////
if(isset($_POST['aantal4'])) {
$eraf = round($_POST['aantal4']*700000);
$gelderaf = number_format($eraf, 0, '.' , '.');
$land = round($_POST['aantal4']*200);
if($_POST['aantal4'] == 1) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have purchased 1 drugslab.</td></tr>\n";
}
else if($_POST['aantal4']*100 > $landover) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">There isnt enough land, you need <b>$land</b>M<sup>2</sup>.</td></tr>\n";
}
else if($eraf > $clan->cash) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">The Gang doesnt have enough cash, you need <b>;$eraf</b>.</td></tr>\n";
}
else if(!preg_match('/^[0-9]{1,15}$/',$_POST['aantal4'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">Numbers Only.</td></tr>\n";
}
else {
mysql_query("UPDATE `[clans]` SET `drugslab`=`drugslab`+'{$_POST['aantal4']}', `cash`=`cash`-'$eraf',`money_lvl1`=`money_lvl1`+12 WHERE `name`='$data->clan'");
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have bought <b>{$_POST['aantal4']}</b> Druglabs for <b>;$gelderaf</b>.</td></tr>\n";
	}
}

/////////////////
////Houses////
///////////////

if(isset($_POST['aantal5'])) {
$eraf = round($_POST['aantal5']*1250000);
$gelderaf = number_format($eraf, 0, '.' , '.');
$land = round($_POST['aantal5']*250);
if($_POST['aantal5'] == 1) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have purchased 1 Home.</td></tr>\n";
}
else if($_POST['aantal5']*100 > $landover) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">There isnt enough land, you need <b>$land</b>M<sup>2</sup>.</td></tr>\n";
}
else if($eraf > $clan->cash) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">The Gang doesnt have enough cash, you need <b>;$eraf</b>.</td></tr>\n";
}
else if(!preg_match('/^[0-9]{1,15}$/',$_POST['aantal5'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">Numbers Only.</td></tr>\n";
}
else {
mysql_query("UPDATE `[clans]` SET `homes`=`homes`+'{$_POST['aantal5']}', `cash`=`cash`-'$eraf',`money_lvl1`=`money_lvl1`+21 WHERE `name`='$data->clan'");
    print " <tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You have bought <b>{$_POST['aantal5']}</b> homes for <b>;$gelderaf</b>.</td></tr>\n";
	}
}
?>
</table>
</body>
</html>