<?php
error_reporting(0);


  $OMNILOG				= 1;
  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  if($data->clanlevel == 9) {
    if(isset($_POST['change_owner']) && $_POST['owner'] != $data->login) {
      $dbres			= mysql_query("SELECT `login`,`level`,`clan` FROM `[users]` WHERE `login`='{$_POST['owner']}'");
      if(($owner = mysql_fetch_object($dbres)) && $owner->clan == $data->clan && $owner->level & 0x01) {
        mysql_query("UPDATE `[users]` SET `clanlevel`=1 WHERE `login`='{$data->login}'");
        mysql_query("UPDATE `[users]` SET `clanlevel`=9 WHERE `login`='{$owner->login}'");
        mysql_query("UPDATE `[clans]` SET `owner`='{$owner->login}' WHERE `name`='{$data->clan}'");
        header("Location: /criminals/clan.php?x={$data->clan}\n");
      }
    }
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>
 
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>


<table width=100%>
<?php /* ------------------------- */

   
    print "  <tr><td><table width=100%>\n";
    print "	<tr><td class=\"subTitle\" style=\"letter-spacing: normal;\"><b>Gang</b></td>  <td class=\"subTitle\" style=\"letter-spacing: normal;\" width=125><b>Owner</b></td>  <td class=\"subTitle\" width=75 style=\"letter-spacing: normal;\"><b>Power</b></td></tr>\n";
    $dbres				= mysql_query("SELECT `name`,`owner`,`type`,`def_lvl1`,`homes` FROM `[clans]` ORDER BY `type`");
    while($clan = mysql_fetch_object($dbres)) {
      $power				= 0;
      $dbres2				= mysql_query("SELECT `attack`,`defence`,`clicks` FROM `[users]` WHERE `clan`='{$clan->name}'");
      while($member = mysql_fetch_object($dbres2))
        $power				+= round(($member->attack+$member->defence)/2+$member->clicks*5);
      $power				+= ($clan->def_lvl1*3000)/2;
      $power				+= ($clan->homes*1250)/2;
      $clanpower[$clan->type][$clan->name] = $power;
    }
    $lasttype				= 1;
    foreach($clanpower as $type => $info) {
      if($type != $lasttype)
        print "  <tr><td><br></td></tr>\n";

      arsort($info);
      foreach($info as $name => $power) {
        $dbres				= mysql_query("SELECT `name`,`owner` FROM `[clans]` WHERE `name`='$name'");
        $clan					= mysql_fetch_object($dbres);
        print "	<tr><td class=\"mainTxt\"><a href=\"clan.php?x={$clan->name}\" class='btn btn-info'>{$clan->name}</a></td>  <td class=\"mainTxt\" width=125><a href=\"profile.php?x={$clan->owner}\" class='btn btn-info'>{$clan->owner}</a></td>   <td class=\"mainTxt\" align=\"right\" width=75>$power&nbsp;</td>";
        if($data->clanlevel >= 7)
          print "  <td align=\"center\" class=\"mainTxt\" width=75><a href=\"clanwar.php?x=$name\" class='btn btn-info'>Attack</a></td></tr>\n";
        else
          print "</tr>\n";
        $lasttype				= $type;
      }
    }
    print "  </table></td></tr>\n";
  
/* ------------------------- */ ?>
</table>

</body>

</html>
<?
mysql_close();
ob_flush();
?>