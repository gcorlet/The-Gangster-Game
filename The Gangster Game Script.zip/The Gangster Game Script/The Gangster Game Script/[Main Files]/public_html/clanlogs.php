<?php
error_reporting(0);

  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<table width=100%>
<?php /* ------------------------- */

  if($_GET['x'] == "attack") {
    print "  <tr><td class=\"subTitle\"><b>Attacks</b></td></tr>\n  <tr><td><table width=100%>";
    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `attacktime` FROM `[clanwar]` WHERE `attack`='{$data->clan}'  ORDER BY `time` DESC LIMIT 0,25");
    while($info = mysql_fetch_object($dbres)) {
      $result				= ($info->code & 0x01 == 1) ? "lost" : "won";
      $money				= $info->money ;
    if ($info->gewonnen ==0){
$gewonnen	= "Lost";
}
if ($info->gewonnen == 1){
$gewonnen	= "Won";
}  
print <<<ENDHTML
    <tr><td class="mainTxt" width=125>{$info->attacktime}</td>
	<td class="mainTxt"><a href="clan.php?x={$info->defence}" class='btn btn-info'>{$info->defence}</a></td>
	<td width=100 class="mainTxt" align="center"> $info->geld</td>
	<td width=100 class="mainTxt" align="center">$info->land m�</td>
	<td width=100 class="mainTxt" align="center">$gewonnen</td>
ENDHTML;
        }

    print "  </table></td></tr>\n  <tr><td><br></td></tr>\n\n  <tr><td class=\"subTitle\"><b>Apologies</b></td></tr>\n";
    print "  <tr><td><table width=100%>\n";
    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `attacktime` FROM `[clanwar]` WHERE `defence`='{$data->clan}' ORDER BY `time` DESC LIMIT 0,25");
    while($info = mysql_fetch_object($dbres)) {
      $result				= ($info->code & 0x01 == 1) ? "lost" : "won";
      $money				= $info->money;
     
    if ($info->gewonnen ==0){
$gewonnen	= "Won";
}
if ($info->gewonnen == 1){
$gewonnen	= "Lost";
} 
 print <<<ENDHTML
      <tr><td class="mainTxt" width=125>{$info->attacktime}</td>
	<td class="mainTxt"><a href="clan.php?x={$info->attack}" class='btn btn-info'>{$info->attack}</a></td>
	<td width=100 class="mainTxt" align="center"> $info->geld</td>
	<td width=100 class="mainTxt" align="center">$info->land m�</td>
	<td width=100 class="mainTxt" align="center">$gewonnen</td>
	
ENDHTML;
    }
  }

	else if($_GET['x'] == "donatielog") {
    print "  <tr><td class=\"subTitle\"><b>Gang Donation info </b></td></tr>\n  <tr><td><table width=100%>";
  $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    if($profiel = mysql_fetch_object($dbres)) {
      
      print <<<ENDHTML
      <tr><td class="mainTxt" > Here you can see what particular days donations are on.<br>
Monday Gang Donations is <a href="bank.php?don=$profiel->maandag" class='btn btn-info'> <b>$profiel->maandag </b></a>.<br>
Tuesday Gang Donations is <a href="bank.php?don=$profiel->dinsdag" class='btn btn-info'> <b>$profiel->dinsdag </b></a>.<br>
Wednesday Gang Donations is <a href="bank.php?don=$profiel->woensdag" class='btn btn-info'> <b>$profiel->woensdag </b></a>.<br>
Thursday Gang Donations is <a href="bank.php?don=$profiel->donderdag" class='btn btn-info'> <b>$profiel->donderdag </b></a>.<br>
Friday Gang Donations is <a href="bank.php?don=$profiel->vrijdag" class='btn btn-info'> <b>$profiel->vrijdag</b></a>.<br>
Saturday Gang Donationsis <a href="bank.php?don=$profiel->zaterdag" class='btn btn-info'> <b>$profiel->zaterdag </b></a>.<br>
Sunday Gang Donations is <a href="bank.php?don=$profiel->zondag" class='btn btn-info'> <b>$profiel->zondag </b></a>.<br>
The last donation was by $profiel->donatie.



</td></tr>

ENDHTML;
    }
  }
  else if($_GET['x'] == "click") {
    print "  <tr><td class=\"subTitle\" style=\"letter-spacing: normal;\" width=125><b>Date</b></td>  <td class=\"subTitle\" style=\"letter-spacing: normal;\"><b>Nickname</b></td>  <td class=\"subTitle\" style=\"letter-spacing: normal;\" width=100><b>Number</b></td></tr>\n";
    $dbres				= mysql_query("SELECT * FROM `[logs]` WHERE `clan`='{$data->clan}'  AND `area`='clanclick' ORDER BY `time`");
    while($info = mysql_fetch_object($dbres)) {
      print <<<ENDHTML
  <tr><td class="mainTxt" width=125>{$info->time}</td>
	<td class="mainTxt"><a href="profile.php?x={$info->login}" class='btn btn-info'>{$info->login}</a></td>
	<td class="mainTxt" width=100 align="center">{$info->code}</td></tr>
ENDHTML;
    }
  }
  else {
    print <<<ENDHTML

<table align="center" width=100%>
  <tr><td class="subTitle"><b>Gang Info</b></td>
  <tr><td class="mainTxt">
<center>
 <input type="button" class='btn btn-info' style="width: 230;" value=" Attack log "onClick="window.self.location=('clanlogs.php?x=attack');"></form>
<input type="button" class='btn btn-info' style="width: 230;" value=" Donation log "onClick="window.self.location=('clandonatielog.php');"></form><br><br>
<input type="button" class='btn btn-info' style="width: 230;" value=" Clicks log "onClick="window.self.location=('clanlogs.php?x=click');"></form>
<input type="button" class='btn btn-info' style="width: 230;" value=" Gang Donation info "onClick="window.self.location=('clanlogs.php?x=donatielog');"></form><br><br>
</form>
</center>

ENDHTML;
  }

/* ------------------------- */ ?>
</table>

</body>


</html>
<?
mysql_close();
ob_flush();
?>