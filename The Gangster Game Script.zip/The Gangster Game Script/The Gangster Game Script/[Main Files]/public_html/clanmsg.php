<?php
error_reporting(0);

include("_include-config.php");
mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$clan->login}'");
if(! check_login()) {
  header("Location: login.php");
  exit;
}    include("_include-gevangenis.php");

    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);

if($data->sms >= 1){
    print <<<ENDHTML
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link ref="stylesheet" type"text/css" href="css/bootstrap.css">
</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<center>You may no longer email.
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
    exit;
    }
	
/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
  
</head>

<BODY onLoad="movein()">
<body>
<table width=100%>
<?php /* ------------------------- */
print "  <tr><td class=\"subTitle\"><b>Gang Message</b></td></tr>\n";
if($_GET['p'] == "msg" && $data->clanlevel >= 8) {
  if(isset($_POST['bekijk'])) {

            $bericht		= $_POST['message'];

;
                        $bericht                 = nl2br($bericht);
                        $bericht                 = str_replace("[b]", "<b>",$bericht);
                        $bericht                 = str_replace("[/b]", "</b>",$bericht);
                        $bericht                 = str_replace("[i]", "<i>",$bericht);
                        $bericht                 = str_replace("[/i]", "</i>",$bericht);
                        $bericht                 = str_replace("[u]", "<u>",$bericht);

                        $bericht                 = eregi_replace("\\[color=([^\\[]*)\\]([^\\[]*)\\[/color\\]","<font color=\"\\1\">\\2</font>",$bericht);

        $bericht	= preg_replace('/(http:\/\/\S+)/','<a href="$1" target=\"_blank\">$1</a>',$bericht);
        $bericht	= preg_replace('/\n/',"<br>\n",$bericht);
           $bericht	= str_replace(":ban", "<img src=\"images/smilies/ban.gif\">",  $bericht);
         $bericht	= str_replace(":(", "<img src=\"images/smilies/icon_sad.gif\">",  $bericht);
         $bericht	= str_replace(";)", "<img src=\"images/smilies/icon_wink.gif\">",  $bericht);
         $bericht	= str_replace(":frown", "<img src=\"images/smilies/frown.gif\">",  $bericht);
         $bericht	= str_replace(":lol:", "<img src=\"images/smilies/icon_lol.gif\">",  $bericht);
         $bericht	= str_replace("8)", "<img src=\"images/smilies/icon_cool.gif\">",  $bericht);
         $bericht	= str_replace(":!:", "<img src=\"images/smilies/icon_exclaim.gif\">",  $bericht);
         $bericht	= str_replace(":?:", "<img src=\"images/smilies/icon_question.gif\">",  $bericht);
         $bericht	= str_replace(":o", "<img src=\"images/smilies/icon_surprised.gif\">",  $bericht);
         $bericht	= str_replace(":arrow:", "<img src=\"images/smilies/icon_arrow.gif\">",  $bericht);
         $bericht	= str_replace("8|", "<img src=\"images/smilies/icon_eek.gif\">",  $bericht);
         $bericht	= str_replace(":mad:", "<img src=\"images/smilies/icon_mad.gif\">",  $bericht);
         $bericht	= str_replace(":twisted:", "<img src=\"images/smilies/icon_twisted.gif\">",  $bericht);
         $bericht	= str_replace(":@", "<img src=\"images/smilies/icon_twisted.gif\">",  $bericht);
         $bericht	= str_replace(":|", "<img src=\"images/smilies/icon_neutral.gif\">",  $bericht);
         $bericht	= str_replace(":tup:", "<img src=\"images/smilies/icon_tup.gif\">",  $bericht);
         $bericht	= str_replace(":tdn:", "<img src=\"images/smilies/icon_tdn.gif\">",  $bericht);
         $bericht	= str_replace("(n)", "<img src=\"images/smilies/icon_tdn.gif\">",  $bericht);
         $bericht	= str_replace("(y)", "<img src=\"images/smilies/icon_tup.gif\">",  $bericht);
         $bericht	= str_replace(":evil:", "<img src=\"images/smilies/icon_evil.gif\">",  $bericht);
         $bericht	= str_replace(":censored:", "<img src=\"images/smilies/icon_censored.gif\">",  $bericht);
         $bericht	= str_replace(":redface:", "<img src=\"images/smilies/icon_redface.gif\">",  $bericht);
         $bericht	= str_replace(":$", "<img src=\"images/smilies/icon_redface.gif\">",  $bericht);
         $bericht	= str_replace(":rolleyes:", "<img src=\"images/smilies/icon_rolleyes.gif\">",  $bericht);
      $bericht	= str_replace(":'(", "<img src=\"images/smilies/icon_cry.gif\" alt=\"Cry\">", $bericht);
       $bericht	= str_replace(":bloos", "<img src=\"images/smilies/bloos.gif\">", $bericht);
        $bericht	= str_replace(":coool", "<img src=\"images/smilies/coool.gif\">", $bericht);
        $bericht	= str_replace(":confused", "<img src=\"images/smilies/confused.gif\">", $bericht);
        $bericht	= str_replace(":flipa", "<img src=\"images/smilies/flipa.gif\">", $bericht);
        $bericht	= str_replace(":frown", "<img src=\"images/smilies/frown.gif\">", $bericht);
        $bericht	= str_replace(":1frown:", "<img src=\"images/smilies/frown1.gif\">", $bericht);
        $bericht	= str_replace(":dead", "<img src=\"images/smilies/icon_dead.gif\">", $bericht);
        $bericht	= str_replace(":disagree", "<img src=\"images/smilies/icon_disagree.gif\">", $bericht);
        $bericht	= str_replace(":duh", "<img src=\"images/smilies/icon_duh.gif\">", $bericht);
        $bericht	= str_replace(":hmmz", "<img src=\"images/smilies/icon_hmmz.gif\">", $bericht);
        $bericht	= str_replace(":slotje", "<img src=\"images/smilies/icon_slotje.gif\">", $bericht);
        $bericht	= str_replace(":nooo", "<img src=\"images/smilies/nooo.gif\">", $bericht);
        $bericht	= str_replace(":puh2", "<img src=\"images/smilies/puh2.gif\">", $bericht);
        $bericht	= str_replace(":shiny", "<img src=\"images/smilies/shiny.gif\">", $bericht);
        $bericht	= str_replace(":smile", "<img src=\"images/smilies/smile.gif\">", $bericht);
        $bericht	= str_replace(":thumbsup", "<img src=\"images/smilies/thumbsup.gif\">", $bericht);
        $bericht	= str_replace(":twisted:", "<img src=\"images/smilies/icon_twisted.gif\">", $bericht);
        $bericht	= str_replace(":wink", "<img src=\"images/smilies/wink.gif\">", $bericht);
        $bericht	= str_replace(":yes", "<img src=\"images/smilies/yes_new.gif\">", $bericht);
        $bericht	= str_replace(":tup:", "<img src=\"images/smilies/icon_tup.gif\">", $bericht);
        $bericht	= str_replace(":tdn:", "<img src=\"images/smilies/icon_tdn.gif\">", $bericht);
        $bericht	= str_replace("(n)", "<img src=\"images/smilies/icon_tdn.gif\">", $bericht);
        $bericht	= str_replace("(y)", "<img src=\"images/smilies/icon_tup.gif\">", $bericht);
        $bericht= str_replace(":evil:", "<img src=\"images/smilies/icon_evil.gif\">", $bericht);
        $bericht	= str_replace(":censored:", "<img src=\"images/smilies/icon_censored.gif\">", $bericht);
$bericht	= str_replace("war-age.org", "**", $bericht);
$bericht	= str_replace("http://bullet-star.net", "**", $bericht);
$bericht	= str_replace("kanker", "**", $bericht);
$bericht	= str_replace("je moeder", "**", $bericht);
$bericht	= str_replace("tyfus", "**", $bericht);
$bericht	= str_replace("eikel", "**", $bericht);
$bericht	= str_replace("homo", "**", $bericht);
$bericht	= str_replace("klootzak", "**", $bericht);
        $bericht	= str_replace(":redface:", "<img src=\"images/smilies/icon_redface.gif\">", $bericht);
        $bericht	= str_replace(":$", "<img src=\"images/smilies/icon_redface.gif\">", $bericht);
        $bericht	= str_replace(":rolleyes:", "<img src=\"images/smilies/icon_rolleyes.gif\">", $bericht);
      $bericht	= str_replace(":sadley", "<img src=\"images/smilies/sadley.gif\">", $bericht);
     $bericht	= str_replace(":janew:", "<img src=\"images/smilies/yes_new.gif\">", $bericht);  


      

print <<<ENDHTML

  <tr><td class="mainTxt" style="letter-spacing: normal;"><table width=100%>
    <tr><td width=100>From:</td>     <td>{$data->clan}  ({$data->login})</td></tr>

    <tr><td width=100>Subject:</td>  <td>{$_POST['subject']}</td></tr>

 </td></tr>
 </table></table>
<table width=100%>  <tr><td class="mainTxt">
$bericht
  </td></tr>
  
ENDHTML;
}


 if(isset($_POST['submit'])) {
     $_POST['subject']               = preg_replace('/</','&#60;',$_POST['subject']);
        $_POST['message']               = preg_replace('/</','&#60;',$_POST['message']); 

      if($_POST['message'] == ""){
print "  <tr><td class=\"mainTxt\">You need to enter a message</td></tr>\n";
exit;
}

if( $_POST['leaders'] ){
      $dbres                            = mysql_query("SELECT `login` FROM `[users]` WHERE `clanlevel`=8 AND `clan`='{$data->clan}'");
      while($member = mysql_fetch_object($dbres)) {
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'$data->clan  ($data->login)','".$member->login."','{$_POST['subject']}','{$_POST['message']}')"); 
}
}
if( $_POST['generalen'] ){
      $dbres                            = mysql_query("SELECT `login` FROM `[users]` WHERE `clanlevel`=7 AND `clan`='{$data->clan}'");
      while($member = mysql_fetch_object($dbres)) {
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'$data->clan  ($data->login)','".$member->login."','{$_POST['subject']}','{$_POST['message']}')"); 
}
}
if( $_POST['managers'] ){
      $dbres                            = mysql_query("SELECT `login` FROM `[users]` WHERE `clanlevel`=6 AND `clan`='{$data->clan}'");
      while($member = mysql_fetch_object($dbres)) {
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'$data->clan  ($data->login)','".$member->login."','{$_POST['subject']}','{$_POST['message']}')"); 
}
}
if( $_POST['recruiters'] ){
      $dbres                            = mysql_query("SELECT `login` FROM `[users]` WHERE `clanlevel`=2 AND `clan`='{$data->clan}'");
      while($member = mysql_fetch_object($dbres)) {
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'$data->clan  ($data->login)','".$member->login."','{$_POST['subject']}','{$_POST['message']}')"); 
}
}
if( $_POST['members'] ){
      $dbres                            = mysql_query("SELECT `login` FROM `[users]` WHERE `clanlevel`=8 AND `clan`='{$data->clan}'");
      while($member = mysql_fetch_object($dbres)) {
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'$data->clan  ($data->login)','".$member->login."','{$_POST['subject']}','{$_POST['message']}')"); 
}
}
      $dbres                            = mysql_query("SELECT `login` FROM `[users]` WHERE `clanlevel`=9 AND `clan`='{$data->clan}'");
      while($member = mysql_fetch_object($dbres)) {   
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'$data->clan  ($data->login)','".$member->login."','{$_POST['subject']}','{$_POST['message']}')"); 
}
    print "  <tr><td class=\"mainTxt\">Message Sent</td></tr>\n";
  }

}

print <<<ENDHTML
  <tr><td class="mainTxt">
        <form name="form1" method="POST" action="clanmsg.php?p=msg"><table>
        <input type="hidden" name="id" value="$id">
        <input type="hidden" name="code" value="$code">
<table align="left"><tr><td width=100>Who is the message for?<br></td></tr>
 <tr><td width=100></td>  </tr>
   <tr><td width=100>Leaders:</td>            <td width=20><input type="checkbox" class='btn btn-info' name="leaders"></td></tr>
   <tr><td width=100>General:</td>            <td width=20><input type="checkbox" class='btn btn-info' name="generalen"></td></tr>
   <tr><td width=100>Managers:</td>            <td width=20><input type="checkbox" class='btn btn-info' name="managers"></td></tr>
   <tr><td width=100>Recruiters:</td>            <td width=20><input type="checkbox" class='btn btn-info' name="recruiters"></td></tr>
   <tr><td width=100>Members:</td>            <td width=20><input type="checkbox" class='btn btn-info' name="members"></td></tr>
      </table>
<table align="right"><center>
<tr><td width=100>Subject:</td> <td>

          <input type="text" name="subject" value="{$_REQUEST['subject']}" maxlength=25 size="20"></td></tr>
        <tr><td width=100 valign="top">Message:<br><br>
	<input type="button" class='btn btn-info' value=" BOLD "onClick="document.form1.message.value += ' [b]  TEKST  [/b]'">
	<input type="button" class='btn btn-info' value=" UnderLine "onClick="document.form1.message.value += ' [u]  TEKST  [/u]'">
	<input type="button" class='btn btn-info' value=" Itallic "onClick="document.form1.message.value += ' [i]  TEKST  [/i]'">					</td>
                                                <td><textarea name="message" cols=40 rows=16>{$_REQUEST['message']}</textarea></td></tr>
        <tr><td width=100/></td>                        <td align="right"><input type="submit" class='btn btn-info' name="submit" value="Send"> <input type="submit" class='btn btn-info' name="bekijk" value="View Message"></td></tr>
  </td></tr>
ENDHTML;
    $data				= mysql_fetch_object($dbres);
/* ------------------------- */ ?>
</table>
</body>
</html>
</table>

</body>


</html>
<?
mysql_close();
ob_flush();
?>