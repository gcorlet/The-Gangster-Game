<?php
error_reporting(0);

  include("_include-config.php");
  
  if(! isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
  }



      include("_include-gevangenis.php");
 
?>
<html>

<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

<table width=100%>
<?php /* ------------------------- */

  if(isset($_GET['x'])) {
    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$_GET['x']}'");
    if($clan = mysql_fetch_object($dbres)) {


      print "  <tr><td class=\"subTitle\"><b>{$clan->name}</b></td></tr>\n";
      print "  <tr><td class=\"mainTxt\"><i>{$clan->info}</i></td></tr>\n";

      print "  <tr><td class=\"mainTxt\"><table width=100%>\n";
print <<<ENDHTML
<table align="right"><p><img src="{$clan->avatarc}" width="220" height="180"></p></tr></td>
<table align="left">
ENDHTML;
      print "	<tr><td width=100>Owner:</td>  <td><a href=\"profile.php?x={$clan->owner}\">{$clan->owner}</a></td></tr>\n";
      $dbres				= mysql_query("SELECT `attack`,`defence`,`clicks`,`type` FROM `[users]` WHERE `clan`='{$clan->name}'");
      print "	<tr><td width=100>Members:</td>  <td>". (mysql_num_rows($dbres)) ."</td></tr>\n";
      while($member = mysql_fetch_object($dbres))
        $power				+= round(($member->attack+$member->defence)/2+$member->clicks*5);
      $power				+= ($clan->def_lvl1*1500)/2;
      $power				+= ($clan->def_lvl4*20000)/2;

      print "	<tr><td width=100>Power:</td>  <td>".number_format($power,0,',','.')."</td></tr>\n";
      print "	<tr><td width=100>Land:</td>  <td>".number_format($clan->land,0,',','.')."m<sup>2</sup></td></tr>\n";
      print "	<tr><td width=100>Cash:</td>  <td>".number_format($clan->cash,0,',','.')."</td></tr>\n";
      print "	<tr><td width=100>Bank:</td>  <td>".number_format($clan->bank,0,',','.')."</td></tr>\n";
      print "	<tr><td width=100>Clicks:</td>  <td>".number_format($clan->clicks,0,',','.')."</td></tr>\n";
      print "	<tr><td width=100>Clicks Per Day:</td>  <td>{$clan->clickstoday}</td></tr>\n";
      print "	<tr><td width=100>Began On:</td>  <td>{$clan->started}</td></tr>\n";
      print "  </table></td></tr>\n";
      print "  <tr><td align=\"right\"><table><tr><td class=\"mainTxt\" width=100 align=\"center\"><a href=\"clan.php?p=join&clan={$clan->name}\">Join</a></td>";
      print "<td class=\"mainTxt\" width=100 align=\"center\"><a href=\"clanbezit.php?x={$clan->name}\">Gang Possessions</a></td>"; 
  
      print "<td class=\"mainTxt\" width=100 align=\"center\"><a href=\"clan-donate.php?x={$clan->name}\">Donate</a></td>"; 
      if($data->clanlevel >= 7)
        print "<td class=\"mainTxt\" width=100 align=\"center\"><a href=\"clanwar.php?x={$clan->name}\">Attack</a></td>";
      print "</tr></table></td></tr>\n  <tr><td><br></td></tr>\n\n";

      print <<<ENDHTML
  <tr><td><table width=100%>
  <tr><td align="center" class="subTitle" width=15><b>#</b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center"><a href="clan.php?x={$clan->name}&s=login"><b>Name</a></b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=125><a href="clan.php?x={$clan->name}&s=rank"><b>Rank</b></a></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=100><a href="clan.php?x={$clan->name}&s=money"><b>CCash</b></a></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=75><a href="clan.php?x={$clan->name}&s=power"><b>Power</b></a></td></tr>
ENDHTML;

      $begin				= ($_GET['p'] >= 0) ? $_GET['p']*15 : 0;
      if($_GET['s'] == "login")
        $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$clan->name}' ORDER BY `login` LIMIT $begin,15");
      else if($_GET['s'] == "money")
        $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$clan->name}' ORDER BY `cash`+`bank` DESC,`login` ASC LIMIT $begin,15");
      else if($_GET['s'] == "power")
         $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$clan->name}' ORDER BY (`attack`+`defence`)/2+`clicks`*5 DESC,`login` ASC LIMIT $begin,15");
      else
        $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`type` FROM `[users]` WHERE `clan`='{$clan->name}' ORDER BY `clanlevel` DESC,`login` ASC LIMIT $begin,15");

      for($j=$begin+1; $member = mysql_fetch_object($dbres); $j++) {
        $rank				= Array("","Member","Recruiter","","","","Manager","Generaal","Leader","Owner");
        $rank				= $rank[$member->clanlevel];
        $power				= number_format(round(($member->attack+$member->defence)/2+$member->clicks*5),0,',','.');
        $money				= number_format($member->cash+$member->bank,0,',','.');

        print <<<ENDHTML
  <tr><td align="center" class="mainTxt">$j</td>
	<td class="mainTxt"><a href="profile.php?x={$member->login}">{$member->login}</a></td>
	<td align="center" class="mainTxt">$rank</td>
	<td align="center" class="mainTxt">$money</td>
	<td align="center" class="mainTxt">$power</td></tr>

ENDHTML;
      }

      $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `clan`='{$clan->name}'");
      print "</table>\n\n<table width=100%>\n  <tr><td class=\"mainTxt\" align=\"center\">";
      if(mysql_num_rows($dbres) <= 15)
        print "| 1 |</td></tr></table>\n";
      else {
        if($begin/15 == 0)
          print "&#60;&#60; ";
        else
          print "<a href=\"clan.php?x={$clan->name}&s={$_GET['s']}&p=". ($begin/15-1) ."\">&#60;&#60;</a> ";

        for($i=0; $i<mysql_num_rows($dbres)/15; $i++) {
          print "<a href=\"clan.php?x={$clan->name}&s={$_GET['s']}&p=$i\">". ($i+1) ."</a> ";
        }

        if($begin+15 >= mysql_num_rows($dbres))
          print "&#62;&#62; ";
        else
          print "<a href=\"clan.php?x={$clan->name}&s={$_GET['s']}&p=". ($begin/15+1) ."\">&#62;&#62;</a>";

        print "  </table></td></tr>\n";
      }
    }
  }
  


else if($_GET['p'] == "list") {
    print "  <tr><td><table width=100%>\n";
     print "	<tr><td class=\"subTitle\" style=\"letter-spacing: normal;\"><b>Clan</b></td>  <td class=\"subTitle\" style=\"letter-spacing: normal;\" width=125><b>Owner</b></td>  <td class=\"subTitle\" width=75 style=\"letter-spacing: normal;\"><b>Members</b></td>  <td class=\"subTitle\" width=75 style=\"letter-spacing: normal;\"><b>Power</b></td></tr>\n";
    $dbres				= mysql_query("SELECT `name`,`owner`,`type`,`def_lvl1` FROM `[clans]` ORDER BY `type`");
    while($clan = mysql_fetch_object($dbres)) {
      $power				= 0;
      $dbres2				= mysql_query("SELECT `attack`,`defence`,`clicks`,`type` FROM `[users]` WHERE `clan`='{$clan->name}'");
      while($member = mysql_fetch_object($dbres2))
     $power				+= round(($member->attack+$member->defence)/2+$member->clicks*5);
     $power				+= ($clan->def_lvl1);
$power				+= ($clan->attack_lvl1);

      $clanpower[$clan->type][$clan->name] = $power;
    }

    $lasttype				= 1;
    foreach($clanpower as $type => $info) {


       arsort($info);
      foreach($info as $name => $power) {
        $dbres				= mysql_query("SELECT `name`,`owner`,`type` FROM `[clans]` WHERE `name`='$name'");
        $clan					= mysql_fetch_object($dbres);
        $dbres			= mysql_query("SELECT `id` FROM `[users]` WHERE `clan`='$name'");
        $nummembers				= mysql_num_rows($dbres);
      $type2				= Array("","Drugsdealers","Wetenschappers","Politie");
      $type2				= $type2[$clan->type];
        print "	<tr><td class=\"mainTxt\"><a href=\"?x=$name\">$name</a></td>  <td class=\"mainTxt\" width=125><a href=\"profile.php?x={$clan->owner}\">{$clan->owner}</a></td>  <td class=\"mainTxt\" align=\"center\" width=75>$nummembers</td>  <td class=\"mainTxt\" align=\"right\" width=75>$power&nbsp;</td>";
        if($data->clanlevel >= 7)
          print "  <td align=\"center\" class=\"mainTxt\" width=75><a href=\"clanwar.php?x=$name\">Attack</td></tr>\n";
        else
          print "</tr>\n";
        $lasttype				= $type;
      }
    }
    print "  </table></td></tr>\n";
   $db = mysql_query("SELECT `name` FROM `[clans]`"); 
   $num = mysql_num_rows($db);
    echo "<tr><td class=Maintxt>There are currently <b>$num</b> gangs in the game</tr></td>";
  }







  else if($_GET['p'] == "join") {
    if($data->clanlevel == 0) {
      print "  <tr><td class=\"subTitle\"><b>Sign up for a gang!</b></td></tr>\n";
      if(isset($_POST['clan'])) {
      $dbres2 = mysql_query("SELECT * FROM `[clanban]` WHERE `clan`='{$_POST['clan']}' AND `speler`='$data->login'");
      if(mysql_num_rows($dbres2) != 0){
      print "<table width=100%><tr><td class=\"mainTxt\"><b> {$data->login} </b> you are banned from that clan!<br>you can not be in it...</td></tr></table>\n";
      exit;
      }
      $dbres2 = mysql_query("SELECT * FROM `[users]` WHERE `clan`='{$_POST['clan']}' OR `clan`='{$_POST['clan']}-[recruit]' AND `clanlevel` > 0");
      if(mysql_num_rows($dbres2) > 29){
      print "<table width=100%><tr><td class=\"mainTxt\">There are already 30 Members in the Gang!<br>Even if there are more notices, they must be dealt with.</td></tr></table>\n";
      exit;
      }
        $clan					= substr($_POST['clan'],0,32);
        $dbres					= mysql_query("SELECT `name`,`owner`,`type` FROM `[clans]` WHERE `name`='{$_POST['clan']}'");
        if($clan = mysql_fetch_object($dbres)) {
            $data->clan				= "{$clan->name}-[recruit]";
            mysql_query("UPDATE `[users]` SET `clan`='{$clan->name}-[recruit]' WHERE `login`='{$data->login}'");
            print "  <tr><td class=\"mainTxt\">You have applied to join {$clan->name}</td></tr>\n";
        
        }
        else
          print "  <tr><td class=\"mainTxt\"><b>That gang does not exist!</b></td></tr>\n";
          exit;
      }
        print "  <tr><td class=\"mainTxt\" align=\"left\"><form method=\"post\"> <b>Clan: </b><input type=\"text\" name=\"clan\" value=\"{$_GET['clan']}\" maxlength=32> <input type=\"submit\" value=\"Join\"></td></tr>\n";
    }
    else
      print "  <tr><td class=\"mainTxt\">You are already in a Gang</td></tr>\n";
  }
  else if($_GET['p'] == "new" && $data->clanlevel == 9) {
    print "  <tr><td class=\"subTitle\"><b>New Gang</b></td></tr>\n";
    if(isset($_POST['name'])) {
      $_POST['name']				= substr($_POST['name'],0,16);
      if(preg_match('/^[A-Za-z0-9_\- ]+$/',$_POST['name'])) {
if($_POST['name'] == ' ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '  ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '   ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '    ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}   
if($_POST['name'] == '     ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
} 
if($_POST['name'] == '      ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '       ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '        ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '         ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '          ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '           ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '            ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
} 
if($_POST['name'] == '             ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
} 
if($_POST['name'] == '              ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}
if($_POST['name'] == '               ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}  
if($_POST['name'] == '                ') 
{ 
$_POST['name'] = str_replace(" ","*",$_POST['name']); 
} 
else 
{ 
}   
        $dbres					= mysql_query("SELECT `name` FROM `[clans]` WHERE `name`='{$_POST['name']}'");
        if(mysql_num_rows($dbres) == 0) {
          $dbres				= mysql_query("SELECT `land` FROM `[clans]`");
          $land					= 0;
          while($clan = mysql_fetch_object($dbres))
            $land				+= $clan->land;

          if(9000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 - $land >= 300) {
            $data->clan				= $_POST['name'];
            $data->clanlevel			= 9;
            mysql_query("UPDATE `[users]` SET `clan`='{$_POST['name']}',`clanlevel`=9 WHERE `login`='{$data->login}'");
            mysql_query("INSERT INTO `[clans]`(`name`,`owner`,`started`,`type`) values('{$_POST['name']}','{$data->login}',NOW(),1)");
            print "  <tr><td class=\"mainTxt\"><b>You have madew a new gang!</b><br><i>You will now be sent back to your Headquarters!</i></td></tr>\n<script language=\"javascript\">\nsetTimeout(\"parent.window.location.reload()\",1000)\n</script>\n";
            exit;
          }
          else
            exit;
        }
        else
          print "  <tr><td class=\"mainTxt\">That Gang names is already in use.</td></tr>\n";
          exit;
      }
      else
        print "  <tr><td class=\"mainTxt\">Use only Letters, numbers, _ -, in your gang name</td></tr>\n";
    exit;
    }
  else if($_GET['p'] == "quit" && $data->clanlevel > 0 && $data->clanlevel < 9) {
    print "  <tr><td class=\"subTitle\"><b><font color=red>ERROR</font></b></td></tr>\n";
    if(isset($_POST['quit'])) {
      $data->clan				= "";
      $data->clanlevel				= 0;
      mysql_query("UPDATE `[users]` SET `clan`='',`clanlevel`=0 WHERE `login`='{$data->login}'");
      print <<<ENDHTML
  <tr><td class="mainTxt">You have left the gang</td></tr>
<script language="javascript">
setTimeout("parent.window.location.reload()",2000);
</script>
ENDHTML;
    }
    else if(isset($_POST['cancel'])) {
      print <<<ENDHTML
<script language="javascript">
document.location = "hq.php";
</script>
ENDHTML;
    }
    else {
      print <<<ENDHTML
  <tr><td class="mainTxt" align="center"><form method="post"><br><br>
<font color=red> Error Go Back </font>
  </form></td></tr>
ENDHTML;
    }
  }
  else if($_GET['p'] == "delete" && $data->clanlevel == 9) {
    print "  <tr><td class=\"subTitle\"><b>Remove the Gang</b></td></tr>\n";
    if(isset($_POST['delete'])) {
      $dbres					= mysql_query("SELECT `login` FROM `[users]` WHERE `clan`='{$data->clan}' OR `clan`='{$data->clan}-[recruit]'");
      while($member = mysql_fetch_object($dbres))
      mysql_query("UPDATE `[users]` SET `clan`='',`clanlevel`=0 WHERE `clan`='{$data->clan}' OR `clan`='{$data->clan}-[recruit]'");
      mysql_query("DELETE FROM `[clans]` WHERE `name`='{$data->clan}'");
      $data->clan				= "";
      $data->clanlevel				= 0;
      print <<<ENDHTML
  <tr><td class="mainTxt">The Gang Has Been Removed</td></tr>
<script language="javascript">
setTimeout("parent.window.location.reload()",2000);
</script>
ENDHTML;
    }
    else if(isset($_POST['cancel'])) {
      print <<<ENDHTML
<script language="javascript">
document.location = "hq.php";
</script>
ENDHTML;
    }
    else {
      print <<<ENDHTML
  <tr><td class="mainTxt" align="center"><form method="post">
	Are you sure you want to remove your Gang?<br><br>
	<input type="submit" name="delete" value="Yes" style="width: 100px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="submit" name="cancel" value="No" style="width: 100px;">
  </form></td></tr>
ENDHTML;
    }
  }

/* ------------------------- */ ?>
</table>

</body>


</html>
<noscript><noscript><plaintext><plaintext>
<?phpmysql_close($MySQL); ?>

<?
}
?>