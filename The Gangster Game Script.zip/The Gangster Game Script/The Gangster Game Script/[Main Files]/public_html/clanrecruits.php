<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");


  $I = mysql_query("SELECT * FROM `[users]` WHERE `clan`='{$data->clan}'");
  $II = mysql_num_rows($I);
  
  $A = mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
  $B = mysql_fetch_assoc($A);
  
  $getal = $B['maxm'] - $II;
  
  if($getal <= 0)
  {
  echo " You have reached your members limit, no more members from now!  {$B['maxm']} ";
  exit; 
  }
  /* ------------------------- */ ?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>
<body>
<TD vAlign=top align=middle width="50%">
<table width='40%' cellpadding='2' cellspacing='1' align='center' ><TR>
          <TD class=main align=center colSpan=2><b>You can still take on <? echo "$getal" ?> members</b><td class=main>Accept<td class=main>Reject
	<?
	$select = mysql_query("SELECT * FROM `[users]` WHERE `clan`='{$data->clan}-[recruit]'");
	while($list = mysql_fetch_object($select)) {
	  $rank			= Array("","Cafone","LowLife","Shoplifter","Pickpocket","Mugger","Thief","WiseGuy","Associate","Mobster","Gangster","Assassin","Good Fella","Mob Boss","The Don","The Godfather","Legendary Godfather");
      $rank			= $rank[$list->rank];
	echo "<tr><td class=sub><a href='profile.php?x=$list->login'>$list->login</a></td><td class=sub align=right>$rank</td><td class=sub align=right><form method=post><input type=submit name='neem' width='15' value='$list->login'><td class=sub align=right><form method=post><input type=submit name='weiger' width='15' value='$list->login'> </td>";
	}
	
	if($_POST['neem'])
	{
	if($data->clanlevel == 1) 
	{ echo " ERROR! Client Kicked! ";
	mysql_query("UPDATE `[users]` SET `clan`,`clanlevel`='' WHERE `login`='$data->login'");
	exit; 
	}
    //
    $I = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$POST_['neem']}'");
    $II = mysql_fetch_assoc($I);
	//
    if($II['clanlevel'] != 0){    echo "You cannot accept {$_POST['neem']}!"; exit;}
    $jegaat = $data->clan;
    //
    $tellen = mysql_query("SELECT * FROM `[users]` WHERE `clan`='{$data->clan}-[recruit]' AND `login`='{$_POST['neem']}'");
    $iCou = mysql_num_rows($tellen);
    if($iCou == 0)
    { echo " An Error Has Occured ";
    exit;}
    echo "Some names: {$_POST['neem']} on in the {$data->clan} Gang!!";    
	mysql_query("UPDATE `[users]` SET `clan`='$jegaat',`clanlevel`='1' WHERE `login`='{$_POST['neem']}'");
	exit;
	//
	
	}
	
	
	if($_POST['weiger'])
	{
    echo " You refused {$_POST['weiger']} ";
    mysql_query("UPDATE `[users]` SET `clan`='' WHERE `login`='{$_POST['weiger']}'");
    exit;
	}
	?>
</TABLE><br><br>