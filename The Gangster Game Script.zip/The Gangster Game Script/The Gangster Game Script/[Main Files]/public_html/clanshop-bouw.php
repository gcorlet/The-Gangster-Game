<?php
error_reporting(0);

  $_POST['omnilog']			= 1;
  $OMNILOG				= 1;
 include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
}


  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);
    include("_include-gevangenis.php");


    $power				+= round(($member->attack+$member->defence)/2+$member->clicks*5);
      $power1				+= ($clan->attack+$member->defence)/2;



      $dbres				= mysql_query("SELECT `name`,`url` FROM `[weapons]` WHERE `area`=8 OR `area`=8+{$clan->type} ORDER BY `area`,`costs`");
      while($weapon = mysql_fetch_object($dbres)) {
        $name				= $weapon->name;
        $type				= Array("Homes"		=> "homes",
						"Wall"		=> "def_lvl1",
                                                "Safe House"	=> "def_lvl2",
                                                "Bunker"	=> "def_lvl3",
						"Coffeeshop"	=> "money_lvl1",
						"Chemical Lab"	=> "money_lvl1",
                                                "Islands"	=> "money_lvl3",
                                                "Weapons"	=> "attack_lvl1",
						"Share"	=> "money_lvl1");
        $type				= $type[$weapon->name];
        $lastarea			= $weapon->area;
      }

if(isset($_POST['13']) && preg_match('/^[0-9]+$/',$_POST['a13'])) {
		$guns = $_POST['a13'];
		$power = round($_POST['a13']*1050);
		$Price = round($_POST['a13']*85000);
		$aantal	= round($data->wapens+$_POST['a13']);
		if($Price < $clan->bank) {
			mysql_query("UPDATE `[clans]` SET `bank`=`bank`-$Price,`wapens`=`wapens`+'{$_POST['aantal13']}',`attack_lvl1`=`attack_lvl1`+$power WHERE `name`='{$data->clan}'");
			print "You have purchased {$_POST['a13']} grenade Launcher.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['14']) && preg_match('/^[0-9]+$/',$_POST['a14'])) {
		$guns = $_POST['a14'];
		$power = round($_POST['a14']*1250);
		$Price = round($_POST['a14']*105000);
		$aantal	= round($data->wapens+$_POST['a14']);
		if($Price < $clan->bank) {
			mysql_query("UPDATE `[clans]` SET `bank`=`bank`-$Price,`wapens`=`wapens`+'{$_POST['aantal14']}',`attack_lvl1`=`attack_lvl1`+$power WHERE `name`='{$data->clan}'");
			print "You have purchased {$_POST['a14']} m3m .50cal's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['15']) && preg_match('/^[0-9]+$/',$_POST['a15'])) {
		$guns = $_POST['a15'];
		$power = round($_POST['a15']*1550);
		$Price = round($_POST['a15']*135000);
		$aantal	= round($data->wapens+$_POST['a15']);
		if($Price < $clan->bank) {
			mysql_query("UPDATE `[clans]` SET `bank`=`bank`-$Price,`wapens`=`wapens`+'{$_POST['aantal15']}',`attack_lvl1`=`attack_lvl1`+$power WHERE `name`='{$data->clan}'");
			print "You have purchased {$_POST['a15']} bazooka's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['16']) && preg_match('/^[0-9]+$/',$_POST['a16'])) {
		$guns = $_POST['a16'];
		$power = round($_POST['a16']*1800);
		$Price = round($_POST['a16']*179000);
		$aantal	= round($data->wapens+$_POST['a16']);
		if($Price < $clan->bank) {

			mysql_query("UPDATE `[clans]` SET `bank`=`bank`-$Price,`attack_lvl1`=`attack_lvl1`+$power WHERE `name`='{$data->clan}'");
			print "You have purchased {$_POST['a16']} miniguns.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}







/* ------------------------- */ ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel"stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">
<table align="center" width="80%">
<?
if($data->clanlevel < 6 OR $data->clanlevel == 7) {
?>
<tr><td class="mainTxt" align="center">This is for the Owners, Generals and Leaders of the Gangs!</td></tr>
<?
exit;
}
?>
<tr><td class="subTitle" colspan="2">Gang Shop - Weapons</td></tr>
<tr>
<td class="mainTxt" width="50%" align="center"><b>Grenade Launcher</b></td>
<td class="mainTxt" width="50%" align="center"><b>Bazooka</b></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;85,000</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;135,000</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80"></td><td><img src="images/winkel/item-Grenade_Launcher.gif"></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80"></td><td><img src="images/winkel/item-Bazooka.gif"></td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Attack Power:</td><td>1050</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Attack Power:</td><td>1550</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Total Sold To Other Gangs:</td><td></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Total Sold To Other Gangs:</td><td></td></table></td>
</tr>
<tr>
<form method="POST"><td class="mainTxt" align=center width="50%">Total Amount: <input maxlength="6" type="text" class='btn btn-info' name="a13" value="1"> <input type="submit" class='btn btn-info' name="13" value="Purchase"></td></form>
<form method="POST"><td class="mainTxt" align=center width="50%">Total Amount: <input maxlength="6" type="text" class='btn btn-info' name="a15" value="1"> <input type="submit" class='btn btn-info' name="15" value="Purchase"></td></form>
</tr>

<br>
<tr>
<td class="mainTxt" width="50%" align="center"><b>M3M .50CAL</b></td>
<td class="mainTxt" width="50%" align="center"><b>MiniGun</b></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;105,000</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;189.000</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80"></td><img src="images/winkel/item-machinegun.gif"></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80"></td><td><img src="images/winkel/item-minigun.gif"></td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Attack Power:</td><td>1250</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Attack Power:</td><td>1800</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Total Sold To Other Gangs:</td><td></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Total Sold To Other Gangs:</td><td></td></table></td>
</tr>
<tr>
<form method="POST"><td class="mainTxt" align=center width="50%">Total Amount: <input maxlength="6" type="text" class='btn btn-info' name="a14" value="1"> <input type="submit" class='btn btn-info' name="14" value="Purchase"></td></form>
<form method="POST"><td class="mainTxt" align=center width="50%">Total Amount: <input maxlength="6" type="text" class='btn btn-info' name="a16" value="1"> <input type="submit" class='btn btn-info' name="16" value="Purchase"></td></form>
</tr>

</body>
</html>

