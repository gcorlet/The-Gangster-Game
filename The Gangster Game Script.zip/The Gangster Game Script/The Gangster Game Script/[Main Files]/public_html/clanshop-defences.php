<?php
error_reporting(0);

  $_POST['omnilog']			= 1;
  $OMNILOG				= 1;
   include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
}


  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);
    include("_include-gevangenis.php");


    $power				+= round(($member->attack+$member->defence)/2+$member->clicks*5);
      $power				+= ($clan->def_lvl1*1500)/2;



      $dbres				= mysql_query("SELECT `name`,`url` FROM `[weapons]` WHERE `area`=8 OR `area`=8+{$clan->type} ORDER BY `area`,`costs`");
      while($weapon = mysql_fetch_object($dbres)) {
        $name				= $weapon->name;
        $type				= Array("Homes"		=> "homes",
						"Wall"		=> "def_lvl1",
                                                "Safe House"	=> "def_lvl1",
                                                "Dogs"	        => "def_lvl1",
                                                "Cameras"	=> "def_lvl1",
						"Coffeeshop"	=> "money_lvl1",
						"Chemical Lab"	=> "money_lvl1",
                                                "Islands"	=> "money_lvl3",
						"Share"	=> "money_lvl1");
        $type				= $type[$weapon->name];
        $lastarea			= $weapon->area;
      }


if(isset($_POST['4']) && preg_match('/^[0-9]+$/',$_POST['a4'])) {
		$guns = $_POST['a4'];
		$power = round($_POST['a4']*250);
		$Price = round($_POST['a4']*55000);
		$aantal	= round($data->verdediging4+$_POST['a4']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price < $clan->bank) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a4']} walls.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}



if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*30);
		$Price = round($_POST['a1']*3800);
		$aantal	= round($data->verdediging1+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price < $clan->bank) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']} dogs.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*100);
		$Price = round($_POST['a2']*29000);
		$aantal	= round($data->verdediging2+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price < $clan->bank) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a2']} camera's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['3']) && preg_match('/^[0-9]+$/',$_POST['a3'])) {
		$guns = $_POST['a3'];
		$power = round($_POST['a3']*180);
		$Price = round($_POST['a3']*41000);
		$aantal	= round($data->verdediging3+$_POST['a3']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price < $clan->bank) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a3']} bunkers.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}





/* ------------------------- */ ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body style="margin: 0px;">
<table align="center" width="80%">
<?
if($data->clanlevel < 6 OR $data->clanlevel == 7) {
?>
<tr><td class="mainTxt" align="center">This is for the Owner, Generals, and the Leaders of the Gang!</td></tr>
<?
exit;
}
?>
<tr><td class="subTitle" colspan="2">Gang Shop - Defences</td></tr>
<tr>
<td class="mainTxt" width="50%" align="center"><b>Guard Dogs</b></td>
<td class="mainTxt" width="50%" align="center"><b>Cameras</b></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;3500</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;29000</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80"></td><td><img src="images/winkel/item-Bulldog.gif"></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80"></td><td><img src="images/winkel/item-Cam.gif"></td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Defence Power:</td><td>30</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Defence Power:</td><td>100</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Total Sold To Other Gangs:</td><td></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Total Sold To Other Gangs:</td><td></td></table></td>
</tr>
<tr>
<form method="POST"><td class="mainTxt" width="50%">Total Amount: <input maxlength="6" type="text" name="a1" value="1"> <input type="submit" name=1 value="Purchase"></td></form>
<form method="POST"><td class="mainTxt" width="50%">Total Amount: <input maxlength="6" type="text" name="a2" value="1"> <input type="submit" name=2 value="Purchase"></td></form>
</tr>
<br>
<tr>
<td class="mainTxt" width="50%" align="center"><b>Walls</b></td>
<td class="mainTxt" width="50%" align="center"><b>Bunkers</b></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;41000</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Price:</td><td>;55000</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80"></td><td><img src="images/winkel/item-Stone_wall.gif"></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80"></td><td><img src="images/items/bunker.gif"></td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Defence Power:</td><td>250</td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Defence Power:</td><td>180</td></table></td>
</tr>
<tr>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Total Sold To Other Gangs:</td><td></td></table></td>
<td class="mainTxt" width="50%"><table width="100%"><td width="80">Total Sold To Other Gangs:</td><td></td></table></td>
</tr>
<tr>
<form method="POST"><td class="mainTxt" width="50%">Total Amount: <input maxlength="6" type="text" name="a4" value="1"> <input type="submit" name=4 value="Purchase"></td></form>
<form method="POST"><td class="mainTxt" width="50%">Total Amount: <input maxlength="6" type="text" name="a3" value="1"> <input type="submit" name=3 value="Purchase"></td></form>
</tr>

</body>
</html>