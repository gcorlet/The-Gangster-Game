<?php
error_reporting(0);

?>

<?php /* ------------------------- */
if($configloaded != "1") {
  $_POST['omnilog']			= 1;
  $OMNILOG				= 1;
   include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
}
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<table align=center width=100%>
  <tr><td class=subTitle><b>Buy Land</b></td></tr>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">


<?PHP
  $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);

  if(isset($_POST['id'])) {
			$num10 = $_POST['num'];
			$id    = $_POST['id'];
	   $genoegcash = 200000*$num10;
if($num10 < 1) {
print "<tr><table align=center width=100%><td class=\"mainTxt\">Minimum of 100m<sup>2</sup></td></table></tr>";
exit;
}
$num11 = 100*$num10;
if(preg_match('/^[0-9_\-]+$/',$num10)) {
	   if($genoegcash <= $clan->bank) {
$insert2 = "INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`hoeveel`) values(NOW(),'$data->login','{$data->clan}','land','$num10')";
$insert = "UPDATE `[clans]`  set `land`=`land`+$num10*100, `bank`=`bank`-$genoegcash WHERE `name`='{$clan->name}'"; 
$insert_now = mysql_query($insert);
$insert_now2 = mysql_query($insert2);
echo "<tr><table align=center width=100%><td class=\"mainTxt\">You have bought {$num11} m<sup>2</sup> of land</td></table></tr>\n";

}
else {
echo "<tr><table align=center width=100%><td class=\"mainTxt\">You dont have enough Gang Cash to buy {$num11} m<sup>2</sup> of land</td></table></tr>";
}
}

else 
echo "<tr><table align=center width=100%><td class=\"mainTxt\">You may only enter Numbers!</td></table></tr>";
}
?>
<html>
<table align=center width=100%>

  <tr><td class=mainTxt>


<table height="90" cellSpacing="0" cellPadding="0" width="100%">
<td align=right><a href="../../clanshop.php"><font color="yellow" size=2>Back to Shop Menu</font></a>
  <tr>
    <td height="70"><font color="white">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font>Building Grounds<font color="white"><br><img src="images/game/bouwgrond.jpg" width="190" height="154">
      </td>
    <td vAlign="top" align="right" height="70">
    <table height="100%" width="100%">
      <tr>
        <td vAlign="top">&nbsp;</td>
      </tr>
      <tr>
        <td vAlign="bottom">
        <table width="100%">
          <tr>
            <td width="75">Land:</td>
            <td>100 m<sup>2</sup> </td>
          </tr>
          <tr>
            <td width="75">Max.:</td>
            <td>There is no maximum.</td>
          </tr>
          <tr>
            <td vAlign="top" width="75">Explanation:</td>
            <td>Land is nescessary to build Buildings</td>
          </tr>
          <tr>
            <td width="75">Cost:</td>
            <td>$200000</td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td height="19">&nbsp;</td>
    <td align="right" height="19"
   	 
	 <?PHP
	if($genoegcash <= $clan->bank){
	  
	          print "




<tr><td></td>  <td height=5 align=\"right\"><form method=\"post\"><input type=\"hidden\" name=\"id\" maxlength=64 value=\"{$weapon->id}\"><input type=\"text\" class='btn btn-info' name=\"num\" maxlength=64 style=\"width: 50;\" value=\"1\">&nbsp;<input type=\"submit\" class='btn btn-info' name=\"submit\" style=\"width: 75;\" value=\"Buy\"></form></td></tr>\n";
	     
 print <<<ENDHTML

	 </table>
<tr><td class="mainTxt"><center><b>Your Gang has  {$clan->bank} </b></center></td></tr>


ENDHTML;
  }
	   else {
	          print "

	 <tr><td></td>  <td height=5 align=\"right\"><form method=\"post\"><input type=\"hidden\" name=\"id\" class='btn btn-info' maxlength=64 value=\"{$weapon->id}\"><input type=\"text\" name=\"num\" class='btn btn-info' maxlength=64 style=\"width: 50;\" value=\"1\"></form></td></tr>\n";
print <<<ENDHTML
     
 </table>
<tr><td class="mainTxt"><center><b>Your Gang has {$clan->bank} </b></center></td></tr>

	

ENDHTML;
  }

?>	

	</td>
  </tr>
  
</table>

</body>
</html>

<?
mysql_close();
ob_flush();
?>