<?php
error_reporting(0);

  $_POST['omnilog']			= 1;
  $OMNILOG				= 1;
   include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

</head>


<table width=100%>
<?php /* ------------------------- */

  if($_GET['p'] == "buy" && ($data->clanlevel >= 8 || $data->clanlevel == 6)) { 
print "  <tr><td class=\"subTitle\"><b>Clan - Bouwterrein</b></td></tr>\n";

    $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);
    if(isset($_GET['x'])) {
      $dbres				= mysql_query("SELECT * FROM `[weapons]` WHERE `name`='{$_GET['x']}' AND (`area`=8 OR `area`=8+{$clan->type})");
      if($item = mysql_fetch_object($dbres)) {
        if($clan->type == 1)
          $item->costs			= round($item->costs*0.95);

        if($item->costs <= $clan->cash) {
          if(eval($item->eval) > 0) {
            $type			= Array("Homes"		=> "homes",
						"walls"		=> "def_lvl1",
						"Coffeeshop"	=> "money_lvl1",
						"Chemicals Lab"	=> "money_lvl1",
						"Share"	=> "money_lvl1");
            $type			= $type[$item->name];
            $clan->cash			-= $item->costs;
            $clan->{"$type"}++;
mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`hoeveel`) values(NOW(),'$data->login','{$data->clan}','$type','1')");
            mysql_query("UPDATE `[clans]` SET `cash`={$clan->cash},`$type`=". ($clan->{"$type"}) ." WHERE `name`='{$clan->name}'");
            print "  <tr><td class=\"mainTxt\">You have bought a new {$item->name} </td></tr>\n";
          }
          else
            print "  <tr><td class=\"mainTxt\">{$item->error}</td></tr>\n";
        }
        else
          print "  <tr><td class=\"mainTxt\">You dont have enough cash to build a {$item->name} </td></tr>\n";
      }
    }

    $dbres				= mysql_query("SELECT * FROM `[weapons]` WHERE `area`=8 OR `area`=8+{$clan->type}");
    while($weapon = mysql_fetch_object($dbres)) {
      if($clan->type == 1)
        $weapon->costs			= round($weapon->costs*0.95);
      else if($clan->type == 2)
        $weapon->defence		= round($weapon->defence*1.05);

      eval($weapon->eval);
      eval("\$weapon->max = \"{$weapon->max}\";");

      print <<<ENDHTML
  <tr><td class="mainTxt">
	<table width=100% height=100% cellpadding=0 cellspacing=0>
	  <tr><td>&nbsp;<i>{$weapon->name}</i><br><img src="images/{$weapon->url}.gif" width=200 height=150></td>

ENDHTML;

      eval("\$weapon->max = \"{$weapon->max}\";");
      print "	  <td valign=\"top\" align=\"right\"><table width=100% height=100%>\n";
      print "	    <tr><td valign=\"top\">{$weapon->extra}</td></tr>\n";
      print "	    <tr><td valign=\"bottom\"><table width=100%>\n";
      if($weapon->attack != NULL)
        print "	      <tr><td width=75>Attack:</td>		<td>{$weapon->attack}</td></tr>\n";
      if($weapon->defence != NULL)
        print "	      <tr><td width=75>Defence:</td>		<td>{$weapon->defence}</td></tr>\n";
      if($weapon->costs != NULL)
        print "	      <tr><td width=75>Cost:</td>		<td>\${$weapon->costs}</td></tr>\n";
      if($weapon->max != NULL)
        print "	      <tr><td width=75 valign=\"top\">Weapons Max:</td>	<td>{$weapon->max}</td></tr>\n";
        print <<<ENDHTML
	    </table></td></tr>
	  </table></td></tr>
ENDHTML;
      if($clan->cash >= preg_replace("/,/","",$weapon->costs) && eval($weapon->eval) > 0)
        print "	  <tr><td></td>  <td height=5 align=\"right\"><a href=\"clanshop.php?p=buy&x={$weapon->name}\"><b>Buy</b></a></td></tr>\n";

   else
        print "	  <tr><td></td>  <td height=5 align=\"right\"><a href=\"clanshop.php?p=buy&x={$weapon->name}\" style=\"color: #000000;\">Buy</a></td></tr>\n";

      print <<<ENDHTML

	</table>
  </td></tr>

ENDHTML;
    }
 	echo"  <tr><td class=\"mainTxt\"><center><b>Your gang has {$clan->cash} and {$clan->bank} in the bank </b></center></td></tr>";
 }
    
  else if($data->clanlevel >= 8 || $data->clanlevel == 6) {
   $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    $clan				= mysql_fetch_object($dbres);
 print <<<ENDHTML
  <tr><td class="subTitle"><b>Gang - Building Grounds</b></td></tr>
  <tr><td class="mainTxt" align=center>

- <a href="clanshop-defence.php" class='btn btn-info'>Defences</a>
<br>
- <a href="clanshop-weapons.php" class='btn btn-info'>Weapons</a>
<br>
- <a href="clanshop-land.php" class='btn btn-info'>Land</a>
<br>
- <a href="clanitems-cash.php" class='btn btn-info'>Buildings</a>
<br>

  </td></tr>
 <tr><td class="mainTxt"><center><b>Your Gang has {$clan->cash} and {$clan->bank} in the bank </b></center></td></tr>
ENDHTML;
  }

/* ------------------------- */ ?>
</table>

</body>


</html>
<?
mysql_close();
ob_flush();
?>