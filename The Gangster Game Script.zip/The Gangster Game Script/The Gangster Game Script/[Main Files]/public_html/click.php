<?php
error_reporting(0);
 
  include('_include-config.php');
  

?>

<html>
<head>
<title></title>
</head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<table class='main'style='' align='center' height=300 cellpadding=0 cellspacing=0>
<?php /* ------------------------- */

  if(isset($_GET['x'])) {
      $dbres                                = mysql_query("SELECT `login`,`cash`,`bank`,`clicks`,`clickstoday`,`drugspower`,`type`,`IPs`,`clan`,`clicktext` FROM `[users]` WHERE `login`='{$_GET['x']}'");
    if($data = mysql_fetch_object($dbres)) {
      $clientIP                                = $_SERVER['REMOTE_ADDR'];
      $forwardedFor                        = ($_SERVER['HTTP_X_FORWARDED_FOR'] == "") ? $_SERVER['HTTP_CLIENT_IP'] : $_SERVER['HTTP_X_FORWARDED_FOR'];

if($data->drugspower == d){
    print <<<ENDHTML
<table width=100%><tr><td class=subtitle>Persoonlijke Click Link</td></table>
  <table width=100%><tr><td class=mainTxt>
	<center><B>{$data->login} doesnt have enough drugspower!<BR> So therefore you cannot click on this ClickLink!</B>
	</center>
    </td></tr>
  </table>
</body>
ENDHTML;
    exit;
     }
      if(preg_match("/$clientIP/",$data->IPs) == 0 && ($forwardedFor == "" || preg_match("/$forwardedFor/",$data->IPs) == 0)) {
         if($data->clickstoday < 50) {
if($data->clicktext == "") {
$data->clicktext = " {$data->login} has no ClickText!";
}
          $sentence                        = Array(
            							Array("","{$data->login} has asked for your mobile number...",
              								"{$data->login} asked you if you were a working PIMP...",
              								"{$data->login} wants to ask you if you want a brand new fiat..."),
                                                Array("",'Here you can put your own text for <b>$data->login</b><br><br>
                                                                <center><$data->clicktext<center><br>                                                               
                                                                <B>{$data->login}</b> now has <b>{$data->clicks}</b> junkies <BR><BR><BR><b><a href=login.php> Click Here </a> </b>to register as a free member!</center></b>',
                                                        'Here you can put your own text for<b>$data->login</b><br><br>
                                                                <center>$data->clicktext<center><br> 
                                                                {$data->login} now has{$data->clicks} klonen <BR><BR><BR><b><a href=login.php>  Click Here </a> </b>to register as a free member!</center></b>',
                                                        'Here you can put your own text for <b>$data->login</b><br><br>
                                                                <center>$data->clicktext<center><br> 
                                                                {$data->login} now has {$data->clicks} agenten <BR><BR><BR><b><a href=login.php> Click Here </a> </b>to register as a free member!</center></b>')
                                          );


          $dbres                        = mysql_query("SELECT * FROM `[temp]` WHERE `id`='{$_POST['id']}' AND `code`='{$_POST['code']}' AND `area`='click'");
          if(($check = mysql_fetch_object($dbres)) && $check->IP == $clientIP) {
            if($data->clicks < 25) {
              $data->cash                += 1000;
              $data->bank                += 1000;
            }
            else if($data->clicks >= 25 && $data->clicks < 50) {
              $data->cash                += 750;
              $data->bank                += 750;
            }
            else {
              $data->cash                += 500;
              $data->bank                += 500;
            }
            $data->clicks                += 1;
            $data->clickstoday                += 1;

mysql_query("UPDATE `[users]` SET `drugspower`=`drugspower`-'5', `clicks`={$data->clicks},`clickstoday`={$data->clickstoday},`cash`={$data->cash},`bank`={$data->bank},`IPs`='{$data->IPs},$clientIP' WHERE `login`='{$data->login}'");

            if(isset($_SESSION['login']))


            include("_include-banners.php");
            $sentence                        = eval("return (\"{$sentence[1][$data->type]}\");");
            print <<<ENDHTML
  <tr><td class="mainTxt" align="center" width=799>
        <br><b>$sentence</b>
  </td></tr>
  <tr><td align="center" bgcolor="#333333" height=5><br><br>$bannercode</td></tr>
ENDHTML;
          }
          else {
            include("_include-banners.php");
            $code                        = rand(100000,999999);
            mysql_query("INSERT INTO `[temp]`(login,IP,code,area,time) values('{$data->login}','$clientIP','$code','click',NOW())");
            $id                                = mysql_insert_id();
            $sentence                        = eval("return (\"{$sentence[0][$data->type]}\");");
            print <<<ENDHTML
  <tr><td class="mainTxt" align="center" width=799>
        <br><b>$sentence</b>
        <form method="post">
                <input type="hidden" name="id" value="$id">
                <input type="hidden" name="code" value="$code">
                <input type="submit" value="Continue" style="border: 1px outset #ECF0E2
    </form>
  </td></tr>
ENDHTML;
          }
        }
        else {
          $type                                = Array("CrImInaL","P.I.M.P","Agent");
          $type                                = $type[$data->type];
          print "  <tr><td class=\"mainTxt\" align=\"center\" width=799>{$data->login} has clicked 50 $type s already</b><BR><BR><BR><b><a href=login.php> Click Here </a> </b>to register as a FREE member!</center></b></td></tr>\n";
        }
      }
      else {
        $type                                = Array("CrImInaL","P.I.M.P","Agent");
        $type                                = $type[$data->type];
        print "  <table width=799 align=center><tr><td class=subtitle><b>Personalised Click Link</b></td>\n";
        print "  <center><tr><td class=\"mainTxt\" align=\"center\" width=799><center>You have already had a $type from <b>{$data->login}</b><BR><i>You can only click the CLICKLINK once every hour.</i><BR><BR><BR><b><a href=login.php>  Click Here </a> </b>to register as a FREE member!</center></b></td></tr>\n";        
      }
    }
  }



/* ------------------------- */ ?>
</table>




    </tr>
</table>
<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  </table></td></tr>
</table>
<br>
<br>
</body>

<center>
<br>
</center>
</table>


</html>
<? mysql_close(); ?>