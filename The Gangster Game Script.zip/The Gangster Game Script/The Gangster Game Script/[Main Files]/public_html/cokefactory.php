<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(!($_SESSION)) {
    header("Location: login.php");
    exit;
  } 
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);

    $fabriek2				= mysql_query("SELECT * FROM `[cokefabriek]` WHERE `land`='{$data->land}'");
    $fabriek				= mysql_fetch_object($fabriek2);
    $fabriekenover2				= mysql_query("SELECT * FROM `[cokefabriek]` WHERE `land`='{$data->land}' AND `owner`=''");
    $fabriekenover				= mysql_num_rows($fabriekenover2);

    $fabriek1db				= mysql_query("SELECT * FROM `[cokefabriek]` WHERE `land`='{$data->land}' AND `nummer`='1'");
    $fabriek1				= mysql_fetch_object($fabriek1db);

    $fabriek2db				= mysql_query("SELECT * FROM `[cokefabriek]` WHERE `land`='{$data->land}' AND `nummer`='2'");
    $fabriek2				= mysql_fetch_object($fabriek2db);

    $fabriek3db				= mysql_query("SELECT * FROM `[cokefabriek]` WHERE `land`='{$data->land}' AND `nummer`='3'");
    $fabriek3				= mysql_fetch_object($fabriek3db);

    $jouwfabriek2 			= mysql_query("SELECT * FROM `[cokefabriek]` WHERE `owner`='{$data->login}'");
    $jouwfabriek			= mysql_fetch_object($jouwfabriek2);

    $runner1db 			= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$jouwfabriek->runner1}'");
    $runner1			= mysql_fetch_object($runner1db);
    $runner2db 			= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$jouwfabriek->runner2}'");
    $runner2			= mysql_fetch_object($runner2db);
    $runner3db 			= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$jouwfabriek->runner3}'");
    $runner3			= mysql_fetch_object($runner3db);
    $runner4db 			= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$jouwfabriek->runner4}'");
    $runner4			= mysql_fetch_object($runner4db);
    $runner5db 			= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$jouwfabriek->runner5}'");
    $runner5			= mysql_fetch_object($runner5db);
    $runner6db 			= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$jouwfabriek->runner6}'");
    $runner6			= mysql_fetch_object($runner6db);
    $runner7db 			= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$jouwfabriek->runner7}'");
    $runner7			= mysql_fetch_object($runner7db);
    $runner8db 			= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$jouwfabriek->runner8}'");
    $runner8			= mysql_fetch_object($runner8db);



























    $fabriekland1 			= array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland");
    $fabriekland 			= $fabriekland1[$jouwfabriek->land];

    $land1 			= array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland");
    $land 			= $land1[$data->land];

    $Invitationen2 			= mysql_query("SELECT * FROM `[runnertemp]` WHERE `login`='{$data->login}'");
    $Invitationen			= mysql_fetch_object($Invitationen2);

if($fabriekenover == 1) {
$text1 = is;
$text2 = "Cocaine Factory";
} else {
$text1 = are;
$text2 = "Cocaine Factories";
}

?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">
<table align="center" width="80%">
<tr><td class="subTitle" colspan="4"><b>Cocaine Factory</b></td></tr>
<tr><td class="mainTxt" colspan="4"><b>Information:<br>
The Cocaine Factory with Drug Runner feature has been moved from the VIP
section, to Public Players. Enjoy!</b>
<br>
<br>
<font color=red><b>WARNING - PLEASE READ: 1 cocaine factory per person, if you purchase another factory, it will make your first factory invalid, and meaning an admin will have to reset it for you!</b></font>
<br>
<br>
In each country there are 3 Cocaine Factories, each stand at a price of <b>275.000.000</b>. <br>
<br>
In every Cocaine Factory you can hire other players to become a drug runner for you.
You are allowed a maximum of 8 Drug Runners per factory, and your only allowed to purchase 1
Cocaine Factory in TOTAL!<br><br>
The way you make money is by handing some Cocaine to one of your runners, and they sell it
for a fixed price. The drug runner then sells it on and gives you the money you requested.
He keeps some profit made on the sale, its about 70/30 to you. But the cocaine factory or..
being a drug runner is a very profitable job. Recommended to anyone.<br><br>

</td></tr>
<tr><td class="mainTxt" colspan="4" align="center"><b><?=$fabriekenover?> </b><?=$text2?> left in <b><?=$land?></b></td></tr>
<?
 {
?>
<tr><td class="subTitle" colspan="4">Buy Cocaine Factory</td></tr>
<?
  if(isset($_POST['koop1'])) {
if($data->cash < 275000000) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You dont have enough cash, you need <b>75.000.000</b>!</td></tr>";
} else {

mysql_query("UPDATE `[users]` SET `cokefabriek`='1',`cash`=`cash`-275000000 WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[cokefabriek]` SET `owner`='{$data->login}' WHERE `land`='{$data->land}' AND `nummer`='1'");
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have bought <b>Cocaine Factory 1</b> for <b>275.000.000</b>!<script language=\"javascript\">setTimeout('self.window.location.href=\"cokefactory.php\"',600)</script></td></tr>";
}
}

  if(isset($_POST['koop2'])) {
if($data->cash < 275000000) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You dont have enough cash, you need <b>75.000.000</b>!</td></tr>";
} else {


mysql_query("UPDATE `[users]` SET `cokefabriek`='1',`cash`=`cash`-275000000 WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[cokefabriek]` SET `owner`='{$data->login}' WHERE `land`='{$data->land}' AND `nummer`='2'");
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have bought <b>Cocaine Factory 2</b> for <b>275.000.000</b>!<script language=\"javascript\">setTimeout('self.window.location.href=\"cokefactory.php\"',600)</script></td></tr>";
}
}

  if(isset($_POST['koop3'])) {
if($data->cash < 275000000) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You dont have enough cash, you need <b>75.000.000</b>!</td></tr>";
} else {

mysql_query("UPDATE `[users]` SET `cokefabriek`='1',`cash`=`cash`-275000000 WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[cokefabriek]` SET `owner`='{$data->login}' WHERE `land`='{$data->land}' AND `nummer`='3'");
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have bought <b>Cocaine Factory 3</b> for <b>275.000.000</b>!<script language=\"javascript\">setTimeout('self.window.location.href=\"cokefactory.php\"',600)</script></td></tr>";
}
}
?>
<tr><td class="mainTxt" colspan="4">Here you can see which factories are still up for sale:</td></tr>
<?
if($fabriek1->owner == '') {
?>
<form method="POST">
<tr><td class="mainTxt">Cocaine Factory - 1</td><td class="mainTxt">275.000.000</td><td class="mainTxt" align="center" colspan="2"><input class="btn btn-info" type="submit" name="koop1" value="Purchase Factory!"></tr>
</form>
<?
}
if($fabriek2->owner == '') {
?>
<form method="POST">
<tr><td class="mainTxt">Cocaine Factory - 2</td><td class="mainTxt">275.000.000</td><td class="mainTxt" align="center" colspan="2"><input class="btn btn-info" type="submit" name="koop2" value="Purchase Factory!"></tr>
</form>
<?
}
if($fabriek3->owner == '') {
?>
<form method="POST">
<tr><td class="mainTxt">Cocaine Factory - 3</td><td class="mainTxt">275.000.000</td><td class="mainTxt" align="center" colspan="2"><input class="btn btn-info" type="submit" name="koop3" value="Purchase Factory!"></tr>
</form>
<?
}
} 
 if($data->cokefabriek == 0 AND $data->runner == 0){
?>
<tr><td class="subTitle" colspan="4">Drug Runners</td></tr>
<tr><td class="mainTxt" colspan="4">Here you can accept invitations from different Cocaine Factories:</td></tr>
<tr><td class="mainTxt" width="102"><b>Factory</b></td><td class="mainTxt" width="499"><b>Owner</b></td><td class="mainTxt" width="70"><b>Country</b></td><td class="mainTxt" width="29" align="center"><b>Number</b></td></tr>
<?
$query = "SELECT * FROM `[runnertemp]` WHERE `runner`='{$data->login}' ORDER BY `land` DESC LIMIT 0,18";
$info = mysql_query($query) or die(mysql_error());
while ($gegeven = mysql_fetch_array($info)) {
$nummer = $gegeven["nummer"];
$owner = $gegeven["owner"];
$land1 			= array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland");
$land 			= $land1[$gegeven["land"]];
$nummer2			= mysql_query("SELECT * FROM `[cokefabriek]` WHERE `owner`='$owner'");
$nummer1				= mysql_fetch_object($nummer2);
echo "
<tr>
    <td class=mainTxt>Cocaine Factory ".$nummer1->nummer."</td>
    <td class=mainTxt>".$owner."</td>
    <td class=mainTxt>".$land."</td>
    <td align=center class=mainTxt><input type=radio class='btn btn-info' name=run value=1 checked></td>
</tr>
         ";
}
?>
<form method="POST">
<tr><td class="mainTxt" colspan="4" align="center"><input type="submit" width="100" class="btn btn-info" name="acceptrunner" value="Accept"> <input type="submit" width="100" class="btn btn-info" name="deleteinvite" value="Reject"></td></tr>
</form>
<?
  if(isset($_POST['acceptrunner'])) {
if($owner == '') {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have not been invited!</td></tr>";
} else {
mysql_query("DELETE FROM `[runnertemp]` WHERE `runner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='{$nummer}' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[cokefabriek]` SET `runner{$nummer}`='{$data->login}' WHERE `owner`='{$owner}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$owner."','Invitation Accepted','".$data->login." has accepted the invitation to let you work along side in the facotry.')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You are a Drug Runner for <b>{$owner}</b> and will make <b>200</b> profit per gram of coke that you sell.<script language=\"javascript\">setTimeout('self.window.location.href=\"cokefactory.php\"',2000)</script></td></tr>";
}
}

  if(isset($_POST['deleteinvite'])) {
if($owner == '') {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have not been invited!</td></tr>";
} else {
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$owner."','Invitation Rejected','".$data->login." turned down your invitation for a Drug Runner Job.')"); 
mysql_query("DELETE FROM `[runnertemp]` WHERE `runner`='{$data->login}'");
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">Your invitation has been turned down, sorry.</td></tr>";
}
}


}
?>
</table>
<?
if($data->cokefabriek == 1 AND $data->land == $jouwfabriek->land) {
?>
<table align="center" width="80%">
<tr><td class="subTitle" colspan="3">Your Cocaine Factory</td></tr>
<tr><td class="mainTxt" colspan="3">You are the owner of <b>Cocaine Factory - <?=$jouwfabriek->nummer?></b> in <b><?=$fabriekland?></td></tr>
<tr><td class="mainTxt">Coke Supply:</td><td class="mainTxt" colspan="2">You have <b><?=$jouwfabriek->coke?></b> grams coke</td></tr>
<?
if($jouwfabriek->runner1 != '') {
?>
<tr><td class="mainTxt">Runner 1 Coke:</td><td class="mainTxt" colspan="2">Runner 1 has <b><?=$runner1->cokeverkoop?></b> grams of coke</td></tr>
<?
}
if($jouwfabriek->runner2 != '') {
?>
<tr><td class="mainTxt">Runner 2 Coke:</td><td class="mainTxt" colspan="2">Runner 2 has <b><?=$runner2->cokeverkoop?></b> grams of coke</td></tr>
<?
}
if($jouwfabriek->runner3 != '') {
?>
<tr><td class="mainTxt">Runner 3 Coke:</td><td class="mainTxt" colspan="2">Runner 3 has <b><?=$runner3->cokeverkoop?></b> grams of coke</td></tr>
<?
}
if($jouwfabriek->runner4 != '') {
?>
<tr><td class="mainTxt">Runner 4 Coke:</td><td class="mainTxt" colspan="2">Runner 4 has <b><?=$runner4->cokeverkoop?></b> grams of coke</td></tr>
<?
}
if($jouwfabriek->runner5 != '') {
?>
<tr><td class="mainTxt">Runner 5 Coke:</td><td class="mainTxt" colspan="2">Runner 5 has <b><?=$runner5->cokeverkoop?></b> grams of coke</td></tr>
<?
}
if($jouwfabriek->runner6 != '') {
?>
<tr><td class="mainTxt">Runner 6 Coke:</td><td class="mainTxt" colspan="2">Runner 6 has <b><?=$runner6->cokeverkoop?></b> grams of coke</td></tr>
<?
}
if($jouwfabriek->runner7 != '') {
?>
<tr><td class="mainTxt">Runner 7 Coke:</td><td class="mainTxt" colspan="2">Runner 7 has <b><?=$runner7->cokeverkoop?></b> grams of coke</td></tr>
<?
}
if($jouwfabriek->runner8 != '') {
?>
<tr><td class="mainTxt">Runner 8 Coke:</td><td class="mainTxt" colspan="2">Runner 8 has <b><?=$runner8->coke?></b> grams of coke</td></tr>
<?
}
?>
<tr><td class="subTitle" colspan="3">Producing Cocaine</td></tr>
<?
  if(isset($_POST['cokemaken'])) {
if($data->cash < 495000) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You dont have enough cash on you, you require <b>495.000</b>!</td></tr>";
} else {
mysql_query("UPDATE `[users]` SET `coketijd`=NOW(),`cash`=`cash`-350000 WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+1500 WHERE `owner`='{$data->login}'");
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have produced <b>1.500</b> grams of coke!<script language=\"javascript\">setTimeout('self.window.location.href=\"cokefactory.php\"',1200)</script></td></tr>";
}
}
?>
<tr><td class="mainTxt" colspan="3" align="center">You can produce <b>1500</b> grams of coke per hour, at a price of <b>495.000</b></td></tr>
<?
	$tijd2            = mysql_query("SELECT *,UNIX_TIMESTAMP(`coketijd`) AS `coketijd`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
	  $tijd1            = mysql_fetch_object($tijd2);
	$tijdverschil1        = $tijd1->coketijd-time(); 
	if($tijd1->coketijd + 3600 > time()){
   list($uur,$min,$sec)=explode(":",date("H:i:s",$tijdverschil1));
?>
<script type="text/javascript">
 <?echo 'var u='.$uur.';var m='.$min.';var s='.$sec.'+1;';?>
 function settimer(i){return (i>9)?i:"0"+i;}
 function timer(){s--;
 if((s==0)&&(m==0)&&(u==0)){document.getElementById('timeout').submit();}
 if((s==0)&&(m==0)&&(u!=0)){u--;m=59;}
 if((s==-1)&&(m!=0)){m--;s=59;}
 if(s>=0){document.getElementById('timer').value=settimer(u)+':'+settimer(m)+':'+settimer(s);}}
 setInterval("timer()",1000);
</script>
<tr><td class="mainTxt" colspan="3" align="center">When the timer reaches 15.00.00, you can produce another load of coke  -  <input style="border: 0px solid;" type="text" size="6" id="timer" value="<?=date("H:i:s",$tijd1->coketijd-time())?>"></td></tr>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt" colspan="3" align="center"><input class="btn btn-info" type="submit" name="cokemaken" value="Rub Some funk On it!"></td></tr>
</form>
<?
}
?>
<tr><td class="subTitle" colspan="3">Runners Invites/Dismissed</td></tr>
<?
  if(isset($_POST['runner1uitnodig'])) {
$controle2                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['runner1naam']}'");
$controle			= mysql_num_rows($controle2); 
$runner				= mysql_fetch_object($controle2);
$controle32                    	= mysql_query("SELECT * FROM `[runnertemp]` WHERE `runner`='{$_POST['runner1naam']}'");
$controle3			= mysql_num_rows($controle32); 
if($controle < 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner1naam']}</b> doesnt Exist!</td></tr>";
} else if($controle3 > 0) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner1naam']}</b> is already invited!</td></tr>";
} else if($runner->runner == 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner1naam']}</b> already works as a drug runner!</td></tr>";
} else if($runner->login == $data->login) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You cant invite yourself!</td></tr>";
} else {
mysql_query("INSERT INTO `[runnertemp]`(`owner`,`runner`,`nummer`,`land`) 
VALUES('".$data->login."','".$_POST['runner1naam']."','1','".$data->land."')"); 
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$_POST['runner1naam']."','Invitation','You have been invited by ".$data->login." to work at there Cocaine Factory. To accept the invitation, visit the Cocaine Factory and follow instructions. Decide promptly!<br><br> Do not reply to this message!')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have invited <b>{$_POST['runner1naam']}</b> to work in the factory. Your awaiting there reply.</td></tr>";
}
}

  if(isset($_POST['runner2uitnodig'])) {
$controle2                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['runner2naam']}'");
$controle			= mysql_num_rows($controle2); 
$runner				= mysql_fetch_object($controle2);
$controle32                    	= mysql_query("SELECT * FROM `[runnertemp]` WHERE `runner`='{$_POST['runner2naam']}'");
$controle3			= mysql_num_rows($controle32); 
if($controle < 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner2naam']}</b> doesnt exist!</td></tr>";
} else if($controle3 > 0) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner2naam']}</b> is already invited!</td></tr>";
} else if($runner->runner == 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner2naam']}</b> already works as a Drug Runner!</td></tr>";
} else if($runner->login == $data->login) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You cant invite yourself!</td></tr>";
} else {
mysql_query("INSERT INTO `[runnertemp]`(`owner`,`runner`,`nummer`,`land`) 
VALUES('".$data->login."','".$_POST['runner2naam']."','2','".$data->land."')"); 
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$_POST['runner2naam']."','Invitation','You have been invited by ".$data->login." to work at there Cocaine Factory. To accept the invitation, visit the Cocaine Factory and follow instructions. Decide promptly!<br><br> Do not reply to this message!')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have invited <b>{$_POST['runner2naam']}</b> to work in the factory. Your awaiting there reply.</td></tr>";
}
}

  if(isset($_POST['runner3uitnodig'])) {
$controle2                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['runner3naam']}'");
$controle			= mysql_num_rows($controle2); 
$runner				= mysql_fetch_object($controle2);
$controle32                    	= mysql_query("SELECT * FROM `[runnertemp]` WHERE `runner`='{$_POST['runner3naam']}'");
$controle3			= mysql_num_rows($controle32); 
if($controle < 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner3naam']}</b> doesnt exist!</td></tr>";
} else if($controle3 > 0) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner3naam']}</b> is already invited!</td></tr>";
} else if($runner->runner == 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner3naam']}</b> already works as a Drug Runner!</td></tr>";
} else if($runner->login == $data->login) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You cant invite yourself!</td></tr>";
} else {
mysql_query("INSERT INTO `[runnertemp]`(`owner`,`runner`,`nummer`,`land`) 
VALUES('".$data->login."','".$_POST['runner3naam']."','3','".$data->land."')"); 
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$_POST['runner3naam']."','Invitation','You have been invited by ".$data->login." to work at there Cocaine Factory. To accept the invitation, visit the Cocaine Factory and follow instructions. Decide promptly!<br><br> Do not reply to this message!')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have invited <b>{$_POST['runner3naam']}</b> to work in the factory. Your awaiting there reply.</td></tr>";
}
}

  if(isset($_POST['runner4uitnodig'])) {
$controle2                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['runner4naam']}'");
$controle			= mysql_num_rows($controle2); 
$runner				= mysql_fetch_object($controle2);
$controle32                    	= mysql_query("SELECT * FROM `[runnertemp]` WHERE `runner`='{$_POST['runner4naam']}'");
$controle3			= mysql_num_rows($controle32); 
if($controle < 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner4naam']}</b> doesnt exist!</td></tr>";
} else if($controle3 > 0) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner4naam']}</b> is already invited!</td></tr>";
} else if($runner->runner == 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner4naam']}</b> already works as a Drug Runner!</td></tr>";
} else if($runner->login == $data->login) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You cant invite yourself!</td></tr>";
} else {
mysql_query("INSERT INTO `[runnertemp]`(`owner`,`runner`,`nummer`,`land`) 
VALUES('".$data->login."','".$_POST['runner4naam']."','4','".$data->land."')"); 
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$_POST['runner4naam']."','Invitation','You have been invited by ".$data->login." to work at there Cocaine Factory. To accept the invitation, visit the Cocaine Factory and follow instructions. Decide promptly!<br><br> Do not reply to this message!')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have invited <b>{$_POST['runner4naam']}</b> to work in the factory. Your awaiting there reply.</td></tr>";
}
}

  if(isset($_POST['runner5uitnodig'])) {
$controle2                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['runner5naam']}'");
$controle			= mysql_num_rows($controle2); 
$runner				= mysql_fetch_object($controle2);
$controle32                    	= mysql_query("SELECT * FROM `[runnertemp]` WHERE `runner`='{$_POST['runner5naam']}'");
$controle3			= mysql_num_rows($controle32); 
if($controle < 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner5naam']}</b> doesnt exist!</td></tr>";
} else if($controle3 > 0) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner5naam']}</b> is already invited!</td></tr>";
} else if($runner->runner == 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner5naam']}</b> already works as a Drug Runner!</td></tr>";
} else if($runner->login == $data->login) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You cant invite yourself!</td></tr>";
} else {
mysql_query("INSERT INTO `[runnertemp]`(`owner`,`runner`,`nummer`,`land`) 
VALUES('".$data->login."','".$_POST['runner5naam']."','5','".$data->land."')"); 
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$_POST['runner5naam']."','Invitation','You have been invited by ".$data->login." to work at there Cocaine Factory. To accept the invitation, visit the Cocaine Factory and follow instructions. Decide promptly!<br><br> Do not reply to this message!')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have invited <b>{$_POST['runner5naam']}</b> to work in the factory. Your awaiting there reply.</td></tr>";
}
}

  if(isset($_POST['runner6uitnodig'])) {
$controle2                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['runner6naam']}'");
$controle			= mysql_num_rows($controle2); 
$runner				= mysql_fetch_object($controle2);
$controle32                    	= mysql_query("SELECT * FROM `[runnertemp]` WHERE `runner`='{$_POST['runner6naam']}'");
$controle3			= mysql_num_rows($controle32); 
if($controle < 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner6naam']}</b> doesnt exist!</td></tr>";
} else if($controle3 > 0) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner6naam']}</b> is already invited!</td></tr>";
} else if($runner->runner == 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner6naam']}</b> already works as a Drug Runner!</td></tr>";
} else if($runner->login == $data->login) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You cant invite yourself!</td></tr>";
} else {
mysql_query("INSERT INTO `[runnertemp]`(`owner`,`runner`,`nummer`,`land`) 
VALUES('".$data->login."','".$_POST['runner6naam']."','6','".$data->land."')"); 
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$_POST['runner6naam']."','Invitation','You have been invited by ".$data->login." to work at there Cocaine Factory. To accept the invitation, visit the Cocaine Factory and follow instructions. Decide promptly!<br><br> Do not reply to this message!')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have invited <b>{$_POST['runner6naam']}</b> to work in the factory. Your awaiting there reply.</td></tr>";
}
}

  if(isset($_POST['runner7uitnodig'])) {
$controle2                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['runner7naam']}'");
$controle			= mysql_num_rows($controle2); 
$runner				= mysql_fetch_object($controle2);
$controle32                    	= mysql_query("SELECT * FROM `[runnertemp]` WHERE `runner`='{$_POST['runner7naam']}'");
$controle3			= mysql_num_rows($controle32); 
if($controle < 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner7naam']}</b> doesnt exist!</td></tr>";
} else if($controle3 > 0) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner7naam']}</b> is already invited!</td></tr>";
} else if($runner->runner == 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner7naam']}</b> already works as a Drug Runner!</td></tr>";
} else if($runner->login == $data->login) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You cant invite yourself!</td></tr>";
} else {
mysql_query("INSERT INTO `[runnertemp]`(`owner`,`runner`,`nummer`,`land`) 
VALUES('".$data->login."','".$_POST['runner7naam']."','7','".$data->land."')"); 
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$_POST['runner7naam']."','Invitation','You have been invited by ".$data->login." to work at there Cocaine Factory. To accept the invitation, visit the Cocaine Factory and follow instructions. Decide promptly!<br><br> Do not reply to this message!')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have invited <b>{$_POST['runner7naam']}</b> to work in the factory. Your awaiting there reply.</td></tr>";
}
}

  if(isset($_POST['runner8uitnodig'])) {
$controle2                    	= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['runner8naam']}'");
$controle			= mysql_num_rows($controle2); 
$runner				= mysql_fetch_object($controle2);
$controle32                    	= mysql_query("SELECT * FROM `[runnertemp]` WHERE `runner`='{$_POST['runner8naam']}'");
$controle3			= mysql_num_rows($controle32); 
if($controle < 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner8naam']}</b> doesnt exist!</td></tr>";
} else if($controle3 > 0) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner8naam']}</b> is already invited!</td></tr>";
} else if($runner->runner == 1) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\"><b>{$_POST['runner8naam']}</b> already works as a Drug Runner!</td></tr>";
} else if($runner->login == $data->login) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You cant invite yourself!</td></tr>";
} else {
mysql_query("INSERT INTO `[runnertemp]`(`owner`,`runner`,`nummer`,`land`) 
VALUES('".$data->login."','".$_POST['runner8naam']."','8','".$data->land."')"); 
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$_POST['runner8naam']."','Invitation','You have been invited by ".$data->login." to work at there Cocaine Factory. To accept the invitation, visit the Cocaine Factory and follow instructions. Decide promptly!<br><br> Do not reply to this message!')"); 
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have invited <b>{$_POST['runner8naam']}</b> to work in the factory. Your awaiting there reply.</td></tr>";
}
}

  if(isset($_POST['ontslarunner1'])) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have Fired <b>{$jouwfabriek->runner1}</b>.</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+$runner1->cokeverkoop WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='0',`cokeverkoop`='0' WHERE `login`='{$jouwfabriek->runner1}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$jouwfabriek->runner1."','Fired!','You are no longer a Drug Runner, you have been fired!.')");
mysql_query("UPDATE `[cokefabriek]` SET `runner1`='' WHERE `owner`='{$data->login}'");
}
  if(isset($_POST['ontslarunner2'])) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have Fired <b>{$jouwfabriek->runner2}</b>.</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+$runner2->cokeverkoop WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='0',`cokeverkoop`='0' WHERE `login`='{$jouwfabriek->runner2}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$jouwfabriek->runner2."','Fired!','You are no longer a Drug Runner, you have been fired!.')");
mysql_query("UPDATE `[cokefabriek]` SET `runner2`='' WHERE `owner`='{$data->login}'");
}
  if(isset($_POST['ontslarunner3'])) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have Fired <b>{$jouwfabriek->runner3}</b>.</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+$runner3->cokeverkoop WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='0',`cokeverkoop`='0' WHERE `login`='{$jouwfabriek->runner3}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$jouwfabriek->runner3."','Fired!','You are no longer a Drug Runner, you have been fired!.')");
mysql_query("UPDATE `[cokefabriek]` SET `runner3`='' WHERE `owner`='{$data->login}'");
}
  if(isset($_POST['ontslarunner4'])) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have Fired <b>{$jouwfabriek->runner4}</b>.</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+`$runner4->cokeverkoop WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='0',`cokeverkoop`='0' WHERE `login`='{$jouwfabriek->runner4}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$jouwfabriek->runner4."','Fired!','You are no longer a Drug Runner, you have been fired!.')");
mysql_query("UPDATE `[cokefabriek]` SET `runner4`='' WHERE `owner`='{$data->login}'");
}
  if(isset($_POST['ontslarunner5'])) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have Fired <b>{$jouwfabriek->runner5}</b>.</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+$runner5->cokeverkoop WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='0',`cokeverkoop`='0' WHERE `login`='{$jouwfabriek->runner5}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$jouwfabriek->runner5."','Fired!','You are no longer a Drug Runner, you have been fired!.')");
mysql_query("UPDATE `[cokefabriek]` SET `runner5`='' WHERE `owner`='{$data->login}'");
}
  if(isset($_POST['ontslarunner6'])) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have Fired <b>{$jouwfabriek->runner6}</b>.</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+$runner6->cokeverkoop WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='0',`cokeverkoop`='0' WHERE `login`='{$jouwfabriek->runner6}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$jouwfabriek->runner6."','Fired!','You are no longer a Drug Runner, you have been fired!.')");
mysql_query("UPDATE `[cokefabriek]` SET `runner6`='' WHERE `owner`='{$data->login}'");
}
  if(isset($_POST['ontslarunner7'])) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have Fired <b>{$jouwfabriek->runner7}</b>.</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+$runner7->cokeverkoop WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='0',`cokeverkoop`='0' WHERE `login`='{$jouwfabriek->runner7}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$jouwfabriek->runner7."','Fired!','You are no longer a Drug Runner, you have been fired!.')");
mysql_query("UPDATE `[cokefabriek]` SET `runner7`='' WHERE `owner`='{$data->login}'");
}
  if(isset($_POST['ontslarunner8'])) {
print"<tr><td class=\"mainTxt\" align=\"center\" colspan=\"4\">You have Fired <b>{$jouwfabriek->runner8}</b>.</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+$runner8->cokeverkoop WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `runner`='0',`cokeverkoop`='0' WHERE `login`='{$jouwfabriek->runner8}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$jouwfabriek->runner8."','Fired!','You are no longer a Drug Runner, you have been fired!.')");
mysql_query("UPDATE `[cokefabriek]` SET `runner8`='' WHERE `owner`='{$data->login}'");
}
?>
<tr><td class="mainTxt" colspan="3">Here you can Invite and Fire employees</td></tr>
<?
if($jouwfabriek->runner1 == '') {
?>
<form method="POST">
<tr><td class="mainTxt" width="28%">Runner 1 Invite</td><td class="mainTxt" width="44%">Name: <input type="text" class="btn btn-info" name="runner1naam"></td><td class="mainTxt" width="28%" align="center"><input class="2" type="submit" name="runner1uitnodig" value="Employ"></td></tr>
</form>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt">Runner 1:</td><td class="mainTxt"><?=$jouwfabriek->runner1?></td><td class="mainTxt" align="center"><input class="btn btn-info" type="submit" name="ontslarunner1" value="DISMISS!"></td></tr>
</form>
<?
}
if($jouwfabriek->runner2 == '') {
?>
<form method="POST">
<tr><td class="mainTxt" width="28%">Runner 2 Invite</td><td class="mainTxt" width="44%">Name: <input type="text" name="runner2naam"></td><td class="mainTxt" width="28%" align="center"><input class="2" type="submit" name="runner2uitnodig" value="Employ"></td></tr>
</form>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt">Runner 2:</td><td class="mainTxt"><?=$jouwfabriek->runner2?></td><td class="mainTxt" align="center"><input class="2" type="submit" class="btn btn-info" name="ontslarunner2" value="DISMISS!"></td></tr>
</form>
<?
}
if($jouwfabriek->runner3 == '') {
?>
<form method="POST">
<tr><td class="mainTxt" width="28%">Runner 3 Invite</td><td class="mainTxt" width="44%">Name: <input type="text" name="runner3naam"></td><td class="mainTxt" width="28%" align="center"><input class="2" type="submit" name="runner3uitnodig" value="Employ"></td></tr>
</form>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt">Runner 3:</td><td class="mainTxt"><?=$jouwfabriek->runner3?></td><td class="mainTxt" align="center"><input type="submit" class="btn btn-info" name="ontslarunner3" value="DISMISS!"></td></tr>
</form>
<?
}
if($jouwfabriek->runner4 == '') {
?>
<form method="POST">
<tr><td class="mainTxt" width="28%">Runner 4 Invite</td><td class="mainTxt" width="44%">Name: <input type="text" name="runner4naam"></td><td class="mainTxt" width="28%" align="center"><input class="btn btn-info" type="submit" name="runner4uitnodig" value="Employ"></td></tr>
</form>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt">Runner 4:</td><td class="mainTxt"><?=$jouwfabriek->runner4?></td><td class="mainTxt" align="center"><input class="btn btn-info" type="submit" name="ontslarunner4" value="DISMISS!"></td></tr>
</form>
<?
}
if($jouwfabriek->runner5 == '') {
?>
<form method="POST">
<tr><td class="mainTxt" width="28%">Runner 5 Invite</td><td class="mainTxt" width="44%">Name: <input type="text" name="runner5naam"></td><td class="mainTxt" width="28%" align="center"><input class="btn btn-info" type="submit" name="runner5uitnodig" value="Employ"></td></tr>
</form>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt">Runner 5:</td><td class="mainTxt"><?=$jouwfabriek->runner5?></td><td class="mainTxt" align="center"><input class="btn btn-info" type="submit" name="ontslarunner5" value="DISMISS!"></td></tr>
</form>
<?
}
if($jouwfabriek->runner6 == '') {
?>
<form method="POST">
<tr><td class="mainTxt" width="28%">Runner 6 Invite</td><td class="mainTxt" width="44%">Name: <input type="text" name="runner6naam"></td><td class="mainTxt" width="28%" align="center"><input class="btn btn-info" type="submit" name="runner6uitnodig" value="Employ"></td></tr>
</form>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt">Runner 6:</td><td class="mainTxt"><?=$jouwfabriek->runner6?></td><td class="mainTxt" align="center"><input class="btn btn-info" type="submit" name="ontslarunner6" value="DISMISS!"></td></tr>
</form>
<?
}
if($jouwfabriek->runner7 == '') {
?>
<form method="POST">
<tr><td class="mainTxt" width="28%">Runner 7 Invite</td><td class="mainTxt" width="44%">Name: <input type="text" name="runner7naam"></td><td class="mainTxt" width="28%" align="center"><input class="btn btn-info" type="submit" name="runner7uitnodig" value="Employ"></td></tr>
</form>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt">Runner 7:</td><td class="mainTxt"><?=$jouwfabriek->runner7?></td><td class="mainTxt" align="center"><input class="btn btn-info" type="submit" name="ontslarunner7" value="DISMISS!"></td></tr>
</form>
<?
}
if($jouwfabriek->runner8 == '') {
?>
<form method="POST">
<tr><td class="mainTxt" width="28%">Runner 8 Invite</td><td class="mainTxt" width="44%">Name: <input type="text" name="runner8naam"></td><td class="mainTxt" width="28%" align="center"><input class="btn btn-info" type="submit" name="runner8uitnodig" value="Employ"></td></tr>
</form>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt">Runner 8:</td><td class="mainTxt"><?=$jouwfabriek->runner8?></td><td class="mainTxt" align="center"><input class="btn btn-info" type="submit" name="ontslarunner8" value="DISMISS!"></td></tr>
</form>
<?
}
?>
<tr><td class="subTitle" colspan="3">Distribute Cocaine</td></tr>
<tr><td class="mainTxt" colspan="3">Here you can distribute your coke to your Drug Runners</td></tr>
<form method="POST">
<tr><td class="mainTxt">
<select style="width: 100;" name="runner">
<?
if($jouwfabriek->runner1 != '') {
?>
<option value="1">Runner1</option>
<?
}
?>
<?
if($jouwfabriek->runner2 != '') {
?>
<option value="2">Runner2</option>
<?
}
?>
<?
if($jouwfabriek->runner3 != '') {
?>
<option value="3">Runner3</option>
<?
}
?>
<?
if($jouwfabriek->runner4 != '') {
?>
<option value="4">Runner4</option>
<?
}
?>
<?
if($jouwfabriek->runner5 != '') {
?>
<option value="5">Runner5</option>
<?
}
?>
<?
if($jouwfabriek->runner6 != '') {
?>
<option value="6">Runner6</option>
<?
}
?>
<?
if($jouwfabriek->runner7 != '') {
?>
<option value="7">Runner7</option>
<?
}
?>
<?
if($jouwfabriek->runner8 != '') {
?>
<option value="8">Runner8</option>
<?
}
?>
</select>
</td><td class="mainTxt">Number of grams: <input type="text" class="btn btn-info" name="aantalgram"></td><td class="mainTxt"><input class="btn btn-info" type="submit" name="geef" value="Distribute"></td></tr>
</form>
<?
  if(isset($_POST['geef'])) {
if($_POST['runner'] == 1) {
$wie = runner1;
} if($_POST['runner'] == 2) {
$wie = runner2;
} if($_POST['runner'] == 3) {
$wie = runner3;
} if($_POST['runner'] == 4) {
$wie = runner4;
} if($_POST['runner'] == 5) {
$wie = runner5;
} if($_POST['runner'] == 6) {
$wie = runner6;
} if($_POST['runner'] == 7) {
$wie = runner7;
} if($_POST['runner'] == 8) {
$wie = runner8;
}
if($jouwfabriek->coke < $_POST['aantalgram']) {
print"<tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You You dont have that much cocaine!</td></tr>";
} else if($_POST['aantalgram'] <= 0) {
print"<tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You can give a minimum of 1 gram!</td></tr>";
} else if(!preg_match('/^[0-9]{1,15}$/',$_POST['aantalgram'])) {
print"<tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">Numbers Only.</td></tr>";
} else {
print"<tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have distributed <b>{$_POST['aantalgram']}</b> grams of coke to <b>{$jouwfabriek->$wie}</b>.<script language=\"javascript\">setTimeout('self.window.location.href=\"cokefactory.php\"',1000)</script></td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`-'{$_POST['aantalgram']}' WHERE `owner`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `cokeverkoop`=`cokeverkoop`+'{$_POST['aantalgram']}' WHERE `login`='{$jouwfabriek->$wie}'");
}
}
?>
</table> 
<?
} else if($data->cokefabriek == 1 AND $data->land != $jouwfabriek->land) {
?>
<table align="center" width="80%">
<tr><td class="mainTxt" align="center"></b>!</td></tr>
</table>
<?
}
if($data->runner >= 1) {
$getal = $data->runner;

$runnerfabrdb				= mysql_query("SELECT * FROM `[cokefabriek]` WHERE `runner{$getal}`='{$data->login}'");
$runnerfabr				= mysql_fetch_object($runnerfabrdb);

?>
<table align="center" width="80%">
<tr><td class="subTitle">Drug Runner</td></tr>
<tr><td class="mainTxt">You are a runner for <b><?=$runnerfabr->owner?></b></td></tr>
<tr><td class="mainTxt">Currently you have <b><?=$data->cokeverkoop?></b> grams of coke to deal. You receive ;200 per gram, and your boss[<?=$runnerfabr->owner?>] receives ;500.<br><br> You can deal <b>3000</b> grams maximum, per hour.<br><br> From 3000 Grams you will make ;600,000!</td></tr>
<?
	$tijd3            = mysql_query("SELECT *,UNIX_TIMESTAMP(`verkooptijd`) AS `verkooptijd`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
	  $tijd3            = mysql_fetch_object($tijd4);
	$tijdverschil3        = $tijd3->coketijd-time(); 
	if($tijd3->verkooptijd + 3600 > time()){
   list($uur2,$min2,$sec2)=explode(":",date("H:i:s",$tijdverschil3));
?>
<script type="text/javascript">
 <?echo 'var u='.$uur2.';var m='.$min2.';var s='.$sec2.'+1;';?>
 function settimer(i){return (i>9)?i:"0"+i;}
 function timer(){s--;
 if((s==0)&&(m==0)&&(u==0)){document.getElementById('timeout').submit();}
 if((s==0)&&(m==0)&&(u!=0)){u--;m=59;}
 if((s==-1)&&(m!=0)){m--;s=59;}
 if(s>=0){document.getElementById('timer2').value=settimer(u)+':'+settimer(m)+':'+settimer(s);}}
 setInterval("timer()",1000);
</script>
<tr><td class="mainTxt" colspan="3" align="center">When the timer reaches 15.00.00, you can start selling more coke!  -  <input style="border: 0px solid;" type="text" size="6" id="timer2" value="<?=date("H:i:s",$tijd3->verkooptijd-time())?>">.</td></tr>
<?
} else {
?>
<form method="POST">
<tr><td class="mainTxt" colspan="3" align="center"><input class="btn btn-info" type="submit" name="verkoopcoke" value="Deal YO"></td></tr>
</form>
<?
}
  if(isset($_POST['verkoopcoke'])) {
$winst12 = $data->cokeverkoop*200;
$winst22 = $data->cokeverkoop*500;

$winst1 = number_format($winst12, 0, '.' , '.');
$winst2 = number_format($winst22, 0, '.' , '.');

if($data->cokeverkoop == 0) {
print"<tr><td class=\"mainTxt\" align=\"center\">You dont have any coke to sell!</td></tr>";
} else if($data->cokeverkoop <= 3000) {
mysql_query("UPDATE `[users]` SET `verkooptijd`=NOW(),`cokeverkoop`='0',`cash`=`cash`+$winst12 WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+$winst22 WHERE `login`='{$runnerfabr->owner}'");
print"<tr><td class=\"mainTxt\" align=\"center\">You have managed to deal some coke. You received <b>{$winst1}</b> profit, which is put directly into the bank. You made your boss[<?=$runnerfabr->owner?>] <b>{$winst2}</b> profit!</td></tr>";

} else if($data->cokeverkoop > 3000) {
mysql_query("UPDATE `[users]` SET `verkooptijd`=NOW(),`cokeverkoop`=`cokeverkoop`-3000,`bank`=`bank`+600000 WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `bank`=`bank`+1500000 WHERE `login`='{$runnerfabr->owner}'");
print"<tr><td class=\"mainTxt\" align=\"center\">You have sold 3000 grams of coke this hour. Which has given you <b>600.000</b>, which is put into the bank, and you made your boss[<?=$runnerfabr->owner?>]  <b>1.500.000</b>!</td></tr>";
}
}
?>
<form method="POST">
<tr><td class="mainTxt">Do you want to quit? <input class="btn btn-info" type="submit" name="neemontslag" value="QUIT!"></td></tr>
</form>
<?
  if(isset($_POST['neemontslag'])) {
print"<tr><td class=\"mainTxt\" align=\"center\">You have quit your job as a Drug Runner, you are no longer associated with cocaine dealing.... Just murdering, stealing and so on...</td></tr>";
mysql_query("UPDATE `[cokefabriek]` SET `runner{$data->runner}`='' WHERE `owner`='{$runnerfabr->owner}'");
mysql_query("UPDATE `[cokefabriek]` SET `coke`=`coke`+$data->cokeverkoop WHERE `owner`='{$runnerfabr->owner}'");
mysql_query("UPDATE `[users]` SET `runner2`='0',`cokeverkoop`='0' WHERE `login`='{$data->login}'");
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'Auto Message','".$runnerfabr->owner."','Worker Quit','".$data->login." has quit as one of your employee drug runners.')");
}



?>
</table>
<?
}
?>













































































</body>
</html>