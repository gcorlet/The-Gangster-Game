<?php
error_reporting(0);

  $OMNILOG				= 1;
  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>

<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">


</head>

<table align="center" width=100%>
  <tr><td class="subTitle"><b>Crack the Safe - VIP Credits </b></td></tr>
 
<?php
  $dbres				= mysql_query("SELECT * FROM `[kraakkluis]` WHERE `area`='2' ");
    $gok				= mysql_fetch_object($dbres);



  if(isset($_POST['submit'])  && preg_match('/^[0-9]+$/',$_POST['code'])) {
 $dbres				= mysql_query("SELECT * FROM `[kraaknr]` WHERE `login`='{$data->login}' AND `area`='2' AND FLOOR(UNIX_TIMESTAMP(`time`)/(60*60*24))=FLOOR(UNIX_TIMESTAMP(NOW())/(60*60*24))");
$num = mysql_num_rows($dbres);
$code				= $_POST['code'];
$code2 = $gok->code;

if($data->belcredits < 10){
print"<tr><td class=\"mainTxt\">You dont have 10 VIP Credits";
}
else if($num >=5){
print"<tr><td class=\"mainTxt\">You have already tried to crack this code 5 times today.";
}
else if($code >= 100){
print"<tr><td class=\"mainTxt\">The code is to high";
}
else if($code <= -1){
print"<tr><td class=\"mainTxt\">The code is to low";
}

else if($code == $code2){
        $data->belcredit			+= $gok->kluis;
$code = rand(0,99);
  
       mysql_query("UPDATE `[users]` SET `belcredits`={$data->belcredits} WHERE `login`='{$_SESSION['login']}'");      
                     mysql_query("UPDATE `[kraakkluis]` SET `kluis`='5000',`code`='$code',`winnaar`='$data->login' WHERE `area`='2'");
 mysql_query("DELETE FROM `[kraaknr]` WHERE `area`='2'");
print"<tr><td class=\"mainTxt\">You cracked the code!";
}
else{

            $data->belcredit			- 10;
           mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-10 WHERE `login`='{$_SESSION['login']}'");
            mysql_query("UPDATE `[kraakkluis]` SET `kluis`=`kluis`+'10' WHERE `area`='2'");
    mysql_query("INSERT INTO `[kraaknr]` (time,login,getal,area) VALUES (NOW(),'$data->login', '$code','2')");


print"<tr><td class=\"mainTxt\">You got the wrong code!";
}
}
$dbres				= mysql_query("SELECT * FROM `[kraaknr]` WHERE `login`='{$data->login}'  AND FLOOR(UNIX_TIMESTAMP(`time`)/(60*60*24))=FLOOR(UNIX_TIMESTAMP(NOW())/(60*60*24))");
$num = mysql_num_rows($dbres);
 $time2 = time()+105400;
$time = date("Y-m-d", "$time2");
   print <<<ENDHTML
 <tr><td class="mainTxt"><center>
The object of 'Crack the Safe'... Well the name explanes it all.<br>
You have to guess a number between 0-99 and try to see if it cracks the safe.<br>
It costs 10 VIP Credits each guess, but you will receive the contents of the safe if you guess correctly.<br>
The Contents of the safe is ' $gok->kluis ' VIP Credits.
<br>
<br>
You have a maximum of 5 attempts each day!
<br>
<br>
The last winner was $gok->winnaar.<br>
You have attempted to crack the safe <b>$num X </b> today.
<br>
  </td></tr>
 <tr><td class="mainTxt"><center>	<form method="POST">
Code (0-99): <input type="text" name="code" size=2 maxlength=2 >
				<input type="button" onClick="document.forms[0].elements[0].value = Math.round(Math.random()*98+1);" value="Random">

<br><input type="submit" name="submit" value="Crack" style="width: 75px;"></form>
  </td></tr>
</table>
ENDHTML;
print " <table width=100%>  <tr><td class=\"subTitle\"><b>Last 25 attempts</b></td></tr></table>\n";
 print "  <table width=100%> <tr><td class=\"subTitle\" style=\"letter-spacing: normal;\">User</td>  <td class=\"subTitle\" style=\"letter-spacing: normal;\">Attempted Code</td></tr>\n";
 
  $dbres				= mysql_query("SELECT * FROM `[kraaknr]` WHERE `area`='2' ORDER BY `time` DESC LIMIT 0,25");
    while($info = mysql_fetch_object($dbres)) {

     
  print <<<ENDHTML

<td class="mainTxt"><a href="profile.php?x={$info->login}">{$info->login}</a></td>
	<td width=100 class="mainTxt" align="center">{$info->getal}</td></tr>
ENDHTML;
}
?>
</body>


</html>

</html>
<?php mysql_close(); ?>