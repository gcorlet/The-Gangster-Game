<?php
error_reporting(0);

  include('_include-config.php');
 
  if(! check_login()) {
    header('Location: login.php');
    exit;
  }

?>

<html>
<head>
<title></title>

</head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</td>
</td>
<table width="85%" align="center">
</td></tr>
</table>

<?PHP

if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`=0 where `login`='$data->login'");
exit;
}

?>
<?PHP
if($_GET['x'] == 'credits') {








}

$gegevens = mysql_query("SELECT * FROM `[extra]` WHERE  `name`='clanbank'  ") or die(mysql_error()); 
while($rij = mysql_fetch_object($gegevens)) { 
$clanbank	=	$rij->waarde;
}

$gegevens = mysql_query("SELECT * FROM `[extra]` WHERE  `name`='bank'  ") or die(mysql_error()); 
while($rij = mysql_fetch_object($gegevens)) { 
$bank	=	$rij->waarde;
}


$gegevens = mysql_query("SELECT * FROM `[extra]` WHERE  `name`='banken'  ") or die(mysql_error()); 
while($rij = mysql_fetch_object($gegevens)) { 
$banken	=	$rij->waarde;
}

$gegevens = mysql_query("SELECT * FROM `[extra]` WHERE  `name`='powerb'  ") or die(mysql_error()); 
while($rij = mysql_fetch_object($gegevens)) { 
$powerb	=	$rij->waarde;
}

$gegevens = mysql_query("SELECT * FROM `[extra]` WHERE  `name`='energiecentrales'  ") or die(mysql_error()); 
while($rij = mysql_fetch_object($gegevens)) { 
$energiecentrales	=	$rij->waarde;
}
?>
<form method="post" action="creditshop.php" name="f">
<table width="85%" align="center">
  <tr><td class=subTitle colspan=3><b>Spend GIX Credits</b></td></tr>
  <tr><td class=mainTxt>
<tr>
<td class=subTitle width=20>&nbsp;#</td><td class=subTitle width="208"><b>Options</b></td>
<td class=subTitle width="199">
<b>GIX Credits</b></td>
</tr>
	<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="geld"></td>
<td class=mainTxt width="208">&#8364;<? print"$bank";?> Bank Cash</td><td class=mainTxt width="199">Cost 
250 Credits</td>
	</tr>
<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="clangeld"></td>
<td class=mainTxt width="208">&#8364;<? print"$clanbank";?> Gang bank cash <i>(Gang)</i></td><td class=mainTxt width="199">cost 
250 Credits</td>
</tr>

<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="centrales"></td>
<td class=mainTxt width="208"><? print"$energiecentrales";?> Power Stations <i>(Gang)</i></td>
<td class=mainTxt width="199">Cost 200 Credits</td>
</tr>

<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="clanbes"></td>
<td class=mainTxt width="208"> 24 Hour Gang Protection <i>(Gang)</i></td>
<td class=mainTxt width="199">Cost 200 Credits</td>
</tr>

<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="kogels"></td>
<td class=mainTxt width="208">1500 Bullets <i></i></td>
<td class=mainTxt width="199">Cost 50 Credits</td>
</tr>

<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="bankuh"></td>
<td class=mainTxt width="208"><? print"$banken";?> Extra Bank Turns <i>!</i></td>
<td class=mainTxt width="199">Cost 100 Credits</td>
</tr>

<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="powerb"></td>
<td class=mainTxt width="208"><? print"$powerb";?> Attack and Defence <i>!</i></td>
<td class=mainTxt width="199">Cost 300 VIP Credits</td>
</tr>




<tr>
<td colspan=2 class=mainTxt><b>Current Credits:</b> <? echo $data->belcredits ?></td>
<td align=right class=mainTxt width="199">
<p align="left">Ammount<input type=input value="0" size=3 name="bieden">x
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=submit value="Buy" name="submit">

</tr></td><table width="85%" align="center">
  <?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "geld") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 250*$_POST['bieden'];
           $genoeg = 100*$wtf;
           $land = $bank;
           $wtf = $_POST['bieden'];
           $landz = $land*$_POST['bieden'];
           $belcredits = $data->belcredits;
           $kost1 = $kost*1;
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to purchase this?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
$insert = "UPDATE `[users]` SET `bank`=`bank`+'$landz',`belcredits`=`belcredits`-'$kost1'  WHERE `login`='$data->login'";
$insert_now = mysql_query($insert) or die("FOUT in query ");
$landz = $bieden*1;
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>&#8364;$bank</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
if($_POST['gebruik'] == "powerb") {
           $bieden = $_POST['bieden'];
           $kost = 300;
           $land = $powerb;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";


if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough VIP Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to purchase this?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query ("UPDATE `[users]` SET `attack`=`attack`+'$landz'  WHERE `login`='$data->login'");
$insert = "UPDATE `[users]` SET `defence`=`defence`+'$landz'  WHERE `login`='$data->login'";
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");


$insert_now = mysql_query($insert) or die("FOUT in query ");
$landz = $bieden*1;
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>$bieden</b> X <b>$powerb</b>attack and defence  <br></td></tr>\n";
}
}
?>

<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "clangeld") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 250;
           $land = $clanbank;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough VIP Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($data->clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your not in a gang!</td></tr>\n";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[clans]` SET `bank`=`bank`+$landz WHERE `name`='$data->clan'");
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>&#8364;$clanbank clan geld</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>

<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "kogels") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 50;
           $land = 500;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `kogels`=`kogels`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>500 Bullets</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
?>


<?PHP
if (isset($_POST['gebruik'])) {
if($_POST['gebruik'] == "bankuh") {
if($amount > 0 && preg_match('/^[0-9]{1,15}$/',$_POST['banken'])) {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 200;
           $land = $banken;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough VIP Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `bankleft`=`bankleft`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>$bankenx extra banks</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
}
?>

<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "maffia") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 100;
           $land = 1;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough VIP Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">DO you want to buy this?</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
if($bieden > 1) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Max. 1 hour behind eachother</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `maffiamode`=1, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your under Mafia Protection!<br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "drugs") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 50;
           $land = 1500;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough VIP Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `drugspower`=`drugspower`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>1500 Drugs Power</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "bankuh") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 100;
           $land = $banken;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this??</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `bankleft`=`bankleft`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>$banken bank turns</b> <b>$bieden</b>x  <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "bankmax") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 100;
           $land = $extra;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `bankmax`=`bankmax`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>$extra extra transfer turns</b> <b>$bieden</b>x  <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "centrales") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 200;
           $land = $energiecentrales;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your not in a Gang!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
$bied= $bieden*$energiecentrales;
mysql_query("INSERT INTO `[clanlogs]` (`datum`,`wie`,`waar`,`wat`,`hoeveel`) values(NOW(),'$data->login','{$data->clan}','belcen','$bied')");

mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `centrale`=`centrale`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>$energiecentrales Centrals</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "boor") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 750;
           $land = 20;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your not in a Gang!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl9`=`money_lvl9`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>20 Islands</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "boor") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 25000;
           $land = 250;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your not in a Gang!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimmum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl9`=`money_lvl9`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>250 Islands</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
?>

<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "energie") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 1000;
           $land = 20;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your not in a gang!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl10`=`money_lvl10`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>20 Energy Factories</b> <b>$bieden</b>x  <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "energie2") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 2500;
           $land = 50;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your not in a gang!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl10`=`money_lvl10`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>50 energy factories</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "geldbanken") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 100;
           $land = $banken;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
mysql_query("UPDATE `[users]` SET `bankmax`=`bankmax`-'$kost1' WHERE `login`='$data->login'");
print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>$banken extra bank turns</b> <b>$bieden</b>x  <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "clanbes") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 300;
           $land = 1;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
           $dbres = mysql_query("SELECT `name`,`info`,UNIX_TIMESTAMP(`started`) AS `started` FROM `[clans]` WHERE `name`='{$data->clan}'");
           $clan                                      = mysql_fetch_object($dbres);
           $protection                                = round($clan->started/3600-time()/3600) + 24;

if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>Error</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy this?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your not in a Gang!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden > 1) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 1 each time..</td></tr>\n";
exit;
}
if($protection > 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Your Gang is already under protection.</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `started`=`started`=NOW() WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>24 hour Gang Protection</b><br></td></tr>\n";
}
}
}
?>