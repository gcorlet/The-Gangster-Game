<html>
<head>
<title>The Gangster Game</title>
<link rel="stylesheet" type="text/css" href="css.css">
</head>
<body bgcolor=black>
  <tr><td class="subTitle"><a name="crimtype"><b><font color="white">Criminal Types</font></b></a></td></tr>
  <tr><td class="mainTxt">

<br><br><font color="white"><b>
There are 30 Different Types of Criminal People to choose from. There is a special bonus with each type.</b></font><br><br>
<font color="white"><b>Firstly You might pick a criminal with a bonus in Attack and another may have a bonus in Defence.</b></font><br>
<br>
<br>
<font color="red">
The following Criminal Types are equiped with an Attack bonus from the start:</font><br>
<br>
<font color="red">Thug </font><br>
<font color="red">Officer</font><br>
<font color="red">Hired Gun</font><br>
<font color="red">Hustler</font><br>
<font color="red">Original Gangster</font><br>
<font color="red">Peacekeeper</font><br>
<font color="red">Gangster Bitch</font><br>
<font color="red">Hoodie</font><br>
<font color="red">Lady Bitch</font><br>
<font color="red">Avenger</font><br>
<font color="red">Capone</font><br>
<font color="red">PIMP</font><br>
<font color="red">WiseGuy</font><br>
<font color="red">Fella</font><br>
<font color="red">The Daddy</font><br>

<br>
<br>
<font color="orange">
The following Criminal Types are equiped with a Defence bonus from the start:</font><br>
<br>
<font color="orange">Drugdealer</font><br>
<font color="orange">Pretty Boy</font><br>
<font color="orange">Gangster Wanabee</font><br>
<font color="orange">Ho</font><br>
<font color="orange">Playa</font><br>
<font color="orange">Rude boy</font><br>
<font color="orange">Street Doll</font><br>
<font color="orange">Drug Runner</font><br>
<font color="orange">Criminal</font><br>
<font color="orange">Royal Thug</font><br>
<font color="orange">Mugger</font><br>
<font color="orange">Thief</font><br>
<font color="orange">Pretty Women</font><br>
<font color="orange">Mobster</font><br>
<font color="orange">Gangster Girl</font><br>

<br>
<br>


</body>
</html>  
