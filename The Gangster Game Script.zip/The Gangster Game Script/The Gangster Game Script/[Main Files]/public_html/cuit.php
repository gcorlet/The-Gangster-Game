<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
 
 if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
if(! ($data->level >= 255 ))
if($data->clanlevel <= 7){
    print <<<ENDHTML
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

  <table width=100%>
    <tr><td class="mainTxt">
	<tr><td class="subTitle"><b>Clan</b></td></tr>
	 <tr><td class="mainTxt"><center>You are not the leader or Owner.
	</center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
 
 exit;
 }
  include("_include-leaderopties.php");  
/* ------------------------- */ ?>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<html>


<table width=100%>
  <tr><td class="subTitle"><b>Gang Donation Out</b></td>
 <tr><td class="mainTxt">From this option you can select the gang members money flows in/out.
 </td>

<?php /* ------------------------- */


   
      $dbres				= mysql_query("SELECT `login` FROM `[users]` WHERE `clan`='{$data->clan}'");
      while($member = mysql_fetch_object($dbres)) {
      
 if ( isset ( $_GET['uit'] ) && !empty ( $_GET['uit'] ) )
        {
   
mysql_query("UPDATE `[users]` SET `aanuit`='2' WHERE `login`='$uit'");

   }
  if ( isset ( $_GET['aan'] ) && !empty ( $_GET['aan'] ) )
        {
   
mysql_query("UPDATE `[users]` SET `aanuit`='1' WHERE `login`='$aan'");

   }
}

    print <<<ENDHTML
  <tr><td><form method="post"><table width=100%>
  <tr><td align="center" class="subTitle" width=15><b>#</b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center"><a href="cuit.php?s=login"><b>Nickname</a></b></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=75><a href="cuit.php?s=power"><b>Donations</b></a></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=100><a href="cuit.php?s=rank"><b>In/Out</b></a></td></tr>
ENDHTML;

    if($_GET['s'] == "login")
      $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`cdonatie`,`aanuit`, `type` FROM `[users]` WHERE `clan`='{$data->clan}' AND `activated`=1 ORDER BY `login`");
    else if($_GET['s'] == "power")
      $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`cdonatie`,`aanuit`, `type` FROM `[users]` WHERE `clan`='{$data->clan}' AND `activated`=1 ORDER BY `cdonatie` DESC,`login` ASC");
    else if ($_GET['s'] == "rank")
      $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`cdonatie`,`aanuit`, `type` FROM `[users]` WHERE `clan`='{$data->clan}' AND `activated`=1 ORDER BY  `aanuit`  DESC,`login` ASC");
else
     $dbres				= mysql_query("SELECT `login`,`attack`,`defence`,`clicks`,`bank`,`cash`,`clanlevel`,`cdonatie`,`aanuit`,`type` FROM `[users]` WHERE `clan`='{$data->clan}' AND `activated`=1 ORDER BY `clanlevel` DESC,`login` ASC");
    for($j=1; $member = mysql_fetch_object($dbres); $j++) {
      $rank				= Array("","1","Recruiter","","","","Manager","Generaal","Leader","Owner");
      ${"select{$member->aanuit}"}	= " selected";
      $power				= round(($member->attack+$member->defence)/2+$member->clicks*5);

      print <<<ENDHTML
  <tr><td align="center" class="mainTxt">$j</td>
	<td class="mainTxt"><a href="profile.php?x={$member->login}">{$member->login}</a></td>
	<td align="center" class="mainTxt">$member->cdonatie</td>
	<td align="center" class="mainTxt" width=100>
ENDHTML;
      if($member->clanlevel < 9) {
    if($member->aanuit == 1) {
        print <<<ENDHTML
        <a href="cuit.php?uit=$member->login">Set Donation <b><font color=red>Out</b></a></td></tr>
ENDHTML;
      }

    if($member->aanuit == 2) {
        print <<<ENDHTML
        <a href="cuit.php?aan=$member->login">Set Donation <b><font color=green>In</b></a></td></tr>
ENDHTML;
      }

}
      else
        print "In</td></tr>\n";

     ${"select{$member->clanlevel}"} = "";
    }

  
?>

<?
mysql_close();
ob_flush();
?>