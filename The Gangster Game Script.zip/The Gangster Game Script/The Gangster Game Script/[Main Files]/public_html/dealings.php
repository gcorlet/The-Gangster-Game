<?php
error_reporting(0);

  include("_include-config.php"); 
  if(! check_login()) { 
    header("Location: login.php"); 
    exit; 
  }
  
 mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'"); 

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);	

echo'<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">';




if($data->gijzel < 1)

{

echo"  <table width=100% >

     <body bgcolor=\"black\">
    <tr><td class=\"subTitle\"><font color=\"gold\"><b>Sorry</b></font></td></tr>
    <tr><td class=\"mainTxt\">
	<center><font color=\"yellow\">You cannot deal anymore times this hour<br></font>
	</center>
    </td></tr>
  </table>
</body>";


}else{



  
$kansfiat       = rand(1, 25);
$kansford       = rand(1, 45);
$kanscitroen    = rand(1, 65);
$kansmaserati   = rand(1, 75);
$kansferrari    = rand(1, 100);  

$profiat			= rand(20, 40);
$proford			= rand(15, 30);
$procitroen		    = rand(10, 20);
$promaserati		= rand(5, 15);
$proferrari		    = rand(0, 5);



$bieden = $data->dealing;
$clicksk = $bieden*'450';
 


$deal = $data->dealvordering;
if ($deal <= 10) {
    $mrank = "Amateur";
} elseif ($deal > 10 AND $deal <= 20) {
    $mrank = "Pro dealer";
} elseif ($deal > 20 AND $deal <= 30) {
    $mrank = "Dealing king";
} elseif ($deal > 30 AND $deal <= 40) {
    $mrank = "Pro Dealer";
} elseif ($deal > 40 AND $deal <= 50) {
    $mrank = "Dealer King";
} elseif ($deal > 50 AND $deal <= 60) {
    $mrank = "Born Dealer";
} elseif ($deal > 60 AND $deal <= 70) {
    $mrank = "Prison King";
} elseif ($deal > 70 AND $deal <= 80) {
    $mrank = "Prison Lord";
} elseif ($deal > 80 AND $deal <= 90) {
    $mrank = "Prison God";
} elseif ($deal > 90) {
    $mrank = "Master of the Prison";
}

/* ------------------------- */ ?>
<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

<script type="text/javascript" src="overlib.js"></script>
	<style type="text/css">
<!-- BODY -->
</style>
</head>
<?

  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $gn             = mysql_fetch_object($gn1);  if($gn->gevangenis + $gn->gevangenistijd < time() ){
  $verschil1             = $gn->gevangenis + $gn->gevangenistijd - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");print <<<ENDHTML


  

 
<table width=100% >
<body bgcolor="black">
    <tr><td class="subTitle"><font color="gold"><b>Sorry</b></font></td></tr>
    <tr><td class="mainTxt">
	<center><font color="red">You are no longer in prison<br></font>
	</center>
    </td></tr>
  </table>
</body>
ENDHTML;
	}else{

  print <<<ENDHTML


<body style=" margin: 0px">
<center><table width=100%>
    <tr><td class="subTitle">Dealing</td></tr>
    <tr><td class="mainTxt"><center>You have <b>{$data->dealvordering}%</b> dealing progress and you can still deal <b>{$data->gijzel}x</b> this hour!.</td></tr>
    <tr><td class="mainTxt">
	<center><center>
 <FORM METHOD=post ACTION="">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1" height="153">
  <tr>
    <td width="47%" height="18"></td>
    <td width="34%" height="18"></td>
  </tr>
  <tr>
    <TD width="25%"><A 
      onmouseover="return overlib('Minimum level dealing <b>0%</b><br>Minimum number you can pinch is <b>0</b><br>Maximum number you can pinch is <b>20</b><br> dealing progression % with it: <b>0.20%</b>' , CAPTION, '<center>Bronze</center>', CENTER, RIGHT);" 
      onmouseout=nd();>&nbsp;&nbsp; <b>Deal Bronze by the front door</b></A></TD>
</b></td>
     </A></TD>
    <td width="34%" height="26">
<INPUT name="submitfiat" type="submit" VALUE="Deal!!"></td>
  </tr>
  <tr>
    <TD width="25%"><A 
      onmouseover="return overlib('Minimum level dealing is <b>10%</b><br>Minimum number of pinching is <b>0</b><br>Maximum number of pinching is <b>30</b><br> dealing progression % with it: <b>0.15%</b>' , CAPTION, '<center>Copper</center>', CENTER, RIGHT);" 
      onmouseout=nd();>&nbsp;&nbsp; <b>Deal Copper through the bars, cell to cell</b></A></TD>
</b></td>
     </A></TD>
    <td width="34%" height="26">
<INPUT name="submitford" type="submit" VALUE="Deal!!"></td>
  </tr>
  <tr>
    <TD width="25%"><A 
      onmouseover="return overlib('Minimum level dealing <b>30%</b><br>Minimum number of pinching is <b>0</b><br>Maximum number of pinching is <b>50</b><br> dealing progression % with it: <b>0.10%</b>' , CAPTION, '<center>Silver</center>', CENTER, RIGHT);" 
      onmouseout=nd();>&nbsp;&nbsp; <b>Deal silver to your friends in the prison</b></A></TD>
</b></td>
     </A></TD>
    <td width="34%" height="26">
<INPUT name="submitcitroen" type="submit" VALUE="Deal!!"></td>
  </tr>
  <tr>
    <TD width="25%"><A 
      onmouseover="return overlib('Minimum level dealing <b>60%</b><br>Minimum number of pinching is <b>0</b><br>Maximum number of pinching is <b>200</b><br> dealing progression % with it: <b>0.10%</b>' , CAPTION, '<center>Gold</center>', CENTER, RIGHT);" 
      onmouseout=nd();>&nbsp;&nbsp; <b>Deal gold to the prison guards</b></A></TD>
</b></td>
     </A></TD>
    <td width="34%" height="26">
<INPUT name="submitmaserati" type="submit" VALUE="Deal!!"></td>
  </tr>
  <tr>
    <TD width="25%"><A 
      onmouseover="return overlib('Minimum level dealing <b>90%</b><br>Minimum number of pinching is <b>0</b><br>Maximum number of pinching is <b>500</b><br> dealing progression % with it: <b>0.05%</b>' , CAPTION, '<center>Diamond</center>', CENTER, RIGHT);" 
      onmouseout=nd();>&nbsp;&nbsp; <b>Deal Diamonds while you are training</b></A></TD>
</b></td>
     </A></TD>
    <td width="34%" height="26">
<INPUT name="submitferrari" type="submit" VALUE="Deal!!"></td>
  </tr>
</table>
<p align="center">
</FORM>
<tr><td class="mainTxt"><center>Your Dealing Rank is: <b>{$mrank}</b> </td></tr>
<tr><td class="mainTxt"><center>You have <b>{$data->dealing}</b> deal points which can be exchanged for <b>$$clicksk</b> on the outside. It will go into your bank! <FORM METHOD=post ACTION=""><INPUT name="omzetten" type="submit" VALUE="Exchange?, Click Here">  </td></tr>
	</table>
  </td></tr>

ENDHTML;
?>
<?PHP
if (isset($_POST['omzetten'])) {
$deal = rand(0,20);
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$clicksk',`dealing`='0' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have <b>$$clicksk</b> and 0 dealing points after the exchange. </center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
exit;
}
?>
<?PHP
if (isset($_POST['submitfiat'])) {
$deal = rand(0,20);
mysql_query("UPDATE `[users]` SET `dealvordering`=`dealvordering`+'1',`dealing`=`dealing`+'$deal',`gijzel`=`gijzel`-'1' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=100%>
    <tr><td class="mainTxt">
	<center>You sat by the frontdoor doing deals. You manage to scrape together <b>$deal,</b> deal points!! </center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
exit;
}
?>
<?PHP
if (isset($_POST['submitford'])) {
      if($data->dealvordering < 10){
      print "<table width=100%><tr><td class=\"mainTxt\"><center>The deal done for dealing progression is <b>10%</b> </td></tr></table>\n";
      exit;
      }
$deal = rand(0,30);
mysql_query("UPDATE `[users]` SET `dealvordering`=`dealvordering`+'0.15',`dealing`=`dealing`+'$deal',`gijzel`=`gijzel`-'1' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=100%>
    <tr><td class="mainTxt">
	<center>Your lookout ticked you off about the guard. Nothing was supsected. You manage to grab yourself <b>$deal</b> deal points by sitting by the steps! </center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
exit;
}
?>
<?PHP
if (isset($_POST['submitcitroen'])) {
      if($data->dealvordering < 30){
      print "<table width=100%><tr><td class=\"mainTxt\"><center>The deal done for dealing progress is <b>30%</b> </td></tr></table>\n";
      exit;
      }
$deal = rand(0,50);
mysql_query("UPDATE `[users]` SET `dealvordering`=`dealvordering`+'0.10',`dealing`=`dealing`+'$deal',`gijzel`=`gijzel`-'1' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=100%>
    <tr><td class="mainTxt">
	<center>You sit to eat after getting <b>$deal</b> deal points! </center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
exit;
}
?>
<?PHP
if (isset($_POST['submitmaserati'])) {
      if($data->dealvordering < 60){
      print "<table width=100%><tr><td class=\"mainTxt\"><center>The deal done for dealing progression is <b>60%</b> </td></tr></table>\n";
      exit;
      }
$deal = rand(0,200);
mysql_query("UPDATE `[users]` SET `dealvordering`=`dealvordering`+'0.10',`dealing`=`dealing`+'$deal',`gijzel`=`gijzel`-'1' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=100%>
    <tr><td class="mainTxt">
	<center>You have a quick wash whilst you are dealing. You got <b>$deal</b> deal points </center>
    </td></tr>
  </table>
</body>

</html>
ENDHTML;
exit;
}
?>
<?PHP
if (isset($_POST['submitferrari'])) {
      if($data->dealvordering < 90){
      print "<table width=100%><tr><td class=\"mainTxt\"><center>The deal done for dealing progression is <b>90%</b> </td></tr></table>\n";
      exit;
      }
$deal = rand(0,500);
mysql_query("UPDATE `[users]` SET `dealvordering`=`dealvordering`+'0.05',`dealing`=`dealing`+'$deal',`gijzel`=`gijzel`-'1' WHERE `login`='$data->login'"); 
print <<<ENDHTML
  <table width=100%>
    <tr><td class="mainTxt">
	<center>You are the Pirson King, no inmate or prison guard dare question your word. You take it easy today and make <b>$deal</b> deal points </center>
    </td></tr>
  </table>
</body>

</html>

ENDHTML;
exit;
}}}
?>