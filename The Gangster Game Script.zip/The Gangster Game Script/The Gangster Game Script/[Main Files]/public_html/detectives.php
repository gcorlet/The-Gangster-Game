<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
if(! check_login()) {
    header("Location: login.php");
    exit;
  } 

/* ------------------------- */ ?>
<html>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<?
if (!empty($data) AND $data->topbalk == 1) {	
include('top.php');
}
?>
<?
    mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
$data = mysql_fetch_assoc($sql);

  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $gn             = mysql_fetch_assoc($gn1);  if($gn[gevangenis] + $gn[gevangenistijd] > time()  && $data[login] != ssfahuck && $data[login] != Freek){
  $verschil1             = $gn[gevangenis] + $gn[gevangenistijd] - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");print <<<ENDHTML
<table width=100%><tr><td class='mainTxt'><left>You have been put in Prison for <b>$verschil</b> seconds.<br><br><br>You can deal another <b>{$data[gijzel]}</b> times this hour! <br><br>(<a href="dealings.php"><b>Click Here to start dealing!</b></a>)<td class='mainTxt' align=center height=150 colspan=3><img src=/images/Jail.jpg></td></tr></table>
ENDHTML;
	}
	else{
	
	?>
<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack System</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Select an attack option</option>
<option value=\"bulletfactory.php\">Bullet Factory</option>
<option value=\"hospital.php\">Hospital</option>
<option value=\"attackexp.php\">Attack Experience</option>
<option value=\"killtrain.php\">Weapons Training</option>
<option value=\"detectives.php\">Detective</option>
<option value=\"ckiller.php\">Murder</option>
<option value=\"hirebodyguard.php\">Protection</option>
<option value=\"hitlist.php\">Hitlist</option>
</select>
</table>
";
}
?> 
<body> 
<br><br>
<table width='90%' cellpadding='0' cellspacing='0' bgcolor='#000000' align='center' style='background-color: transparent; border: 0px;'>
<td width=40% valign=top align=center>
<table width='90%' cellpadding='2' cellspacing='1' align='center' >
  <?php 



print <<<ENDHTML

  <?php 
$dbres       = mysql_query("SELECT *,UNIX_TIMESTAMP(`tijd`) AS `tijd`,0 FROM `[detective]`");
while($delete = mysql_fetch_assoc($dbres)){
$tijd             = $delete[tijd]+$delete[uren]*60*60-time();
}

print <<<ENDHTML
<form method="POST">
<body style=" margin: 0px;">
<table align="center" width=80%>
  <tr><td class="subTitle"><b>Information</b></td></tr>
  <tr><td class="mainTxt"><center>Before you can attempt to murder someone,
you must first know them and there wearabouts.
		You can do this by hiring a Detective.<br />
		1 hour detective work cost $20,000<br />
                So if you were to use a detective for 5 hours, it would obviously cost you $100,000
		</td>

  </td></tr>
</table>

 <tr><td class="subTitle" colspan=2><b>Murder</b></td></tr>
  <tr><td class="mainTxt" colspan=2><center><table align="center" width=80% colspan=2><center>
<form method="POST"><center>
		<td align="right">Person:</td>
		<td><input type="text" name="naamd" /></td>
	</tr>
	<tr class="inhoud">
		<td align="right">How Many Hours:</td>
		<td><select size="1" name="uren">
	<option selected value="1">1 hour</option>
	<option value="2">2 hours</option>
	<option value="3">3 hours</option>
	<option value="4">4 hours</option>
	<option value="5">5 hours</option></td>
			</td>
	</tr>
	<tr class="inhoud">
		<td align="right" valign="top">Countries:</td>
		<td>
		<table align="left">
			<tr>
							<td><input type="checkbox" name="zProvincie1" /> NetherLands</td>
								<td><input type="checkbox" name="zProvincie2" /> France</td>
							</tr>
			<tr>	
									<td><input type="checkbox" name="zProvincie3" /> Cuba</td>
								<td><input type="checkbox" name="zProvincie4" /> Russia</td>
							</tr>
			<tr>	
									<td><input type="checkbox" name="zProvincie5" /> Australia</td>
								<td><input type="checkbox" name="zProvincie6" /> USA</td>
							</tr>
<tr>	
									<td><input type="checkbox" name="zProvincie7" /> Germany</td>
								<td><input type="checkbox" name="zProvincie9" /> Belgium</td>
							</tr>
			<tr>	
									<td><input type="checkbox" name="zProvincie10" /> England</td>
								<td><input type="checkbox" name="zProvincie11" /> Ireland</td>
							</tr>
			<tr>	
										<td><input type="checkbox" name="zProvincie8" /> Every Country</td>
							</tr>
			<tr>	
								</tr>
<td class=sub align=right><input type="submit" value="Search Person" name="submitt"></td></tr>
</td></tr></table>
</form>
</td></tr>

		</td>
	</tr>
</table>
</form>
</form>
</table><br>
ENDHTML;



if(isset($_POST['submitt'])) {
$naam          = $_POST['naamd'];
$naam1         = mysql_query("SELECT * FROM `[users]` WHERE `login`='$naam'");
$naam1         = mysql_num_rows($naam1);
$uren = $_POST['uren'];

if($_POST['naamd'] ==""){
print "<table width=100%><tr><td class=maintxt>You must enter a name.</tr></td>";
}
elseif($naam1 ==0){
print "<table width=100%><tr><td class=maintxt>The name you entered does not exist.</tr></td>";
}
elseif($uren*20000 > $data[cash]){
print "<table width=100%><tr><td class=maintxt>You dont have enough cash on you.</tr></td>";
}
else{
$geld        = $uren*20000;
$vind1       = 5/$uren;
$vind1       = round($vind1);
$vind1       = rand(0,$vind1);
$vind        = rand(900,$uren*60*60);

mysql_query("INSERT INTO `[detective]` (`tijd`,`uren`,`zoeker`,`naam`,`status`,`vind`,`land`) values(NOW(),'$uren','$data[login]','$naam','0','$vind','0')");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$geld' WHERE `login`='$data[login]'");
print "<table width=100%><tr><td class=maintxt>The Detective is busy searching</tr></td>";
}
}
print "</td>
";

if(isset($_POST['wis'])) {
$id               = $_POST['id'];
mysql_query("DELETE FROM `[detective]` WHERE `id`='$id'");
print "<table width=100%><tr><td class=maintxt>You have dismissed the Detective.</tr></td>";
}
if( $_POST['wissen'] ){
mysql_query("DELETE FROM `[detective]` WHERE `zoeker`='$data[login]'");}

		print "	<form method=post>";
	print "	
	<table width='80%' cellpadding='2' cellspacing='1' align='center'>
	<tr><td class=subtitle colspan=4 align=center>Current Search Actions</td></tr>
	<tr><td class=maintxt align=center><b>Name:</b></td><td class=maintxt align=center><b>Time Busy:</b></td><td class=maintxt align=center><b>Country:</b></td><td class=maintxt align=center width=50><b>Annul:</b></td></tr>";


$detectives2        = mysql_query("SELECT *,UNIX_TIMESTAMP(`tijd`) AS `tijd`,0 FROM `[detective]` WHERE `zoeker`='$data[login]'");

while($detectives = mysql_fetch_assoc($detectives2)) {
$tijd             = $detectives[tijd]+$detectives[uren]*60*60-time();
$tijd2            = $tijd-3600;
$tijd1            = date("H:i:s", "$tijd2");
$zoeker           = mysql_query("SELECT * FROM `[users]` WHERE `login`='$detectives[naam]'");
$zoeker           = mysql_fetch_assoc($zoeker);
$land1         = Array("Busy","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland","");
$land          = $land1[$detectives[land]];

if($detectives[tijd] + $detectives[vind] < time() && $detectives[vind] !=0){
mysql_query("UPDATE `[detective]` SET `land`='$zoeker[land]', `status`='1' WHERE `id`='$detectives[id]'");
}

if($tijd <1){
$tijd1 = "Failed";
}

if($detectives[status] ==1){
$tijd1          = "Success";
}

	print " <tr><td class=maintxt><center>{$detectives[naam]}</td>  <td class=maintxt><b><center>{$tijd1}</b></td>  <td class=maintxt><center>{$land}</td><td class=maintxt align=center><input type=radio name=id value={$detectives[id]}></td></tr>";
	}
print " <tr><td class=\"maintxt\" colspan=4><center><input type=\"submit\" value=\"Dismiss!\" name=\"wis\"></td></tr>";
}
?>
</table>
</table>
</body>
</html>
<? mysql_close(); ?>