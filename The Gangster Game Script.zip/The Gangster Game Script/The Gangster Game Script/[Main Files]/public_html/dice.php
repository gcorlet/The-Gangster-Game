<?php
error_reporting(0);

include("_include-config.php");
    include("_include-gevangenis.php");

mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
?>
	<html>
	<head>
		<title><?php echo $page->sitetitle; ?></title>


	<link rel="stylesheet" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css" type="text/css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
	<body>
<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Dice Casino</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/dicepicture.jpg border=0></center>
</td>


	<table width='100%%' cellpadding='2' cellspacing='1' align='center' >
	<table width='100%%' cellpadding='2' cellspacing='1' align='center' >
		<tr><td class=subTitle colspan="2"><b>Game with 2 Dice.</b></td></tr>
	<?
	$inzet = $_POST['inzet'];
// begin starten

if(isset($_POST['gooi']) && preg_match('/^[0-9]+$/',$_POST['inzet'])) { 
	if($inzet > $data->bank OR $inzet <0){
	print "<table width=100%><tr><td class=mainTxt> Invalid Bet </tr></td>";
	exit;}
		elseif(!preg_match('/^[0-9]{3,10}$/',$_POST['inzet'])){
    echo "<table width=100%><tr><td class=mainTxt><font color=red>* error!</font> </tr></td>"; exit;}
	
		$dbres = mysql_query("SELECT `starter` FROM `[dobbel]` WHERE `starter`='$data->login'");
    $logincheck = mysql_fetch_object($dbres);
    $logincheck1 = mysql_num_rows($dbres);
    if ($logincheck1 >0){
	print " <table width=100%><tr><td class=mainTxt><tr><td class=mainTxt>You have already started playing dice</tr></td> ";
	exit;}
	 
if($inzet > 1000000){
$steen1 = rand(1,4);
$steen2 = rand(1,6);
}

if($inzet < 1000000){
 $steen1 = rand(1,6);    $steen2 = rand(1,6);
}

else{
 $steen1 = rand(1,6);    $steen2 = rand(1,6);
}
print " <tr><td colspan=3 align=center class=mainTxt><img src=images/gokken/dobbel/$steen1.gif> <font color=white> </b></font><img src=images/gokken/dobbel/$steen2.gif></td></tr>";  
  
  $totaal = $steen1+$steen2;
    mysql_query("INSERT INTO `[dobbel]`(`starter`,`inzet`,`gekozen`) values('$data->login','$inzet','$totaal')");
    mysql_query("UPDATE `[users]` SET `bank`=`bank`-'$inzet' WHERE `login`='$data->login'");
	print "<table width=100%><tr><td class=mainTxt> The game has started with bets of <b>$inzet</b></tr></td>";
	exit;}		
	

// -- Einde Starten



if(isset($_POST['gooi22']) && preg_match('/^[0-9]+$/',$_POST['inzet'])) { 
	if($inzet > $data->cash OR $inzet <0){
	print "<table width=100%><tr><td class=mainTxt> Invalid Bet  </tr></td>";
	exit;}
		elseif(!preg_match('/^[0-9]{3,10}$/',$_POST['inzet'])){
    echo "<table width=100%><tr><td class=mainTxt><font color=red>* error!</font> </tr></td>"; exit;}
	
		$dbres = mysql_query("SELECT `starter` FROM `[dobbel]` WHERE `starter`='$data->login'");
    $logincheck = mysql_fetch_object($dbres);
    $logincheck1 = mysql_num_rows($dbres);
    if ($logincheck1 >0){
	print " <table width=100%><tr><td class=mainTxt><tr><td class=mainTxt>You have already started playing dice! </tr></td> ";
	exit;}
	  $steen1 = rand(1,6);    $steen2 = rand(1,6);


print " <tr><td colspan=3 align=center class=mainTxt><img src=images/gokken/dobbel/$steen1.gif> <font color=white> </b></font><img src=images/gokken/dobbel/$steen2.gif></td></tr>";  
  
  $totaal = $steen1+$steen2;
    mysql_query("INSERT INTO `[dobbel]`(`starter`,`inzet`,`gekozen`) values('$data->login','$inzet','$totaal')");
    mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$inzet' WHERE `login`='$data->login'");
	print "<table width=100%><tr><td class=mainTxt> The game has started with bets of <b>$inzet</b> </tr></td>";
	exit;}		
	

// -- Einde Starten

?>

		<form method="post">
	<table width='100%%' cellpadding='2' cellspacing='1' align='center' >
		<tr><td class=mainTxt colspan="2"><center>Start a game of dice</td></tr>
		<tr><td class=mainTxt align="right">Amount:</td><td class=mainTxt align="center"><input type="text"  class="btn btn-info" name="inzet" size="10" />&nbsp;
									<input type="submit" class="btn btn-info" style="width: 200;" name="gooi" value="Roll with Bank money">	<input type="submit" class="btn btn-info" style="width: 200;" name="gooi22" value="Roll with cash in hand"></td></tr>
</table>
</form>


<?php
// begin  Als er word ge accepteerd

	
if(isset($_POST['gooi2'])) { 
$id = $_POST['id'];
	$infoz = mysql_query("SELECT * FROM `[dobbel]` WHERE `id`='$id'");
	$info = mysql_fetch_object($infoz);
	$userstat = mysql_query("SELECT * FROM `[users]` WHERE `login`='$info->starter'");
	$us = mysql_fetch_object($userstat);
	
	if($info->inzet > $data->bank){
	print "<table width=100%><tr><td class=mainTxt> You dont have that ammount of money in the bank! </tr></td> ";
	exit; }
	
	if($us->id == $data->id){
	print " <table width=100%><tr><td class=mainTxt>You cannot challenge yourself!  </tr></td>";
	exit;}
	
	if($us->id == ""){
	print " <table width=100%><tr><td class=mainTxt> Wrong! </tr></td>";
	exit;}
		  $steen1 = rand(1,6);    $steen2 = rand(1,6);


print " <table width=100%><tr><td colspan=3 align=center class=mainTxt><img src=images/gokken/dobbel/$steen1.gif> <font color=white> </b></font><img src=images/gokken/dobbel/$steen2.gif></td></tr>";  
  
  $totaal = $steen1+$steen2;
$inzet	=	$info->inzet*2;
	if($info->gekozen > $totaal){
	mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','***dice***','$info->starter','win','$data->login has lost a game of dice <br> You chose $info->gekozen and chose $data->login $totaal.<br>You won $info->inzet')"); 

	mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$inzet' WHERE `login`='$info->starter'");
	mysql_query("UPDATE `[users]` SET `bank`=`bank`-'$info->inzet' WHERE `login`='$data->login'");
	mysql_query("DELETE FROM `[dobbel]` WHERE `id`='$id'");
	print " <tr><td class=mainTxt>You has lost $info->starter has $info->gekozen eyes and you has $totaal eyes.<br> You have lost $info->inzet.  </tr></td>";	
exit;	}
		if($info->gekozen == $totaal){
		mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','***dice***','$info->starter','draw','$data->login plays dice<br> you had $totaal . <br> you have got $info->inzet <br> It was a Draw')"); 


	mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$info->inzet' WHERE `login`='$info->starter'");
mysql_query("DELETE FROM `[dobbel]` WHERE `id`='$id'");
	print " <tr><td class=mainTxt>It was a draw $info->starter has $info->gekozen eyes and you $totaal eyes.<br> You have got $info->inzet back in the pocket.  </tr></td>";	
exit;}
	if($info->gekozen < $totaal){
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','***dice***','$info->starter','lost','$data->login has won a game of dice!<br> You had $info->gekozen and $data->login had $totaal<br> you lost $info->inzet')"); 

	mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$info->inzet' WHERE `login`='$data->login'");
mysql_query("DELETE FROM `[dobbel]` WHERE `id`='$id'");
	print " <tr><td class=mainTxt>You have beaten $info->starter , you had $info->gekozen and $totaal .<br> You have won $info->inzet .  </tr></td>";	

exit;}
}
	// einde
if(isset($_POST['gooi12'])) { 
$id = $_POST['id'];
	$infoz = mysql_query("SELECT * FROM `[dobbel]` WHERE `id`='$id'");
	$info = mysql_fetch_object($infoz);
	$userstat = mysql_query("SELECT * FROM `[users]` WHERE `login`='$info->starter'");
	$us = mysql_fetch_object($userstat);
	
	if($info->inzet > $data->cash){
	print "<table width=100%><tr><td class=mainTxt> You dont have enough cash in hand! </tr></td> ";
	exit; }
	
	if($us->id == $data->id){
	print " <table width=100%><tr><td class=mainTxt>You cannot challenge yourself!  </tr></td>";
	exit;}
	
	if($us->id == ""){
	print " <table width=100%><tr><td class=mainTxt> Error! </tr></td>";
	exit;}
		  $steen1 = rand(1,6);    $steen2 = rand(1,6);


print " <table width=100%><tr><td colspan=3 align=center class=mainTxt><img src=images/gokken/dobbel/$steen1.gifimages/gokken/dobbel/$steen2.gif> <font color=white> </b></font><img src=images/gokken/dobbel/$steen2.gif></td></tr>";  
  
  $totaal = $steen1+$steen2;
$inzet	=	$info->inzet*2;
	if($info->gekozen > $totaal){
	mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','***dobbelen***','$info->starter','win','$data->login has lost a game of dice <br> You chose $info->gekozen and chose $data->login $totaal.<br>You won $info->inzet'win','$data->login has lost a game of dice <br> You chose $info->gekozen and chose $data->login $totaal.<br>You won $info->inzet')"); 

	mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$inzet' WHERE `login`='$info->starter'");
	mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$info->inzet' WHERE `login`='$data->login'");
	mysql_query("DELETE FROM `[dobbel]` WHERE `id`='$id'");
	print " <tr><td class=mainTxt>You have lost $info->starter had $info->gekozen eyes and you had $totaal eyes.<br> You have lost $info->inzet.  </tr></td>";	
exit;	}
		if($info->gekozen == $totaal){
		mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','***dice***','$info->starter','draw','$data->login plays dice<br> you had $totaal . <br> you have got $info->inzet <br> It was a Draw')"); 


	mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$info->inzet' WHERE `login`='$info->starter'");
mysql_query("DELETE FROM `[dobbel]` WHERE `id`='$id'");
	print " <tr><td class=mainTxt>Draw $info->starter has $info->gekozen eyes and you had $totaal eyes.<br> You have got $info->inzet back in the pocket.  </tr></td>";	
exit;}
	if($info->gekozen < $totaal){
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','***dice***','$info->starter','lost','$data->login has won a game of dice!<br> You had $info->gekozen and $data->login had $totaal<br> you lost $info->inzet')"); 

	mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$info->inzet' WHERE `login`='$data->login'");
mysql_query("DELETE FROM `[dobbel]` WHERE `id`='$id'");
	print " <tr><td class=mainTxt>You have beaten $info->starter , you had $info->gekozen and $totaal .<br> You have won $info->inzet   </tr></td>";	

exit;}
}
	// einde
	?>
<form onSubmit="JavaScript:this.b.disabled=true;" method="post">
<table width='100%' cellpadding='2' cellspacing='1' align='center' >
<tr><td class=subTitle align=left>#</TD>
<td class=subTitle align=left>Starter</TD>
<td class=subTitle align=left>Bet</TD></TR>

	<?
	
	$select = mysql_query("SELECT * FROM `[dobbel]`  ORDER BY `id` DESC LIMIT 0,250");
	while($list = mysql_fetch_object($select)) {
	echo "<form method=post><tr><td class=mainTxt><input type=radio name=id value={$list->id}></td><td align=left class=mainTxt><b><a href='profile.php?x=$list->starter'>$list->starter</a><td align=left class=mainTxt>$list->inzet</b></td></tr>";
	}
?>
<tr><td colspan=3 align=center class=mainTxt><input type="submit" class="btn btn-info" style="width: 200;" name="gooi2" value="Roll with Bank Cash"><input type="submit" class="btn btn-info" style="width: 200;" name="gooi12" value="Roll with Cash in Hand">
				<br> The money you win goes into the bank.	</td></tr>



	

	</body>
	</html>				