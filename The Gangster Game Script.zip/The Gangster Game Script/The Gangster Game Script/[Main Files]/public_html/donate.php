<?php
error_reporting(0);

  $OMNILOG				= 1;
  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    include("_include-gevangenis.php");
/* ------------------------- */ ?>
<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<script language="javascript">
    
    function getKeyCode(eventObject)
    {
      if (!eventObject) keyCode = window.event.keyCode; //IE
      else keyCode = eventObject.which;   //Mozilla
      return keyCode;
    }
      
    function onlyNumeric(eventObject)
    {
      keyCode = getKeyCode(eventObject);
      if (((keyCode > 31) && (keyCode < 48)) || ((keyCode > 57) && (keyCode < 127)))
      {
          if (!eventObject) window.event.keyCode = 0; //IE
          else eventObject.preventDefault(); //Mozilla
          return false;
      }
    }
  </script>
</head>


<table width=100%>
<?php /* ------------------------- */

  if(round($data->signup/3600-time()/3600) + 12 <= 0) {
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`cash`,`bank` FROM `[users]` WHERE `login`='{$_GET['x']}' AND `activated`=1");
    if(($to = mysql_fetch_object($dbres)) && $to->login != $data->login) {
      if(round($to->signup/3600-time()/3600) + 12 <= 0) {
        print "  <tr><td class=\"subTitle\"><b>Donate</b></td></tr>\n";
        if(isset($_POST['submit']) && preg_match("/^[0-9]+\$/",$_POST['amount']) && $_POST['amount'] > 0) {
          $amount			= $_POST['amount'];

          if($amount <= $data->cash) {
            $data->cash			-= $amount;
            $to->cash			+= $amount;
            mysql_query("UPDATE `[users]` SET `cash`={$data->cash} WHERE `login`='{$data->login}'");
            mysql_query("UPDATE `[users]` SET `cash`={$to->cash} WHERE `login`='{$to->login}'");

            $forwardedFor		= ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['HTTP_CLIENT_IP'];
            $forwardedFor		= preg_replace('/, .+/','',$forwardedFor);
            mysql_query("INSERT INTO `[logs]`(`time`,`IP`,`forwardedFor`,`login`,`person`,`code`,`area`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','{$data->login}','{$to->login}',$amount,'donate')");
            print "  <tr><td class=\"mainTxt\">You $amount is donated to $to->login.</td></tr>\n";
          }
          else
            print "  <tr><td class=\"mainTxt\">You dont have that much money</td></tr>\n";
        }
      
     
    }
        if(isset($_POST['submit2']) && preg_match("/^[0-9]+\$/",$_POST['amount']) && $_POST['amount'] > 0) {
          $amount			= $_POST['amount'];

          if($amount <= $data->bank) {
			$amount2	=	$amount*0.9;
            $data->bank			-= $amount;
            $to->bank			+= $amount2;
            mysql_query("UPDATE `[users]` SET `bank`={$data->bank} WHERE `login`='{$data->login}'");
            mysql_query("UPDATE `[users]` SET `bank`={$to->bank} WHERE `login`='{$to->login}'");

            $forwardedFor		= ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['HTTP_CLIENT_IP'];
            $forwardedFor		= preg_replace('/, .+/','',$forwardedFor);
            mysql_query("INSERT INTO `[logs]`(`time`,`IP`,`forwardedFor`,`login`,`person`,`code`,`area`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','{$data->login}','{$to->login}',$amount2,'donate')");
            print "  <tr><td class=\"mainTxt\">Your $amount2 is donated to $to->login.</td></tr>\n";
          }
          else
            print "  <tr><td class=\"mainTxt\">You dont have that much money</td></tr>\n";
        }
      
     
}
    print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	<table align="center">
	  <tr><td > Donate from you bank account. This will cost 10% from the donation amount.</td></tr>
	</table>
<tr><td class="mainTxt" align="center">
	<form method="post"><table align="center">
	  <tr><td width=60>To:</td>  <td><input type="text" name="to" value="{$_GET['x']}"></td></tr>
		<tr><td width=60>Amount:</td>  <td><input type="text" name="amount" maxlength="11" onkeypress="onlyNumeric(arguments[0])"></td></tr>  
</table>
<br>
<table align="center">
<tr><td class="mainTxt" align="center">
<br><br>
<td align="right"><input type="submit" name="submit" value="Donate with cash"  style="width: 200;"><br><br>
<input type="submit" name="submit2" value="Donate the money"  style="width: 200;"></td></tr>
	</table></form>
  </td></tr>
ENDHTML;
  }
  else
    print "  <tr><td class=\"mainTxt\">You are still under protection. Right now you cant donate</td></tr>\n";

/* ------------------------- */ ?>
</table>

</body>


</html>
<?
mysql_close();
ob_flush();
?>