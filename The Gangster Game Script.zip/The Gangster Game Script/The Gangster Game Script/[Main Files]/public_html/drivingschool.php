<?php
error_reporting(0);

  include_once("_include-config.php");
      include("_include-gevangenis.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

$owner = mysql_fetch_assoc(mysql_query("SELECT * FROM `[rijbewijs]`"));


 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
 $data = mysql_fetch_assoc($sql);

$land        = array("","Nederland","Frankrijk","Cuba","Rusland","Australie","VS");
$land1     = $land [$owner['id']];

$iSelect = mysql_query("SELECT `id`,`auto`,`tuning`,`banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro`,`rijbewijs` FROM `tunegarage` WHERE `eigenaar`='{$data['login']}'");

$iSelect2 = mysql_query("SELECT `id`,`auto`,`tuning`,`banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro`,`rijbewijs` FROM `tunegarage` WHERE `eigenaar`='{$data['login']}'");
$koe = mysql_fetch_assoc($iSelect2);


  if($koe[rijbewijs] == 0) {
	$vip = 'No car selected';
  } 
  
  elseif($koe[rijbewijs] == 1) {
	$vip = $koe[auto];
  }

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>

<body style=" margin: 0px;">

<?
if ($data['topbalk'] == 1) {	
include('top.php');
}

?>

<table align="center" width=100%> 

<?

if($owner[owner] == '1'){
echo "<table width=87% align=center>
<center>


<tr><td class=subTitle>Purchase Drivers school</td></tr>
<tr><td class=mainTxt align=center>This driving school does not have an owner.</td></tr>
<tr><td class=mainTxt align=center>
<a href=\"drivingschool.php\">Click hERE to purchase the Driving school!</a>
</table>";

} else {
?> 

<?php /* ------------------------- */


echo"<table width=100% align=center>";
echo"<tr><td class=subTitle colspan=12><b>Owner</b></td>";
echo"  <tr><td class='mainTxt'><left>Driving school: {$owner['naam']}<br><br>Owner: {$owner['owner']}<br><br>Students: {$owner['leerlingen']}<br><br>Succeeded Students: {$owner['geslaagde']}<br><br>Profit: {$owner['winst']},-<br><br>Place: {$land1}<br><br>Cost to get license: {$owner['kosten']},-<td class='mainTxt' align=center height=150 colspan=3><img src='images/game/rijbewijs_plaatje.jpg' height=150></td></tr></table>";
echo"<table width=100% align=center><tr><td class='mainTxt'><center><a href=drivingschool.php?x=instellen><b>Car Estabilshes</a> <td class='mainTxt'><center><a href=drivingschool.php?x=slagen><b>You received your drivers license</a><td class='mainTxt'><center><a href=drivingschool.php?x=info><b>License Information</b></a></td></tr>";
echo"</FORM></center></table>";

    if($data[login] ==  $owner[owner]){
echo"<table width=100% align=center><tr><td class='mainTxt'><center><a href=drivingschool.php?x=owner><b>Owner Options</a></td></tr>";
}

if($_GET['x'] == "info")
{
echo"<table width=100% align=center>";
echo"<tr><td class=subTitle colspan=12><b>License Information</b></td>";
echo"<tr><td class=mainTxt align=center >You have passed <b>{$data['rijbewijsmissie']}</b> your <b>10</b> questions<br>
You have won<b>{$data['rijbewijsauto']}</b> of you 5 races <b>5</b><br><br>

<b>Car</b>: {$vip}<br><br>



<b>License Progress:</b><br><br>

<img name='garage' src='balkgroen.gif' width='{$data[Rijbewijsvordering]}' height='14' maxlength='100%' alt='{$data[Rijbewijsvordering]}% ',- {$data[Rijbewijsvordering]}% 

</td></tr></table>
 </td>
	</tr>

<table width=100% align=center><tr><td class=mainTxt align=center><b>Car Establishes:</b><br>  You must owner a car first to get your Drivers License.<br>The cars which you establish descend on your Garage<br><br>

Please Note: All cars are not suitable to learn to drive in. Some cars are usable to crush in return for bullets! Racing Models are suitable to learn to drive in <BR><BR>

<a href=\"dv.php\"><B><font color=\"gold\">Click HERE to purchase a Dodge Viper! It is possible to learn to drive in this car and your able to pimp it out.</a><BR><BR></font>

<b>To get your driving License:</b><br>To obtain your License you must.<br>Answer correctly 10 questions and win 5 races.<br>You can also pimp your car in addition to getting your license.<br>If you have a Driving License, you have an advantage in your races.<br><br><b>Your License Information:</b><br>Here you can find information about your driving license<br>Pay Attention: You can obtain 1 drivers license, so therefore pick a good school.<br><br><b>Our Pleasure to Explain this!<br></b></table>";
}

if($_GET['x'] == "instellen")
{
echo"<table width=100% align=center><form method=post>";
echo"<tr><td class=subTitle ><b>Established Car</b></td>";

    if($koe[rijbewijs] == 1){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/game/rijbewijs_plaatje.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>you can get only 1 Drivers License</b><br></TD></TR>
    ";
     }else{

echo"<tr><td class=mainTxt align=center >This driving school cost <b>{$owner['kosten']},-</b> to get your license.<b><br><br>Car:
 
<select name=autoid>";
	while($iList = mysql_fetch_assoc($iSelect)) {
echo "<option value={$iList['id']}>{$iList['id']}  {$iList['auto']}</option>";

}
echo"<tr><td class=maintxt ><center><input type=submit name=submit value=\"Use this car for my driving lessons\"></form>";

if(isset($_POST['submit']))
{

if($koe[rijbewijs] == 1)
{
Die ("<tr><td class=mainTxt colspan=2 align=center> You have already chosen a car");
}

if($_POST['autoid'] == '')
{
Die ("<tr><td class=mainTxt colspan=2 align=center> This car is not in your garage");
}
if($data['cash'] < $owner['kosten'])
{
Die("<tr><td class=mainTxt colspan=2 align=center>You dont have enough monsy in your bank");
}
mysql_query("UPDATE `[rijbewijs]` SET `leerlingen`=`leerlingen`+'1',`winst`=`winst`+'{$owner['kosten']}' WHERE `id`='{$data['land']}'");
mysql_query("UPDATE `tunegarage` SET `rijbewijs`='1' WHERE `id`='{$_POST['autoid']}'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'{$owner['kosten']}' WHERE `login`='{$data['login']}'");
echo "<tr><td class=mainTxt colspan=2 align=center>You can now obtain your Drivers License</table>";
}

}
}

if($_GET['x'] == "slagen")
{
echo"<table width=100% align=center>";
echo"<tr><td class=subTitle colspan=3><b>Obtain License</b></td>";

    if($koe[rijbewijs] == 0){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/game/rijbewijs_plaatje.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>You cannot take the questions,<br></B>  You can return once you have chosen a car.</TD></TR>
    ";
     }else{


    if($data[rijbewijsmissie] == 0){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/1.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B>  Which one is shown here?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen1a>A level crossing with more than 2 tracks</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen1b>A dangerous point of crossing</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen1c>A tram rails crossing</a></TD>
    ";
     }
    if($data[rijbewijsmissie] == 1){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/2.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B>  Which one should you be 160 meters from the track?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen2a>Sign A</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen2b>Sign B</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen2c>Sign C</a></TD>
    ";
     }
    if($data[rijbewijsmissie] == 2){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/3.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B> Which sign indicates no maximum speed ?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen3a>Sign A</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen3b>Sign B</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen3c>Sign c</a></TD>
    ";
     }
    if($data[rijbewijsmissie] == 3){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/4.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B>  You must give way to the cyclist here?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen4a>Yes</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen4b>No</a></TD>
    ";
     }
    if($data[rijbewijsmissie] == 4){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/5.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B> This is no pavement... Give primary way to pedestrians ?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen5a>Yes</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen5b>No</a></TD>
    ";
     }
    if($data[rijbewijsmissie] == 5){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/6.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B>  Is your 2 year theory certificate valid?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen6a>Yes</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen6b>No</a></TD>
    ";
     }
    if($data[rijbewijsmissie] == 6){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/7.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B>  After which sign can you drive a maxiumum of 80MPH ?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen7a>After Sign A</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen7b>After Sign B</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen7c>You cant after either of the signs</a></TD>
    ";
     }
    if($data[rijbewijsmissie] == 7){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/8.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B>  What does this sign mean ?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen8a>Prohibited end to all</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen8b>Childrens crossing</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen8c>After this sign you can driver as fast as you want</a></TD>
    ";
     }
    if($data[rijbewijsmissie] == 8){
echo"  <TR><form method='post' action=''>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/9.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B>Whats the speed limit here ?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt align=center>    <input type='text' name='headadmin' maxlength='16'>m p/h
    <TD vAlign=top class=mainTxt>    <input type='submit' value='Ik weet het antwoord' name='do1'>
    </TD>
    </form>
    ";
     }
    if($data[rijbewijsmissie] == 9){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/tunen/10.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question:</B>  A drum is linked to the obligatory equipment of a car ?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen10a>Yes</a></TD>
   <TD vAlign=top class=mainTxt><a href=drivingschool.php?x=slagen10b>No</a></TD>
    ";
     }

    if($data[rijbewijsmissie] > 9){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/game/rijbewijs_plaatje.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Well Done</B> You have correctly answer the 10 questions. If you have won 5 races then you get your license. </TD></TR>
    ";
     }
}
}
echo"<table width=100% align=center>";

if($_GET['x'] == "slagen1a")
{
if($data['rijbewijsmissie'] != 0){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>1</b> is <font color=green><b>Correct</b></font>. Only <b>9</b> questions to go.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen1b")
{
if($data['rijbewijsmissie'] != 0){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>1</b> is <font color=red><b>Wrong</b></font>.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen1c")
{
if($data['rijbewijsmissie'] != 0){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>1</b> is <font color=red><b>Wrong</b></font>.</TD></TR>";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}


if($_GET['x'] == "slagen2a")
{
if($data['rijbewijsmissie'] != 1){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>2</b> is <font color=red><b>Wrong</b></font>.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen2b")
{
if($data['rijbewijsmissie'] != 1){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>2</b> is <font color=green><b>Correct</b></font>. Only <b>8</b> Questions left.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen2c")
{
if($data['rijbewijsmissie'] != 1){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>2</b> is <font color=red><b>Wrong</b></font>. </TD></TR>";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen3a")
{
if($data['rijbewijsmissie'] != 2){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>3</b> is <font color=red><b>Wrong</b></font>.</TD></TR>";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen3b")
{
if($data['rijbewijsmissie'] != 2){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>3</b> is <font color=red><b>Wrong</b></font>. ";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen3c")
{
if($data['rijbewijsmissie'] != 2){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>3</b> is <font color=green><b>Correct</b></font>. Only <b>7</b> questions left.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}

if($_GET['x'] == "slagen4a")
{
if($data['rijbewijsmissie'] != 3){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>4</b> is <font color=red><b>Wrong</b></font>.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen4b")
{
if($data['rijbewijsmissie'] != 3){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>4</b> is <font color=green><b>Correct</b></font>. Only <b>6</b> questions left.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen5a")
{
if($data['rijbewijsmissie'] != 4){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>5</b> is <font color=red><b>Wrong</b></font>. ";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen5b")
{
if($data['rijbewijsmissie'] != 4){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>5</b> is <font color=green><b>Correct</b></font>. Only <b>5</b> questions left.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen6a")
{
if($data['rijbewijsmissie'] != 5){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>6</b> is <font color=red><b>Wrong</b></font>. Het koste je <b>10.000</b>, Je kan het altijd Only een paar keer proberen.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen6b")
{
if($data['rijbewijsmissie'] != 5){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>6</b> is <font color=green><b>Correct</b></font>. Only <b>4</b> questions left.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}

if($_GET['x'] == "slagen7a")
{
if($data['rijbewijsmissie'] != 6){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>7</b> is <font color=red><b>Wrong</b></font>. ";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen7b")
{
if($data['rijbewijsmissie'] != 6){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>7</b> is <font color=green><b>Correct</b></font>. Only <b>3</b> questions left.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen7c")
{
if($data['rijbewijsmissie'] != 6){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>7</b> is <font color=red><b>Wrong</b></font>.</TD></TR>";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen8a")
{
if($data['rijbewijsmissie'] != 7){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>8</b> is <font color=red><b>Wrong</b></font>. ";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen8b")
{
if($data['rijbewijsmissie'] != 7){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>8</b> is <font color=green><b>Correct</b></font>. Only <b>2</b> questions left.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen8c")
{
if($data['rijbewijsmissie'] != 7){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>8</b> is <font color=red><b>Wrong</b></font>. </TD></TR>";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if (isset($_POST['do1'])){
if($data['rijbewijsmissie'] != 8){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
if ($_POST['headadmin'] == "50"){
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>8</b> is <font color=green><b>Correct</b></font>. Only <b>1</b> questions left.";
exit;
} else {
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>8</b> is <font color=red><b>Wrong</b></font>. </TD></TR>";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
}

if($_GET['x'] == "slagen10a")
{
if($data['rijbewijsmissie'] != 9){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>10</b> is <font color=red><b>Wrong</b></font>.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "slagen10b")
{
if($data['rijbewijsmissie'] != 9){
echo "<tr><td class=mainTxt colspan=2 align=center>How've you done here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>10</b> is <font color=green><b>Correct</b></font>. You have completed the questions, <b> Well Done</b>.";
echo "<script language=\"javascript\">setTimeout('window.location=\"drivingschool.php?x=slagen\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `rijbewijsmissie`=`rijbewijsmissie`+'1',`Rijbewijsvordering`=`Rijbewijsvordering`+'9' WHERE `login`='{$data['login']}'");
}
}





?>
<?
if($_GET['x'] == "owner")
{
   if($data->login == $owner->owner){
   echo "  <center><table width=80%><tr><td class=subTitle><b>Owner Optionss</b></td>";
   echo "<form method=\"post\"><table width=80%><td class=maintxt><center>Cost:
<INPUT name='hoeveel' type='text' VALUE='' maxlength='20' style='width: 
150;'><center>
<INPUT name='submit12' type='submit' VALUE='Change cost of Driving License'></tr></td></table>";


   echo "<form method=\"post\"><table width=80%><td class=maintxt><center>Name:
<INPUT name='hoeveel1' type='text' VALUE='' maxlength='20' style='width: 
150;'><center>
<INPUT name='submit13' type='submit' VALUE='Change name of Driving school'></tr></td></table>";

   echo "<form method=\"post\"><table width=80%><td class=maintxt><center><input type=submit name=\"submit3\" Value=\"Reset Profit Chart\"><input type=submit name=\"submit4\" Value=\"Reset number of customers\"></tr></td></table>";
 echo "<form method=\"post\"><center><table width=80%><tr><td class=subTitle><b>Put on the auction</b></td>";
   echo "<tr><td class=maintxt>        <p><b>Info</b><BR><textarea name=info rows=7 cols=85></textarea><br>            <b>Auctime Sale Time</b>&nbsp;&nbsp;&nbsp;&nbsp;
            <select name=\"veilingtijd\">
<option value=\"1\">1 hour</option>
<option value=\"2\">2 hour</option>
<option value=\"3\">3 hour</option>
<option value=\"4\">4 hour</option>
<option value=\"5\">5 hour</option>
<option value=\"6\">6 hour</option>
</select><br><b>Starting Offer</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=text name=beginbod value=5000 size=6>,-<br><br>";
        echo "<input type=submit value=\"Sell by Auction Sale\" name=veiling></p>";
echo "</form></tr></td>";

if(isset($_POST['veiling']) && $info !="")
{
  $info          = $_POST['info'];
  $dbres2        = mysql_query("SELECT `id` FROM `[veiling2]` WHERE `land`='$data[land]' AND `item`='14'");
if(mysql_num_rows($dbres2) != 0) 
{
   print "  <table width=100%><tr><td class=\"mainTxt\">The driving school is already on auction</td></tr></table>\n";
}
elseif($_POST['veilingtijd'] < 1)
{
   print "  <table width=100%><tr><td class=\"mainTxt\">The auction sale time must be a minimum of 1 hour<br> And the maximum og 6 hours.</td></tr></table>\n";
   exit;
}
elseif($_POST['veilingtijd'] > 6)
{
   print "  <table width=100%><tr><td class=\"mainTxt\">The auction sale time must be a minimum of 1 hour<br> And the maximum og 6 hours.</td></tr></table>\n";
   exit;
}
elseif($_POST['beginbod'] < 1000)
{
   print "  <table width=100%><tr><td class=\"mainTxt\">Het begin bod moet minimaal 1000,- zijn</td></tr></table>\n";
   exit;
}
elseif($_POST['beginbod'] > 10000000)
{
   print "  <table width=100%><tr><td class=\"mainTxt\">The starting offer has a maximum of 10000000,- zijn</td></tr></table>\n";
   exit;
}
elseif(! is_numeric($_POST['veilingtijd']))
{
   print "  <table width=100%><tr><td class=\"mainTxt\">Figures between 1 and 6 only.</td></tr></table>\n";
   exit;
}
else {

if($_POST['veilingtijd'] == "1")
{
 $uur = 3600;
}
if($_POST['veilingtijd'] == "2")
{
 $uur = 7200;
}
if($_POST['veilingtijd'] == "3")
{
 $uur = 10800;
}
if($_POST['veilingtijd'] == "4")
{
 $uur = 14400;
}
if($_POST['veilingtijd'] == "5")
{
 $uur = 18000;
}
if($_POST['veilingtijd'] == "6")
{
 $uur = 21600;
}


   mysql_query("INSERT INTO `[veiling2]` (`plaatser`, `tijd`, `item`, `land`, `beginbod`, `bod`, `veilingtijd`, `aanbiedtijd`, `info`) VALUES ('$data[login]', NOW(), '14', '$data[land]', '$beginbod', '$beginbod', '$uur', NOW(), '$info')");
   print "<table width=100%><tr><td class=\"mainTxt\" align=\"center\">The driving school has just been put on auction for ".$_POST['veilingtijd']." hours, <br> and a starting offer of".$_POST['beginbod']." </table>";
}
}
}


if (isset($_POST['submit12'])) {
$insert = "UPDATE `[rijbewijs]` SET `kosten`='$hoeveel' WHERE `id`='{$data[land]}'";
$insert_now = mysql_query($insert) or die("Wrong : " . mysql_error());
echo "<tr><td class=mainTxt colspan=2 align=center>The cost is now: <b>$hoeveel</b> to obtain your license</font>";
exit;
}




if (isset($_POST['submit13'])) {
$insert = "UPDATE `[rijbewijs]` SET `naam`='$hoeveel1' WHERE `id`='{$data[land]}'";
$insert_now = mysql_query($insert) or die("Wrong : " . mysql_error());
echo "<tr><td class=mainTxt colspan=2 align=center>The Driving school is now called <b>$hoeveel1</b></font>";
exit;
}

if (isset($_POST['submit3'])){
if($data->login == $owner->owner){
mysql_query("UPDATE `[rijbewijs]` SET `winst`='0' WHERE `id`='{$data[land]}'");
echo "<table width=100%><tr><td class=mainTxt><center> The profit chart has been reset </TD></TR> ";
}
else
echo "<table width=100%><tr><td class=mainTxt><center> Error: You are not the owner </TD></TR> ";
}

if (isset($_POST['submit4'])){
if($data->login == $owner->owner){
mysql_query("UPDATE `[rijbewijs]` SET `leerlingen`='0' WHERE `id`='{$data[land]}'");
echo "<table width=100%><tr><td class=mainTxt><center> The customer total has been reset </TD></TR> ";
}
else
echo "<table width=100%><tr><td class=mainTxt><center> Error: You are not the owner </TD></TR> ";
}
}
}
?>

<? mysql_close(); ?>