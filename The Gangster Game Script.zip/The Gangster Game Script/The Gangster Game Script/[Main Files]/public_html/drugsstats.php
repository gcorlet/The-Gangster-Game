<?php
error_reporting(0);

  $_POST['omnilog']			= 1;
  $OMNILOG				= 1;
  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

  $land1        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=1");
  $land1         = mysql_fetch_object($land1);
  $land2        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=2");
  $land2         = mysql_fetch_object($land2);
  $land3        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=3");
  $land3         = mysql_fetch_object($land3);
  $land4        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=4");
  $land4         = mysql_fetch_object($land4);
  $land5        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=5");
  $land5         = mysql_fetch_object($land5);
  $land6        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=6");
  $land6         = mysql_fetch_object($land6);
  $land7        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=7");
  $land7         = mysql_fetch_object($land7);
  
  $land8        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=8");
  $land8         = mysql_fetch_object($land8);
  $land9        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=9");
  $land9         = mysql_fetch_object($land9);
  $land10        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=10");
  $land10         = mysql_fetch_object($land10);
  $land11        = mysql_query("SELECT * FROM `[drugs]` WHERE `land`=11");
  $land11         = mysql_fetch_object($land11); 



/* ------------------------- */ ?>

<html>


<head>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<?php
// PageView Limit
// No more than X pageviews in one minute.

Function PageViewLimit(){

   $PvlViews=25; //
   $error="<center><b><BR><BR>You have reached the maximum page views per minute on this current page [PV 25]</b></center>"; // .

   session_start();
   if(!isset($_SESSION['Pvl'])){
      $_SESSION['Pvl']['Time']=time();
      $_SESSION['Pvl']['Views']=1;
   }
   else{
      //
      if((time()-$_SESSION['Pvl']['Time']) >= 60){

     $_SESSION['Pvl'] = null;

     $_SESSION['Pvl']['Time']=time();
     $_SESSION['Pvl']['Views']=1;
      }
      else{
         $_SESSION['Pvl']['Views']++;

     if($_SESSION['Pvl']['Views']>=$PvlViews){
           exit($error);
         }
      }
   }
}
PageViewLimit();
?> 
</head>


<body style="; margin: 0px;">
<table width=100%>

  <tr><td>
  <table align=center width=100%>  
    <tr>
        <td class=subTitle>
          <div align="center"><b>Land</b></div></td>
        <td class=subTitle>
        <div align="center"><b>Cocaine</b></div></td>
        <td class=subTitle>
          <div align="center"><b>Weed</b></div></td>
          <td class=subTitle>
          <div align="center"><b>LSD</b></div></td>
          <td class=subTitle>
          <div align="center"><b>Opium</b></div></td>
          <td class=subTitle>
          <div align="center"><b>Exstacy</b></div></td>
          <tr>
	        	<td width=3% align=center class=mainTxt>#1</td>
			<td width=15% align=center class=mainTxt><? echo "$land1->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land1->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land1->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land1->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land1->prijs5"; ?></td>
	

		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#2</td>
			<td width=15% align=center class=mainTxt><? echo "$land2->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land2->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land2->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land2->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land2->prijs5"; ?></td>

		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#3</td>
			<td width=15% align=center class=mainTxt><? echo "$land3->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land3->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land3->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land3->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land3->prijs5"; ?></td>

		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#4</td>
			<td width=15% align=center class=mainTxt><? echo "$land4->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land4->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land4->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land4->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land4->prijs5"; ?></td>

		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#5</td>
			<td width=15% align=center class=mainTxt><? echo "$land5->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land5->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land5->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land5->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land5->prijs5"; ?></td>

		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#6</td>
			<td width=15% align=center class=mainTxt><? echo "$land6->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land6->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land6->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land6->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land6->prijs5"; ?></td>

		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#7</td>
			<td width=15% align=center class=mainTxt><? echo "$land7->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land7->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land7->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land7->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land7->prijs5"; ?></td> 

			
			
		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#8</td>
			<td width=15% align=center class=mainTxt><? echo "$land8->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land8->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land8->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land8->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land8->prijs5"; ?></td>
 
			
		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#9</td>
			<td width=15% align=center class=mainTxt><? echo "$land9->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land9>prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land9->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land9->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land9->prijs5"; ?></td> 
			
		</tr><tr>
	        	<td width=3% align=center class=mainTxt>#10</td>
			<td width=15% align=center class=mainTxt><? echo "$land10->prijs1"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land10->prijs2"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land10->prijs3"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land10->prijs4"; ?></td>
			<td width=15% align=center class=mainTxt><? echo "$land10->prijs5"; ?></td> 
			
	
			
			
			
			
			
			

</table>


</body>


</html>


