<?php
error_reporting(0);

  include("_include-config.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 
<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
  <?php
// PageView Limit
// No more than X pageviews in one minute.

Function PageViewLimit(){

   $PvlViews=25; // Number of pageviews.
   $error="<center><b><BR>Error:<BR>This page is limited to 20 pageviews a minute.</b></center>"; // Change in the error in something you want.

   session_start();
   if(!isset($_SESSION['Pvl'])){
      $_SESSION['Pvl']['Time']=time();
      $_SESSION['Pvl']['Views']=1;
   }
   else{
      // delete if excists longer than 60 seconds, and make a new one
      if((time()-$_SESSION['Pvl']['Time']) >= 60){

     $_SESSION['Pvl'] = null;

     $_SESSION['Pvl']['Time']=time();
     $_SESSION['Pvl']['Views']=1;
      }
      else{
         $_SESSION['Pvl']['Views']++;

     if($_SESSION['Pvl']['Views']>=$PvlViews){
           exit($error);
         }
      }
   }
}
PageViewLimit();
?> 
 </head>
 <body><center>
  <table width='100%'>
<?
#if($data->level < '255') {
#	echo '<tr><td class="mainTxt" colspan="6">New Script has been placed... Press F5 to refresh the website.</td></tr>'; exit; }

$mijn_voertuig	= $data->voertuig;
$mijn_rank		= $data->rank;
$mijn_login		= $data->login;
$mijn_reistijd 	= $data->reistijd;
?>
   <tr>
	<td class="subTitle" colspan="6"><b>Transport</b></td>
   </tr>
<?php
if($mijn_reistijd >= time()) {
	echo '<tr><td class="mainTxt" align="center" colspan="6">
			  	You are travelling at the moment with no vehicle to buy or sell.<br></td>
		  </tr>'; exit;
}
if($_POST['koop'] && $_POST['akkoord']) { // Sales and Agrreement... Just look or can you buy it?;)
	$query['koop2']		= mysql_query("SELECT * FROM `[voertuigen]` WHERE `voertuig_id`='".$_POST['koop']."' ORDER BY `rank` ASC");
	$query_tel['koop2'] = mysql_num_rows($query['koop2']);
	$nieuw_query_fetch	= mysql_fetch_array($query['koop2']);
	if($mijn_rank < $nieuw_query_fetch['rank']) {
		echo '<tr>
				<td class="mainTxt" align="center" colspan="6">
				 Your rank is not yet high enough to purchase this vehicle.<br></td>
			  </tr>';
	} elseif($mijn_voertuig != 1) {
		echo '<tr>
				<td class="mainTxt" align="center" colspan="6">First you must sell your current vehicle.<br>\n
			  	<a href="drugsvehicle.php?verkoop='.$mijn_voertuig.'" class="btn btn-info">Click Here</a> to buy this.</td>
			  </tr>';
	} elseif($data->cash < $nieuw_query_fetch['prijs']) {
		$verschil = $nieuw_query_fetch['prijs'] - $data->cash;
		echo '<tr>
				<td class="mainTxt" align="center" colspan="6">
					You came in '.number_format($verschil,2,',','.').' short for a '.$nieuw_query_fetch['voertuig'].'.
			  	</td>
			  </tr>';
	} else {
		mysql_query("UPDATE `[users]` SET `voertuig`='".$nieuw_query_fetch['voertuig_id']."',`cash`=`cash`-".$nieuw_query_fetch['prijs']."
					 WHERE `login`='".$data->login."'") or die("foutje: ".mysql_error());
		echo '<tr>
				<td class="mainTxt" align="center" colspan="6">You have bought '.$nieuw_query_fetch['voertuig'].'</td>
			  </tr>';
	}
	exit;		
} elseif ( $_GET['koop'] ) { //  :)
	$query['koop1']		= mysql_query("SELECT * FROM `[voertuigen]` WHERE `voertuig_id`='".$_GET['koop']."' AND rank <= ".$mijn_rank." ORDER BY `rank` ASC");
	$query_tel['koop1'] = mysql_num_rows($query['koop1']);			$query_fetch		= mysql_fetch_array($query['koop1']);
	if($query_tel['koop1'] == 1 && $query_fetch['voertuig_id'] != 1) {
	echo '<form method="post" action="drugsvehicle.php">
		   <tr> 
		    <td class="mainTxt" align="center" colspan="6"><font size="2">Your certain you want to buy '.$query_fetch['voertuig'].' 
				for '.number_format($query_fetch['prijs'],2,',','.').'?</font></td>
		   </tr><input type="hidden" name="koop" value="'.$_GET['koop'].'">
		   <tr>
		   	<td class="mainTxt" align="right" colspan="3" width="50%"><input type="submit" class="btn btn-info" name="akkoord" value="Yes"></td>
			<td class="mainTxt" align="left" colspan="3" width="50%"><input type="submit" class="btn btn-info" name="weiger" value="No"></td>
		   </tr>
		  </form>';
	exit;
	}
} elseif($_POST['verkoop'] && $_POST['akkoord']) { // :)
	$query['verkoop2']	= mysql_query("SELECT * FROM `[voertuigen]` WHERE `voertuig_id`='".$_POST['verkoop']."' ORDER BY `rank` ASC");
	$query_tel['verkoop2'] = mysql_num_rows($query['verkoop2']);		$nieuw_query_fetch	= mysql_fetch_array($query['verkoop2']);
	if($mijn_rank < $nieuw_query_fetch['rank']) {
		echo '<tr>
				<td class="mainTxt" align="center" colspan="6">
				  Your rank is not high enough to purchase this vehicle.<br></td>
			  </tr>';
	} elseif($mijn_voertuig != $_POST['verkoop']) {
		echo '<tr>
				<td class="mainTxt" align="center" colspan="6">You must firstly purchase the vehicle.<br>\n
			  	<a href="drugsvehicle.php?koop='.$_POST['verkoop'].'" class="btn btn-info">Click Here</a> to buy this.</td>
			  </tr>';
	} else {
		$prijs = floor($nieuw_query_fetch['prijs'] * 0.75);
		mysql_query("UPDATE `[users]` SET `voertuig`='1',`cash`=`cash`+".$prijs."
					 WHERE `login`='".$data->login."'") or die("foutje: ".mysql_error());
		echo '<tr>
				<td class="mainTxt" align="center" colspan="6">You have bought '.$nieuw_query_fetch['voertuig'].' for '.number_format($prijs,2,',','.').'.</td>
			  </tr>';
	}		
	exit;
} elseif ( $_GET['verkoop'] ) { //  ;)
	$query['verkoop1']		= mysql_query("SELECT * FROM `[voertuigen]` WHERE `voertuig_id`='".$mijn_voertuig."' AND rank <= ".$mijn_rank." ORDER BY `rank` ASC");
	$query_tel['verkoop1']	= mysql_num_rows($query['verkoop1']);
	$query_fetch			= mysql_fetch_array($query['verkoop1']);
	if($query_tel['verkoop1'] == 1 && $query_fetch['voertuig_id'] != 1) {
	echo '<form method="post">
		   <tr> 
		    <td class="mainTxt" align="center" colspan="6"><font size="2">Your certain you want to buy '.$query_fetch['voertuig'].' 
				for '.number_format(floor($query_fetch['prijs']*0.75),2,',','.').'?</font></td>
		   </tr> <input type="hidden" class=" btn btn-info" name="verkoop" value="'.$_GET['verkoop'].'">
		   <tr>
		   	<td class="mainTxt" align="right" colspan="3" width="50%"><input type="submit" class="btn btn-info" name="akkoord" value="Yes"></td>
			<td class="mainTxt" align="left" colspan="3" width="50%"><input type="submit" class="btn btn-info" name="weiger" value="No"></td>
		   </tr>
		  </form>';
	exit; 
	} 
}
//  ;)		  
if($data->login == "admin" || $data->login == "TGoC") {
	$query['1']		= mysql_query("SELECT * FROM `[voertuigen]` ORDER BY `rank` ASC");
} else {
	$query['1']		= mysql_query("SELECT * FROM `[voertuigen]` where rank <= ".$mijn_rank." ORDER BY `rank` ASC");
}
$query_tel['1'] = mysql_num_rows($query['1']);
if($query_tel['1'] < 1) {
	echo '<tr><td class="mainTxt" colspan="6">No such Vehicle exists. Possible an error in the database.<br>\n
		  If this is still a problem in a hour,<br>\n
		  then contact an admin via Ticket Support.<br></td></tr>\n\n';
} else {
	echo '<tr>
			<td class="mainTxt" colspan="2">Type</td>
			<td class="mainTxt">Max. Drugs</td>
			<td class="mainTxt">Travel Time</td>
			<td class="mainTxt">Travel Expences</td>
			<td class="mainTxt">Buy</td>
		  </tr>';
	while($voertuig = mysql_fetch_object($query['1'])) {
		$voertuig_reis_tijd = $voertuig->reistijd-3600;
		echo '<tr>
				<td class="mainTxt" colspan="2">'. $voertuig->voertuig .'</td>
				<td class="mainTxt">'. $voertuig->inhoud .'</td>
				<td class="mainTxt">'. date("H:i",$voertuig_reis_tijd) .'</td>
				<td class="mainTxt">'. number_format($voertuig->reiskosten,0,',','.') .',-</td>';
		if($voertuig->voertuig_id == 1) {
		  echo '<td class="mainTxt">&nbsp;</a></td>';
		} elseif($mijn_voertuig == $voertuig->voertuig_id) {
		  echo '<td class="mainTxt"><a href="drugsvehicle.php?verkoop='. $voertuig->voertuig_id .'" class="btn btn-info" >Sell</a></td>';
		} else {
		  echo '<td class="mainTxt"><a href="drugsvehicle.php?koop='. $voertuig->voertuig_id .'" class="btn btn-info">
		  			'. number_format($voertuig->prijs,0,',','.') .',-</a>
				</td>';
		}
		echo '</tr>';
	}
}
?>
  </table>
 </center></body>
</html> 

