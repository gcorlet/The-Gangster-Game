<?php
error_reporting(0);

  include('_include-jail.php');
 
  if(! check_login()) {
    header('Location: login.php');
    exit;
  }

?>

<html>
<head>
<title><?=$title; ?></title>

</head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 

</td>
</td>
<table width="441" align="center">
</td></tr>
</table>

<?PHP

if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>ERROR</b></center></font></td></tr>";
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`=0 where `login`='$data->login'");
exit;
}

?>
<?PHP
if($_GET['x'] == 'credits') {


}
?>
<form method="post" action="dv.php" name="f">
<table width="441" align="center">
  <tr><td class=subTitle colspan=3><b>Buy a Dodge Viper</b></td></tr>
  <tr><td class=mainTxt>




<tr>
<td width=20 class=mainTxt></td>
<td class=mainTxt width="208">The ultimate racing vehicle... Especially when its tuned up in the gangsta garage!</td><td class=mainTxt width="199"></td>
</tr>


<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="clangeld"></td>
<td class=mainTxt width="208"><font color="yellow"><b>Buy Dodge</b> <img src="images/smilies/icon_star_gold.gif" border="0"></font></td><td class=mainTxt width="199"><a href="buycredits.php" target="_self">Cost 100 VIP Credits</a></td>
</tr>


<tr>
<td colspan=2 class=mainTxt><b>Current VIP Credits:</b> <? echo $data->belcredits ?></td>
<td align=right class=mainTxt width="199">
<p align="left">aantal <input type=input value="0" size=3 name="bieden">x
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=submit value="Buy" name="submit">

</tr></td><table width="441" align="center">

<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "clangeld") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 100;
           $land = 12;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough VIP Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>ERROR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy it!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
mysql_query("INSERT INTO `tunegarage`(`auto`,`eigenaar`) values('Dodge Viper','{$data->login}')");
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have bought a dodge viper<br></td></tr>\n";
}
}
?>



