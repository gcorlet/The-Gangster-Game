<?php
error_reporting(0);

  $UPDATE_DB				= 1;
  include("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }


$don = 20;
/* ------------------------- */ ?>

<html>
<head>
<title><?=$title; ?></title>
</head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">



<script language="javascript">
function icon(theicon) {
document.form3.info.value += ""+theicon;
document.form3.info.focus();
}

function setsmilie(which){
document.form3.info.value = document.form3.info.value + which;
}

</script>

<base target="mainFrame" />

</head>
<?php /* ------------------------- */

  if(isset($_POST['nieuwe'])) {
    $test				= preg_replace('/\</','&#60;',$_POST['test']);
    $verdediger     = mysql_query("SELECT * FROM `[users]` WHERE `login`='$test'"); 
   $verdediger1    = mysql_fetch_object($verdediger);
   $controle       = mysql_num_rows($verdediger); 

if($test =="{$data->login}"){
print "You cant give yourself a Will";
die();
}

elseif($verdediger1->level == 255){
echo "Admins dont want your will";
die();
}

elseif($controle <1){
	echo "This user does not exist";
		die();
		}
    mysql_query("UPDATE `[users]` SET `testament`='{$test}' WHERE `login`='{$data->login}'");
    print "  <tr><td class=\"mainTxt\">The notary has trasnfered your will on {$test}</td></tr>\n";
  }

  if(isset($_POST['afbeelding'])) {
    $data->avaurl		        = preg_replace('/\</','&#60;',$_POST['avatar']);
    mysql_query("UPDATE `[users]` SET `avaurl`='{$data->avaurl}' WHERE `login`='{$data->login}'");
    print "  <tr><td class=\"mainTxt\">Your image has been changed</td></tr>\n";
  }

if(isset($_POST['budadd'])){
$login = $data->login;
$name = $_POST['budname'];
$tegenstander1 = mysql_query("SELECT `login` FROM `[users]` WHERE `login`='$name'");
$tegenstander1 = mysql_num_rows($tegenstander1);

$dbres = mysql_query("SELECT * FROM `[buddylist]` WHERE `name`='{$name}' AND `login`='{$data->login}'");
$dubbel = mysql_num_rows($dbres);

$dbres = mysql_query("SELECT * FROM `[buddylist]` WHERE `login`='{$data->login}'");
$dubbell = mysql_num_rows($dbres);

if($tegenstander1 ==0){
echo "<table class=thinline cellspacing=0 cellpadding=0 width=95%>
<tr><td class=Subtitle>Friends List</td></tr>
<tr><td class=mainTxt><font color=red>The player you added does not exist!</font></td></tr></table><br>";
}

elseif($dubbel ==1){
print "<table class=thinline cellspacing=0 cellpadding=0 width=95%>
<tr><td class=Subtitle>Friends List</td></tr>
<tr><td class=mainTxt><font color=red><font color=red>This player is already in your friends list</font></td></tr></table><br>";
}

elseif($dubbell >= $don){
print "<table class=thinline cellspacing=0 cellpadding=0 width=95%>
<tr><td class=Subtitle>Friends List</td></tr>
<tr><td class=mainTxt><font color=red><font color=red>You can have a maximum of $don friends on your firends list!</font></td></tr></table><br>";
}
else {
$name = ucfirst(strtolower($name));
mysql_query("INSERT INTO `[buddylist]`(login,name,date) values('$login','$name',NOW())");
print "<table class=thinline cellspacing=0 cellpadding=0 width=95%>
<tr><td class=Subtitle>Vrienden lijst</td></tr>
<tr><td class=mainTxt><font color=red>You have added {$name} to your friends list.</td></tr></table><br>";
}
}
  if(isset($_POST['profile1'])) {
  $data->type        = $_POST['type'];
    $type        = $_POST['type'];
    ${"select$type"}      = "selected";
    mysql_query("UPDATE `[users]` SET `type`='{$data->type}' WHERE `login`='{$data->login}'");
    print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">Play Type has been adapted</td></tr>\n";
  }
else if(isset($_POST['password'])) {
  if($_POST['pass'] != $_POST['confirm']) {
      print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">The two passwords are not the same.</td></tr></table>\n";
}
   else if($_POST['pass'] != "" && $_POST['pass'] == $_POST['confirm']) {
      mysql_query("UPDATE `[users]` SET `pass`=MD5('{$_POST['pass']}') WHERE `login`='{$data->login}'");
      print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">Your password has been changed</td></tr></table>\n";
    }
  }
else if(isset($_POST['tekst'])) {
    $data->info				= preg_replace('/\</','&#60;',substr($_POST['info'],0,500000));
    mysql_query("UPDATE `[users]` SET `info`='{$data->info}' WHERE `login`='{$data->login}'");
    print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">Your personal text has been changed!</td></tr>\n";
  }
else if(isset($_POST['allies'])) {
    $data->allies				= preg_replace('/\</','&#60;',substr($_POST['allies'],0,500000));
    mysql_query("UPDATE `[users]` SET `allies`='{$data->allies}' WHERE `login`='{$data->login}'");
    print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">Your friends list has been changed!</td></tr>\n";
  }
else if(isset($_POST['enemies'])) {
    $data->enemies				= preg_replace('/\</','&#60;',substr($_POST['enemies'],0,500000));
    mysql_query("UPDATE `[users]` SET `enemies`='{$data->enemies}' WHERE `login`='{$data->login}'");
    print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">Your enemies list has been changed!</td></tr>\n";
  }
else if(isset($_POST['clickinfo2'])) {
    $data->info				= preg_replace('/\</','&#60;',substr($_POST['clickinfo'],0,500000));
    mysql_query("UPDATE `[users]` SET `clicktext`='{$_POST['clickinfo']}' WHERE `login`='{$data->login}'");
    print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">Your click text has been changed!</td></tr>\n";
  }

else if(isset($_POST['persoon'])) {

    $data->sex				= $_POST['sex'];
    $sex				= $_POST['sex'];
    ${"select$sex"}			= "selected";

    mysql_query("UPDATE `[users]` SET `geslacht`='$sex' WHERE `login`='{$data->login}'");
    print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">Your information of yourself has been changed!</td></tr>\n";
  }

else if(isset($_POST['type'])) {

    $data->ctype				= $_POST['ctype'];
    $ctype				= $_POST['ctype'];
    ${"select$ctype"}			= "selected";

    mysql_query("UPDATE `[users]` SET `ctype`='$ctype' WHERE `login`='{$data->login}'");
    print "<table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\">  <tr><td class=\"mainTxt\">Your Criminal Character type has been changed!</td></tr>\n";
  }




else if(isset($_POST['nonactief'])) {
    $data->nonactief			= $_POST['nonactie'];
    $nonactief				= $_POST['nonactie'];
    ${"select$nonactie"}			= "selected";
    mysql_query("UPDATE `[users]` SET `nonactief`='{$data->nonactief}',`dagen`='1' WHERE `login`='{$data->login}'");
    print "  <table class=\"thinline\" cellspacing=\"0\" cellpadding=\"0\" width=\"95%\"><tr><td class=\"mainTxt\">Your status is set to Un-Active</td></tr>\n";
  }

  $data->name				= stripslashes($data->name);
  $data->age				= stripslashes($data->age);
  $data->url				= stripslashes($data->url);
  $data->info				= stripslashes($data->info);
  $data->allies				= stripslashes($data->allies);
  $data->enemies			= stripslashes($data->enemies);
  $data->avatar			        = stripslashes($data->avatar);
	$allies 	= $data->allies;
	$enemies 	= $data->enemies;

  $geslacht				= Array("","Man","Women");
  $geslacht				= $geslacht[$data->sex];

  $dbres				= mysql_query("SELECT id FROM `[messages]` WHERE `read`=0 AND `inbox`=1 AND `to`='{$data->login}'");
  $inboxnew				= mysql_num_rows($dbres);

  $type1 = array("","DrugDealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","Original Gangster","Rude Boy","PeaceKeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Royal Thug","Avenger","Mugger","Capone","Thief","PIMP","Pretty Women","WiseGuy","Mobster","Fella","Gangster Girl","The Daddy");
  $ctype = $type1[$data->ctype];




  print <<<ENDHTML
  


<tr>
<table valign=top width=305 align=center colspan=2>

  <form method="post">
  <table width=99% colspan=2>
  <tr><td valign="top" class="subTitle" colspan="2"><b>Personal Information</b></td></tr>
   <tr>
  <td class=mainTxt colspan=1>Criminal Character Type:</td>
  <td class=mainTxt colspan=1>{$ctype}</td>
  </tr>

<tr>
  <td class=mainTxt colspan=1>E-mail Address:</td>
  <td class=mainTxt colspan=1>{$data->email}</td>
  </tr>
  <tr>
  <td class=mainTxt colspan=1>Sex:</td>
  <td class=mainTxt colspan=1>{$geslacht}</td>
  </tr>
  <tr>
  <td class=mainTxt colspan=1>Friends:</td>
  <td class=mainTxt colspan=1>{$allies}</textarea></td>
  </tr>
  <tr>
  <td class=mainTxt colspan=1>Enemies:</td>
  <td class=mainTxt colspan=1>{$enemies}</textarea></td>
  </tr>
  

<tr>
  <td class=mainTxt colspan=1>Mailbox:</td>
  <td class=mainTxt colspan=1><a href="message.php?p=inbox" class='btn btn-info'><b>{$inboxnew}</a></td>
  </tr>
  </table>
  </form>
</tr>
  </table>








<td valign=top width=262 align=left>
  
  <form method="post">
  <table width=262 align=left valign=top colspan=2>
  <tr><td valign="top" class="subTitle" colspan="2"><b>Change Criminal Character Type</b></td></tr>
  <tr><td class="mainTxt">
  <tr>
  <td class=mainTxt>Character Type:</td><td class=mainTxt><select type="ctype" name="ctype">
      							<option value="" class='btn btn-info'>Select One</option>
      							<option value="1" $ctype class='btn btn-info'>DrugDealer</option>
							<option value="2" $ctype class='btn btn-info'>Thug</option>
<option value="3" $ctype>Pretty Boy</option>
<option value="4" $ctype>Officer</option>
<option value="5" $ctype> Gangster Wanabee</option>
<option value="6" $ctype> Hired Gun</option>
<option value="7" $ctype> Ho</option>
<option value="8" $ctype> Hustler</option>
<option value="9" $ctype> Original Gangster</option>
<option value="10" $ctype> Playa</option>
<option value="11" $ctype> Rude Boy</option>
<option value="12" $ctype> PeaceKeeper</option>
<option value="13" $ctype> Street Doll</option>
<option value="14" $ctype> Gangster Bitch</option>
<option value="15" $ctype> Drug Runner</option>
<option value="16" $ctype> Hoodie</option>
<option value="17" $ctype> Criminal</option>
<option value="18" $ctype> Lady Bitch</option>
<option value="19" $ctype> Royal Thug</option>
<option value="20" $ctype> Avenger</option>
<option value="21" $ctype> Mugger</option>
<option value="22" $ctype> Capone</option>
<option value="23" $ctype> Thief</option>
<option value="24" $ctype> PIMP</option>
<option value="25" $ctype> Pretty WOmen</option>
<option value="26" $ctype> WiseGuy</option>
<option value="27" $ctype> Mobster</option>
<option value="28" $ctype> Fella</option>
<option value="29" $ctype> Gangster Girl</option>
<option value="30" $ctype> The Daddy</option>

</select></td></tr>


  </tr>

  <tr><td class=mainTxt>&nbsp;</td><td align=right class=mainTxt><input type="submit" class='btn btn-info' name="type" value="Change"></td>
  </tr>

  
  </form>

  </table>
  </form>  





<table valign="top" width="262" align="center" colspan="2">
<tr><td class="subTitle" colspan="1"><b>Friends & Enemies</b></td></tr>
<form method="post">
<tr>
<td class=mainTxt>Friends:</td>
</tr>
<tr><td class="mainTxt"><textarea name="allies" class='btn btn-info' cols='' style='width: 250; height: 75px;'>{$allies}</textarea></tr></td>
<tr>
  <td class=mainTxt><input type="submit" name="allies2" class='btn btn-info' value="Change"></td>
  </tr>
  </form>
 <form method="post">
  <tr>
  <td class=mainTxt>Enemies:</td>
  </tr>
  <tr><td class="mainTxt"><textarea name="enemies" class='btn btn-info' cols='' style='width: 250; height: 75px;'>{$enemies}</textarea></tr></td>
  <tr>
  <td class=mainTxt><input type="submit" class='btn btn-info' name="enemies2" value="Change"></td>
  </tr>
  </form>
  </table>
  <form name="form3" method="post">
  <table width=99%>
  <tr><td class="subTitle" colspan="2"><b>Personal Text</b></td></tr>
<td class=mainTxt colspan=2>
<input type="button" value="B" class='btn btn-info' style="font-weight:bold; width: 30px" onClick="javascript:icon('[b] [/b]')">
<input type="button" value="i" class='btn btn-info' style="font-style:italic; width: 30px" onClick="javascript:icon('[i] [/i]')">
<input type="button" value="u" class='btn btn-info' style="text-decoration: underline; width: 30px" onClick="javascript:icon('[u] [/u]')">
<input type="button" value="Scroll" class='btn btn-info' style="text-decoration: none; width: 40px" onClick="javascript:icon('[scroll] [/scroll]')">
<input type="button" value="Color" class='btn btn-info' style="text-decoration: none; width: 40px" onClick="javascript:icon('[color=red] [/color]')">
<input type="button" value="Image" class='btn btn-info' style="text-decoration: none; width: 40px" onClick="javascript:icon('[img] [/img]')">
<input type=\"button" value="Center" class='btn btn-info' style="text-decoration: none; width: 50px" onClick="javascript:icon('[center][/center]')">
<br><br>
<A HREF="javascript:setsmilie('_O_')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/worship.gif" alt="_O_" border="0"></a>
<A HREF="javascript:setsmilie('::)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/tears.gif" alt="::)" border="0"></a>
<A HREF="javascript:setsmilie(';)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smilewink.gif" alt=";)" border="0"></a>
<A HREF="javascript:setsmilie(':)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smiletongue.gif" alt=":)" border="0"></a>
<A HREF="javascript:setsmilie(':D')" ONFOCUS="filter:blur()"class='btn btn-info'><img src="images/smilies/smileteeth.gif" alt=":D" border="0"></a>
<A HREF="javascript:setsmilie('(zz)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smilesleeping.gif" alt="(zz)" border="0"></a>
<A HREF="javascript:setsmilie(':(')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smileredface.gif" alt=":(" border="0"></a>
<A HREF="javascript:setsmilie('(H)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smilecool.gif" alt="(H)" border="0"></a>
<A HREF="javascript:setsmilie('(omg)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smileomg.gif" alt="(omg)" border="0"></a>
<A HREF="javascript:setsmilie(';D')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smilemean.gif" alt=";D" border="0"></a>
<A HREF="javascript:setsmilie('(bb)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smilebounce.gif" alt="(bb)" border="0"></a>
<A HREF="javascript:setsmilie(':S')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/smileconfused.gif" alt=":S" border="0"></a>
<A HREF="javascript:setsmilie('::D')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/lol.gif" alt="::D" border="0"></a>
<A HREF="javascript:setsmilie('|)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/indifferent.gif" alt="|)" border="0"></a>
<A HREF="javascript:setsmilie('|:')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/happytears.gif" alt="|:" border="0"></a>
<A HREF="javascript:setsmilie('|}')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/frustrated.gif" alt="|}" border="0"></a>
<A HREF="javascript:setsmilie('(st)')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/silence.gif" alt="(st)" border="0"></a>
<A HREF="javascript:setsmilie(':W')" ONFOCUS="filter:blur()" class='btn btn-info'><img src="images/smilies/bye.gif" alt=":W" border="0"></a>
</td>
  </tr>
  <tr>
  <td valign=top class=mainTxt width=20%>Info:</td><td class=mainTxt><textarea name="info" class='btn btn-info' cols='' style='width: 250; height: 150px;'>{$data->info}</textarea></td>
  </tr>
  <tr>
  <td class=mainTxt>&nbsp;</td><td align=right class=mainTxt><input type="submit" class='btn btn-info' name="tekst" value="Change"></td>
  </tr>
  </table>
  </form>

<br>
  
  <form method="post">
  <table width=99%>
  <tr><td class="subTitle" colspan="2"><b>Change Password</b></td></tr>
  <tr><td class="mainTxt">
  <tr>
  <td class=mainTxt>New Password:</td><td class=mainTxt><input type="password" class='btn btn-info' name="pass"></td>
  </tr>
  <tr>
  <td class=mainTxt>Again:</td><td class=mainTxt><input type="password" class='btn btn-info' name="confirm"></td>
  </tr>
  <tr>
  <td class=mainTxt>&nbsp;</td><td align=right class=mainTxt><input type="submit" class='btn btn-info' name="password" value="Change"></td>
  </tr>
  </table>
  </form>


</td>
<td valign=top width=305 align=center>
  
  <form method="post">
  <table width=99%>
  <tr><td valign="top" class="subTitle" colspan="2"><b> Change Sex</b></td></tr>
  <tr><td class="mainTxt">
  <tr>
  <td class=mainTxt>Sex:</td><td class=mainTxt><select type="sex" name="sex">
      							<option value="" class='btn btn-info'>Select</option>
      							<option value="1" $select1 class='btn btn-info'>Man</option>
							<option value="2" $select1 class='btn btn-info'>Woman</option>
</select></td></tr>


  </tr>

  <tr><td class=mainTxt>&nbsp;</td><td align=right class=mainTxt><input type="submit" class='btn btn-info' name="persoon" value="Change"></td>
  </tr>

  
  </form>

  </table>
  </form>  
<br>

  
  <form method="post">
  <table width=99%>
  <tr><td class="subTitle" colspan="2"><b>Picture</b></td></tr>
  <tr><td class="mainTxt">
  <tr>
  <td align=center class=mainTxt>Current Picture:<br>
  <img src="{$data->avaurl}" width=300 height=300>  
  </td>
  </tr>
  <tr>
  <td align=center class=mainTxt>Picture: <input type=text class='btn btn-info' name=avatar value="{$data->avaurl}" size=50><br><a href="http://www.imageshack.us" target="_blank">Link to Image</a></td>
  </tr>
  <tr>
  <td align=right class=mainTxt><input type=submit value="Change" class='btn btn-info' name="afbeelding"></td>
  </tr>
  </table>
  </form>

</td></tr></td></table>

 
ENDHTML;

/* ------------------------- */ ?>


</table>

</body>


</html>