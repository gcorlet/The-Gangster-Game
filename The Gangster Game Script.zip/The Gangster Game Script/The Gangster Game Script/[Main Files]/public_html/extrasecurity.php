<?php
error_reporting(0);

if (!function_exists(secure)){
function secure($todo)
{
if (preg_match('/[\'<>"]|\bOR\b|\bAND\b|[+][1-9]*[+]|[+][1-9]*|[1-9]*[+]|[-][1-9]*[-]|[-][1-9]*|[1-9]*[-]|\bDROP\b|\bTRUNCATE\b|%00|\bSELECT\b|echo|print|query|\$[a-z]*/i',$todo)){
$todo=htmlentities($todo,ENT_QUOTES,"UTF-8");
@header("HTTP/1.0 400 Bad Request");
die ('<span style="font-weight: bold;font-size: 40px;">Bad request</span><div style="margin-left: 20px;">The server ignored your request.<br />This was detected as a possible hack attempt.<br /><br />\''.$todo.'\'<br />Is not allowed</div>');
exit;}
return htmlentities($todo,ENT_QUOTES,"UTF-8");
}}
foreach($_REQUEST as $key => $value) {
if(gettype($_REQUEST[$key])=="array"){
foreach($$_REQUEST[$key] as &$key2){
secure($_REQUEST[$key][$key2]);
//Only check if secure
}
}else{
secure($_REQUEST[$key]);
//Only check if secure
}
}
foreach($_POST as $key => $value) {
if(gettype($_POST[$key])=="array"){
foreach($$_POST[$key] as $key2 => $value2){
$_POST[$key][$key2]=secure($_POST[$key][$key2]);}
}else{
$_POST[$key]=secure($_POST[$key]);
}}
foreach($_GET as $key => $value) {
if(gettype($_GET[$key])=="array"){
foreach($$_GET[$key] as $key2 => $value2){
$_GET[$key][$key2]=secure($_GET[$key][$key2]);}
}else{
$_GET[$key]=secure($_GET[$key]);}
}




?>