<?php
error_reporting(0);

  include("_include-config.php");
      
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<html>

<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">


</head>

<table align="center" width=100%>
  <tr><td class="subTitle"><b> </b></td></tr>
 

 <tr><td class="mainTxt"><center>


<font color="FF0000">Failure!</a><br></font>
The Pin Code which has been entered was not correct.<br>
Please go back and enter it again. <br>
If it fails to comply, contact an admin via the ticket system.<br><br>

Do bare inmind we do receive emails on every purchase... <br>
So dont try and blag that you have paid when you haven't.



 <br>
<br>


  </td></tr>
 

</body>


</html>

</html>
<?php mysql_close(); ?>