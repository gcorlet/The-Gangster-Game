<?php
error_reporting(0);

  include_once("_include-config.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }


if(isset($_GET['sub'])){
$_GET['sub']=htmlspecialchars(addslashes($_GET['sub']));
}
if(isset($_GET['p'])){
$_GET['p']=htmlspecialchars(addslashes($_GET['p']));
}
if(isset($_GET['topic'])){
$_GET['topic']=htmlspecialchars(addslashes($_GET['topic']));
}
if(isset($_GET['slotje'])){
$_GET['slotje']=htmlspecialchars(addslashes($_GET['slotje']));
}
if(isset($_GET['delreply'])){
$_GET['delreply']=htmlspecialchars(addslashes($_GET['delreply']));
}
if(isset($_GET['verplaats'])){
$_GET['verplaats']=htmlspecialchars(addslashes($_GET['verplaats']));
}
if(isset($_POST['forum'] )){
$_POST['forum'] =htmlspecialchars(addslashes($_POST['forum'] ));
}
if(isset($_GET['reageer'])){
$_GET['reageer']=htmlspecialchars(addslashes($_GET['reageer']));
}
if(isset($_GET['quote'])){
$_GET['quote']=htmlspecialchars(addslashes($_GET['quote']));
}
if(isset($_GET['edittopic'])){
$_GET['edittopic']=htmlspecialchars(addslashes($_GET['edittopic']));
}
if(isset($_GET['editreply'])){
$_GET['editreply']=htmlspecialchars(addslashes($_GET['editreply']));
}
if(isset($_GET['delreply'])){
$_GET['delreply']=htmlspecialchars(addslashes($_GET['delreply']));
}
if(isset($_GET['sub'])){
$_GET['sub']=htmlspecialchars(addslashes($_GET['sub']));
}
if(isset($_GET['sub'])){
$_GET['sub']=htmlspecialchars(addslashes($_GET['sub']));
}
if(isset($_GET['sub'])){
$_GET['sub']=htmlspecialchars(addslashes($_GET['sub']));
}
if(isset($_GET['sub'])){
$_GET['sub']=htmlspecialchars(addslashes($_GET['sub']));
}

if(! $_GET['p']) {
	$begin = 0;
}
else {
	$begin = $_GET['p'];
}
  
/* ------------------------- */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<script language="javascript">
function icon(theicon) {
document.form3.info.value += ""+theicon;
document.form3.info.focus();
}

function setsmilie(which){
document.form3.info.value = document.form3.info.value + which;
}

</script>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body background="#333333" text="#FFFFFF" link="#999999" vlink="#999999" alink="#999999" topmargin="0">



<?
if($_GET['sub']) {
	$query2 = mysql_query("SELECT * FROM `[forum_sub]` WHERE `id`={$_GET['sub']}");
	$sub  = mysql_fetch_object($query2);
	if($sub->mods == "") {
		$mods = "None";
	} else { 
		$mods = $sub->mods;
        }
        if($data->forumstatus == "gwsp9") {
	}
	elseif($data->forumstatus == "gwsp2") {
	}
	elseif($data->forumstatus == "gwsp1") {
	}
	else {
		




	}

	print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"75%\" align=\"center\"><tr><td><div align=\"left\"><a href=\"forum.php?newtopic={$_GET['sub']}\"><b>Start New Topic</b></a></div><div align=\"right\">\n";
	print "	</div></td></tr><tr><td align=\"left\">Moderator(s): <font color=red><b>$mods</b></font></td></tr><tr><td><table align=\"center\" width=\"100%\"><tr><td width=\"5%\" align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\">&nbsp;</td><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"45%\"><b>Topic</b></td><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"10%\"><b>By</b></td><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"10%\"><b>Replies</b></td><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"30%\"><b>Last Reply</b></td></tr>\n";
	$query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `subid`={$_GET['sub']} ORDER BY `date` DESC");
		while($forum = mysql_fetch_object($query)) {
    
			if($forum->slotje == 0) {
				$image = "opentopic.gif";
			}
			else {
				$image = "closed.gif";
			}
			if($forum->datum == "") {
			  $forum->datum = "None";
			  }
			if($forum->title == "") {
			  $forum->title = "None";
			  }
			print "	<tr><td width=\"5%\"><a href=\"forum.php?verplaats={$forum->id}\"><img src=\"images/icons/{$image}\" border=0></a></td><td width=\"45%\"><a href=\"forum.php?topic={$forum->id}\"><b>$forum->title</b></a></td><td align=\"center\" width=\"10%\"><a href=\"profile.php?x={$forum->login}\">$forum->login</a></td><td align=\"center\" width=\"10%\">$forum->replys</td><td width=\"30%\">$forum->datum</td></tr><tr>\n";
		}
	print "	</table></tr></td></table></td></tr></table>\n";
}
elseif($_GET['topic']) {
	if(isset($_POST['add'])) {
		$id	   		= $_GET['topic'];
		$bericht 	= $_POST['message'];
		$datum		= date("d-m-Y H:i");
		$query  = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['topic']}");
		$lol	= mysql_fetch_object($query); 	
		print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You have placed a topic.<BR><BR><a href=\"forum.php?topic={$_GET['topic']}\">Go Back</a></td></tr></table></td></tr></table>\n";
 		mysql_query("INSERT INTO `[foum_replys]`(topicid,datum,login,title,text,date) values($id,'$datum','$data->login','RE:','$bericht',NOW())") or die("There is an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
 		mysql_query("UPDATE `[forum_topics]` SET `replys`=`replys`+1,`datum`='$datum',`date1`=NOW() WHERE `id`={$_GET['topic']}") or die("There was an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
 		mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`+1 WHERE `id`={$lol->subid}") or die("There was an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
 		mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`+1 WHERE `login`='{$data->login}'") or die("There was an error. The following went wrong: <br>\n".mysql_error()."<br>Extra informatie:".mysql_errno());
	}
	else {
	$query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['topic']}");
	$topic = mysql_fetch_object($query);
        $user_query2 = mysql_query("SELECT  UNIX_TIMESTAMP(`online`) AS `online`,`forumstatus`,`login`,`forumposts`,`avaurl` FROM `[users]` WHERE `login`='{$topic->login}'");
        $user2                = mysql_fetch_object($user_query2);

                if($user2->forumstatus == "gwsp9") {
			$status = "<font color=green><b>Owner</b></font>";
		}
		elseif($user2->forumstatus == "gwsp1") {
			$status = "<font color=green><b>Moderator</b></font>";
		}
		elseif($user2->forumstatus == "gwsp2") {
			$status = "<font color=red><b>Webmaster</b></font>";
		}
                elseif($user2->forumposts <= 50) {
			$status = "Forum Cafone";
		}
		elseif($user2->forumposts <= 150) {
			$status = "Forum Mobster";
		}
		elseif($user2->forumposts > 150) {
			$status = "Forum MobBoss";
		}
		elseif($user2->forumposts > 750) {
			$status = "Forum Godfather";
		}
		else {
			$status = "Normaal";
		}
				if(time() - $user2->online < 300) {
					$online2	= "<img src=\"images/icons/online.gif\"> <font color=green><b>Online</b></font>";
				}
				else {
					$online2 = "<img src=\"images/icons/offline.gif\"> <font color=red><b>Offline</b></font>";
				}
      		$topic->text 		= htmlspecialchars($topic->text);      
        	$topic->text 		= nl2br($topic->text);  
		$topic->text 		= str_replace("[b]", "<b>",$topic->text);   
		$topic->text 		= str_replace("[/b]", "</b>",$topic->text);    
		$topic->text 		= str_replace("[i]", "<i>",$topic->text);   
		$topic->text 		= str_replace("[/i]", "</i>",$topic->text);    
		$topic->text 		= str_replace("[u]", "<u>",$topic->text);   
		$topic->text 		= str_replace("[/u]", "</u>",$topic->text);    
       		$topic->text	 	= eregi_replace("\\[color=([^\\[]*)\\]([^\\[]*)\\[/color\\]","<font color=\"\\1\">\\2</font>",$topic->text);     
       		$topic->text 		= eregi_replace("\\[email=([^\\[]*)\\]([^\\[]*)\\[/email\\]", "<a href=\"mailto:\\1\">\\2</a>",$topic->text);    
       		$topic->text 		= eregi_replace("\\[url=([^\\[]*)\\]([^\\[]*)\\[/url\\]","<a href=\"\\1\" target=_blank>\\2</a>",$topic->text);
       		$topic->text 		= eregi_replace("\\[img]([^\\[]*)\\[/img\\]","<img src=\"\\1\">",$topic->text);   
 
		$topic->text 		= str_replace("(h)", "<img src=\"images/smilies/icon_cool.gif\" border=0>",$topic->text);   
		$topic->text 		= str_replace("(H)", "<img src=\"images/smilies/icon_cool.gif\" border=0>",$topic->text);    
		$topic->text 		= str_replace(":$", "<img src=\"images/smilies/icon_embarassed.gif\" border=0>",$topic->text);    
		$topic->text 		= str_replace(":(", "<img src=\"images/smilies/icon_frown.gif\" border=0>",$topic->text); 
		$topic->text 		= str_replace("(a)", "<img src=\"images/smilies/icon_innocent.gif\" border=0>",$topic->text); 
		$topic->text 		= str_replace("(A)", "<img src=\"images/smilies/icon_innocent.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace("(k)", "<img src=\"images/smilies/icon_kiss.gif\" border=0>",$topic->text);  
		$topic->text 		= str_replace("(K)", "<img src=\"images/smilies/icon_kiss.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":D", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":d", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$topic->text); 
		$topic->text 		= str_replace("(m)", "<img src=\"images/smilies/icon_moneyinmouth.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace("(M)", "<img src=\"images/smilies/icon_moneyinmouth.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":#", "<img src=\"images/smilies/icon_sealed.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":)", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":0", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":o", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":O", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":p", "<img src=\"images/smilies/icon_razz.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":P", "<img src=\"images/smilies/icon_razz.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(";)", "<img src=\"images/smilies/icon_wink.gif\" border=0>",$topic->text);        
		$topic->text 		= str_replace(":@", "<img src=\"images/smilies/icon_yell.gif\" border=0>",$topic->text);

                             

		print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><table align=\"center\" width=\"100%\" cellspacing=0><tr><td class=\"mainTxt\"><table width=\"100%\"><tr><td width=\"110\" valign=\"top\"><b><a href=\"profile.php?x={$topic->login}\">$topic->login</a></b><BR>$status<BR><BR><img src=\"{$user2->avaurl}\" width=\"100\" height=\"100\"><BR><BR>$online2<BR>Posts: $user2->forumposts</td><td  valign=\"top\" align=\"left\">$topic->text</td></tr>\n";
		if($data->login == $topic->login) {
			print "	<tr><td><i>$topic->datum1</i></td><td colspan=2 align=\"right\"><a href=\"forum.php?edittopic={$topic->id}\">Edit</a></td></tr></table></td></tr>\n";
		}
		else {
			print "	<tr><td><i>$topic->datum1</i></td><td colspan=2>&nbsp;</td></tr></table></td></tr>\n";
		}
		$query2 = mysql_query("SELECT * FROM `[foum_replys]` WHERE `topicid`={$_GET['topic']} AND `del`=0 ORDER BY `date` ASC LIMIT $begin,10");
		while($forum = mysql_fetch_object($query2)) {
                        $user_query = mysql_query("SELECT  UNIX_TIMESTAMP(`online`) AS `online`,`forumstatus`,`login`,`forumposts`,`avaurl` FROM `[users]` WHERE `login`='{$forum->login}'");
			$user		= mysql_fetch_object($user_query);
			$forum->text 		= htmlspecialchars($forum->text);      
			$forum->text 		= nl2br($forum->text);  
			$forum->text 		= str_replace("[b]", "<b>",$forum->text);   
			$forum->text 		= str_replace("[/b]", "</b>",$forum->text);    
			$forum->text 		= str_replace("[i]", "<i>",$forum->text);   
			$forum->text 		= str_replace("[/i]", "</i>",$forum->text);    
			$forum->text 		= str_replace("[u]", "<u>",$forum->text);   
			$forum->text 		= str_replace("[/u]", "</u>",$forum->text);
			$forum->text	 	= eregi_replace("\\[color=([^\\[]*)\\]([^\\[]*)\\[/color\\]","<font color=\"\\1\">\\2</font>",$forum->text);     
			$forum->text 		= eregi_replace("\\[email=([^\\[]*)\\]([^\\[]*)\\[/email\\]", "<a href=\"mailto:\\1\">\\2</a>",$forum->text);    
			$forum->text 		= eregi_replace("\\[url=([^\\[]*)\\]([^\\[]*)\\[/url\\]","<a href=\"\\1\" target=_blank>\\2</a>",$forum->text); 
			$forum->text 		= eregi_replace("\\[img]([^\\[]*)\\[/img\\]","<img src=\"\\1\">",$forum->text);   
			
			$forum->text 		= eregi_replace("\\[quote]([^\\[]*)\\[/quote\\]","<center><table width=90%><tr><td>Quote:<br><hr color=\"#FFFFFF\" size=1 width=100%></td></tr><tr><td>\\1</td></tr><tr><td><hr color=\"#FFFFFF\" size=1 width=100%></td></tr></table></center>",$forum->text);   
			$forum->text 		= str_replace("(h)", "<img src=\"images/smilies/icon_cool.gif\" border=0>",$forum->text);   
			$forum->text 		= str_replace("(H)", "<img src=\"images/smilies/icon_cool.gif\" border=0>",$forum->text);    
			$forum->text 		= str_replace(":$", "<img src=\"images/icons/smilies/icon_embarassed.gif\" border=0>",$forum->text);    
			$forum->text 		= str_replace(":(", "<img src=\"images/smilies/icon_frown.gif\" border=0>",$forum->text); 
			$forum->text 		= str_replace("(a)", "<img src=\"images/smilies/icon_innocent.gif\" border=0>",$forum->text); 
			$forum->text 		= str_replace("(A)", "<img src=\"images/smilies/icon_innocent.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace("(k)", "<img src=\"images/smilies/icon_kiss.gif\" border=0>",$forum->text);  
			$forum->text 		= str_replace("(K)", "<img src=\"images/smilies/icon_kiss.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":D", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":d", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$forum->text); 
			$forum->text 		= str_replace("(m)", "<img src=\"images/smilies/icon_moneyinmouth.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace("(M)", "<img src=\"images/smilies/icon_moneyinmouth.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":#", "<img src=\"images/smilies/icon_sealed.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":)", "<img src=\"images/smilies/icon_smile.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":0", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":o", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":O", "<img src=\"images/smilies/icon_surprised.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":p", "<img src=\"images/smilies/icon_razz.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":P", "<img src=\"images/smilies/icon_razz.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(";)", "<img src=\"images/smilies/icon_wink.gif\" border=0>",$forum->text);        
			$forum->text 		= str_replace(":@", "<img src=\"images/smilies/icon_yell.gif\" border=0>",$forum->text);


                                $forum->text  		= str_replace("\r'", "'", $forum->text);
                                $forum->text  		= str_replace("\n'", "'", $forum->text);
                                $forum->text  		= str_replace("\r'", "'", $forum->text);
                                $forum->text  		= str_replace("\r\n\r\n\r\n'", "'", $forum->text);
                                $forum->text  		= str_replace("\r\n\r\n'", "'", $forum->text);


                if($user->forumstatus == "gwsp9") {
			$status = "<font color=green><b>Owner</b></font>";
		}
		elseif($user->forumstatus == "gwsp1") {
			$status = "<font color=green><b>Moderator</b></font>";
		}
		elseif($user->forumstatus == "gwsp2") {
			$status = "<font color=red><b>Webmaster</b></font>";
		}
		elseif($user->forumposts <= 50) {
			$status = "Forum Cafone";
		}
		elseif($user->forumposts <= 150) {
			$status = "Forum Mobster";
		}
		elseif($user->forumposts > 150) {
			$status = "Forum MobBoss";
		}
		elseif($user->forumposts > 750) {
			$status = "Forum Godfather";
		}
		else {
			$status = "Normaal";
		}

				if(time() - $user->online < 300) {
					$online	= "<img src=\"images/icons/online.gif\"> <font color=green><b>Online</b></font>";
				}
				else {
					$online = "<img src=\"images/icons/offline.gif\"> <font color=red><b>Offline</b></font>";
				}
			print "	<tr><td class=\"mainTxt\"><table width=\"100%\"><tr><td width=\"110\" valign=\"top\"><b><a href=\"profile.php?x={$forum->login}\">$forum->login</a></b><BR>$status<BR><BR><img src=\"{$user->avaurl}\" width=\"100\" height=\"100\"><BR><BR>$online<BR>Posts: $user->forumposts</td><td valign=\"top\" align=\"left\">$forum->text</td></tr>\n";
			if($data->forumstatus == "gwsp1" || $data->forumstatus == "gwsp2" || $data->forumstatus == "gwsp9") {
				print "	<tr><td><i>$forum->datum</i></td><td colspan=3 align=\"right\"><a href=\"forum.php?delreply={$forum->id}\">Remove</a> | <a href=\"forum.php?editreply={$forum->id}\">Edit</a> | <a href=\"forum.php?reageer={$topic->id}&quote={$forum->id}\">Quote</a></td></tr></table></td></tr>\n";
			}
			elseif($data->login == $forum->login) {
				print "	<tr><td><i>$forum->datum</i></td><td colspan=3 align=\"right\"><a href=\"forum.php?editreply={$forum->id}\">Edit</a></td></tr></table></td></tr>\n";
			}
			else {
				print "	<tr><td><i>$forum->datum</i></td><td colspan=3><a href=\"forum.php?reageer={$topic->id}&quote={$forum->id}\">Quote</a></td></tr></table></td></tr>\n";
			}
		}
		print "	<tr><td class=\"mainTxt\"><b>Pages:</b> \n";
		$dbres = mysql_query("SELECT * FROM `[foum_replys]` WHERE `topicid`={$_GET['topic']} AND `del`=0");
                $sub_query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['topic']}");
                $sub = mysql_fetch_object($sub_query);
			print "";
					for($i=0; $i<mysql_num_rows($dbres)/10; $i++) {
						print " <a href=\"forum.php?topic={$_GET['topic']}&p={$i}0\" target=\"_self\">". ($i+1) ."</a> ";
					}
echo "<a href=\"forum.php\">Forum Index</a> | <a href=\"forum.php?sub=$sub->subid\">Go back to the Forum</a>";
		if($topic->slotje == 1) {
		

	print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\"><font color=red><b>The topic has been closed.</b></font></td></tr></table></tr></td></table></td></tr></table>\n";
		
		}
		elseif($topic->slotje == 0 && $data->forumstatus == "gwsp9") {
			print " </td></tr><tr><tr>CLOSE&nbsp;TOPIC</td></tr><tr><td align=\"center\" class=\"subTitle\"><B>Reply</b></td></tr><form method=\"post\"><tr><td align=\"center\" class=\"mainTxt\"><textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"10000\"></textarea><BR><input type=\"submit\" name=\"add\" value=\" Add\">&nbsp;<input type=\"button\" value=\" Top \" onclick=\"window.location=('#top')\"></td></tr></form><tr><td align=\"center\"><BR><a href=\"forum.php?slotje={$topic->id}\"><img src=\"images/icons/closed.gif\" border=0></a></td></tr><tr></table></tr></td></table></td></tr></table>\n";
		
                }
                elseif($topic->slotje == 0 && $data->forumstatus == "gwsp1") {
			print " </td></tr><tr><tr>CLOSE&nbsp;TOPIC</td></tr><tr><td align=\"center\" class=\"subTitle\"><B>Reply</b></td></tr><form method=\"post\"><tr><td align=\"center\" class=\"mainTxt\"><textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"10000\"></textarea><BR><input type=\"submit\" name=\"add\" value=\" Add\">&nbsp;<input type=\"button\" value=\" Top \" onclick=\"window.location=('#top')\"></td></tr></form><tr><td align=\"center\"><BR><a href=\"forum.php?slotje={$topic->id}\"><img src=\"images/icons/closed.gif\" border=0></a></td></tr><tr></table></tr></td></table></td></tr></table>\n";
		}
		elseif($topic->slotje == 0 && $data->forumstatus == "gwsp2") {
			print " </td></tr><tr><tr>CLOSE&nbsp;TOPIC</td></tr><tr><td align=\"center\" class=\"subTitle\"><B>Reply</b></td></tr><form method=\"post\"><tr><td align=\"center\" class=\"mainTxt\"><textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"10000\"></textarea><BR><input type=\"submit\" name=\"add\" value=\" Add \">&nbsp;<input type=\"button\" value=\" Top \" onclick=\"window.location=('#top')\"></td></tr></form><tr><td align=\"center\"><BR><a href=\"forum.php?slotje={$topic->id}\"><img src=\"images/icons/closed.gif\" border=0></a></td></tr><tr></table></tr></td></table></td></tr></table>\n";
		}
		else {
			print " </td></tr><tr><tr>&nbsp;</td></tr><tr><td align=\"center\" class=\"subTitle\"><B>Reply</b></td></tr><form method=\"post\"><tr><td align=\"center\" class=\"mainTxt\"><textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"10000\"></textarea><BR><input type=\"submit\" name=\"add\" value=\" Add \">&nbsp;<input type=\"button\" value=\" Top \" onclick=\"window.location=('#top')\"></td></tr></form></table></tr></td></table></td></tr></table>\n";
		}
	}
}
elseif($_GET['slotje']) {
	if($data->forumstatus == "gwsp1" || $data->forumstatus == "gwsp2" || $data->forumstatus == "gwsp9") {
		mysql_query("UPDATE `[forum_topics]` SET `slotje`=1 WHERE `id`={$_GET['slotje']}");
		print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You have closed this topic.<BR><BR><a href=\"forum.php?topic={$_GET['slotje']}\">Return</a></tr></td></table></td></tr></table>\n";
	}
}
elseif($_GET['delreply']) {
	if($data->forumstatus == "gwsp1" || $data->forumstatus == "gwsp2" || $data->forumstatus == "gwsp9") {
		$query = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['delreply']}");
		$reply = mysql_fetch_object($query);
		$query2 = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$reply->topicid}");
		$topic = mysql_fetch_object($query2);
		mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`-1 WHERE `login`='{$reply->login}'");
		mysql_query("UPDATE `[foum_replys]` SET `del`=1 WHERE `id`={$_GET['delreply']}");
		mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`-1 WHERE `id`={$topic->subid}");
		mysql_query("UPDATE `[forum_topics]` SET `replys`=`replys`-1 WHERE `id`={$topic->id}");
		print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Message successfully removed.</tr></td></table></td></tr></table>\n";
	}
}
elseif($_GET['verplaats']) {
	if($data->forumstatus == "gwsp1" || $data->forumstatus == "gwsp2" || $data->forumstatus == "gwsp9") {
		$topic_query 	= mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['verplaats']}");
		$topic	   		= mysql_fetch_object($topic_query);		
		$sub_query 		= mysql_query("SELECT * FROM `[forum_sub]` ORDER BY `area` ASC");
		if(isset($_POST['verplaats'])) {
			mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`-{$topic->replys},`topics`=`topics`-1 WHERE `id`={$topic->subid}");
			mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`+{$topic->replys},`topics`=`topics`+1 WHERE `id`={$_POST['forum']}");
			mysql_query("UPDATE `[forum_topics]` SET `subid`={$_POST['forum']} WHERE `id`={$_GET['verplaats']}");
			print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">Move Topic.</tr></td></table></td></tr></table>\n";
		}
		else {
			print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\"><b>$topic->title</b><BR><form method=\"post\">Forum:<br><select name=\"forum\">\n";
			while($sub = mysql_fetch_object($sub_query)) {
				print "<option value=\"{$sub->id}\">$sub->title</option>";
			}
			print "</select> <input type=\"submit\" name=\"verplaats\" value=\" Move \"></form></tr></td></table></td></tr></table>\n";
		}
	}
	else {
			print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You cant move messgaes</tr></td></table></td></tr></table>\n";
	}
}
elseif($_GET['reageer']) {
	if(isset($_POST['add'])) {
		$id	   		= $_GET['reageer'];
		$bericht 	= $_POST['message'];
		$datum		= date("d-m-Y H:i");
		$query  = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['topic']}");
		$lol	= mysql_fetch_object($query); 	
		print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You have placed a message.<BR><BR><a href=\"forum.php?topic={$_GET['topic']}\">Return</a></td></tr></table></td></tr></table>\n";
 		mysql_query("INSERT INTO `[foum_replys]`(topicid,datum,login,title,text,date) values($id,'$datum','$data->login','RE:','$bericht',NOW())") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
 		mysql_query("UPDATE `[forum_topics]` SET `replys`=`replys`+1,`datum`='$datum',`date1`=NOW() WHERE `id`={$_GET['reageer']}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
 		mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`+1 WHERE `id`={$lol->subid}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
 		mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`+1 WHERE `login`='{$data->login}'") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
	}
	else {
		$query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['reageer']}");
		$topic = mysql_fetch_object($query);
		if($topic->slotje == 0) {
		  if($_GET['quote']) {
		  	$quote_query = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['quote']}");
			$reply = mysql_fetch_object($quote_query);
			$quote = "[quote={$reply->login}]{$reply->text}[/quote]";
		  }
		  print " <table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\" class=\"subTitle\"><B>Reply</b></td></tr><form method=\"post\"><tr><td align=\"center\" class=\"mainTxt\"><textarea rows=\"6\" name=\"message\" cols=\"60\" maxlength=\"10000\">{$quote}</textarea><BR><input type=\"submit\" name=\"add\" value=\" Add\">&nbsp;<input type=\"button\" value=\" Top \" onclick=\"window.location=('#top')\"></td></tr></form></table></tr></td></table>\n";
		}
	}
}
elseif($_GET['newtopic']) {
	if(isset($_POST['add'])) {
		$id	   		= htmlspecialchars(addslashes($_GET['newtopic']));
		$titel 		= htmlspecialchars(addslashes($_POST['title']));
		$bericht 	= htmlspecialchars(addslashes($_POST['message']));
		$datum		= date("d-m-Y H:i");
		print "	<table width=\"100%\" cellspacing=0><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td class=\"subTitle\" align=\"left\"><b><img src=\"images/icons/blokje.jpg\"> Forum</b></td></tr><tr><td align=\"center\">You have placed a message.</tr></td></table></td></tr></table>\n"; echo "<a href=\"forum.php\">Forum Index</a> | <a href=\"forum.php?sub=$sub->subid\">Go back to the Forum</a>";
 		mysql_query("INSERT INTO `[forum_topics]`(subid,datum1,login,title,text,date,date1) values($id,'$datum','$data->login','$titel','$bericht',NOW(),NOW())") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
 		mysql_query("UPDATE `[forum_sub]` SET `topics`=`topics`+1 WHERE `id`={$id}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
 		mysql_query("UPDATE `[users]` SET `forumposts`=`forumposts`+1 WHERE `login`='{$data->login}'") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
	}
	else {
	print <<<ENDHTML
<script language="javascript">
function icon(theicon) {
document.form3.info.value += ""+theicon;
document.form3.info.focus();
}

function setsmilie(which){
document.form3.info.value = document.form3.info.value + which;
}

</script>
<table width="100%" cellspacing=0>
  <tr><td class="subTitle"><b>Forum</b></td></tr>
	<tr><td class="mainTxt">
		<table width="100%" align="center">
			<tr><td class="mainTxt">
				<table align="center" width="100%">
					<form method="post" name="form1">
						<tr><td class="subTitle" colspan=3><b>New Topic</b></td><td width=\"100%"></td></tr>
						<tr>
							<td>Titel:</td>
							<td><input type="text" size="20" name="title"></td><td width="100%"></td>
						</tr>
						<tr>
							<td>Message:</td>
							<td>
							<input type="button" value="B" style="font-weight:bold; width: 30px" onClick="javascript:icon('[b] [/b]')">
							<input type="button" value="i" style="font-style:italic; width: 30px" onClick="javascript:icon('[i] [/i]')">
							<input type="button" value="u" style="text-decoration: underline; width: 30px" onClick="javascript:icon('[u] [/u]')">
							<input type="button" value="Url" onClick="javascript:icon('[url=] [/url]')">
							<input type="button" value="E-mail" onClick="javascript:icon('[email=] [/email]')">
							<input type="button" value="Colour" onClick="javascript:icon('[color=] [/color]')">
							<input type="button" value="Img" onClick="javascript:icon('[img] [/img]')"><br>
							<textarea rows="15" name="message" cols="50" maxlength="10000"></textarea></td><td width="100%"></td>
						</tr>
						<tr><td></td><td align="right"><input type="submit" name="add" value="Add"></td><td width="100%"></td><td width="100%"></td></tr>
					</form>
				</table>
			</tr></td>
		</table>
	</td></tr>
</table>
ENDHTML;
	}
}
elseif($_GET['edittopic']) {
	$query = mysql_query("SELECT * FROM `[forum_topics]` WHERE `id`={$_GET['edittopic']} AND `login`='{$data->login}'");
	$num = mysql_num_rows($query);
	$topic = mysql_fetch_object($query);
	if($num == 1) {
		if(isset($_POST['change'])) {
			$titel 		= htmlspecialchars(addslashes($_POST['title']));
			$bericht 	= htmlspecialchars(addslashes($_POST['message']));
			$id	   		= htmlspecialchars(addslashes($_GET['edittopic']));
			print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">The message has been edited.</tr></td></table></td></tr></table>\n";echo "<a href=\"forum.php\">Forum Index</a> | <a href=\"forum.php?sub=$sub->subid\">Go back to the Forum</a>";
			mysql_query("UPDATE `[forum_topics]` SET `title`='{$titel}',`text`='{$bericht}' WHERE `id`={$id}") or die("There has been an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
		}
		else {
			print "	<table width=\"100%\" cellspacing=0>\n";
			print "		<tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
			print "		<tr><td class=\"mainTxt\">\n";
			print "			<table width=\"100%\" align=\"center\">\n";
			print "				<tr><td class=\"mainTxt\">\n";
			print "					<table align=\"center\" width=\"100%\"><form method=\"post\">\n";
			print " 				<tr><td class=\"mainTxt\" colspan=3>Work Topic</td></tr>\n";
			print " 				<tr><td>Title:</td><td><input type=\"text\" value=\"$topic->title\" size=\"20\" name=\"title\"></td><td width=\"100%\"></td></tr>\n";
			print " 				<tr><td>Message:</td><td><textarea name=\"message\" cols=40 rows=10>$topic->text</textarea></td><td width=\"100%\"></td></tr>\n";
			print " 				<tr><td></td><td align=\"right\"><input type=\"submit\" name=\"change\" value=\"Change\"></td><td width=\"100%\"></td></tr>\n";
			print " 				</form</table>\n";
			print "				</tr></td>\n";
			print "			</table>\n";
			print "		</td></tr>\n";
			print "	</table>\n";
		}
	}
	else {
		print "	<table width=\"100%\" cellspacing=0>\n";
		print "		<tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
		print "		<tr><td class=\"mainTxt\">\n";
		print "			<table width=\"100%\" align=\"center\">\n";
		print "				<tr><td align=\"center\">\n";
		print "				Error!\n";
		print "				</tr></td>\n";
		print "			</table>\n";
		print "		</td></tr>\n";
		print "	</table>\n";
	}
}
elseif($_GET['editreply']) {
	$query = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['editreply']} AND `login`='{$data->login}'");
	$num = mysql_num_rows($query);
	$topic = mysql_fetch_object($query);
	if($num == 1) {
		if(isset($_POST['change'])) {
			$titel 		= htmlspecialchars(addslashes($_POST['title']));
			$bericht 	= htmlspecialchars(addslashes($_POST['message']));
			$id	   		= htmlspecialchars(addslashes($_GET['editreply']));
			print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You have changed the message.</tr></td></table></td></tr></table>\n";
			mysql_query("UPDATE `[foum_replys]` SET `text`='{$bericht}' WHERE `id`={$id}") or die("There was an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());

		}
		else {
			print "	<table width=\"100%\" cellspacing=0>\n";
			print "		<tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
			print "		<tr><td class=\"mainTxt\">\n";
			print "			<table width=\"100%\" align=\"center\">\n";
			print "				<tr><td class=\"mainTxt\">\n";
			print "					<table align=\"center\" width=\"100%\"><form method=\"post\">\n";
			print " 				<tr><td class=\"mainTxt\" colspan=3>Work Replies</td></tr>\n";
			print " 				<tr><td>Message:</td><td><textarea name=\"message\" cols=40 rows=10>$topic->text</textarea></td><td width=\"100%\"></td></tr>\n";
			print " 				<tr><td></td><td align=\"right\"><input type=\"submit\" name=\"change\" value=\"Change\"></td><td width=\"100%\"></td></tr>\n";
			print " 				</form</table>\n";
			print "				</tr></td>\n";
			print "			</table>\n";
			print "		</td></tr>\n";
			print "	</table>\n";
		}
	}
	elseif($data->forumstatus == "gwsp1" || $data->forumstatus == "gwsp2" || $data->forumstatus == "gwsp9") {
		$query2 = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['editreply']}");
		$topic2 = mysql_fetch_object($query2);
		if(isset($_POST['change'])) {
			$titel 		= $_POST['title'];
			$bericht 	= $_POST['message'];
			$id	   		= $_GET['editreply'];
			print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You have changed the message.</tr></td></table></td></tr></table>\n";
			mysql_query("UPDATE `[foum_replys]` SET `text`='{$bericht}' WHERE `id`={$id}") or die("There was an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());

		}
		else {
			print "	<table width=\"100%\" cellspacing=0>\n";
			print "		<tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
			print "		<tr><td class=\"mainTxt\">\n";
			print "			<table width=\"100%\" align=\"center\">\n";
			print "				<tr><td class=\"mainTxt\">\n";
			print "					<table align=\"center\" width=\"100%\"><form method=\"post\">\n";
			print " 				<tr><td class=\"mainTxt\" colspan=3>Work Reply</td></tr>\n";
			print " 				<tr><td>Message:</td><td><textarea name=\"message\" cols=40 rows=10>$topic2->text</textarea></td><td width=\"100%\"></td></tr>\n";
			print " 				<tr><td></td><td align=\"right\"><input type=\"submit\" name=\"change\" value=\"Change\"></td><td width=\"100%\"></td></tr>\n";
			print " 				</form</table>\n";
			print "				</tr></td>\n";
			print "			</table>\n";
			print "		</td></tr>\n";
			print "	</table>\n";
		}
	}
	else {
		print "	<table width=\"100%\" cellspacing=0>\n";
		print "		<tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
		print "		<tr><td class=\"mainTxt\">\n";
		print "			<table width=\"100%\" align=\"center\">\n";
		print "				<tr><td align=\"center\">\n";
		print "				Error!\n";
		print "				</tr></td>\n";
		print "			</table>\n";
		print "		</td></tr>\n";
		print "	</table>\n";
	}
}
elseif($_GET['delreply']) {
	$query = mysql_query("SELECT * FROM `[foum_replys]` WHERE `id`={$_GET['delreply']} AND `login`='{$data->login}'");
	$num = mysql_num_rows($query);
	$topic = mysql_fetch_object($query);
	if($num == 1) {
			$query2 = mysql_query("SELECT * FROM `[foum_topics]` WHERE `id`={$topic->topicid}");
			$sub = mysql_fetch_object($query2);
			$id = $_GET['delreply'];
			print "	<table width=\"100%\" cellspacing=0><tr><td class=\"subTitle\"><b>Forum</b></td></tr><tr><td class=\"mainTxt\"><table width=\"100%\" align=\"center\"><tr><td align=\"center\">You have removed the topic.</tr></td></table></td></tr></table>\n";
			mysql_query("DELETE FROM `[foum_replys]` WHERE `id`='{$id}'");
	 		mysql_query("UPDATE `[forum_topics]` SET `replys`=`replys`-1 WHERE `id`='{$topic->topicid}'");
 			mysql_query("UPDATE `[forum_sub]` SET `replys`=`replys`-1 WHERE `id`='{$sub->subid}'") or die("There was an error. The following went wrong: <br>\n".mysql_error()."<br>Extra information:".mysql_errno());
	}
	else {
		print "	<table width=\"100%\" cellspacing=0>\n";
		print "		<tr><td class=\"subTitle\"><b>Forum</b></td></tr>\n";
		print "		<tr><td class=\"mainTxt\">\n";
		print "			<table width=\"100%\" align=\"center\">\n";
		print "				<tr><td align=\"center\">\n";
		print "				Error!\n";
		print "				</tr></td>\n";
		print "			</table>\n";
		print "		</td></tr>\n";
		print "	</table>\n";
	}
}
else {

print " <center><table width=75%><tr><td class=Subtitle colspan=2>Forum</tr></td><tr><td class=Maintxt>Welcome to the forum. Select a Category<br> Have you read the rules!
</a></tr></td></td></tr></table>\n";

	print "	<table width=\"75%\" align=\"center\"></tr></td></table><tr><td><table align=\"center\" width=\"70%\"><tr><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"70%\" colspan=\"1\"><b>General</b></td><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"10%\"><b>Topics</b></td><td align=\"center\" class=\"subTitle\" style=\"letter-spacing: normal;\" width=\"15%\"><b>Replies</b></td></tr>\n";
			$query = mysql_query("SELECT * FROM `[forum_sub]` WHERE `area`=1");
			while($forum = mysql_fetch_object($query)) {
			print "	<tr  onClick=\"window.location.href='forum.php?sub={$forum->id}'\"><td class=maintxt width=\"80%\"><img src=images/icons/arrow.gif><a href=\"forum.php?sub={$forum->id}\" target=\"_self\"><b>$forum->title</b></a><br>$forum->text</td><td align=\"center\" class=maintxt width=\"10%\">$forum->topics</td><td class=maintxt align=\"center\" width=\"10%\">$forum->replys</td></tr>\n";
			}


}
?>
</body>

</html>
