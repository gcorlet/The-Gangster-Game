<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) { 
    header("Location: login.php"); 
    exit; 
  } 

mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'"); 

$p=$_GET['p']; // 
$time = time();
$fraudetijd = (time() + 120); //
	
/* ------------------------- */ ?><head> 
<title><?php echo $page->sitetitle; ?></title>
<title></title> 
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="text/css" href="css/bootstrap.css">

<LINK href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css" type=text/css rel=stylesheet>


 

<TABLE width="70%" align=center>
  <TBODY>
  <TR>
    <TD class=subtitle><b>Pledge Fraud</b></TD></TD>
 <?php
echo" <tr>
<td class=maintxt><center><img src=images/game/fraude.jpg witdh=150></td></tr>
<tr>
<TD class=subtitle><b>Options</b></TD></TD>
      <tr>
        <td class=maintxt><center><A href=\"fraud.php?p=fraudeer\" class='btn btn-info'>Pledge Fraud
        <br><center><A href=\"fraud.php?p=stats\" class='btn btn-info'>Statistics</tr>
  </TD></TR>
";

if($p == stats){
$timer2 = gmdate('i:s',($data->fraudetijd - time()));;
 if($data->gelukt > $data->mislukt) {
        $gesnapt = Good;
        }
        elseif($data->gelukt < $data->mislukt) {
        $gesnapt = Shit;
        }
        elseif($data->gelukt = $data->mislukt) {
        $gesnapt = Chill;
        }
        if($data->fraudetijd - time() < 0) {
        $pleeg = Now;
        }
        elseif($data->fraudetijd - time() > 0) { 
        $pleeg = $timer2;
        }

print <<<ENDHTML
<TR><TD class=maintxt><center>Status: <b>{$gesnapt}</b>
      <tr><TD class=maintxt><center>Fraud: <b>{$pleeg}</b>
       <tr><TD class=maintxt ><center>Total Profit from Fraud: <b>{$data->winst}</b></td></tr>
      
ENDHTML;
} 
elseif($p == fraudeer){
if(isset($_POST['bedrijf'])) {
$data->bedrijf        = $_POST['type'];
$bedrijf        = $_POST['type'];
${"select$type"}      = "selected";
mysql_query("UPDATE `[users]` SET `type`='{$data->bedrijf}' WHERE `login`='{$data->login}'");
print "<tr><td class=\"mainTxt\" align=\"center\">The fraud you want to commit has been changed to $data->bedrijf!</td></tr>\n";
}

$codene = rand(100,2500); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee);echo" <form method=post>
   <tr><td class=maintxt align=center><b>Which fraud will you commit!</b>
   <tr><td class=maintxt align=center><select type=type class='btn btn-info' name=type style=width=150>
              <option value=Bank $select1 class='btn btn-info'>Bank</option>
              <option value=Insurance $select2 class='btn btn-info'>Life Insurance</option>
              <option value=Tax $select3 class='btn btn-info'>Tax Income</option>
              </select><input type=submit name=bedrijf value=Select class='btn btn-info'>
   <br>
   <tr><td class=maintxt align=center><b>Commiting a fraud can lead to success or failure!</b>
   <input name=code2 type=hidden class='btn btn-info' value=$codene>
   <input name=codecheck type=hidden class='btn btn-info' value=$codechecker>
   <tr><td class=maintxt align=center><b>Code -></b></font><input type=text class='btn btn-info' name=code size=2> <input type=submit class='btn btn-info' name=fraude value=\"Commit Fraud\" size=200>    </form>
<tr><td class=maintxt align=center><img src=coden.php?security=$codee>"; 

if(!empty($_POST['fraude'])) {
$rand=rand(1,100);
$winst=rand(999,99999);
$timer = gmdate('i:s',($data->fraudetijd - time()));
if($_POST['code'] != $_POST['code2']) {
print "
<tr><td class=Subtitle>Wrong Code</td></tr>
<tr><td class=mainTxt><font color=red><center><img src='images/icons/light_error.jpg' width='16' height='16'>You entered an invalid code!</font></td></tr>";
}
elseif($data->fraudetijd - time() > 0) { 
print " <tr><td class=\"mainTxt\"><center><b>You must wait $timer until you commit another fraud</b></td></tr>\n";
}
elseif($rand > 50){
mysql_query("UPDATE `[users]` SET `fraudetijd`='$fraudetijd' WHERE `login`='{$data->login}'"); 
 mysql_query("UPDATE `[users]` SET `winst`=winst+'$winst' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$winst' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `gelukt`=gelukt+'1' WHERE `login`='{$data->login}'");
print " <tr><td class=\"mainTxt\"><align=left><b>Congratulations you successfully commited the perfect fraud. You gained <font color=green>$winst profit!</b></font></td></tr>\n";
}
elseif($rand > 40){
mysql_query("UPDATE `[users]` SET `fraudetijd`='$fraudetijd' WHERE `login`='{$data->login}'");  
   mysql_query("UPDATE `[users]` SET `mislukt`=mislukt+'1' WHERE `login`='$data->login'");
print " <tr><td  class=\"mainTxt\" ><b><align=left>Lesson number 1, The <?=$data->bedrijf ?> Fraud failed! Dont leave the papers behind!</b></td></tr>\n";
}
elseif($rand > 20){
mysql_query("UPDATE `[users]` SET `fraudetijd`='$fraudetijd' WHERE `login`='{$data->login}'");  
   mysql_query("UPDATE `[users]` SET `mislukt`=mislukt+'1' WHERE `login`='$data->login'");
print "  <tr><td  class=\"mainTxt\"><b><align=left>Lesson Number 2, The <?=$data->bedrijf ?> Fraud failed. Awlays take a pen and paper with you!</b></td></tr>\n";
	}
elseif($rand > 15){
mysql_query("UPDATE `[users]` SET `fraudetijd`='$fraudetijd' WHERE `login`='{$data->login}'");  
   mysql_query("UPDATE `[users]` SET `mislukt`=mislukt+'1' WHERE `login`='$data->login'");
print "  <tr><td class=\"mainTxt\"><align=left><b>Lesson Number 3, The <?=$data->bedrijf; ?> Fraud Failed. Always go through the plan before going through with it!</b></td></tr>\n";
}



}

echo"</tr></td>";
}

 ?>
 
</TR></TBODY></TABLE>