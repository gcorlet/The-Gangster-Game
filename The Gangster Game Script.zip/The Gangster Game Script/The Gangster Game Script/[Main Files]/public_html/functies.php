<?php
error_reporting(0);

include_once("_include-config.php");
    include("_include-gevangenis.php");
ob_start();
// Status & Balken Start
// Rankbalk Functie
function rankvord()
{
$userQuery = mysql_query("SELECT rankvord FROM `[users]` WHERE login='".$_SESSION['login']."'") or die (mysql_error());
$data = mysql_fetch_assoc($userQuery);

	if($data['rankvord'] > 50) 
	{
	 echo "
	 <table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100'>
	 <tr>
	 <td width='".$data['rankvord']."%' height='14' bgcolor='#00FF00'><font color='#000000'><p align='center'><b>".$data['rankvord']."%</b></font></td>
	 <td width='".$data['rankvord'].">%' height='14' bgcolor='#008000'></td></tr>
	 </table>
	 </td>
	</tr>";

	}
	else
	{
	echo "
	<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='100'>
	<td width='".$data['rankvord']."' height='14' bgcolor='#00FF00''></td>
	<td width='100' height='14' bgcolor='#008000'><b><font color='#FFFFFF'>".$data['rankvord']."%</font></td></tr>
	</table>	  
	</td></tr>
	";
	}
}
// Function MissieTijd
function missietijd()
{
 $queryMissie = mysql_query("SELECT gebruikersnaam FROM missie WHERE gebruikersnaam='".$_SESSION['login']."'");
 $missieRows = mysql_num_rows($queryMissie);

 $Nu = mktime( date('h'), date('i'), date('s'), date('m'), date('d'), date('Y') );
 $Eind = mktime( date('h')+1, 0, 0, date('m'), date('d'), date('Y') );
 $Verschil = $Eind-$Nu;

	if($missieRows == 0)
	{
 	 echo "Nu";
	}
	else
	{
	 echo "00:".date('i:s', $Verschil)."";
	}
}
// Misdaad
function misdaadtijd()
{
 $queryMisdaad = mysql_query("SELECT *,UNIX_TIMESTAMP(`misdaad`) AS `misdaad`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aMisdaad = mysql_fetch_assoc($queryMisdaad);
 $sMisdaadtijd = (( $aMisdaad['misdaad'] + $aMisdaad['misdaadtime']) - time()) - 3600; // Neemt tijd uit database, doet er 2 minuten bij en trekt de huidige tijd ervanaf

	if($aMisdaad['misdaad'] + $aMisdaad['misdaadtime'] < time())
	{
	 echo "Nu";
	}
	else
	{
	 echo "00:".date("i:s", "$sMisdaadtijd")."";
	}
}
function autosteeltijd()
{
 $queryAuto = mysql_query("SELECT *,UNIX_TIMESTAMP(`auto`) AS `auto`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aAuto = mysql_fetch_assoc($queryAuto);
 $sAutotijd = ( $aAuto['auto'] + $aAuto['autotime'] ) - time();

	if($sAutotijd <= -1)
	{
	 echo "Nu";
	}
	else
	{
	 echo "00:".date("i:s", "$sAutotijd")."";
	}
}
function sportschooltijd()
{
 $queryOpdruk = mysql_query("SELECT *,UNIX_TIMESTAMP(`opdruktijd`) AS `opdruktijd`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aOpdruk = mysql_fetch_assoc($queryOpdruk);
 $sOpdruktijd = (($aOpdruk['opdruktijd'] + $aOpdruk['opdruktijd1']) - time()) - 3600;

	if($aOpdruk['opdruktijd'] + $aOpdruk['opdruktijd1'] < time())
	{
	 echo "Nu";
	}
	else
	{
	 echo date("H:i:s", "$sOpdruktijd");
	}
}
function gevangenistijd()
{
 $queryGevangenis = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aGevang = mysql_fetch_assoc($queryGevangenis);
 $sGevangtijd = $aGevang['gevangenis'] + $aGevang['gevangenistijd'] - time() - 3600;
	if($aGevang['gevangenis'] + $aGevang['gevangenistijd'] < time())
	{
	 echo "00:00:00";
	}
	else
	{
	 echo date("H:i:s", "$sGevangtijd");
	}
}
function beschermingtijd()
{
 $queryBescherming = mysql_query("SELECT *,UNIX_TIMESTAMP(`bescherming`) AS `bescherming`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aBescherming = mysql_fetch_assoc($queryBescherming);
 $sBescherming = $aBescherming['bescherming'] + $aBescherming['beschermingtijd'] - time() - 3600;
	if($aBescherming['bescherming'] + $aBescherming['beschermingtijd'] < time())
	{
	 echo "00:00:00";
	}
	else
	{
	 echo date("H:i:s", "$sBescherming");
	}
}
function werktijd()
{
 $queryWerk = mysql_query("SELECT *,UNIX_TIMESTAMP(`werken`) AS `werken`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aWerk = mysql_fetch_assoc($queryWerk);
 $sWerk = (($aWerk['werken'] + $aWerk['werken1']) - time()) - 3600;
	if($aWerk['werken'] + $aWerk['werken1'] < time())
	{
	 echo "Nu";
	}
	else
	{
	 echo date("H:i:s", "$sWerk");
	}
}
function gevangenis()
{
 $queryGevangenis = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aGevangenis = mysql_fetch_assoc($queryGevangenis);
 $sGevangenis = $aGevangenis['gevangenis'] + $aGevangenis['gevangenistijd'] - time() - 3600;
 
	if($aGevangenis['gevangenis'] + $aGevangenis['gevangenistijd'] > time())
	{
echo "<table width='100%' cellspacing='1' cellpadding='2'>
	  <tr><td class='subTitle'>Gevangenis</td></tr>
	  <tr><td class='mainTxt'>Je zit nog voor ".date("H:i:s", "$sGevangenis")." seconden/minuten in de gevangenis.</td></tr>
      </table>";
	exit;
	}
}

function sportschool()
{
 $querySport = mysql_query("SELECT *,UNIX_TIMESTAMP(`opdruktijd`) AS `opdruktijd`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aSport = mysql_fetch_assoc($querySport);
 $sSport = $aSport['opdruktijd'] + $aSport['opdruktijd1'] - time() - 3600;
 
	if($aSport['opdruktijd'] + $aSport['opdruktijd1'] > time())
	{
echo "<table width='100%' cellspacing='1' cellpadding='2'>
	  <tr><td class='subTitle'>Sportschool</td></tr>
	  <tr><td class='mainTxt'>Je moet nog ".date("H:i:s", "$sSport")." seconden/minuten wachten voordat je weer kan sporten.</td></tr>
      </table>";
	exit;
	}
}

function misdaad()
{
 $queryMisdaad = mysql_query("SELECT *,UNIX_TIMESTAMP(`misdaad`) AS `misdaad`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aMisdaad = mysql_fetch_assoc($queryMisdaad);
 $sMisdaad = $aMisdaad['misdaad'] + $aMisdaad['misdaadtime'] - time() - 3600;
 
	if($aMisdaad['misdaad'] + $aMisdaad['misdaadtime'] > time())
	{
echo "<table width='100%' cellspacing='1' cellpadding='2'>
	  <tr><td class='subTitle'>Misdaad</td></tr>
	  <tr><td class='mainTxt'>Je moet nog ".date("H:i:s", "$sMisdaad")." seconden/minuten wachten voordat je weer een misdaad kan doen.</td></tr>
      </table>";
	exit;
	}
}
function werken()
{
 $queryWerk = mysql_query("SELECT *,UNIX_TIMESTAMP(`werken`) AS `werken`,0 FROM `[users]` WHERE login='".$_SESSION['login']."'");
 $aWerk = mysql_fetch_assoc($queryWerk);
 $sWerk = $aWerk['werken'] + $aWerk['werken1'] - time() - 3600;
 
	if($aWerk['werken'] + $aWerk['werken1'] > time())
	{
echo "<table width='100%' cellspacing='1' cellpadding='2'>
	  <tr><td class='subTitle'>Werken</td></tr>
	  <tr><td class='mainTxt'>Je moet nog ".date("H:i:s", "$sWerk")." seconden/minuten wachten voordat je weer kan werken.</td></tr>
      </table>";
	exit;
	}
}

function landImage($string)
{
	if($string == "1")
	{
		$image = '<img src="./images/game/landen/belgie.gif" border="0" alt="Belgi�">';
	}
	elseif($string == "2")
	{
		$image = '<img src="./images/game/landen/duitsland.gif" border="0" alt="Duitsland">';
	}
	elseif($string == "3")
	{
		$image = '<img src="./images/game/landen/engeland.gif" border="0" alt="Engeland">';
	}
	elseif($string == "4")
	{
		$image = '<img src="./images/game/landen/frankrijk.gif" border="0" alt="Frankrijk">';
	}
	elseif($string == "5")
	{
		$image = '<img src="./images/game/landen/griekenland.gif" border="0" alt="Griekenland">';
	}
	elseif($string == "6")
	{
		$image = '<img src="./images/game/landen/italie.gif" border="0" alt="Itali�">';
	}
	elseif($string == "7")
	{
		$image = '<img src="./images/game/landen/nederland.gif" border="0" alt="Nederland">';
	}

	return $image;
}

function landImageName($string)
{
	$image = "";
	if($string == "1")
	{
		$image = '<img src="./images/game/landen/belgie.gif" border="0" alt="Belgi�"> Belgi�';
	}
	elseif($string == "2")
	{
		$image = '<img src="./images/game/landen/duitsland.gif" border="0" alt="Duitsland"> Duitsland';
	}
	elseif($string == "3")
	{
		$image = '<img src="./images/game/landen/engeland.gif" border="0" alt="Engeland"> Engeland';
	}
	elseif($string == "4")
	{
		$image = '<img src="./images/game/landen/frankrijk.gif" border="0" alt="Frankrijk"> Frankrijk';
	}
	elseif($string == "5")
	{
		$image = '<img src="./images/game/landen/griekenland.gif" border="0" alt="Griekenland"> Griekenland';
	}
	elseif($string == "6")
	{
		$image = '<img src="./images/game/landen/italie.gif" border="0" alt="Itali�"> Itali�';
	}
	elseif($string == "7")
	{
		$image = '<img src="./images/game/landen/nederland.gif" border="0" alt="Nederland"> Nederland';
	}

	return $image;
}

function name($string) {

	$query = mysql_query("SELECT login, vipdagen, admin FROM `[users]` WHERE login='". $string ."'");
	$assoc = mysql_fetch_assoc($query);
		
if($assoc['admin'] == 1){
$naam = '<font color="red">'.$assoc['login'].'</font> <img src="./images/game/admin.gif" border="0" alt="Admin">';
}
	elseif($assoc['vipdagen'] > 0 && $assoc['admin'] != 1){
	$naam = '<strong><font color="yellow">'.$assoc['login'].'</font></strong> <img src="./images/game/vip.gif" border="0" alt="Vip">';
	}
	else
	{
	$naam = $assoc['login'];
	}
	
	$urlEnnaam = '<a href="profile.php?x='.$assoc['login'].'">'.$naam.'</a>';
	
	return $urlEnnaam;
}

ob_end_flush();
?>

