<?php
error_reporting(0);

include("_include-config.php");
 
 
 

 if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");





?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<?
if (!empty($data) AND $data->topbalk == 1) {	
include('top.php');
}
?>
<head>



<center>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/ingame-css/css.css">

<head>
<table align=center width=80%> 
<tr><td class=subTitle>
	<p align="center"><b>Dealing</b></td></tr> 

<tr><td class=mainTxt >
<p align="center">
</tr></td><tr><td class=maintxt><center><p>&nbsp; <a href="ganja.php?x=joints">
<img border="0" src="images/game/drugs.jpg" width="80" height="80" onMouseOver="document.bbcode.helpbox.value= 'Here you can grow weed,, minimum 500 ,, maximum 25000 ounces '"></a>
<a href="ganja.php?x=sell">
<img border="0" src="images/game/drugs.jpg" width="80" height="81" onMouseOver="document.bbcode.helpbox.value= 'One ounce will sell for upto 40!'"></a>
<a href="ganja.php?x=donate">
<img border="0" src="images/game/drugs.jpg" width="80" height="81" onMouseOver="document.bbcode.helpbox.value= 'Here you can send you weed to other people.'"></a>
<a href="ganja.php?x=prijzen">
<img border="0" src="images/game/drugs.jpg" width="80" height="81" onMouseOver="document.bbcode.helpbox.value= 'Check here for the last sale price for each country'"></a><tr><td class="mainTxt" align="center"><script language="javascript">
function opmaak(op,kl){
op1=op
if(kl)op1=op+'='+kl
document.commentform.commentbericht.value+='['+op1+']tekst[/'+op+']'
}
</script>
<form name="bbcode">

<center>
<input type="text" name="helpbox" maxlength="100" align="center" style="width:395; style=; height:19"hight:100px; font-size:15px" class="helpline" value="Tip: Move your cursor over each plant at a time" /></form></td></tr><form id='commentform' name='commentform' readonly='readonly' method='post'>   
  </td></tr>
</table>


<?
if($_GET['x'] == "joints"){
print <<<ENDHTML
<table align="center" width=80%>
 <tr><td class="subTitle" colspan="3"><b>Growing Ganja!</b></td>
   <tr><td class="mainTxt"  colspan="3"><center>
You have <b>$data->joint</b> ounces of ganja
<FORM METHOD=post ACTION="">
<tr><td class="mainTxt" colspan="3"><center>Small: 7,900,- Normal: 17,000,- <br><center>Medium-Large: 110,000,- Large: 200,000,- Xlarge: 400,000,-
<tr><td class="mainTxt" colspan="1"><input type="hidden" class="btn btn-info" name="codez" size="5" maxlength="6" value="$lol">
<center><img src="images/icons/0.gif">Ounces: <td class="mainTxt" colspan="1"><center><select type=bieden name=bieden>
      						<option value="1" $select1>500 Oz - Small Plants </option>
							<option value="2" $select1>1000 Oz - Medium Plants</option>
							<option value="3" $select1>5000 Oz - Medium to Large Plants</option>
							<option value="4" $select1>10000 Oz - Large Plants</option>
							<option value="5" $select1>25000 Oz - Extra Large Plants</option>
<td class="mainTxt" colspan="1"><center><br><INPUT name="junk" class="btn btn-info" type="submit" VALUE="Grow">
</FORM>
<tr><td class="subtitle" colspan="3">Tip!</tr></td>
<tr><td class="maintxt" colspan="3"><center>Buy seeds to grow plants<br>then the money you make from selling the weed, will pay for growing more plants.<br>The more weed there is, the happier everyone is!
<tr><td class="maintxt" colspan="3"><center></tr></tr> 
 </table></td></tr>
ENDHTML;
}
if ($_POST['bieden'] == 1){
$nodig =  "7900";
$joint =  "500";
$packet =  "Small";
}
if ($_POST['bieden']  == 2){
$nodig =  "17000";
$joint =  "1000";
$packet =  "Normal";
}
if ($_POST['bieden']  == 3){
$nodig =  "110000";
$joint =  "5000";
$packet =  "Midi";
}
if ($_POST['bieden']  == 4){
$nodig =  "200000";
$joint =  "10000";
$packet =  "Large";
}
if ($_POST['bieden']  == 5){
$nodig =  "400000";
$joint =  "25000";
$packet =  "Xlarge";
}
$kost = $landprijs;
$dbres                                = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$data->login}'");
$clan                                = mysql_fetch_object($dbres);
if (isset($_POST['junk'])) {
$bieden				= $_POST['bieden'];
${"select$bieden"}			= "selected";
if($data->joint > 25000) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><b><font color=black>You have 25,000 ounces already to sell!</b></font></td></tr>\n";
}
elseif($data->joint > 24999) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><b><font color=black>You have arrived at your maximum limit</b></font></td></tr>\n";
}
elseif($data->joint +$joint > 25000) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><b><font color=black>Buying that amount will take you over tha maximum of 25000!</b></font></td></tr>\n";
}
elseif($data->cash < $nodig) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><b><font color=black>You dont have enough cash!</b></font></td></tr>\n";
}

elseif($bieden < 1) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><font color=black><b>Hey! minimum of 1 ounce!</b></font></td></tr>\n";
}
else {
$landz = $bieden*1;
mysql_query("UPDATE `[users]` SET `jointtijd`=`jointtijd`+1 WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$nodig',`joint`=`joint`+'$joint' WHERE `login`='{$data->login}'") or die(mysql_error());
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><b>You have purchased $packet type plants and grown $joint ounces of pure sticky weed. All that weed for {$nodig},-<script language=\"javascript\">setTimeout('self.window.location.href=\"ganja.php?x=joints\"',1500)</script></b></td></tr>\n";
}
}
$rand = rand(100000,999999);
$_SESSION["lol"] = $rand;
$lol = $_SESSION["lol"];
?><?
if($_GET['x'] == "sell"){
if ($data->land == 1){
$landprijs2 =  "35.49";
}
if ($data->land == 2){
$landprijs2 =  "5";
}
if ($data->land == 3){
$landprijs2 =  "22.01";
}
if ($data->land == 4){
$landprijs2 =  "12.09";
}
if ($data->land == 5){
$landprijs2 =  "25.75";
}
if ($data->land == 6){
$landprijs2 =  "28.99";
}
if ($data->land == 7){
$landprijs2 =  "17.62";
}
if ($data->land == 8){
$landprijs2 =  "6.19";
}
if ($data->land == 9){
$landprijs2 =  "39.99";
}
if ($data->land == 10){
$landprijs2 =  "33.47";
}
print <<<ENDHTML
<table align="center" width=80%>
 <tr><td class="subTitle"><b>Sell Dope</b></td>
<tr><td class="mainTxt"><center>
You have <b>$data->joint</b> ounces of ganja<br>
Your customers dont want to pay no more than <b>{$landprijs2}</b>, per ounce...<br> Fuckin poor scum...
<tr><td class=maintxt>
<center><FORM METHOD=post ACTION="">

<b>Ounces<br><input name="verkoop" value="$data->joint"><br>
<INPUT name="sell" type="submit" VALUE="Deal the Dope"><br>
</FORM>
  </table></td></tr>
ENDHTML;
}
$kost = $landprijs2;
if($_POST['sell']) {
$verkoop = $_POST['verkoop'];
$verkoop = htmlspecialchars($_POST['verkoop']);
$verkoop = substr($_POST['verkoop'],0,11);
$joint = $data->joint;
$kost1 = $landprijs2*$_POST['verkoop'];
if($data->joint < $bieden) {
print "  <center><center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><center><tr><td class=\"mainTxt\"><center><b><font color=black>Get first supply of dope</b></font></td></tr>\n";
}
elseif($verkoop < 0 OR !preg_match('/^[0-9]{1,15}$/',$_POST['verkoop'])) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><font color=black><b> Invalid Input.</b></font></td></tr>\n";
}
elseif($verkoop < 50) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><font color=black><b>Woo 50 ounces sold!</b></font></td></tr>\n";
}
elseif($joint > $_POST['verkoop'] && preg_match('/^[0-9]{1,15}$/',$_POST['verkoop'])) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$kost1',`joint`=`joint`-'$verkoop' WHERE `login`='{$data->login}'") or die(mysql_error());
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><b>You have sold $verkoop ounces for {$kost1},-<script language=\"javascript\">setTimeout('self.window.location.href=\"ganja.php?x=sell\"',1500)</script></b></td></tr>\n";
}
elseif($joint == $_POST['verkoop'] && preg_match('/^[0-9]{1,15}$/',$_POST['verkoop'])) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$kost1',`joint`=`joint`-'$verkoop' WHERE `login`='{$data->login}'") or die(mysql_error());
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><b>You have sold $verkoop Ounces for {$kost1},-<script language=\"javascript\">setTimeout('self.window.location.href=\"ganja.php?x=sell\"',1500)</script></b></td></tr>\n";
}
}
$rand = rand(100000,999999);
$_SESSION["lol"] = $rand;
$lol = $_SESSION["lol"];
?><?
if($_GET['x'] == "prijzen"){
print <<<ENDHTML
<table align="center" width=80%>
<tr><td class="subtitle">Prices
ENDHTML;
}
?><? 
if($_GET['x'] == "prijzen")
$gegevens = mysql_query("SELECT * FROM `[redlight]`") or die(mysql_error()); 
while($rij = mysql_fetch_object($gegevens)) { 
$prijs = number_format($rij->maximum,0,",",".");

if ($rij->land == 1){
$land = "Amsterdam, Netherlands";
$landprijs =  "35.49";
}
if ($rij->land == 2){
$land = "Parijs, France";
$landprijs =  "5";
}
if ($rij->land == 3){
$land = "Havana, Cuba ";
$landprijs =  "22.01";
}
if ($rij->land == 4){
$land = "Moskou, Russia";
$landprijs =  "12.09";
}
if ($rij->land == 5){
$land =  "Sydney, Australia";
$landprijs =  "25.75";
}
if ($rij->land == 6){
$land =  "New York, USA";
$landprijs =  "28.99";
}
if ($rij->land == 7){
$land =  "Berlin, Germany";
$landprijs =  "17.62";
}
if ($rij->land == 8){
$land =  "Brusells, Belgium";
$landprijs =  "6.19";
}
if ($rij->land == 9){
$land =  "London, England";
$landprijs =  "39.99";
}
if ($rij->land == 10){
$land =  "Dublin, Ireland";
$landprijs =  "33.47";
}
echo("
<tr><table align=\"center\" width=\" 80%\"  cellspacing=\"0\" cellpading=\"0\">
<tr><td class=\" mainTxt\"  width=\" 2%\" >
Country: $land <td class=\" mainTxt\"  width=\" 2%\" >Price: $landprijs ");
}
?>
<?
if($_POST[donate]) {
$donate = $_POST[player];
$joncos = $_POST[amount];
$joint = $data->joint;
if($donate = '') {
print "  <center><center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><center><tr><td class=\"mainTxt\"><center><b><font color=black>Enter a players name!</b></font></td></tr>\n";
}
elseif($joncos < 1) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><font color=black><b>Maybe you should be abit kinder and send atleast the one ounce?</b></font></td></tr>\n";
}
if($joncos < 0 OR !preg_match('/^[0-9]{1,15}$/',$_POST[amount])) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><font color=black><b>Invalid Input.</b></font></td></tr>\n";
}
elseif($joncos = '') {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><font color=black><b>Be kind if you have nothing to send?</b></font></td></tr>\n";
}
if($joint < $_POST[amount]) {
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><font color=black><b>The imported ganja is not at your correct ammount, verify your current ammount of ounces.</b></font></td></tr>\n";
}
elseif($joint > $_POST[amount] && preg_match('/^[0-9]{1,15}$/',$_POST[amount])) {
mysql_query("UPDATE `[users]` SET `joint`=`joint`+'$amount' WHERE `login`='{$player}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `joint`=`joint`-'$amount' WHERE `login`='{$data->login}'") or die(mysql_error());
print "  <center><tr><table align=\"center\" width=\"80%\">\n";
print "  <center><tr><td class=\"mainTxt\"><center><b>You have sent $amount Ounces, to $player.</b></td></tr>\n";
}
}
?>
<?
if($_GET[x] == "donate"){
print <<<ENDHTML
<center>
<tr><table align=center width=80%>
<tr><td class=subtitle>Donate</tr></td>
<center>
<tr><td class=maintxt><center>Player:
<center><select name=player><option value=''> - Select Player - </option>
ENDHTML;
?>
<?
if($_GET[x] == "donate")			
$dbres= mysql_query("SELECT * FROM `[users]` WHERE `login`!='$data->login'");
	while($crew = mysql_fetch_assoc($dbres))
		echo "<option value=\"{$crew['login']}\">{$crew['login']}</option>";
}
?>
<?
if($_GET[x] == "donate"){
print <<<ENDHTML
<center><tr><td class=maintxt><center>Ounces:&nbsp;<input name="amount" value="0">&nbsp;<INPUT name="donate" class="btn btn-info" type="submit" VALUE="Send them Green Soldiers">
</form>
</tr></td></table>
ENDHTML;
}
?>

</table></body></html><? mysql_close(); ?>