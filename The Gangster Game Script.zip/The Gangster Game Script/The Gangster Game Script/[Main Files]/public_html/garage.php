<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">
<?
if($data->garage == 99999999) {
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);
?>
<table align="center" width="40%">
<tr><td class="subTitle">Buy Garage</td></tr>
<tr><td class="mainTxt">You have not purchased the garage,<br>you can buy it for ;80.000.</td></tr>
<tr><td class="mainTxt" align="center">Garage</td></tr>
<tr><td class="mainTxt" align="center"><img width="240" height="220" src="images/garage.jpg"></td></tr>
<tr><td class="mainTxt" align="center">;80.000</td></tr>
<form method="POST">
<tr><td class="mainTxt" align="center"><input type="submit" name="koop" value="Purchase"></td></tr>
</form>
<?
if(isset($_POST['koop'])){
if($data->cash < 80000) {
print "<tr><td class=\"mainTxt\">You dont have enough cash.</td></tr>";
} else {
    mysql_query("UPDATE `[users]` SET `cash`=`cash`-80000, `garage`='1' WHERE `login`='{$data->login}'");
print "<tr><td class=\"mainTxt\">You have bought the garage.<script language=\"javascript\">setTimeout('self.window.location.href=\"garage.php\"',600)</script></td></tr>";
}
}

print"</table>";
} else {
?>
<table width=100%>
  <tr><td class="subTitle"><b>Garage</b></td></tr>


<?

$dbres           = mysql_query("SELECT *,UNIX_TIMESTAMP(`tijd`) AS `tijd`,0 FROM `[veiling]`");



  if(isset($_GET['x'])) {





    $dbres				= mysql_query("SELECT * FROM `[garage]` WHERE `id`='{$_GET['x']}' ");
    if($rij = mysql_fetch_object($dbres)) {
if($data->login != $rij->owner){
	print "<tr><td class=\"mainTxt\">This is not your car.</td></tr>";
}

if($data->login == $rij->owner){


if(isset($_POST['repareer'])) {


$dbres				= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='$data->login' AND `id`='{$_GET['x']}'");
while($rij = mysql_fetch_object($dbres)) {



$waard = Array('','5000','10000','15000','20000','25000','30000','35000','40000','45000','50000','55000','60000','65000','70000','75000','80000','85000','90000','95000','100000','105000','110000','130000','130000','130000','140000');
	
$geld1 = Array('','200','500','600','900','1200','1500','1800','2100','2400','1700','2500','3000','2900','2700','3200','3500','3300','3900','4500','5000','5500','6000','7500','7500','7500','8000');
	
$geld2 = $geld1[$rij->soort];
			$geld3 = $waard[$rij->soort];
			$geld = $geld3-$rij->schade*$geld2;
$geld4 = Array('','400','1000','1200','1800','2400','3000','3600','4200','4800','3400','5000','6000','5800','5400','6400','7000','6600','7800','9000','10000','11000','12000','15000','15000','15000','17500');
				$geld5 = $geld4[$rij->soort];
				$geld6 = $rij->schade*$geld5;
			$soort = Array('','Seat','Opel','Nissan','Fiat','Ford','Mini','Mercedes','Honda','Smart','Volkswagen','Lotus','Bmw','Dodge','Jeep','Pontiac','Mercedes [Mission 1]','Eagle','Chrysler','Porsche','Jaguar','Viper','Ferarri','Ford Shelby GT500','Mitsubishi Eclipse GT','Audi Le Mans quattro','Jaguar XK');
				$soortauto = $soort[$rij->soort];

	if($data->cash < $geld6)
    		{
				print "<tr><td class=\"mainTxt\">You dont have enough cash. You need $geld6 .</td></tr>";
				exit;

			}
else{
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$geld6' WHERE `login`='$data->login'");
			mysql_query("UPDATE `[garage]` SET `schade`=0 WHERE `owner`='$data->login' AND `id`='{$_GET['x']}'");
print "<tr><td class=\"mainTxt\">You have successfully repaired your car.</td></tr>";
 exit;
}
}
}  
if(isset($_POST['verkoop'])) {


$dbres				= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='$data->login' AND `id`='{$_GET['x']}'");
while($rij = mysql_fetch_object($dbres)) {
if($data->land != $rij->land)
    		{
$land1         = Array("","Belgium","Germany","England","France","Greece","Italy","Aruba","Netherlands","");
  $land          = $land1[$data->land];
			print "<tr><td class=\"mainTxt\">Your car is not in $land.</td></tr>";
		exit;
	}


else{

				$waard = Array('','5000','10000','15000','20000','25000','30000','35000','40000','45000','50000','55000','60000','65000','70000','75000','80000','85000','90000','95000','100000','105000','110000','130000','130000','130000','140000');
				$geld1 = Array('','200','500','600','900','1200','1500','1800','2100','2400','1700','2500','3000','2900','2700','3200','3500','3300','3900','4500','5000','5500','6000','7500','7500','7500','8000');
				$geld2 = $geld1[$rij->soort];
				$geld3 = $waard[$rij->soort];
				$geld = $geld3+$rij->schade*$geld2;

			$soort = Array('','Seat','Opel','Nissan','Fiat','Ford','Mini','Mercedes','Honda','Smart','Volkswagen','Lotus','Bmw','Dodge','Jeep','Pontiac','Mercedes [Mission 1]','Eagle','CHrysler','Porsche','Jaguar','Viper','Ferarri','Ford Shelby GT500','Mitsubishi Eclipse GT','Audi Le Mans quattro','Jaguar XK');
				$soortauto = $soort[$rij->soort];
if($geld < 1000)
                {
					$geld    = 1000;
				}

                               
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$geld' WHERE `login`='$data->login'");
				mysql_query("DELETE FROM `[garage]` WHERE `owner`='$data->login' AND `id`='{$_GET['x']}'");
print "<tr><td class=\"mainTxt\">You have sold your car for $geld </td></tr>";
 exit;
}
}
}
 if(isset($_POST['veiling'])) {


$dbres				= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='$data->login' AND `id`='{$_GET['x']}'");
while($rij = mysql_fetch_object($dbres)) {



				$waard = Array('','5000','10000','15000','20000','25000','30000','35000','40000','45000','50000','55000','60000','65000','70000','75000','80000','85000','90000','95000','100000','105000','110000','130000','130000','130000','140000');
				$geld1 = Array('','200','500','600','900','1200','1500','1800','2100','2400','1700','2500','3000','2900','2700','3200','3500','3300','3900','4500','5000','5500','6000','7500','7500','7500','8000');
				$geld2 = $geld1[$rij->soort];
				$geld3 = $waard[$rij->soort];
				$geld = $geld3-$rij->schade*$geld2;
if($geld < 1000)
                {
					$geld    = 1000;
				}
			$soort = Array('','Seat','Opel','Nissan','Fiat','Ford','Mini','Mercedes','Honda','Smart','Volkswagen','Lotus','Bmw','Dodge','Jeep','Pontiac','Mercedes [Mission 1]','Eagle','CHrysler','Porsche','Jaguar','Viper','Ferarri','Ford Shelby GT500','Mitsubishi Eclipse GT','Audi Le Mans quattro','Jaguar XK');
				$soortauto = $soort[$rij->soort];

mysql_query("INSERT INTO `[autoveiling]` (`plaatser`,`vid`,`wat`,`wat1`,`bod1`,`tijd`) values('$data->login','{$_GET['x']}','auto','$soortauto','$bod',NOW())");
	mysql_query("UPDATE `[garage]` SET `veiling`=1 WHERE `id`='{$_GET['x']}'");

print "<tr><td class=\"mainTxt\">You have sold your car.</td></tr>";
 exit;
}
}

		
 





		$waard = Array('','5000','10000','15000','20000','25000','30000','35000','40000','45000','50000','55000','60000','65000','70000','75000','80000','85000','90000','95000','100000','105000','110000','130000','130000','130000','140000');
		$geld1 = Array('','200','500','600','900','1200','1500','1800','2100','2400','1700','2500','3000','2900','2700','3200','3500','3300','3900','4500','5000','5500','6000','7500','7500','7500','');
		$geld2 = $geld1[$rij->soort];
		$geld3 = $waard[$rij->soort];
		$geld = $geld3-$rij->schade*$geld2;
		$geld4 = Array('','400','1000','1200','1800','2400','3000','3600','4200','4800','3400','5000','6000','5800','5400','6400','7000','6600','7800','9000','10000','11000','12000','15000','15000','15000','17500');
		$geld5 = $geld4[$rij->soort];
		$geld6 = $rij->schade*$geld5;

		$soort = Array('','Seat','Opel','Nissan','Fiat','Ford','Mini','Mercedes','Honda','Smart','Volkswagen','Lotus','Bmw','Dodge','Jeep','Pontiac','Mercedes [Mission 1]','Eagle','CHrysler','Porsche','Jaguar','Viper','Ferarri','Ford Shelby GT500','Mitsubishi Eclipse GT','Audi Le Mans quattro','Jaguar XK');
		$soortauto = $soort[$rij->soort];
		if($geld < 1000)
                {
					$geld    = 1000;
				}
$land1         = Array("","Belgie","Germany","England","France","Greece","Italy","Aruba","Netherlands","");
  $land          = $land1[$rij->land];
    print <<<ENDHTML
</table> <table width=100%>
<td class="mainTxt">
<form method="post"><table align="center">
<tr><td colspan="2" width="200" align="center"><img src="images/autos/{$soortauto}.gif" width="200" height="150" border="1"></td></tr> 
<tr><td align="left" width="100">ID:</td>			<td align="right" width="100">{$rij->id}</td></tr>
<tr><td align="left" width="100">Car:</td>			<td align="right" width="100">{$soortauto}</td></tr>
<tr><td align="left" width="100">Damage:</td>			<td align="right" width="100">{$rij->schade}%</td>
<tr><td align="left" width="100">Value:</td>			<td align="right" width="100">{$geld}</td>
<tr><td align="left" width="100">Repair:</td>		<td align="right" width="100">{$geld6}</td></tr>
</table>


ENDHTML;
 if($rij->bezig == 0) {
    print <<<ENDHTML

<td class="mainTxt"><table align="center">

<form method="post"><input type="button" style="width: 230;" class="btn btn-info" value=" Use this car for organised crime "onClick="window.self.location=('orgcrime.php?org123={$_GET['x']}');"></form>
<form method="post"><input type="button" style="width: 230;" class="btn btn-info" value=" Sell in the auction "onClick="window.self.location=('autoveiling.php?id123={$_GET['x']}');"></form>
 </form>                                          
<form method="post"><input type="submit" style="width: 230;" class="btn btn-info" name="repareer" value="Repair"></form>
<form method="post"><input type="submit" style="width: 230;" class="btn btn-info" name="verkoop" value="Sell to the car dealer"></form>
<form method="post"><input type="button" style="width: 230;" class="btn btn-info" value="Pimp this Car "onClick="window.self.location=('pimpcar.php?garage={$_get['x']}');"></form>
<form method="post"><input type="button" style="width: 230;" class="btn btn-info" value="Go Race with this Car "onClick="window.self.location=('tunerace.php?auto={$_GET['x']}');"></form>
<ENDHTML;


print <ENDHTML
                                               
 

</table></form>
ENDHTML;
  }  
  exit;
    }  

}
}


else {


print <<<ENDHTML
<table align="center" width=100%>
          <td  align=center class=subTitle>ID</td>
                <td w align=center class=subTitle>Auto</td>
        <td  align=center class=subTitle>Damage</td>
	<td class=subTitle>More Info</b></td>
ENDHTML;

$dbres				= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='$data->login'");
while($rij = mysql_fetch_object($dbres)) {
	$soort = Array('','Seat','Opel','Nissan','Fiat','Ford','Mini','Mercedes','Honda','Smart','Volkswagen','Lotus','Bmw','Dodge','Jeep','Pontiac','Mercedes [Mission 1]','Eagle','CHrysler','Porsche','Jaguar','Viper','Ferarri','Ford Shelby GT500','Mitsubishi Eclipse GT','Audi Le Mans quattro','Jaguar XK');
				$soortauto = $soort[$rij->soort];
	$land        = Array("Netherlands","Belgium","Germany","France","Spane","Portugal","Italy","Poland","Greece");
		$land        = $land[$rij->land];
echo("

</tr><td class=\"mainTxt\"><center>$rij->id</td>
<td class=\"mainTxt\"><center>$soortauto</td>
<td  class=\"mainTxt\"><center>$rij->schade%</td>
<td  class=\"mainTxt\"><a href=garage.php?x={$rij->id} class='btn btn-info'><center>More info</td>
</tr>
"); 
}
}
}

/* ------------------------- */ ?>
</table>

</body>

</html>