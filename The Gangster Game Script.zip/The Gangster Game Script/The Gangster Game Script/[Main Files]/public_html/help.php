
<html>
<title>The Gangster Game</title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

<body bgcolor="black">
<table width="100%" align="center">
  <tr><td class="subTitle" colspan=3><font color="white"><u><b>What do I fill into the recruiter box?</b></u></font></td></tr>

<tr>
<td align=center>
<center>
<font color="orange">
<b>
<br>
<br>
<br>
Ok, If you asking yourself WTF do I put into the box given at the side of the word 'Recruiter', well the answer is straight forward.<br>
If someone has shown you the way to this site, either by giving you the link or the name of the game, then its only good manners to repay him.<br>
So you enter this persons ingame username into that box. This way when you finish up signing up, that person will receive $100,000 into his bank.<br>
If you carnt be bothered to fill it in, then think to yourself... why should anybody else put your name in therre when they sign up.... <br>
<br>
And WallaH! That solves the mystery of the 'Recruiter Input Box' upon registration!<br>
<br>
NOTE: If you found the website by yourself, you can just leave it blank!



</b>
</font>
</center>
</td>
</tr>
</table>
</body>
</html>