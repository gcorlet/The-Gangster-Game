<?php
error_reporting(0);


  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  } else{

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

mysql_query("select * from `[users]` where `page`='High draw single' AND UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`lpv`) < 180");
#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);
?>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"><style type="text/css">
</style><link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<?

if($_SERVER['REQUEST_METHOD'] == 'POST'){

function kaart(){
$iKaart 	= rand(1,13);
$iSoort 	= rand(1,4);
$aSoort 	= array('','harten','schoppen','ruiten','klaveren');
$aKaart 	= array('','2','3','4','5','6','7','8','9','10','11','12','13','14');
$aWaarde 	= array('','2','3','4','5','6','7','8','9','10','10','10','10','11');		
return"".$aKaart[$iKaart].",".$aSoort[$iSoort].",".$aWaarde[$iKaart]."";	
} 


$kaart1 = explode(",", kaart());
$kaart2 = explode(",", kaart());
$kaart3 = explode(",", kaart());
$kaart4 = explode(",", kaart());

$inzet = $_POST['inzet'];
$bedrag = $inzet;
if($bedrag > 100000000){
$uitslag = "<tr><td class=\"mainTxt\"><font color=red><b>You cant bet more than 100.000.000</b></font></td></tr>";
} elseif($inzet < 100){
$uitslag = "<tr><td class=\"mainTxt\"><font color=red><b>You must bet atleast 100</b></font></td></tr>";
} elseif($data->cash < $inzet){
$uitslag = "<tr><td class=\"mainTxt\"><font color=red><b>Sorry, you dont have enough cash.</b></font></td></tr>";
} elseif(!preg_match('/^[0-9]{1,15}$/',$_POST['inzet'])) {
$uitslag = "<tr><td class=\"mainTxt\"><font color=red><b>Enter only numbers.</b></font></td></tr>";
} elseif(($kaart1[2]+$kaart2[2]) > ($kaart3[2]+$kaart4[2])){
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'".$bedrag."' WHERE `login`='".$data->login."'");
$uitslag = "<tr><td class=\"mainTxt\"><font color=green>Well Done, you won! You doubbled your cash which you bet!</font></td></tr>";
} elseif(($kaart1[2]+$kaart2[2]) < ($kaart3[2]+$kaart4[2])){
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'".$inzet."' WHERE `login`='".$data->login."'");
$uitslag = "<tr><td class=\"mainTxt\"><font color=red>Bad Luck, you have lost the bet</font></td></tr>";
} elseif(($kaart1[2]+$kaart2[2]) == ($kaart3[2]+$kaart4[2])){
$uitslag = "<tr><td class=\"mainTxt\"><b>Equal Game.... No winner!</b></td></tr>";
}	
?>
<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>High Card Casino</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/hcpicture.jpg border=0></center>
</td>

<table align="center" width=100%>
  <tr><td class="subTitle"><b>Pull the highest Card</b></td></tr>
  <tr>
    <td class="mainTxt"><center>Its simple, you and your oppponent draw 2 cards. The person with the highest total value wins. If you win, you double your bet cash!<br><br>

<form method='post' style='display: inline;'>
        Bet: 
        <input name='inzet' class='btn btn-info' type='text'>
      <input type='submit' class='btn btn-info' value='GO GO GO!' class='knop'></form></td>
  </tr>
</table>
<br><br>
<table align='center'>
  <tr>
    <td align='center' class='subTitle'><b><? echo $data->login; ?></b></td>
	<td width='20'></td>
    <td align='center' class='subTitle'><b>Opponent</b></td>
  </tr>
  <tr>
    <td align='center'class='mainTxt'><img src='images/gokken/blackjack/<? echo "$kaart1[1]"; ?><? echo"$kaart1[0]"; ?>.jpg'><img src='images/gokken/blackjack/<? echo "$kaart2[1]"; ?><? echo"$kaart2[0]"; ?>.jpg'></td>
	<td width='20'></td>
    <td align='center'class='mainTxt'><img src='images/gokken/blackjack/<? echo "$kaart3[1]"; ?><? echo"$kaart3[0]"; ?>.jpg'><img src='images/gokken/blackjack/<? echo "$kaart4[1]"; ?><? echo"$kaart4[0]"; ?>.jpg'></td>
  </tr>
  <tr>
    <td align='center'class='mainTxt'>Total Value: <? echo $kaart1[2]+$kaart2[2]; ?></td>
	<td width='20'></td>
    <td align='center'class='mainTxt'>Total Value: <? echo $kaart3[2]+$kaart4[2]; ?></td>
  </tr>
    <tr>
    <td colspan='3'>&nbsp;</td>
  </tr>

</table>
<table align='center'>
  <tr><td align='center' class='mainTxt'><strong><? echo $uitslag; ?></strong></td></tr>
</table>
<?			
} else{
?>

<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>High Card Casino</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/hcpicture.jpg border=0></center>
</td>
<table align="center" width=100%>
  <tr><td class="subTitle"><b>Take the highest Card</b></td></tr>
  <tr>
    <td class="mainTxt"><center>Its simple, you and your oppponent draw 2 cards. The person with the highest total value wins. If you win, you double your bet cash!<br><br>
<form method='post' style='display: inline;'>
        Bet: 
        <input name='inzet' class='btn btn-info' type='text'>
      <input type='submit' class='btn btn-info' value='Go Go Go!' class='knop'></form></td>
  </tr>
</table></td>
  </tr>
</table><?
}
}
?>
