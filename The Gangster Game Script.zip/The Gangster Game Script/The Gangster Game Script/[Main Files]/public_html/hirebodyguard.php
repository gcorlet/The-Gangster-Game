<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'"); 
?> 
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>

<?
 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
$data = mysql_fetch_assoc($sql);

  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $gn             = mysql_fetch_assoc($gn1);  if($gn[gevangenis] + $gn[gevangenistijd] > time()  && $data[login] != ssfahuck && $data[login] != Freek){
  $verschil1             = $gn[gevangenis] + $gn[gevangenistijd] - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");print <<<ENDHTML
<table width=100%><tr><td class='mainTxt'><left>You have to spend another <b>$verschil</b> seconds in prison.<br><br><br>You can deal another <b>{$data[gijzel]}</b> times this hour! <br><br>(<a href="dealings.php"><b>Click Here to begin dealing!</b></a>)<td class='mainTxt' align=center height=150 colspan=3><img src=/images/Jail.jpg></td></tr></table>
ENDHTML;
	}
	else{
	
	?>
<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack System</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Selectan Attack Option</option>
<option value=\"bulletfactory.php\">Bullet Factory</option>
<option value=\"hospital.php\">Hospital</option>
<option value=\"attackexp.php\">Attack Experience</option>
<option value=\"killtrain.php\">Weapons Training</option>
<option value=\"detectives.php\">Detective</option>
<option value=\"ckiller.php\">Murders</option>
<option value=\"hirebodyguard.php\">Go into Hiding</option>
<option value=\"hitlist.php\">Hitlist</option>
</select>
</table>
";
}
?> 

<body style="margin: 0px;">
<table cellspacing=1 cellpadding=2 align=center width=100%>
<tr><td class=subtitle colspan=3 align=center>Protection:</td></tr>
<?php

      $data1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`tijd`) AS `tijd`,0 FROM `[beveiliging]` WHERE `naam`='{$data[login]}'");
      $dataa            = mysql_fetch_assoc($data1);
mysql_query("DELETE FROM `[beveiliging]` WHERE `tijd` < NOW()-43200");

if(($dataa[uren]*3600)+$dataa[tijd] <= time()){
mysql_query("UPDATE `[beveiliging]` SET `soort`='0' WHERE `naam`='{$data[login]}'");
}
if($dataa[tijd] + 43200 > time()){
    print "<tr><td class=maintxt colspan=3 align=center> You have to hire a minimum of 1 in 12 hours, thats if you want protection!</td></tr>";
    exit;
    }
else{
print "
<form method=POST>
        <tr><td class=maintxt colspan=3>{$data[login]}
do you fear for you own safety?<br> Why not hire a bodyguard... Or several <br> The maximum is <b>1 turn per 12 hours</b> bodyguard hire. Or the maximum is... hire bodygaurds for <b>10 hours.</b>
Hiring bodyguards increases the miss percentage of the attacking player. <br> The more bodyguards you hire, the higher this percentage becomes.
<br> Once one bodyguard has protected you from harm, like take a bullet for you etc, he will then leave you alone.

 
</td></tr>

<tr>
<td colspan=3 class=subtitle>Counter-Force Security</td></tr>
<tr><td class=maintxt rowspan=3><img src=images/game/elite.gif></td>
<td class=maintxt colspan=2>
Best protection in and around The Gangster Game. You cannot get any better.<br>
These boys are the business!<br><br>.
The company knows commitment and is renowned for its elite movement and protection.
</td></tr><tr><td class=maintxt rowspan=2>
- Per hour for 1 bodyguard for Counter-Force Security <b>150,000</b>. <br>
- Maximum of <b>2 bodyguards</b> Rents from this Supplier.<br>
- Protection from <b>10 to 25%</b> per bodyguard.
</td>
<td class=maintxt align=right><b>Counter-Force Security 1 bodyguard</b><input type=radio name=bodyguard value=elite1></td>
<tr><td class=maintxt align=right><b>Counter-Force Security 2 bodyguards</b><input type=radio name=bodyguard value=elite2></td></tr>
</tr>

<tr>
<td colspan=3 class=subtitle>Quick Security</td></tr>
<tr><td class=maintxt rowspan=3><img src=images/game/elite.gif></td>
<td class=maintxt colspan=2>
A Great protection business with some employees as long as 27 years in the protection business.<br>
You can count on these guys to protect your sorry ass.... its there job!<br><br>
</td></tr><tr><td class=maintxt rowspan=2>
- Per hour for 1 bodyguard for Quick Security <b>100,000</b>. <br>
- Maximum of <b>2 bodyguards</b> Rents off this Supplier.<br>
- Protection from <b>5 to 20%</b> per bodyguard.
</td>
<td class=maintxt align=right><b>Quick Security 1 bodyguard</b><input type=radio name=bodyguard value=best1></td>
<tr><td class=maintxt align=right><b>Quick Security 2 bodyguards</b><input type=radio name=bodyguard value=best2></td></tr>
</tr>

<tr>
<td colspan=3 class=subtitle>Timestep Security</td></tr>
<tr><td class=maintxt rowspan=2><img src=images/game/elite.gif></td>
<td class=maintxt colspan=2>
Because these are on the cheap side, dont expect them to be worthless. There just a fairly new company and trying to compete with lower prices.<br>
They have some of the highest trained men under there name, and will protect you from anyone....anything.<br><br>
</td></tr><tr><td class=maintxt>
- Per hour Timestep Security <b>50,000</b>.<br> 
- maximum <b>1 bodyguard</b> Rental from this Supplier.<br>
- Protection from <b>5 to 15%</b> per bodyguard.
</td>
<td class=maintxt align=right valign=bottom><b>Timestep 1 bodyguard</b><input type=radio checked name=bodyguard value=synsec1></td>
</tr>

<tr><td class=maintxt colspan=3 align=right>Hours:&nbsp;<select name=uren>
	  			<option selected value=1>1</option><option value=2>2</option><option value=3>3</option>
	  			<option value=4>4</option><option value=5>5</option><option value=6>6</option>
	  			<option value=7>7</option><option value=8>8</option><option value=9>9</option>
	  			<option value=10>10</option>
	  			</select>&nbsp;<input type=submit name=submit value=Submit></td></tr>";
} 
if(isset($_POST['submit'])) {
$uren = $_POST['uren'];
if ( $_POST['bodyguard'] == 'elite1' ){
$kosten = $uren*150000;
$kostend= number_format($kosten,0);
if($uren < 1 OR $uren > 10){
print "<td class=maintxt>Fill in a valid number for amount of hours.";
exit;}
if($data[cash] < $kosten){
print "<td class=maintxt>You dont have enough cash, the cost is $kostend .";
exit;}
else{
$soort = rand(10,25);
mysql_query("INSERT INTO `[beveiliging]`(`naam`,`tijd`,`uren`,`soort`) values('$data[login]',NOW(),'$uren','$soort')");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kosten' WHERE `login`='$data[login]'"); 
print "<td class=maintxt>You have <b>1 bodyguard</b> from Counter-Force Security for a duration of <b>$uren hours</b>.<br><br>";

exit; }
exit; 
}

if ( $_POST['bodyguard'] == 'elite2' ){ 
$kosten = $uren*150000*2;
$kostend= number_format($kosten,0);
if($uren < 1 OR $uren > 10){
print "<td class=maintxt>Fill in a valid number for amount of hours.";
exit;}
if($data[cash] < $kosten){
print "<td class=maintxt>You dont have enough cash, the cost is $kostend.";
exit;}
else{
$soort = rand(20,50);
mysql_query("INSERT INTO `[beveiliging]`(`naam`,`tijd`,`uren`,`soort`) values('$data[login]',NOW(),'$uren','$soort')"); 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kosten' WHERE `login`='$data[login]'");
print "<td class=maintxt>You have <b>2 bodyguards</b> from Counter-Force Security for a duration of <b>$uren hours</b>.<br><br>";
exit; }
exit; 
}
if ( $_POST['bodyguard'] == 'best1' ){
$kosten = $uren*100000;
$kostend= number_format($kosten,0);
if($uren < 1 OR $uren > 10){
print "<td class=maintxt>Fill in a valid number for amount of hours.";
exit;}
if($data[cash] < $kosten){
print "<td class=maintxt>You dont have enough cash, the cost is $kostend.";
exit;}
else{
$soort = rand(5,20);
mysql_query("INSERT INTO `[beveiliging]`(`naam`,`tijd`,`uren`,`soort`) values('$data[login]',NOW(),'$uren','$soort')"); 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kosten' WHERE `login`='$data[login]'");
print "<td class=maintxt>You have <b>1 bodyguard</b> from Quick Security for a duration of <b>$uren hours</b>.<br><br>";
exit; }
exit; 
}
if ( $_POST['bodyguard'] == 'best2' ){
$kosten = $uren*100000*2;
$kostend= number_format($kosten,0);
if($uren < 1 OR $uren > 10){
print "<td class=maintxt>Fill in a valid number for amount of hours.";
exit;}
if($data[cash] < $kosten){
print "<td class=maintxt>You dont have enough cash, the cost is $kostend.";
exit;}
else{
$soort = rand(10,40);
mysql_query("INSERT INTO `[beveiliging]`(`naam`,`tijd`,`uren`,`soort`) values('$data[login]',NOW(),'$uren','$soort')"); 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kosten' WHERE `login`='$data[login]'");
print "<td class=maintxt>You have <b>2 bodyguards</b> from Quick Security for a duration of <b>$uren hours</b>.<br><br>";
exit; }
exit; 
}
if ( $_POST['bodyguard'] == 'synsec1' ){
$kosten = $uren*50000;
$kostend= number_format($kosten,0);
if($uren < 1 OR $uren > 10){
print "<td class=maintxt>Fill in a valid number for amount of hours.";
exit;}
if($data[cash] < $kosten){
print "<td class=maintxt>You dont have enough cash, the cost is $kostend.";
exit;}
else{
$soort = rand(5,15);
mysql_query("INSERT INTO `[beveiliging]`(`naam`,`tijd`,`uren`,`soort`) values('$data[login]',NOW(),'$uren','$soort')"); 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kosten' WHERE `login`='$data[login]'");
print "<td class=maintxt>You have <b>1 bodyguard</b> from TimeStep Security for a duration of <b>$uren hours</b>.<br><br>";
exit; }
exit; 
}
else{
print "Error";
exit; 
}
}
}


?> 

</table>
</body>
</html>