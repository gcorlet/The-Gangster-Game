<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="; margin: 0px;">

</head>

<table width=630 align=center> 
  <tr><td class=subTitle><b>Hire Protection</b></td></tr>
<?php /* ------------------------- */   
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'"); 
   
     
    $boksen1           = mysql_query("SELECT *,UNIX_TIMESTAMP(`huur`) AS `huur`,0 FROM `[users]` WHERE `login`='$data->login'"); 
    $boksen            = mysql_fetch_object($boksen1); 
     
    if($boksen->huur + $boksen->huur1 > time()){ 
    print "<tr><td class=\"mainTxt\" align=\"center\">You are currently under protection...</td></tr>"; 
    } 
    else{ 
     
    if(!isset($_POST['B'])){ 
print <<<ENDHTML
<form method="post" action="hireprotection.php" name="f">
  <tr><td class=mainTxt>
		Hiring Protection will cost you 10.000,- per 10 Minutes. Maybe you need 30 Minutes? That will cost 30.000!<br><br>
		<b>From the choices below, pick a protection:</b><br><br>
		<input name="B1" class="btn btn-info" value="1" type="radio">Hire Bodyguards for 10 Minutes <br>
		<input name="B1" class="btn btn-info" value="2" type="radio">Hire The Mafia for 20 Minutes <br>
		<input name="B1" class="btn btn-info" value="3" type="radio">Hire SAS for 30 Minutes <br><br>
		<input value="Hire Protection" type="submit" class="btn btn-info" name="B">
		</td></tr></form>
<table align=center width=630>
  <tr><td class=subTitle><b>Explanation</b></td></tr>
<tr><td class="mainTxt">
If you hire protection, this means you cannot be attacked or murdered during protection time.<br>
If you have bought protection for 10 minutes, then 10 minutes is a window where your invincible.<br>
This is proven to be used very skillfully by players and not a option bought regularly because of the cost.<br> 
<BR><BR>
<b>Hits on you or contract killers cannot act on you during this time window.</b>
</td></tr>
ENDHTML;

    } 

if(isset($_POST['B'])){ 
    $b1         = $_POST['B1']; 

if($b1 == 1){ 
if($data->cash > 9999) { 
print "<tr><td class=\"mainTxt\">You have 10 minutes protection by the Bodyguards.</td></tr>"; 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='$data->login'"); 
mysql_query("UPDATE `[users]` SET `huur1`='600', `huur`=NOW() WHERE `login`='$data->login'"); 

        } 
        else 
          print "  <tr><td class=\"mainTxt\">You dont have enough cash to hire the Bodyguards as protection. You need to have $10.000!</td></tr>\n"; 
      } 

elseif($b1 == 2){ 
if($data->cash > 19999) { 
print "<tr><td class=\"mainTxt\">You have hired The Mafia as protection for 20 Minutes.</td></tr>"; 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'20000' WHERE `login`='$data->login'"); 
mysql_query("UPDATE `[users]` SET `huur1`='1200', `huur`=NOW() WHERE `login`='$data->login'"); 

        } 
        else 
          print "  <tr><td class=\"mainTxt\">You dont have enough cash to hire The Mafia as protection. It cost $20.000!</td></tr>\n"; 
      } 
       
elseif($b1 == 3){ 
if($data->cash > 29999) { 
print "<tr><td class=\"mainTxt\">You have hired the SAS as protection for 30 Minutes.</td></tr>"; 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'30000' WHERE `login`='$data->login'"); 
mysql_query("UPDATE `[users]` SET `huur1`='1800', `huur`=NOW() WHERE `login`='$data->login'"); 

        } 
        else 
          print "  <tr><td class=\"mainTxt\">You dont have enough cash to hire the SAS as protection. You must pay $30.000!</td></tr>\n"; 
      }       

     
    }}
     
/* ------------------------- */ ?>
</table>







</body>

</html>


