<?php
error_reporting(0);

 include("_include-config.php");
  include("_include-gevangenis.php");
if(! check_login()) {
    header("Location: login.php");
    exit;
  } 
    mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body style="margin: 0px;">

<?
 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
$data = mysql_fetch_assoc($sql);

  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $gn             = mysql_fetch_assoc($gn1);  if($gn[gevangenis] + $gn[gevangenistijd] > time()  && $data[login] != ssfahuck && $data[login] != Freek){
  $verschil1             = $gn[gevangenis] + $gn[gevangenistijd] - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");print <<<ENDHTML
<table width=100%><tr><td class='mainTxt'><left>You end up being stuck prison for <b>$verschil</b> seconds.<br><br><br>You can still deal another <b>{$data[gijzel]}</b> times this hour! <br><br>(<a href="dealings.php"><b>Click Here to go do Dealing!</b></a>)<td class='mainTxt' align=center height=150 colspan=3><img src=/images/Jail.jpg></td></tr></table>
ENDHTML;
	}
	else{
	
	?>
<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack System</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Select an attack option</option>
<option value=\"bulletfactory.php\">Bullet Factory</option>
<option value=\"hospital.php\">Hospital</option>
<option value=\"attackexp.php\">Attack Experience</option>
<option value=\"killtrain.php\">Weapons Training</option>
<option value=\"detectives.php\">Detective</option>
<option value=\"ckiller.php\">Murder</option>
<option value=\"hirebodyguard.php\">Protection</option>
<option value=\"hitlist.php\">Hitlist</option>
</select>
</table>
";
}
?>


<br><br>


<table width='75%' cellpadding='2' cellspacing='1' align='center' >
<tr><td class="subtitle" colspan=5 align=center>Hitlist</td></tr>
<?php   
  







	
	if(isset($_POST['KU'])){
	
	$naam               = $_POST['id'];
	$hitlist2           = mysql_query("SELECT * FROM `[hitlist]` WHERE `id`='$naam'");
	$hitlist3           = mysql_fetch_assoc($hitlist2);
	$hitlistgeld        = $hitlist3[geld]*2;
	
	if($data[cash] < $hitlistgeld){
	print "<tr><td class=maintxt colspan=5 align=center>You dont have enough cash on you.";
	}
	elseif($hitlist3[naam] == ''){
	print "<tr><td class=maintxt colspan=5 align=center>You need to select someone!";
	}
	else{
	print "<tr><td class=maintxt colspan=5 align=center>You have put $hitlist3[naam] on the hitlist.";
	mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$hitlistgeld' WHERE `login`='$data[login]'");
	mysql_query("DELETE FROM `[hitlist]` WHERE `id`='$naam'");
	}	}


	
	$hitlist1           = mysql_query("SELECT * FROM `[hitlist]`");
	
		print "	<form method=\"post\">";
	print "	<tr><td class=subtitle>&nbsp;</td><td class=subtitle align=center>Name:</td><td class=subtitle align=center> Reason:</td><td class=subtitle align=center>Ammount:</td><td class=subtitle align=center>Hitlisted By:</td></tr>";
	
	while($hitlist = mysql_fetch_assoc($hitlist1)){
	print " <tr><td class=maintxt align=center><input type=\"radio\" name=\"id\" value=\"{$hitlist[id]}\"></td> <td class=maintxt width=185>{$hitlist[naam]}</td>  <td class=maintxt>{$hitlist[reden]}</td>  <td class=maintxt width=153>{$hitlist[geld]}</td>  <td class=maintxt width=153>{$hitlist[invoeger]}</td></tr>";
	}
	
print " <tr><td class=maintxt colspan=5 align=center><input type=\"submit\" value=\"Buy Out\" name=\"KU\"></td></tr>";
print " </form></table>";
 
if(isset($_POST['VT'])){
	
	$naam1     = $data[login];
	$geld      = $_POST['geld'];
	$reden	   = $_POST['reden'];
	$man2      = mysql_query("SELECT * FROM `[users]` WHERE `login`='$naam'");
	$man1      = mysql_num_rows($man2);
	$man       = mysql_fetch_assoc($man2);
	$geld1     = 0;
	
	
	if( $_POST['Anoniem'] ){$geld1     = round($geld/10); $naam1 = Anonymous;}
	else {$naam1 = $data[login];}
	
	$geld2        = $geld+$geld1;
	
	if($data[cash] < $geld2){
	print "<tr><td class=maintxt colspan=5 align=center>You dont have enough cash on you.";
	}
	elseif($man1 < 1){
	print "<tr><td class=maintxt colspan=5 align=center>$naam does not exist.";
	}
	elseif($geld < 1000){
	print "<tr><td class=maintxt colspan=5 align=center>You must enter an amount more than 1,000";
	}
	elseif($reden == ''){
	print "<tr><td class=maintxt colspan=5 align=center>You must enter a reason!";
	}
	else{
	print "You have added them.";
	mysql_query("INSERT INTO `[hitlist]`(naam,reden,geld,invoeger) values('$naam','$reden','$geld','$naam1')");
	mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$geld2' WHERE `login`='$data[login]'");
	}
		
	} 

print <<<ENDHTML
<br>
<table width='40%' cellpadding='2' cellspacing='1' align='center' >
<form method="POST">
<tr><td class=subtitle colspan=2 align=center>Place someone on the Hitlist</td></tr>
<tr><td class=maintxt>Anonymous:</td><td class=maintxt><input type="checkbox" name="Anoniem">&nbsp;&nbsp;&nbsp; 
	(Anonymous Cost 10% extra.)</td></tr>
<tr><td class=maintxt>Target:</td><td class=maintxt><input type="text" name="naam" MAXLENGTH="17"></td></tr>
<tr><td class=maintxt>Amount:</td><td class=maintxt><input type="text" name="geld" MAXLENGTH="9"></td></tr>
<tr><td class=maintxt>Reason:</td><td class=maintxt><input type="text" name="reden" MAXLENGTH="255"></td></tr>
<tr><td class=maintxt colspan=2 align=center><input type="submit" value="Add" name="VT"> </td></tr> 
	 </form></table>
ENDHTML;

	

	}
	?>
<?php /*<input type="submit" value="Add" name="VT">*/ ?>
</body>
</html>
