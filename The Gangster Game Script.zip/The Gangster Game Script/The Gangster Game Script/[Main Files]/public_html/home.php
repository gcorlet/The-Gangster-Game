<?php
error_reporting(0);

  include("_include-config.php");
$langvariabeledoortwan = @$_SERVER["HTTP_ACCEPT_LANGUAGE"];
//Start Taalkeuze script

if (isset($_SESSION['taalkeuze'])) { //Kijkt of er een handmatige taalkeuze is gekozen, en kijkt dan in de sessie.
    if ($_SESSION['taalkeuze'] == "nl") {
        include("inc/language/nederlands.inc.php");
    }
    else {
        include("inc/language/engels.inc.php");
    }
    if (isset($_GET) && isset($_GET['taal'])) { //Kijkt of de handmatige taalkeuze word veranderd, en set de sessie weer opnieuw.
        $_SESSION['taalkeuze'] = $_GET['taal'];
        if ($_SESSION['taalkeuze'] == "nl") {
            include("inc/language/nederlands.inc.php");
        }
        else {
        include("inc/language/engels.inc.php");
        }
    }

}
else { // Als geen sessie is geset, hier verder.
    if (isset($_GET) && isset($_GET['taal'])) { //Als er handmatige keuze word gemaakt, word de sessie geset.
        $_SESSION['taalkeuze'] = $_GET['taal'];
        if ($_SESSION['taalkeuze'] == "nl") {
            include("inc/language/nederlands.inc.php");
        }
        else {
            include("inc/language/engels.inc.php");
        }
    }
    else { //Als er geen sessie is geset, en er geen handmatige taalkeuze is gekozen, dan pakt hij de taal van de browser.
        if (eregi("^nl", $langvariabeledoortwan)) { //Kijkt of taal van de browser nl bevat.
            include("inc/language/nederlands.inc.php"); // Zoja, Nederlands weergeven.
        }
        else {
            include("inc/language/engels.inc.php"); //Zoniet, dan standaard Engels.
        }
    }
}  
  
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>


<body style="margin: 0px;">
<table align="center" width=100%>
  <tr><td class="subTitle"><b>Home</b></td></tr>
  <tr><td class="mainTxt">
Welcome to <b><?php echo $page->sitetitle; ?></b>...<br><br>

<font color="#FFFFFF">
<?php

	if($_GET['soort'] != ""){
	$_GET['soort']	=	$_GET['soort'];
	$dbres		=	mysql_query("SELECT * FROM `cms` WHERE `soort`='{$_GET['soort']}'");
		while($cms = mysql_fetch_object($dbres)){
		echo ubb($cms->cms);
		}
	} else {
	$dbres		=	mysql_query("SELECT * FROM `cms` WHERE `id`='1'");
		while($cms = mysql_fetch_object($dbres)){
		echo ubb($cms->cms);
		}
	}

?>

</font></b>    
  </td></tr>
</table>

</body>


</html>