<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


/* ------------------------- */ ?>
<head>
<link rel="stylesheet" type="text/css" href=="css/bootstrap.css">
</head>
<body>
<table width="90%" align="center">
<tr><td class="subtitle" colspan="2">HomeGrown</td></tr>
<td class=maintxt colspan="2">
<center><img src="images/game/coffeshop1.gif" align="center">
</td>
<tr>
<td class=maintxt width="50%"><b><center><a href="weedfarms.php" class="btn btn-info">Weed Farms</td>
<td class=maintxt width="50%"><b><center><a href="sellhomegrown.php" class="btn btn-info">Dealing Growth</td></tr>
</tr>

</table>
<table width="90%" align="center">
</table>