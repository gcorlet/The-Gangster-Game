<?php
error_reporting(0);

ob_start();
include("_include-config.php");
    include("_include-gevangenis.php");


?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body bgproperties="fixed">
<table width="600" align="center">
	<tr>
		<td class="subTitle" colSpan="2" align="center">
		<b><?php echo $page->sitetitle; ?></b>
		</td>
	</tr>
	<tr>
		<td class="subTitle" align="center"><b>&nbsp;Item</b></td>
		<td class="subTitle" align="center"><b>Description</b></td>
	</tr>
	<tr>
		<td class="mainTxt" align="center" width="160" valign="top">
		<span class="tekstheader"><b><font color="green">Information Coming Soon</font></b></span><br><br>
		<table width="115" valign="top" cellpadding="0" cellspacing="0">
			<tr>
				<td width="115">

<?php


$dbres		=	mysql_query("SELECT * FROM `help` ORDER BY `soort`");
	while($help = mysql_fetch_object($dbres)){
	echo "<span class=\"tekstheader\"><a href=\"homehelp.php?soort={$help->soort}\">{$help->soort}</a><br /></span>";
	}

?>

				</td>
			</tr>
		</table>
		</td>
		<td class="mainTxt" width="440">

<?php

	if($_GET['soort'] != ""){
	$_GET['soort']	=	$_GET['soort'];
	$dbres		=	mysql_query("SELECT * FROM `help` WHERE `soort`='{$_GET['soort']}'");
		while($help = mysql_fetch_object($dbres)){
		echo" {$help->help}";
		}
	} else {
	$dbres		=	mysql_query("SELECT * FROM `help` WHERE `id`='1'");
		while($help = mysql_fetch_object($dbres)){
		echo ubb($help->help);
		}
	}

?>

		</td>
	</tr>
	<tr>
		<td class="subTitle" colSpan="2">&nbsp;</td>
	</tr>
</table>
</body>
</html>




<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>