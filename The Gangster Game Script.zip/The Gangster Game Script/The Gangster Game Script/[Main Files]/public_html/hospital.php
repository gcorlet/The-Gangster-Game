<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<center>
<table  width=80%><table width=80% cellspacing=0 cellpadding=2><table width=80%> 
  <tr>
  <td width="80%" class=subTitle><b>Prison</b></td>
<table  width=80%>
<td class="mainTxt"><center><img border=0 src=images/game/hospitalpicture.jpg border=0 width="100%"></center>
</td>
</table></tr></table></table></table></center>


<?
 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
$data = mysql_fetch_assoc($sql);

$owner = mysql_fetch_assoc(mysql_query("SELECT * FROM `ziekenhuis` WHERE `id`='$data[land]'"));
$sql = mysql_fetch_assoc(mysql_query("SELECT * FROM `[users]` WHERE `login`='$owner[owner]'"));

$land        = array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland");
$land1     = $land[$owner[id]];
?>

<body style=" margin: 0px;">

<table align="center" width=87%>  


<table width=80% align=center>
<tr><td class=subTitle colspan=2><b>Owner Information</b></td>

  <tr><td class="mainTxt"><center>Owner of the Hospital: <td class="mainTxt"><center><?= $owner[owner] ?></td></tr>
  <tr><td class="mainTxt"><center>Profits made from Hospital: <td class="mainTxt"><center><?= $owner[winst] ?></td></tr>
    <tr><td class="mainTxt"><center>Patients who visited the Hospital <td class="mainTxt"><center><?= $owner[klanten] ?></td></tr>
  <tr><td class="mainTxt"><center>Country: <td class="mainTxt"><center><?= $land1?></td></tr>

<tr><td class=subTitle colspan=2><b>Help</b></td><form method="post">
  <tr><td class="mainTxt" colspan=2><center>	<p>Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="text" name="name" class="btn btn-info" size="20" maxlength="32">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" class="btn btn-info" value="Heal Chosen Person" name="doit"></p></td></tr>


<tr><td class=subTitle colspan=2><b>Heal Yourself</b></td>
<tr><td class="mainTxt" colspan=2><center>
	<form method="post">
<select name="vlieg">
<option>Select a Method to cure your injuries.</option> 
<option value=1>Painkillers   (2.000,-)</option> 
<option value=2>Anti-biotics (2.500,-)</option>  
<option value=3>AB Injection (3.000,-)</option>
<option value=4>Operation (3.500,-)</option>
</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<INPUT name="doen" class="btn btn-info" type="submit" VALUE="Heal">
<br>
<br>

</select>
</td></tr>

          
                          
      </FORM> 
</center>

</table>

      <?php /* ------------------------- */

$query = mysql_query("SELECT * FROM `[users]` WHERE login = '$data[login]'"); 
$user = mysql_fetch_array($query);
$inzet=2000; 
$inzet=2500; 
$inzet=3000; 
$inzet=3500; 
$vlieg = $_POST['vlieg'];

if($_POST['doen'] && $vlieg == "1") {
if($data[cash] >= 2000) {
    mysql_query("UPDATE `[users]` SET `cash`=`cash`-2000,`health`=100 WHERE `login`='{$data[login]}'"); 
    mysql_query("UPDATE `[users]` SET `cash`=`cash`+2000 WHERE `login`='{$owner[owner]}'");
    mysql_query("UPDATE `ziekenhuis` SET `winst`=`winst`+$inzet,`klanten`=`klanten`+1 WHERE `id`='{$data[land]}'");
echo "<table width=100%><tr><td class=mainTxt><center>";
echo "You begin to heal...<br>
 You heal for <b>25%</b> life."; 
exit;
}
else
echo " <b>You dont have enough money to heal yourself.</b>";

  }

if($_POST['doen'] && $vlieg == "2") {
if($data[cash] >= 2500) {
    mysql_query("UPDATE `[users]` SET `cash`=`cash`-2500,`health`=100 WHERE `login`='{$data[login]}'"); 
    mysql_query("UPDATE `[users]` SET `cash`=`cash`+2500 WHERE `login`='{$owner[owner]}'");
    mysql_query("UPDATE `ziekenhuis` SET `winst`=`winst`+$inzet,`klanten`=`klanten`+1 WHERE `id`='{$data[land]}'");
echo "<table width=100%><tr><td class=mainTxt><center>";
echo "You start to heal...<br>
You have healed for <b>50%</b> life."; 
exit;
}
else
echo " <b>You dont have enough cash to pay for the Anti-Biotics.</b>";

  }

if($_POST['doen'] && $vlieg == "3") {
if($data[cash] >= 3000) {
    mysql_query("UPDATE `[users]` SET `cash`=`cash`-3000,`health`=100 WHERE `login`='{$data[login]}'"); 
    mysql_query("UPDATE `[users]` SET `cash`=`cash`+3000 WHERE `login`='{$owner[owner]}'");
    mysql_query("UPDATE `ziekenhuis` SET `winst`=`winst`+$inzet,`klanten`=`klanten`+1 WHERE `id`='{$data[land]}'");
echo "<table width=100%><tr><td class=mainTxt><center>";
echo "Your feeling better already...<br>
You have been healed for <b>75%</b> life."; 
exit;
}
else
echo " <b>You aint got enough cash to sort yourself the meds.</b>";

  }

if($_POST['doen'] && $vlieg == "4") {
if($data[cash] >= 3500) {
    mysql_query("UPDATE `[users]` SET `cash`=`cash`-3500,`health`=100  WHERE `login`='{$data[login]}'"); 
    mysql_query("UPDATE `[users]` SET `cash`=`cash`+3500 WHERE `login`='{$owner[owner]}'");
    mysql_query("UPDATE `ziekenhuis` SET `winst`=`winst`+$inzet,`klanten`=`klanten`+1 WHERE `id`='{$data[land]}'");
echo "<table width=100%><tr><td class=mainTxt><center>";
echo "You feel on top of the world...<br>
You've made a full recovery after the operation and back up to <b>100%</b> life."; 
exit;
}
else
echo " <b>We know how much you love going under the knife, but you cant afford the op.</b>";

  }



/* ------------------------- */ ?>

  <?php 
// Deze pagina laten zien als er niet op de knop gedrukt is
if(!(isset($_POST['doit']))) {
print <<<ENDHTML
</form>
</td></tr>
ENDHTML;
}
// Knop naam = doit, hieronder is dus als de knop 'doit' word ingedrukt
elseif(isset($_POST['doit'])) {
// Hiermee selecteerd hij de invoeging 'name' met $name
$name          = $_POST['name'];
// Controleren of de persoon bestaat en de informatie opvragen
$naam1         = mysql_query("SELECT * FROM `[users]` WHERE `login`='$name'");
$naam2         = mysql_num_rows($naam1);
$aantal         = mysql_fetch_assoc($naam1);
// Hoeveel schade uitrekenen
$per = 100-$aantal[health];
// Kosten uitrekenen
$amount = $per*2;
$inzet=3500;
print "<tr><td class=\"mainTxt\">";


if ($inzet > $data[cash]) { 
echo "<table width=100%><tr><td class=subtitle><b>Error</b></tr></td>";
echo "<table width=100%><tr><td class=mainTxt>";
echo "You dont have enough cash"; 
echo ""; 
exit; 
} 
if ($naam2 ==0) { 
echo "<table width=100%><tr><td class=subtitle><b>Error</b></tr></td>";
echo "<table width=100%><tr><td class=mainTxt>";
echo "No such name"; 
echo ""; 
exit; 
} 
if ($name ==$data[login]) { 
echo "<table width=100%><tr><td class=subtitle><b>Error</b></tr></td>";
echo "<table width=100%><tr><td class=mainTxt>";
echo "You cannot do it to yourself"; 
echo ""; 
exit; 
} 
if ($_POST['name'] =="") { 
echo "<table width=100%><tr><td class=subtitle><b>Error</b></tr></td>";
echo "<table width=100%><tr><td class=mainTxt>";
echo "You must enter a name if you wish to continue"; 
echo ""; 
exit; 
} 
elseif($naam2 ==""){
echo "<table width=100%><tr><td class=subtitle><b>Error</b></tr></td>";
echo "<table width=100%><tr><td class=mainTxt>";
print "You have to fill in a name";
exit;
}
else{
            $forwardedFor		= ($_SERVER['HTTP_X_FORWARDED_FOR'] != "") ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['HTTP_CLIENT_IP'];
            $forwardedFor		= preg_replace('/, .+/','',$forwardedFor);
              mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','{$data[login]}','{$aantal[login]}','Your miraculously Healed!','$data[login] has paid for your hospital treatment and healed you back to health')");
    mysql_query("UPDATE `[users]` SET `health`=100 WHERE `login`='{$aantal[login]}'");
    mysql_query("UPDATE `[users]` SET `honourpoints`=`honourpoints`+1 WHERE `login`='{$data[login]}'");
    mysql_query("UPDATE `[users]` SET `cash`=`cash`- 3500 WHERE `login`='{$data[login]}'");
print <<<ENDHTML

<html>


<head>
<table width=100%><tr><td class=subtitle><b>suc6 Full</b></tr></td>
<table width=100%><tr><td class=mainTxt><center>
The doctor has completely healed your friend. That will cost you 3500,- for the doctors time.

</html>
ENDHTML;
    exit;

}
}
?>


<?
   if($data[login] == $owner[owner]){
   echo "  <center><table width=80%><tr><td class=subTitle><b>Hospital</b></td>";
   echo "<form method=\"post\"><table width=80%><td class=maintxt><center><input type=submit class='btn btn-info' name=\"submit3\" Value=\"Reset Profit Meter\"><input type=submit class='btn btn-info' name=\"submit4\" Value=\"Reset Patients Chart\"></tr></td></table>";
 echo "";
   echo "";
        echo "";
echo "</form></tr></td>";

if(isset($_POST['veiling']) && $info !="")
{
  $info          = $_POST['info'];
  $dbres2        = mysql_query("SELECT `id` FROM `[veiling]` WHERE `land`='$data[land]' AND `item`='4'");
if(mysql_num_rows($dbres2) != 0) 
{
   print "  <table width=100%><tr><td class=\"mainTxt\">This hospital is on sale at the auction</td></tr></table>\n";
}
elseif($_POST['veilingtijd'] < 1)
{
   print "  <table width=100%><tr><td class=\"mainTxt\">The auction must last a minimal length of 1 hour and a maximum time of 6 hours.</td></tr></table>\n";
   exit;
}
elseif($_POST['veilingtijd'] > 6)
{
   print "  <table width=100%><tr><td class=\"mainTxt\">The auction must last a minimal length of 1 hour and a maximum time of 6 hours.</td></tr></table>\n";
   exit;
}
elseif($_POST['beginbod'] < 1000)
{
   print "  <table width=100%><tr><td class=\"mainTxt\">The start-on offer must be a minimal of 1000</td></tr></table>\n";
   exit;
}
elseif($_POST['beginbod'] > 10000000)
{
   print "  <table width=100%><tr><td class=\"mainTxt\">The maximum bid is 10000000</td></tr></table>\n";
   exit;
}
elseif(! is_numeric($_POST['veilingtijd']))
{
   print "  <table width=100%><tr><td class=\"mainTxt\">Bewteen figures 1 and 6 allowed only.</td></tr></table>\n";
   exit;
}
else {

if($_POST['veilingtijd'] == "1")
{
 $uur = 3600;
}
if($_POST['veilingtijd'] == "2")
{
 $uur = 7200;
}
if($_POST['veilingtijd'] == "3")
{
 $uur = 10800;
}
if($_POST['veilingtijd'] == "4")
{
 $uur = 14400;
}
if($_POST['veilingtijd'] == "5")
{
 $uur = 18000;
}
if($_POST['veilingtijd'] == "6")
{
 $uur = 21600;
}


   mysql_query("INSERT INTO `[veiling]` (`plaatser`, `tijd`, `item`, `land`, `beginbod`, `bod`, `veilingtijd`, `aanbiedtijd`, `info`) VALUES ('$data[login]', NOW(), '4', '$data[land]', '$beginbod', '$beginbod', '$uur', NOW(), '$info')");
   print "<table width=100%><tr><td class=\"mainTxt\" align=\"center\">The hospital is on the auction from $land1 . It lasts ".$_POST['veilingtijd']." hours and the starting bid is placed at ".$_POST['beginbod']." </table>";
}
}
}

if (isset($_POST['submit3'])){
if($data[login] == $owner[owner]){
mysql_query("UPDATE `ziekenhuis` SET `winst`='0' WHERE `id`='$data[land]'");
echo "<table width=100%><tr><td class=mainTxt><center> The profit meter has been successfully reset.</TD></TR> ";
}
else
echo "<table width=100%><tr><td class=mainTxt><center> Error: You are not the owner </TD></TR> ";
}

if (isset($_POST['submit4'])){
if($data[login] == $owner[owner]){
mysql_query("UPDATE `ziekenhuis` SET `klanten`='0' WHERE `id`='$data[land]'");
echo "<table width=100%><tr><td class=mainTxt><center> Patients chart successfully reset. </TD></TR> ";
}
else
echo "<table width=100%><tr><td class=mainTxt><center> Error: You are not the owner </TD></TR> ";
}
?>
<?

?>
<? mysql_close(); ?>