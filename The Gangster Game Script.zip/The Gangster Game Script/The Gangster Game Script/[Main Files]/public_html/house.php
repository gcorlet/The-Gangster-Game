<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");

  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>

<head> 
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>
<body style="margin: 0px;">
<?

$rank = Array("None","Caravan","Small House","Large House","Villa","Large Villa","Luxe Villa","Large Luxe Villa","Gangster Paradise","Paradise Villa","Mediterreinen Villa","Pool Paradise","Private Sucluded Villa","Tropical Villa","Fantasy Home");
$rank = $rank[$data->woning];

?>
<center>
<form method="POST">
<table width=50% align="center">
<tr><td align=center class=subtitle colspan="4"><b>Your House</b></TD></tr>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<?

if(isset($_POST['koop'])){
$woning = $_POST['woning'];
$rank = Array("None","Caravan","Small House","Large House","Villa","Large Villa","Luxe Villa","Large Luxe Villa","Gangster Paradise","Paradise Villa","Mediterreinen Villa","Pool Paradise","Private Succluded Villa","Tropical Villa","Fantasy Home");
$rank = $rank[$woning];
$ran = Array("0","10000","30000","50000","90000","100000","150000","200000","250000","300000","400000","500000","700000","900000","1100000");
$geld = $ran[$woning];
if($data->cash < $geld){
echo "<tr><td class=mainTxt colspan=\"4\"><center><font color=red><center>You dont have enough cash for this house!!</font></center></TD></tr>";
exit;
}
else{
mysql_query("UPDATE `[users]` SET `woning`='$woning' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$geld' WHERE `login`='$data->login'");
echo "<tr><td class=mainTxt colspan=\"4\"><center>You have moved into a new house!<br><br><img src=\"images/items/$rank.jpg\"></center></TD></tr>";
exit;
} 
}

if($_GET['verkoop'] == ja){
if($data->woning == 0){
echo "<tr><td class=mainTxt colspan=\"4\"><center>You currently have no house!</center></TD></tr>";
exit;
}
else{
$ran = Array("0","10000","30000","50000","90000","100000","150000","200000","250000","300000","400000","500000","700000","900000","1100000");
$geldd = $ran[$data->woning];
$geld = $geldd/100*70;
$ba         = number_format($geld,0,",",".");
echo "<tr><td class=mainTxt colspan=\"4\"><center>You have spent\$$ba on a new house</center></TD></tr>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$geld',`woning`='0' WHERE `login`='$data->login'");
exit;
} }

if($data->woning >= 1){
echo "<tr><td class=mainTxt colspan=\"4\"><center>You currently live in a $rank<br><br><img src=\"images/items/$rank.jpg\"><br><br><a href=house.php?verkoop=ja class='btn btn-info'><b>Click here to sell it</b></a></center></TD></tr>";
}
elseif($data->woning == 0){ 

?>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<tr><td class=mainTxt colspan="4">If you sell your house, you get 75% of the original purchase price!</TD></tr>
<tr><td class=mainTxt colspan=2 width=50%><img src='images/items/Caravan.jpg'></td><td class=mainTxt colspan=2 width=50%><img src='images/items/Houten Huis.jpg'></td></tr>
<tr><td class=mainTxt width=25%><input name=woning type=radio value=1> Caravan</td><td class=mainTxt>$<b>10.000</b></td><td class=mainTxt width=25%><input name=woning type=radio value=2> Small House</td><td class=mainTxt>$<b>30.000</b></td></tr>

<tr><td class=mainTxt colspan=2 width=50%><img src='images/items/Luxe Berg Villa.jpg'></td><td class=mainTxt colspan=2 width=50%><img src='images/items/Villa.jpg'></td></tr>
<tr><td class=mainTxt width=25%><input name=woning type=radio value=3> Large House</td><td class=mainTxt>$<b>50.000</b></td><td class=mainTxt width=25%><input name=woning type=radio value=4> Villa</td><td class=mainTxt>$<b>90.000</b></td></tr>
<tr><td class=mainTxt colspan=2 width=50%><img src='images/items/Boshuis.jpg'></td><td class=mainTxt colspan=2 width=50%><img src='images/items/Luxe Bunker.jpg'></td></tr>
<tr><td class=mainTxt width=25%><input name=woning type=radio value=5> Large Villa</td><td class=mainTxt>$<b>100.000</b></td><td class=mainTxt width=25%><input name=woning type=radio value=6> Luxe Villa</td><td class=mainTxt>$<b>150.000</b></td></tr>

<tr><td class=mainTxt colspan=2 width=50%><img src='images/items/Luxe Strand Villa.jpg'></td><td class=mainTxt colspan=2 width=50%><img src='images/items/Gangster Paradise.jpg'></td></tr>
<tr><td class=mainTxt width=25%><input name=woning type=radio value=7> Large Luxe Villa</td><td class=mainTxt>$<b>200.000</b></td><td class=mainTxt width=25%><input name=woning type=radio value=8> Gangster Paradise</td><td class=mainTxt>$<b>250.000</b></td></tr>
<tr><td class=mainTxt colspan=2 width=50%><img src='images/items/Japanse Villa.jpg'></td><td class=mainTxt colspan=2 width=50%><img src='images/items/Mediteraanse Villa.jpg'></td></tr>
<tr><td class=mainTxt width=25%><input name=woning type=radio value=9> Paradise Villa</td><td class=mainTxt>$<b>300.000</b></td><td class=mainTxt width=25%><input name=woning type=radio value=10> Mediteranen Villa</td><td class=mainTxt>$<b>400.000</b></td></tr>

<tr><td class=mainTxt colspan=2 width=50%><img src='images/items/Pool Paradise.jpg'></td><td class=mainTxt colspan=2 width=50%><img src='images/items/Landgoed.jpg'></td></tr>
<tr><td class=mainTxt width=25%><input name=woning type=radio value=11> Pool Paradise</td><td class=mainTxt>$<b>500.000</b></td><td class=mainTxt width=25%><input name=woning type=radio value=12> Private Succluded Villa</td><td class=mainTxt>$<b>700.000</b></td></tr>
<tr><td class=mainTxt colspan=2 width=50%><img src='images/items/Tropische Villa.jpg'></td><td class=mainTxt colspan=2 width=50%><img src='images/items/Fantasy Home.jpg'></td></tr>
<tr><td class=mainTxt width=25%><input name=woning type=radio value=13> Tropical Villa</td><td class=mainTxt>$<b>900.000</b></td><td class=mainTxt width=25%><input name=woning type=radio value=14> Fantasy Home</td><td class=mainTxt>$<b>1.100.000</b></td></tr>

    <tr>
      <td colspan="4" class="mainTxt"><div align="center"><input name="koop" class='btn btn-info' type="submit" id="koop" value="Purchase House"></div></td>
    </tr>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<? } ?> </table>
</form>
</center>

</body>
</html>

<?PHP

// de site word sloom dus moeten we wel alles afsluiten..

mysql_close();

// zo dat was het dan weer voor vandaag..
?>