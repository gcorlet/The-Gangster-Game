<?php
error_reporting(0);

  include("_include-config.php");


if(! check_login()) {
    header("Location: login.php");
    exit;
  } 

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='" . $data->login . "'") or die("FOUT in query ");
?>
<html>

<head>

<title></title>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>

<center><table width=100%>

<?php /* ------------------------- */

  if(isset($_POST['protection']) && $data->signup+12*60*60 > time()) {
    mysql_query("UPDATE `[users]` SET `signup`=FROM_UNIXTIME(UNIX_TIMESTAMP(`signup`)-12*60*60-1) WHERE `login`='{$data->login}'");
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`cash`,`bank`,`attack`,`defence`,`clicks`,`attlosses`,`attwins`,`deflosses`,`defwins`,`type`,`clan`,`clanlevel` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);
  }

  if(isset($_POST['online']) && ($data->attack+$data->defence)/2+$data->clicks*5 < 10000) {
    $data->showonline			= ($data->showonline == 1) ? 0 : 1;
    mysql_query("UPDATE `[users]` SET `showonline`={$data->showonline} WHERE `login`='{$data->login}'");
  }
  

 $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `donatetime` FROM `[respect]` WHERE `login`='{$data->login}' AND `time` >= '{$data->signup}' AND `area`='respect' ORDER BY `time` DESC LIMIT 0,10");
    $bl				= mysql_query("SELECT * FROM `[respect]` WHERE `login`='{$data->login}' AND `area`='respect'");

$clickpower = round($clicks*5);
$power = round($data->attack+$data->defence+$clickpower/2);
  $totalmoney                           = $data->bank + $data->cash;
  $totalmoney                           = number_format(round($totalmoney),0,",",".");
  $cash                                 = $data->cash;
  $cash                                 = number_format(round($cash),0,",",".");
  $bank                                 = $data->bank;
  $bank                                 = number_format(round($bank),0,",",".");
    $land1	                  	= array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland");
    $land                 		= $land1[$data->land];
$rank1	                  	= array("None","Cafone","LowLife","Pickpocket","Shoplifter","Mugger","Thief","WiseGuy","Associate","Mobster","Gangster","Assassin","Good Fella","Mob Boss","The Don","The Lengendary Don","The Godfather");
$rank = $rank1[$data->rank];
  $weapon1		                = array("None","Knuckle-Duster","Stiletto","Colt AR-15A3 Tactical Carbine","BFG-50 Carbine","Tommy Gun","Machine Gun","SA80 Rifle","Assault Rifle","Sniper Rifle","Automatic Shotgun","GG MiniGun");
  $weapon		         	= $weapon1[$data->weapon];
  $pro1		                        = array("None","Helmet","Bulletproof Vest","Bulletproof Bike","Bulletproof Car","Bulletproof Limo");
  $pro		         	        = $pro1[$data->protection];
  $diff5                                = ($moord->getaway + 1800)-time();
  $diff50                               = date("i:s", "$diff5");

  $data2                                = mysql_query("SELECT *,UNIX_TIMESTAMP(`auto`) AS `auto`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $data1                                = mysql_fetch_object($data2);
  $diff3                                = ($data1->auto + 240) - time();
  $diff30                               = date("i:s", "$diff3");

  $data2                                = mysql_query("SELECT *,UNIX_TIMESTAMP(`misdaad`) AS `misdaad`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $data1                                = mysql_fetch_object($data2);
  $diff                                 =($data1->misdaad+120)-time();
  $diff0                                = date("i:s", "$diff");

  $data42                                = mysql_query("SELECT *,UNIX_TIMESTAMP(`opdruktijd`) AS `opdruktijd`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $data4                                = mysql_fetch_object($data42);
  $opdruktijd1 = $data4->opdruktijd1;
  $diff4                                 =($data4->opdruktijd+$opdruktijd1)-time();
  $diff40                                = date("i:s", "$diff4");

  $type = array("","DrugDealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","Original Gangster","Rude Boy","PeaceKeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Royal Thug","Avenger","Mugger","Capone","Thief","PIMP","Pretty Women","WiseGuy","Mobster","Fella","Gangster Girl","The Daddy" );
  $ctype = $type[$data->ctype];



  if($data->familie == "") {
	$Fam = None;
  } else {
 	$Fam = $data->familie;
  }


  if ($diff2 <= -1){
$diff2 = Available;
}
if ($diff <= -1){
$diff = Available;
}
if ($diff3 <= -1){
$diff3 = Available;
}
if ($tijd1 <= -1){
$tijd1 = Now;
}
if ($diff4 <= -1){
$diff4 = Available;
}
if ($diff5 <= -1){
$diff5 = Now;
}	


  $dbres				= mysql_query("SELECT id FROM `[messages]` WHERE `read`=0 AND `inbox`=1 AND `to`='{$data->login}'");
  $inboxnew				= mysql_num_rows($dbres);

  $protection				= round($data->signup/3600-time()/3600) + 12;

	$energierood = 100-$data->energie;
	$healthrood = 100-$data->health;
	$rijbewijsrood = 100-$data->Rijbewijsvordering;
	$rankvordrood = 100-$data->rankvord;
	$moordervaringrood = 100-$data->moordervaring;
?>


<center><table align="center" width=100%>
  <tr><td class="subTitle"><b>Personal Website Links</b></td></tr>
  <tr><td class="mainTxt">

<b>
<a href="<? echo $sitelink;?>/register.php?rec=<? echo $data->login; ?>">
<? echo $sitelink;?>/register.php?rec=<? echo $data->login; ?>
</a>
</b>
<br><br>
To earn some extra cash, invite people to sign up and ask them to put your name in the recruiter box.<br>
This way you will earn <b>1,000,000</b> each time your name is entered when another person signs up!





</tr></td></table>

<table width=7 border=0 cellspacing=5 cellpadding=2>
<tr>
<td valign=top width=278 align=center>




</td>
<td valign=top width=290 align=center>

</td>
</tr>
</table>

<table width=7 border=0 cellspacing=5 cellpadding=2>
<tr>
<td valign=top width=300 align=center>

  <table border=0 width=274 bordercolor=black class=sub2 cellspacing=0 cellpadding=3><? /* cellspacing=0 cellpadding=3 */ ?>
  <tr><td class="subTitle" colspan="2" width="277"><b>Status</b></td></tr>
	<tr>
	<td class=mainTxt width="137"><b>Name:</b></td>
	<td class=mainTxt width="137"><?=$data->login;?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Rank:</b></td>
	<td class=mainTxt width="137"><?=$rank;?></td>
	</tr>


	<tr>
	<td class=mainTxt width="137"><b>Country:</b></td>
	<td class=mainTxt width="137"><?=$land;?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Bullets:</b></td>
	<td class=mainTxt width="137"><?=$data->kogels;?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Family:</b></td>
	<td class=mainTxt width="137"><?=$Fam;?></td>
	</tr>

  </table><br>
  <table border=0 width=274 bordercolor=black class=sub2 cellspacing=0 cellpadding=3><? /*  cellspacing=0 cellpadding=3 */ ?>
  <tr><td class="subTitle" colspan="2" width="277"><b>Power</b></td></tr>
	<tr>
	<td class=mainTxt width="137"><b>Attack:</b></td>
	<td class=mainTxt width="137"><?=$data->attack;?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Defence:</b></td>
	<td class=mainTxt width="137"><?=$data->defence;?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Total Power:</b></td>
	<td class=mainTxt width="137"><?=$power;?></td>
	</tr>
	</table>
	<br>
	 <table border=0 width=274 bordercolor=black class=sub2 cellspacing=0 cellpadding=3><? /*  cellspacing=0 cellpadding=3 */ ?>

	 <tr><td class="subTitle" colspan="2" width="277"><b>Gear</b></td></tr>
	<tr>
	<td class=mainTxt width="137"><b>Weapon:</b></td>
	<td class=mainTxt width="137"><?=$weapon;?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Protection:</b></td>
	<td class=mainTxt width="137"><?=$pro;?></td>
	</tr>
<tr>
	<td class=mainTxt width="137"><b>Bullets:</b></td>
	<td class=mainTxt width="137"><?=$data->kogels;?></td>
	</tr>

  </table>
</td>
<td valign=top width=300 align=center>

  <table border=0 width=300 bordercolor=black class=sub2 cellspacing=0 cellpadding=3><? /*  cellspacing=0 cellpadding=3 */ ?>
  <tr><td class="subTitle" colspan="2" width="277"><b>Waiting Times</b></td></tr>
	<tr>
	<td class=mainTxt width="137"><b>Crime:</b></td>
	<td class=mainTxt width="137"><? if($diff == "Available"){print "{$diff}";}elseif($diff >= -1){print "{$diff0}";} ?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Steal a Car:</b></td>
	<td class=mainTxt width="137"><? if($diff3 == "Available"){print "{$diff3}";}elseif($diff3 >= -1){print "{$diff30}";} ?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Organised Crime:</b></td>
	<td class=mainTxt width="137"><? if($diff2 == "Available"){print "{$diff2}";}elseif($diff2 >= -1){print "{$diff20}";} ?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Sports Training:</b></td>
	<td class=mainTxt width="137"><? if($diff4 == "Available"){print "{$diff4}";}elseif($diff4 >= -1){print "{$diff40}";} ?></td>
	</tr>
	<tr>
	
  </table><br>

  <table border=0 width=300 bordercolor=black class=sub2 cellspacing=0 cellpadding=3><? /*  cellspacing=0 cellpadding=3 */ ?>
  <tr><td class="subTitle" colspan="2" width="277"><b>Cash</b></td></tr>
	<tr>
	<td class=mainTxt width="137"><b>Wallet:</b></td>
	<td class=mainTxt width="137"><?=$data->cash;?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Bank:</b></td>
	<td class=mainTxt width="137"><?=$data->bank;?></td>
	</tr>
	<tr>
	<td class=mainTxt width="137"><b>Total:</b></td>
	<td class=mainTxt width="137"><?=$totalmoney;?></td>
	</tr>
  </table><br>
    <table border=0 width=310 bordercolor=black class=sub2 cellspacing=0 cellpadding=3><? /*  cellspacing=0 cellpadding=3 */ ?>
  <tr><td class="subTitle" colspan="2" width="277"><b>Status Charts</b></td></tr>

<tr>
<td class=mainTxt width="137"><b>Rank Progress:</b></td>
<?
if($data->rankvord == 0) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/barred.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->rankvord?>%</td>
<?
} else if($data->rankvord == 100) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->rankvord?>%</td>
<?
} else {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="<?=$data->rankvord?>" height="6"><img src="images/icons/barred.png" width="<?=$rankvordrood?>" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->rankvord?>%</td>
<?
}
?>
</tr>
<tr>
<td class=mainTxt width="137"><b>Attack Experience:</b></td>
<?
if($data->moordervaring == 0) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/barred.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->moordervaring?>%</td>
<?
} else if($data->moordervaring == 100) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->moordervaring?>%</td>
<?
} else {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="<?=$data->moordervaring?>" height="6"><img src="images/icons/barred.png" width="<?=$moordervaringrood?>" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->moordervaring?>%</td>
<?
}
?>
</tr>
<tr>
<td class=mainTxt width="137"><b>Health:</b></td>
<?
if($data->health == 0) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/barred.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->health?>%</td>
<?
} else if($data->health == 100) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->health?>%</td>
<?
} else {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="<?=$data->health?>" height="6"><img src="images/icons/barred.png" width="<?=$healthrood?>" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->health?>%</td>
<?
}
?>
</tr>
<tr>
<td class=mainTxt width="137"><b>Energy:</b></td>
<?
if($data->energie == 0) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/barred.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->energie?>%</td>
<?
} else if($data->energie == 100) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->energie?>%</td>
<?
} else {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="<?=$data->energie?>" height="6"><img src="images/icons/barred.png" width="<?=$energierood?>" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->energie?>%</td>
<?
}
?>
</tr>
<tr>
<td class=mainTxt width="137"><b>Driving License Progress:</b></td>
<?
if($data->Rijbewijsvordering == 0) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/barred.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->Rijbewijsvordering?>%</td>
<?
} else if($data->Rijbewijsvordering == 100) {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="100" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->Rijbewijsvordering?>%</td>
<?
} else {
?>
<td class=mainTxt width="143"><img src="images/icons/barleft.png" width="2" height="6"><img src="images/icons/bargreen.png" width="<?=$data->Rijbewijsvordering?>" height="6"><img src="images/icons/barred.png" width="<?=$rijbewijsrood?>" height="6"><img src="images/icons/barright.png" width="2" height="6"> <?=$data->Rijbewijsvordering?>%</td>
<?
}
?>
</tr>

<?
 if($protection > 0)
    print "  <form method=\"post\"><i>You have <b>$protection</b> hours left of protection</i><br><br><input type=\"submit\" name=\"protection\" value=\"Protection\"></form>\n";
ENDHTML;
?>

</td></tr>

</td>
</tr>
</table>


</body>


</html>
