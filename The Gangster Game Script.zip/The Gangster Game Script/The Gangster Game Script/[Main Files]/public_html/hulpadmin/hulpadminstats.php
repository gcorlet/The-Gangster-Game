<?php

  include("../_include-config.php");
 
 if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }


  if($data->hulpadmin != 1 && $data->login != $admin1 && $data->login != $admin2)
 {
     exit;
 }

?><head>


</head>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<table width=100%>
  <tr><td class="subTitle"><b>Hulp Admin - Statistieken</b></td></tr>
</table>


<? print <<<ENDHTML
            <div align='center'><table><tr><td class="mainTxt" align="center" width=150><a href="hulpadminstats.php?x=active">Onactieve leden</a></td>
            <td width=5> </td>
            <td class="mainTxt" align="center" width=150><a href="hulpadminstats.php?x=berichten">Laatste 1000 berichten</a></td>
            <td width=5> </td>
            <td class="mainTxt" align="center" width=150><a href="hulpadminstats.php?x=banned">Alle verbannen leden</a></td>
  </td></tr></table><br><br>  </div>

ENDHTML;

/* ------------------------- */ ?>
<?

if($_GET['x'] == "banned"){
echo "
<table align=center width=100%>
<tr>
  <tr><td class=subTitle><b>==> Verbannen leden <==</b></td></tr>
</tr>
</table>
<table align=center width=100%>
<tr>
    <td class=subTitle>#</td>
    <td class=subTitle>Gebruiker</td>
    <td class=subTitle>Email</td>
</tr>";
$query = "SELECT * FROM `[users]` WHERE `level` = '-1'";
$info = mysql_query($query) or die(mysql_error());
$count = 0;
while ($gegeven = mysql_fetch_array($info)) {
$naam = $gegeven["login"];
$email = $gegeven["email"];
$count++;
echo "
<tr>
    <td width=5% align=center class=mainTxt>".$count.".</td>
    <td width=15% align=center class=mainTxt>".$naam."</td>
    <td width=15% align=center class=mainTxt>".$email."</td>
</tr>
         ";
         }
	}
?>
<?

if($_GET['x'] == "belcredits"){
echo "
<table align=center width=100%>
<tr>
  <tr><td class=subTitle><b>Meeste Bel credits</b></td></tr>
</tr>
</table>
<table align=center width=100%>
<tr>
    <td class=subTitle>#</td>
    <td class=subTitle>Gebruiker</td>
     <td class=subTitle>Credits</td>
    <td class=subTitle>Email</td>
</tr>";
$query = "SELECT * FROM `[users]` WHERE `belcredits` > '0'";
$info = mysql_query($query) or die(mysql_error());
$count = 0;
while ($gegeven = mysql_fetch_array($info)) {
$naam = $gegeven["login"];
$belcredits = $gegeven["belcredits"];
$email = $gegeven["email"];
$count++;
echo "
<tr>
    <td width=5% align=center class=mainTxt>".$count.".</td>
    <td width=15% align=center class=mainTxt>".$naam."</td>
        <td width=15% align=center class=mainTxt>".$belcredits."</td>
    <td width=15% align=center class=mainTxt>".$email."</td>
</tr>
         ";
         }
	}
?>
<?

if($_GET['x'] == "attacks"){
echo "
<table align=center width=100%>
<tr>
  <tr><td class=subTitle><b>Attacks boven de 1000</b></td></tr>
</tr>
</table>
<table align=center width=100%>
<tr>
    <td class=subTitle>#</td>
    <td class=subTitle>Gebruiker</td>
    <td class=subTitle>Attacks</td>
</tr>";
$query = "SELECT * FROM `[users]` WHERE `attwins` > '1000'";
$info = mysql_query($query) or die(mysql_error());
$count = 0;
while ($gegeven = mysql_fetch_array($info)) {
$naam = $gegeven["login"];
$attwins = $gegeven["attwins"];
$count++;
echo "
<tr>
    <td width=5% align=center class=mainTxt>".$count.".</td>
    <td width=15% align=center class=mainTxt>".$naam."</td>
    <td width=15% align=center class=mainTxt>".$attwins."</td>
</tr>
         ";
         }
	}
?>
<?

if($_GET['x'] == "active"){
echo "
<table align=center width=100%>
<tr>
  <tr><td class=subTitle><b>==> Onactieve leden <==</b></td></tr>
</tr>
</table>
<table align=center width=100%>
<tr>
    <td class=subTitle>#</td>
    <td class=subTitle>Gebruiker</td>
    <td class=subTitle>Email</td>
</tr>";
$query = "SELECT * FROM `[users]` WHERE `activated` = '0'";
$info = mysql_query($query) or die(mysql_error());
$count = 0;
while ($gegeven = mysql_fetch_array($info)) {
$naam = $gegeven["login"];
$email = $gegeven["email"];
$count++;
echo "
<tr>
    <td width=5% align=center class=mainTxt>".$count.".</td>
    <td width=15% align=center class=mainTxt>".$naam."</td>
    <td width=15% align=center class=mainTxt>".$email."</td>
</tr>
         ";
         }
	}
?>
<?

if($_GET['x'] == "bellers"){
echo "
<table align=center width=100%>
<tr>
  <tr><td class=subTitle><b>Bel Statistieken</b></td></tr>
</tr>
</table>
<table align=center width=100%>
<tr>
    <td class=subTitle>#</td>
    <td class=subTitle>Gebruiker</td>
    <td class=subTitle>vandaag</td>
    <td class=subTitle>totaal</td>
</tr>";
$query = "SELECT * FROM `[users]` WHERE `beller` > '0' ORDER BY beller DESC";
$info = mysql_query($query) or die(mysql_error());
$count = 0;
while ($gegeven = mysql_fetch_array($info)) {
$naam = $gegeven["login"];
$vandaaggebeld2 = $gegeven["vandaaggebeld2"];
$totaalgebeld2 = $gegeven["totaalgebeld2"];
$count++;
echo "
<tr>
    <td width=5% align=center class=mainTxt>".$count.".</td>
    <td width=15% align=center class=mainTxt>".$naam."</td>
    <td width=15% align=center class=mainTxt>".$vandaaggebeld2."</td>
    <td width=15% align=center class=mainTxt>".$totaalgebeld2."</td>
</tr>
         ";
         }
	}
?>
<?
if($_GET['x'] == "bellers"){

$query = "SELECT sum(`gebeld`) as total FROM `[users]` WHERE `gebeld`>'0'";  
$info = mysql_query($query) or die(mysql_error());  
$totaal = mysql_fetch_array($info);
$geld2 = $totaal['total'];
$totaalgeld = 0.84*$geld2;

$query2 = "SELECT sum(`gebeldtoday`) as totalday FROM `[users]` WHERE `gebeldtoday`>'0'";  
$info2 = mysql_query($query2) or die(mysql_error());  
$totaal2 = mysql_fetch_array($info2);
$geld3 = $totaal2['totalday'];
$totaalgeldd = 0.84*$geld3;

$query3 = "SELECT sum(`totaluur`) as totaluur FROM `[users]` WHERE `totaluur`>'0'"; 
$info3 = mysql_query($query3) or die(mysql_error());  
$totaal3 = mysql_fetch_array($info3);
$geld4 = $totaal3['totaluur'];
$totaalgeldd2 = 0.84*$geld4;

$query5 = "SELECT sum(`totalweek`) as totalweek FROM `[users]` WHERE `totalweek`>'0'"; 
$info5 = mysql_query($query5) or die(mysql_error());  
$totaal5 = mysql_fetch_array($info5);
$geld5 = $totaal5['totalweek'];
$totaalgeldd3 = 0.84*$geld5;
print "<table align=center width=100%><tr><td class='maintxt'><center>Er is dit uur <b>{$data->totaluur}</b>x gebeld, dat is <b>$".$totaalgeldd2." </td></tr>\n";    
print "<table align=center width=100%><tr><td class='maintxt'><center>Er is vandaag <b>".$totaal2['totalday']."</b>x gebeld, dat is <b>$".$totaalgeldd."</b> </td></tr>\n";
print "<table align=center width=100%><tr><td class='maintxt'><center>Er is deze week <b>{$data->totalweek}</b>x gebeld, dat is <b>$".$totaalgeldd3."</b> </td></tr>\n";
print "<table align=center width=100%><tr><td class='maintxt'><center>Er is deze maand in totaal <b>".$totaal['total']."</b>x gebeld, dat is <b>$".$totaalgeld."</b> </td></tr>\n"; 
}
?>
<?

if($_GET['x'] == "betaald"){
echo "
<table align=center width=100%>
<tr>
  <tr><td class=subTitle><b>De betaalde leden</b></td></tr>
</tr>
</table>
<table align=center width=100%>
<tr>
    <td class=subTitle>#</td>
    <td class=subTitle>Gebruiker</td>
    <td class=subTitle>dagen</td>
    <td class=subTitle>Email</td>
</tr>";
$query = "SELECT * FROM `[users]` WHERE `paying` > '0'";
$info = mysql_query($query) or die(mysql_error());
$count = 0;
while ($gegeven = mysql_fetch_array($info)) {
$naam = $gegeven["login"];
$bdatum = $gegeven["paying"];
$email = $gegeven["email"];
$count++;
echo "
<tr>
    <td width=5% align=center class=mainTxt>".$count.".</td>
    <td width=15% align=center class=mainTxt>".$naam."</td>
    <td width=15% align=center class=mainTxt>".$bdatum."</td>
    <td width=15% align=center class=mainTxt>".$email."</td>
</tr>
         ";
         }
	}
?>
<?

if($_GET['x'] == "berichten"){
echo "
<table align=center width=100%>
<tr>
  <tr><td class=subTitle><b>==> Laatste 100 berichten <==</b></td></tr>
</tr>
</table>
<table align=center width=100%>
<tr>
    <td class=subTitle>#</td>
    <td class=subTitle>Van</td>
    <td class=subTitle>Naar</td>
    <td class=subTitle>Onderwerp</td>
    <td class=subTitle>Bericht</td>
</tr>";
$query = "SELECT * FROM `[messages]` ORDER BY time DESC LIMIT 0,100";
$info = mysql_query($query) or die(mysql_error());
$count = 0;
while ($gegeven = mysql_fetch_array($info)) {
$van = $gegeven["from"];
$naar = $gegeven["to"];
$subject = $gegeven["subject"];
$bericht = $gegeven["message"];
$count++;
echo "
<tr>
    <td width=5% align=center class=mainTxt>".$count.".</td>
    <td width=15% align=center class=mainTxt>".$van."</td>
    <td width=15% align=center class=mainTxt>".$naar."</td>
    <td width=15% align=center class=mainTxt>".$subject."</td>
    <td width=15% align=center class=mainTxt>".$bericht."</td>
</tr>
         ";
         }
	}
?>
<?PHP mysql_close(); ?>