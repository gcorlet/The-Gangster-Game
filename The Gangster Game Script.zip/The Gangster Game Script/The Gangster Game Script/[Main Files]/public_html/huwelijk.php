<?php
error_reporting(0);

  include("_include-jail.php");
      include("_include-gevangenis.php");
 
  
?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css" rel="stylesheet" type="text/css">
</head>
<body>
<br>
<br>
<table width='60%' cellpadding='2' cellspacing='1' align='center' >
  <tr><td class=subTitle colspan=2><b><center>Marriage</b></td></tr>
<form name="form1" method="post" action="">
<tr><td class=maintxt>Name:</td><td class=maintxt><input type="text" name="partner" maxlength="20"></td></tr>
<tr><td class=maintxt>Price:</td><td class=maintxt>1.000.000,-</td></tr>
<tr><td colspan="2" class=maintxt align=center><input type="submit" name="Submit" value="Will You Marry Me?"></td></tr>
</table></form>

<br><br>
<table width='85%' cellpadding='0' cellspacing='0' bgcolor='#000000' align='center' style='background-color: transparent; border: 0px;'>
<td width="51%" valign=top align=center>
<table width='50%' cellpadding='2' cellspacing='1' align='center' ><form method=post>
<tr><td class=subTitle align=center colSpan=2>Your received proposals</TD></TR>
	<?
	$select = mysql_query("SELECT * FROM `[huwelijk]` WHERE `persoon2`='$data->login' AND status=1 ORDER BY `id` DESC LIMIT 0,25");
	while($list = mysql_fetch_object($select)) {
	echo "<tr><td width=30px class=maintxt><input type=radio name=id value={$list->id}></td><td align=center class=maintxt><b><a href='profile.php?x=$list->persoon1'>$list->persoon1</a></b></td></tr>";
	}
	?>
	<tr><td class=maintxt colspan=2 align=center><input type="submit" name="accepteer" value="Accept"><input type=submit name=weiger value=Reject></td></tr>
	</table>
	<td>
	<td width=85% valign=top align=center><form method=post>
<table width='68%' cellpadding='2' cellspacing='1' align='center' >
<tr><td class=subTitle align=center colSpan=2>Proposals from you</TD></TR>
	<?
	$select = mysql_query("SELECT * FROM `[huwelijk]` WHERE `persoon1`='$data->login' AND status=1 ORDER BY `id` DESC LIMIT 0,25");
	while($list = mysql_fetch_object($select)) {
	echo "<tr><td class=maintxt width=30px><input type=radio name=id value={$list->id}></td><td class=maintxt align=center><b><a href='profile.php?x=$list->persoon2'>$list->persoon2</a></b></td></tr>";
	}
	?>
	<tr><td class=maintxt colspan=2 align=center><input type=submit name=trekin value=Withdraw Proposal></td></tr>
</table>
</td>
</table>

<?
$partner = $_POST['partner'];
$id = $_POST['id'];
if (isset($_POST['Submit'])) {
if($data->trlvl > 9){
print " Already proposed to someone! ";
exit; }
if($data->cash <1000000){
Print "Not enough cash ";
exit;}

$alle1 = mysql_query("SELECT * FROM `[users]` WHERE `login`='$partner'");
$alles = mysql_fetch_object($alle1);
if($alles->level <1){
print "Enter a name! ";
exit;}
if($alles->trlvl > 9){
print "$partner is already married! ";
exit; }
if($alles->id == $data->id){
print " You cant marry yourself! ";
exit; }

print " You asked $partner for there hand in marriage!! You asked whether its a yes or no!! ";
mysql_query("INSERT INTO `[huwelijk]`(`persoon1`,`persoon2`,`status`) values('$data->login','$partner','1')");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'1000000',`speelpunt`=`speelpunt`+'3' WHere `login`='$data->login'");
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','$data->login','$partner','Marriage','<b>$data->login</b> asked for $partner 's hand in marriage, and will meet $partner at the church for there answer.')");  
exit;
}
  
  if(isset($_POST['trekin'])){
  print" Proposal Withdrawn! ";
  mysql_query("DELETE FROM `[huwelijk]` WHERE `id`='$id'");
  exit;}

  if(isset($_POST['accepteer'])){
  if($data->trlvl  >9){
  print " Your already married! $data->trlvl ";
  exit; }
  $inf2 = mysql_query("SELECT * FROM `[huwelijk]` WHERE `id`='$id'");
  $info				= mysql_fetch_object($inf2);
  
  print " You are now married to $info->persoon1 ";
  mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','$info->persoon2','$info->persoon1','Marriage','<b>$info->persoon2</b> You said yes to the proposal. You are now legally* married!!! Congratulations!!! <br><br> *This does not mean your legally married for any people getting ideas about cheap weddings. If you though for a second it was legal, then I pitty you :P')");  
  mysql_query("UPDATE `[users]` SET `trlvl`='10',`bstand`='Getrouwd met $info->persoon2' WHERE `login`='$info->persoon1'");
  mysql_query("UPDATE `[users]` SET `trlvl`='10',`bstand`='Getrouwd met $info->persoon1' WHERE `login`='$info->persoon2'");
  mysql_query("UPDATE `[huwelijk]` SET `status`='10' WHERE `id`='$id'");
  exit;}
  
  if(isset($_POST['weiger'])){
  $id = $_POST['id'];
  $inf2 = mysql_query("SELECT * FROM `[huwelijk]` WHERE `id`='$id'");
  $info				= mysql_fetch_object($inf2);
  
  print" You leave $info->persoon1 standing at the altar! ";
    mysql_query("DELETE FROM `[huwelijk]` WHERE `id`='$id'");
  mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','$info->persoon2','$info->persoon1','Marriage','<b>$info->persoon2</b> You let your dearly beloved stand lonely at the altar!! Hopefully in your next attempt at marriage you wont have seconds thoughts!')");
   exit;}

  if(isset($_POST['scheiden'])){
  
  $inf2 = mysql_query("SELECT * FROM `[huwelijk]` WHERE `persoon1`='$data->login' OR `persoon2`='$data->login'");
  $info				= mysql_fetch_object($inf2);
 if($data->login == $info->persoon1){
 $zaak = 1;}
 
 elseif($data->login == $info->persoon2){
 $zaak = 2;}
 
 if($zaak = 1){
  print" You have been seperated from $info->persoon1 !! ";
    mysql_query("UPDATE `[users]` SET `trlvl`='0',`bstand`='Vrijgezel' WHERE `login`='$info->persoon1'");
    mysql_query("UPDATE `[users]` SET `trlvl`='0',`bstand`='Vrijgezel' WHERE `login`='$info->persoon2'");    
    mysql_query("DELETE FROM `[huwelijk]` WHERE `id`='$id'");
    mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','$info->persoon2','$info->persoon1','Seperation','<b>$info->persoon2</b> You have had a marriage seperation! Your once again a free top G' to sniff the town!!!')");    
   exit;}
 if($zaak = 2){
  print" You have been seperated from $info->persoon2 !! ";
    mysql_query("UPDATE `[users]` SET `trlvl`='0',`bstand`='Vrijgezel' WHERE `login`='$info->persoon1'");
    mysql_query("UPDATE `[users]` SET `trlvl`='0',`bstand`='Vrijgezel' WHERE `login`='$info->persoon2'");    
    mysql_query("DELETE FROM `[huwelijk]` WHERE `id`='$id'");
    mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','$info->persoon1','$info->persoon2','Seperation','<b>$info->persoon1</b> You have had a marriage seperation! Your once again a free top G' to sniff the town!!!')");    
   exit;} }   
   
   
   if($data->trlvl >1){
	print <<<ENDHTML
<center> <BR><BR><BR><BR><BR><BR><BR><BR><tr>
	<td width=35% valign=top align=center><form method=post>
<table width='35%' cellpadding='2' cellspacing='1' align='center' >
<tr><td class=subTitle align=center colSpan=2>Seperation</TD></TR>

<td class=maintxt>Your now happily married!!! .......<br><br>But you can always file for a seperation ofcourse! &nbsp
<td class=maintxt><form method=post><input type=submit name=scheiden value=Seperate>

ENDHTML;
exit;}

mysql_close();