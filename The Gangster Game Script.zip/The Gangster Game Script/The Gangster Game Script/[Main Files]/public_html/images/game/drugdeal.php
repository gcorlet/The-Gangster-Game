<?php /* ------------------------- */


  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


/* ------------------------- */ ?>

<body>
<table width="90%" align="center">
<tr><td class="subtitle" colspan="2"> Drug Dealing</td></tr>
<td class=maintxt colspan="2">
<center><img src="images/game/de4l.gif" align="center">
</td>

<tr>
<td class=maintxt width="50%"><b><center><a href="voertuig.php">Transport</td>
<td class=maintxt width="50%"><b><center><a href="drugsvervoer.php">Shipping Deals</td></tr>
</tr>
</table>
<table width="90%" align="center">
</table>