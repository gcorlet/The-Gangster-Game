<?php /* ------------------------- */


  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


/* ------------------------- */ ?>

<body>
<table width="90%" align="center">
<tr><td class="subtitle" colspan="2">HomeGrown</td></tr>
<td class=maintxt colspan="2">
<center><img src="images/game/coffeshop1.gif" align="center">
</td>
<tr>
<td class=maintxt width="50%"><b><center><a href="wietplantage.php">Weed Farms</td>
<td class=maintxt width="50%"><b><center><a href="drugshandel.php">Dealing Growth</td></tr>
</tr>

</table>
<table width="90%" align="center">
</table>