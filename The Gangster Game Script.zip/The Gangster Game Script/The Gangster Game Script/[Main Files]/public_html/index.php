<LINK REL="SHORTCUT ICON" href="favicon.ico">
<?php
error_reporting(0);

  include("_include-config2.php");

  $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `activated`=1");
  $leden				= mysql_num_rows($dbres);
  $dbres2                                = mysql_query("SELECT `id` FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300");
  $online                                = mysql_num_rows($dbres2);
  $laatstelid = mysql_query("select `login` from `[users]` order by id desc limit 0,3");
  $laatste = @mysql_result($laatstelid,0,0);
	$hoogsterank = mysql_query("SELECT * FROM `[users]` WHERE `activated`>=0 ORDER BY rank DESC LIMIT 0,1");
	$meestepower = mysql_query("SELECT * FROM `[users]` WHERE `activated`>=0 ORDER BY attack DESC LIMIT 0,1");
	$meesterespect = mysql_query("SELECT * FROM `[users]` WHERE `activated`>=0 ORDER BY respect DESC LIMIT 0,1");

  if(isset($_POST['login'],$_POST['pass'])) {
    $dbres				= mysql_query("SELECT `login`,`activated` FROM `[users]` WHERE `login`='{$_POST['login']}' AND `pass`=MD5('{$_POST['pass']}')");
    if(($data = mysql_fetch_object($dbres)) && $data->activated == 1) {
      $validate				= md5(rand(0,1000));
      setcookie("login",$data->login,time()+60*60*24,"/","");
      setcookie("validate",$validate,time()+60*60*24,"/","");
      mysql_query("REPLACE INTO `[online]`(`time`,`login`,`IP`,`validate`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','{$data->login}','$validate')");
      $_SESSION['login']		= $data->login;
      $_SESSION['IP']			= $_SERVER['REMOTE_ADDR'];
      $dbres				= mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
      $_SESSION['data']			= mysql_fetch_object($dbres);
    }
  }
?>
<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/intro/css/css.css">

<link rel="shortcut icon" href="ico.ico" type="image/ico" />
<link rel="icon" href="ico.ico" type="image/ico" />
<style>
body {
  background-image: url('images/bg.png');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center top;
  background-color: #000000;
}
</style>
<style type="text/css">
	#tdColGauche{background: #5a0303 url(layout/intro/images/tiles/blood5.gif) repeat;}
	#tdColCentre{background: url(layout/intro/images/tiles/trousballes5.jpg) no-repeat top left;}
	#tdColCentre.special{background: url(layout/intro/images/tiles/trousballes5_special.jpg) no-repeat top left;}
	#tdColDroite{background: #2e2723 url(layout/intro/images/tiles/city5.jpg);}
</style><script language="javascript" type="text/javascript" src="js/string.js"></script>
<script language="javascript" type="text/javascript" src="js/functions.js"></script>
<script language="javascript" type="text/javascript" src="js/text_counter.js"></script>
<script language="javascript" type="text/javascript" src="js/swfobject.js"></script>


<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

<META NAME="KEYWORDS" CONTENT="free web based rpg,gangs rpg,street rpg,online fun rpg game,online rpg world,free internet rpg,new online rpg game,massive online rpg game ,role playing website,gangsta rpg,rpg gaming  online,new mmorpg games ,play free online mmorpg ,play free mmorpg game,free web based mmorpg,web mmorpg,free browser based mmorpg,free multiplayer web game,online multiplayer rpg game,adventure and role playing game,free gangster game,online gangsta game ,free online gangsta game,free online gangster game, gangster game, gangster rpg script, mafia rpg script, rpg script, mmorpg script, criminals rpg script, crime rpg script, pimp rpg script, thug rpg script, pimp rpg, online pimp game, web pimp,gangster game, rpg, online, criminals, crime, spel, free, gratis, winnen, 123 spel, gratis spel, spel nl, free online gangster game, gangster, mobster, mobstar, mafia, maffia, game, games, drugs, dealer, kill, fight, money, game,rgp,no,name,crime,life,lycos,criminals,barafranca,mobstar,kings,of,chaos,online,php,super,goed,spel,spelletje,spellen,leuk,mooi,Wetenschaper,politie,drugsdealer,junkie,dealer,drugs,freek,massive,multiplayer,online,role,playing,world, mobstar, gangsta, gangster, gang, crew, kill, free, pimp, pimpwar, pimps, rpg, role play, played, based, script, download, mobile, money, gold, digger, world, GRATIS criminals scripts sources bulletstar criminalsloco crime hacking time4crime worldcrime shop route66 misdaden werken mafia maffia american thugwars scripter scriptz thugie mobstar barafranca cola automaat hacken criminalsfanaat xtreme-war spele.nl webfanaat-sg source wmcity source basicwar maralana cheats ciawars source ,bulletstar source, criminal, fanaat, dutchleaders, dutchcrime2005, hosting, bellen, crimetop, funky, crimestar, crime-age, crime-streets, streetgang, gangstercrime, hard trueo, power, geld, php, mysql, html, asp, hulp, win, prijzen, leden ,members, world ,command ,coding, realcrime, crime, streetz ,thug,thugs ,thugz, gun, ak47 ,thugwarz, bulletgame, criminalz, kriminals, kriminalz, krime, crimeclub, Website, statistieken, xylohosting, crimeplanet ,criminalspoint, criminalspoint.nl, google ,wargames, blmgame, belikeme, online criminal, criminal, criminals, spelen, speel, games, online, onlinegames, speel, scripts, limwire, kazaa, kazaalite, downloads, hostting, criminalz, Wargame, RPG, Gangstergame, Pimpgame, Lekker crimineel spelletje spelen voor de fun. mafia video game, mafia game, maffia game, online mafia game, mafiagame, mafia the game, online maffia game, game mafia, mafia pc game, mafia online game, mafie, mafia game online, game maffia, mafia 2 game, mafia full game, mafia save game, pc game mafia, mafis, maffia the game, mafia rpg game, mafia saved game, download mafia game, mafia game download, mafia game music, mafia the game cheats, maafia, mafia game walkthrough, online game mafia, mafia 2 the game, mafia full game download, mafia game patch, save game mafia, game mafia 2, mafia game pc, mafia game soundtrack, www mafia game, game mafia cheats, mafia game downloads, mafia game mods, mafia game saves, mafia 2 pc game, ny mafia game, the mafia game, www mafiagame, mafia game 2, mafia game cheat, mafia game cheats, mafia game map, mafia network game, mafia pc game cheats, mafiagame com, the game mafia, www mafiagame com, for mafia game, mafia boss game, mafia game com, the mafia boss game, www mafia game com, le mafie, mafia card game, mafia game cars, mafia game crack, mafia game demo, mafia game for, mafia game trainer, mafis chess, maffia game, online maffia game, game maffia, maffia the game, criminalz, criminalz game, criminalz online game, criminalz rpg, habbo criminalz, criminalz het spel, red criminalz, het game criminalz, land criminalz, yellow criminalz, online criminalz game, blue criminalz, bedrijf criminalz, bedrijven criminalz, top 50 criminalz, spel criminalz, net gereset, speel criminalz.nl Mafia games , maffia games , online mafia games , online maffia games , maffiagames , mafia games online , games mafia , mafiagames , mafia online games , mafia save games , rpg mafia games , multiplayer mafia games , mafia rpg games , mafia saved games , pc games mafia , based mafia games , mafia games on , mafia pc games criminalz scripts , gratis criminalz script, fun lovin criminalz, fun loving criminalz, britons most wanted criminalz, little criminalz, scripts criminalz, criminalz verkoop, criminalz hacken, free criminalz scripts, criminalz script free, most wanted criminalz, sitekeuring.com criminalz, criminalz php script downloaden, scrip criminalz, art criminalz, coco criminalz, criminalz bug, criminalz free script, criminalz free script, download criminalz script php, koop hier criminalz, script criminalz free, criminalz logo, fun criminalz, fun lovin criminalz 2005, gratis criminalz script php,criminalz hacker, criminalz scripts download, gratis scripts voor criminalz, la vida loca criminalz, my criminalz, criminalz maken, criminalz mycyberchat, criminalz scrip, criminalz script install, criminalz spel net reset, fun love criminalz, nazi war criminalz, treu criminalz, true criminalz, criminals.nl, belikeme.nl, chat, chatbox, chatten, tieners, jongeren, jeugd, kids, kinderen, kindergame, onlinegame, livechat, juegdchat, warchat, nieuwschat, jongerenchat, jongens, meisjes, kriminelen, gangs, wargangs, gangsters, gangsterwar, gangster, wargangsters, online gangsters, veiligspelen, tekst spel, rpg, rpg online, role play, play, playing, fungame, relaxgame, coolgame, supergame gratis GRATIS vuurwerk forum community, wk, euro, geld, snel, gangster nine, gangster 9, gangster, 9 gangster, nine gangsters, nine gangster, gangster IX, gangster ix, ix, nine, gangster script, cheap gangster script, mafia script, rpg mafia script, script for sale, rrpg script, gangster scripts for sale, looking to buy a mafia script, looking to buy a gangster script, rpg gangster script, rpg gangster, gangsters, gangs, online gangster script, online mafia script, online gangster game, script for gansgter rpg, script for mafia rpg, script for gangster online game, script for mafia online game, mafia, ster, rpg, mmorpg, mmorpg gangster game, mmorpg mafia game, maffia online game, maffia rpg script, looking to buy maffia script, lookin to buy gangster script, looking to buy mafia script, buying gangster script, buy gangster script, rpg script, mmorpg script, mmo gangster game, mmo mafia game, mmo maffia game, online mafia game, online gangster game, gangster game, maffia game, mafia game, gangster games, mafia games, maffia games, english gangster scripts, english gangster game, english mafia scripts, english maffia scripts, online english gangster game, online rpg gangster script, online rpg, role playin game, role playing gangster, gangster walk, gangster talk, maffia quotes, mafia quotes, mafia images, gangster images, gang games, crim games, top mafia games, top gangster games, top 10 gangster online games, top10 gangster rpg, top 10 online gangster games, top 10 online mafia games, top 10 mafia rpg, rpgs, rpg's, gangster rpg's, gangster rpgs, mafia rpgs, mafia rpg's, original gangaster, contract gangster, gangster cronicles, gangster crime, crime rpg, crime online game, online crime game, online crime rpg, online crime script, crime scripts, looking to buy crime script, night club script, al capone, al pacino, scarface script, gta rpg script, gta script, grand theft auto script, grand theft auto rpg script, gangster game, the gangster game, gangstergame.com, game gangster, gaming gangster, gangster gaming, browser online gangster game, browser online mafia game, browser gangster rpg, mafia browser rpg, browser mafia rpg, gangster browser rpg,browser based gangster rpg, browser based mafia rpg, browser based gangster game, browser based mafia game, MAFFIA, MAFIA, RPG, MMORPG, GANGSTER, CRIMINAL, CRIME, CRIMES, THUG, text based mafia rpg, texted based mafia game, online mafia text game, online mafia browser game, online gangster bnrowser game, onmline gangster text game, text based gangster rpg, text based gangster game, gangster online mmorpg, mafia online mmorpg, mmorpg gangster, mmorpg mafia, mmorpg gangster game, mmorpg mafia game, text based rpg, browser based rpg, browser rpg, text rpg, text type mafia game, text type gangster game, browser type gangster game, browser type mafia game, browser type gangster rpg, browser tpye mafia rpg, text type mafia rpg, text type gangster rpg, gangster game script, the gangster game script, website script, gangster website script, mafia website script, website game script, website rpg script, i want a mafia rpg script, i want a gangster rpg script, how much are mafia game scripts, how much are mafia rpg scripts, how much are gangster rpg scripts, how much are gangster game scripts, online internet multiplayer games, internet mafia game, internet gangster game, multiplayer gangster game, multiplayer mafia game, free online gangster rpg, free online gangster game, free online mafia rpg, free online mafia game, free multiplayer gangster game, free multiplayer mafia game,">

<META NAME="DESCRIPTION" CONTENT="">
<META NAME="ROBOTS" CONTENT="INDEX,FOLLOW">

<META HTTP-EQUIV="EXPIRES" CONTENT="Mon, 31 Dec 2005 00:00:01 PST">
<META HTTP-EQUIV="CHARSET" CONTENT="ISO-8859-1">
<META HTTP-EQUIV="VW96.OBJECT TYPE" CONTENT="Homepage">
<META NAME="RATING" CONTENT="General">
<META NAME="REVISIT-AFTER" CONTENT="4 days">

<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>

<body onLoad="MM_preloadImages('layout/intro/images/index_boutonLogRoll.jpg','layout/intro/images/index_boutonRegisterRoll.jpg')">
<div id="index">
  <div id="indexContent">

    <div id="group"></div>
   	<!-- Formulaire de login -->
	<div id="loginBox">
			<form method="POST" action="login.php" id="loginForm">

		  <input type="hidden" name="action" value="userLogin" />
		  <label for="gebruikersnaam"><font color='black'>Username:		</font> <input tabIndex="1" size="15" class="btn btn-info" name="login" type="text" maxlength="15" value="" required="required" class="width2"/>
		  </label>
		  <label for="wachtwoord"><font color='black'>Password:		 </font> <input tabIndex="2" size="15" class="btn btn-info" name="pass" type="password" maxlength="25" value="" required="required" class="width2"/>
		  </label>
		 <center><br> <input type="submit" class="btn btn-info"src="layout/intro/images/bt_play_en_off.gif" name="submit" id="play" onMouseOver="MM_swapImage('play','','layout/intro/images/bt_play_en_on.gif',1)" onMouseOut="MM_swapImgRestore()"  onclick="this.form.submit();" class="nobg" value="SUBMIT" />


		</form>
		<ul class="inlineLinks">



					</ul>
	</div>
	<!-- Bouton register -->
    <div id="registerBox">
     <!-- <h3>Story</h3>-->
      <p class="inlineLinks">





<?php /* ------------------------- */
  $login					= $_POST['login'];
  $pass                     = $_POST['pass'];
  $passconfirm              = $_POST['passconfirm'];
  $city						= $_POST['stad'];
  $email					= $_POST['email'];
  $recruiter					= $rec;
 $ctype						= $_POST['ctype'];
  $IP						= $_SERVER['REMOTE_ADDR'];

  if(isset($_POST['submit'])) {
    $message					= Array(
	"<br><br><b><font color='white'>Your login may only contain: A-Z, a-z, 0-9, _  - </b><BR><BR>",
   	"<br><br><b><font color='white'>Your passwords were not the same</b><BR><BR>",
	"<br><br><b><font color='white'>Fill in a valid Email-Address</b><BR><BR>",
	"<br><br><b><font color='white'>Select a Criminal Type</b><BR><BR>",
	"<br><br><b><font color='white'>That login already exists in the database</b><BR><BR>",
	"<br><br><b><font color='white'>That email already exists in the database</b><BR><BR>",
	"<br><br><b><font color='white'>The Recruiter name can only contain A-Z, a-z, 0-9, _  - </b><BR><BR>",
        "<br><br><b><font color='white'>There is already an account in use on this computer!</b></font><BR><BR>"); 

    $msgnum					= -1;
    if(preg_match('/^[a-zA-Z0-9_\-]+$/',$login) == 0)
      $msgnum					= 0;
      if($pass == "" || $pass != $passconfirm)
      $msgnum					= 1;
    if(preg_match('/^.+@.+\..+$/',$email) == 0)
      $msgnum					= 2;
    else {
      $dbres					= mysql_query("SELECT `id` FROM `[users]` WHERE `login`='{$login}'");
      if(mysql_num_rows($dbres) > 0)
        $msgnum					= 4;
      $dbres					= mysql_query("SELECT `id` FROM `[users]` WHERE `email`='{$email}'");
      if(mysql_num_rows($dbres) > 0)
    $msgnum					= 5;
	 $dbres					= mysql_query("SELECT `id` FROM `[users]` WHERE `ip`='{$_SERVER['REMOTE_ADDR']}'");
      if(mysql_num_rows($dbres) > 0)
    $msgnum					= 8;
    if(preg_match('/^[a-zA-Z0-9_\-]+$/',$login) == 0)
        $msgnum					= 6;
     if(mysql_num_rows($dbres) > 0)
        $msgnum                                 = 7;

      if($msgnum == -1) {


        mysql_query("UPDATE `[users]` SET `recruits`=`recruits`+'1' WHERE `login`='{$recruiter}'");
        mysql_query("UPDATE `[users]` SET `cash`=`cash`+'100000' WHERE `login`='{$recruiter}'");
if($rec != "") {
        mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`,`outbox`) values(NOW(),'$page->sitetitle','$recruiter','Referal','You have got a refferal at $page->sitetitle! you get ;100.000 for free from $page->sitetitle!','0')");
}
        mysql_query("INSERT INTO `[users]`(signup,login,pass,IP,email,land) values(NOW(),'$login',MD5('$pass'),'$IP','$email','$city')") or die (mysql_error());


        $id					= mysql_insert_id();
        mail($email,"$page->sitetitle - Account","$page->sitetitle - Account.

Dear $login

Your account details are as follows:

Login          = $login
E-mail address = $email
Password       = $pass

Keep your account information safe and DO NOT give it to amyone under any circumstances.

If you need any support, feel free to contact us via the support ticket on the site, or using the Game Forums.

DO NOT:

-Spam. Spamming is against the rules. Spamming not only annoys the admins, but annoys everybody else too.
 
-Threaten or insult anyone during your time on The Gangster Game. We know its a gangster game and people can get carried away, but do refrain from using abusive behaviour.

-Use proxies. This will result in a permenant ban from your IP.

-Create and Use multiple accounts. All the accounts will be banned. If you have a brother, sister etc take this up with the Admins.

-Do not advertise your own stuff on our site. We appreciate you wouldnt like it if we did it on your site, so dont do it on our site.

If you find a bug in the game. Report it to an Admin IMMEDIATELY. Although finding of a bug is not a bannable offence.
But abusing the bug is, and you will be caught and banned!

Abusing or not Obeying any of these rules will result in a permenant and emmediate ban. No second chances. You have been Warned!

Kind Regards,

Get Respect... Get Loyalty... Get Wealthy... 

The $page->sitetitle Team.","From: $page->sitetitle <$sitelink");
      }
    }
  }

/* ------------------------- */ ?>



<?php /* ------------------------- */

  if(isset($_GET['id'],$_GET['code'])) {
    print "  <tr><td class=\"subTitle\"><b>Activatie</b></td></tr>\n";

    $id						= $_GET['id'];
    $code					= $_GET['code'];
    $dbres					= mysql_query("SELECT `login` FROM `[temp]` WHERE `area`='signup' AND `id`='$id' AND `code`='$code'");
    if($data = mysql_fetch_object($dbres)) {
	$acti = 1;
	mysql_query("UPDATE `[users]` SET `activated`=1,`signup`=NOW() WHERE `login`='{$login}'");
      mysql_query("DELETE FROM `[temp]` WHERE `id`='{$id}'");
      print "  <tr><td class=\"mainTxt\"><font color='white'>Activated Account, You can now loggin</td></tr>\n";
    }
    else
      print "  <tr><td class=\"mainTxt\">Incorrect activation-code...</td></tr>\n";
  }
  else {
    if($msgnum != -1) {
      if(isset($msgnum) && $msgnum != -1)
        print "{$message[$msgnum]}\n";
        $rec = $_GET['rec'];
    print "  <TR><Td><br>&nbsp;</td></tr><tr><td class=\"subTitle\">
		

</td></tr>\n";
      print <<<ENDHTML
<div id="regBox">
  <tr><td class="mainTxt">
	<form method="post" id="regForm" name="regForm" ><table align="center" class="2">
 	  <tr><br><td width=100><font size="2"><b>Login:</b><font color=red>*</td>		<td><input type="text" class="btn btn-info" name="login"  required="required"maxlength=16 style="width: 150;" value="$login"></td></tr>
          <tr><td width=100><font size="2"><b>Password:</b><font color=red>*</font></td>        <td><input type="password" class="btn btn-info" name="pass" required="required" maxlength=16 style="width: 150;" ;"></td></tr>
          <tr><td width=100><font size="2"><b>Repeat Password:</b><font color=red>*</font></td>        <td><input type="password" class="btn btn-info" required="required" name="passconfirm" maxlength=16 style="width: 150;" ;"></td></tr>
	  <tr><td width=100><font size="2"><b>E-Mail:</b><font color=red>*</td>	<td><input type="text" class="btn btn-info" name="email" required="required" maxlength=64 style="width: 150;" value="$email"></td></tr>
        
	  <tr><td width=100><font size="2"><b>Recruiter:<a href="javascript: //" onClick="window.open('help.php')">[?]</a></b></td>	<td><input type="text" CONTENTEDITABLE ="false" class="btn btn-info"  name="recruiter" maxlength=64 style="width: 150;" value="$rec"></td></tr>

 
	<tr><td colspan="2">
	<input size="5" name="user_agreement" type="checkbox" value="1" tabindex=""/>&nbsp;
	I hereby agree with the Terms and Conditions.	<a href="javascript: //" onClick="window.open('tos.php')">[Read Here]</a></td></td></tr>
	<tr><td colspan="2">
    <input type="hidden" name="refer" value="" />
    <input type="hidden" name="action" value="register_submit" />
	<p class="clear"></p>
	</td></tr>
  <tr><td></td><td align="center"> <input class="btn btn-info" type="submit"  name="submit" style="width: 100;" value="Register"></td></tr>
	</table></form><br>
ENDHTML;
    }
    else
      print "<tr><td class=\"subTitle\">You'r Signed Up</td></tr>
<tr><td class=\"mainTxt\">Well Done.<br><br>
Congratulations and Welcome to <b>$page->sitetitle</b>. You can now login and start a world of drugdealing, murder, corruption, gambling and many other crimes that comes along with being a Mob Boss... or on the other hand, a simple drug runner! You decide!</td></tr>\n";
  }

/* ------------------------- */ ?>





		<ul class="inlineLinks">

					</ul>
	</div>
    </div>
  </div>
  <p id="footer">

Members: <?=$leden?> - Online: <?=$online?> - Newest Member: <?=$laatste?> - <a HREF="login.php?x=lostpass">Forgotten your password? Click here to Reset it.</a>

<BR>
<?php
//Copyright variabelen instellen
$beginjaar = '2007'; // Beginjaar van je site
$jaar = date ("Y");  //Ophalen systeemjaar
$jaar2 = $jaar + 1;  //jaar2 = jaar + 1
$bedrijfsnaam = ''; //Bedrijfsnaam website
$rechten = ''; //Neerzetten rechten

echo ' Copyright &copy' . ' ' . $beginjaar . ' - ' . $jaar . ' - ' . $bedrijfsnaam;
?> <?php echo $page->sitetitle; ?>


	  </p>
</div>
</body>
</html>
