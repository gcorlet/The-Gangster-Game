<?php
error_reporting(0);

ob_start();
include("settings.php");
include("_include-config.php");

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);

?>

<html>
<head>
<title><?=$title; ?></title>

<LINK REL="SHORTCUT ICON" href="favicon.ico">

<META NAME="KEYWORDS" CONTENT="free web based rpg,gangs rpg,street rpg,online fun rpg game,online rpg world,free internet rpg,new online rpg game,massive online rpg game ,role playing website,gangsta rpg,rpg gaming  online,new mmorpg games ,play free online mmorpg ,play free mmorpg game,free web based mmorpg,web mmorpg,free browser based mmorpg,free multiplayer web game,online multiplayer rpg game,adventure and role playing game,free gangster game,online gangsta game ,free online gangsta game,free online gangster game, gangster game, gangster rpg script, mafia rpg script, rpg script, mmorpg script, criminals rpg script, crime rpg script, pimp rpg script, thug rpg script, pimp rpg, online pimp game, web pimp,gangster game, rpg, online, criminals, crime, spel, free, gratis, winnen, 123 spel, gratis spel, spel nl, free online gangster game, gangster, mobster, mobstar, mafia, maffia, game, games, drugs, dealer, kill, fight, money, game,rgp,no,name,crime,life,lycos,criminals,barafranca,mobstar,kings,of,chaos,online,php,super,goed,spel,spelletje,spellen,leuk,mooi,Wetenschaper,politie,drugsdealer,junkie,dealer,drugs,freek,massive,multiplayer,online,role,playing,world, mobstar, gangsta, gangster, gang, crew, kill, free, pimp, pimpwar, pimps, rpg, role play, played, based, script, download, mobile, money, gold, digger, world, GRATIS criminals scripts sources bulletstar criminalsloco crime hacking time4crime worldcrime shop route66 misdaden werken mafia maffia american thugwars scripter scriptz thugie mobstar barafranca cola automaat hacken criminalsfanaat xtreme-war spele.nl webfanaat-sg source wmcity source basicwar maralana cheats ciawars source ,bulletstar source, criminal, fanaat, dutchleaders, dutchcrime2005, hosting, bellen, crimetop, funky, crimestar, crime-age, crime-streets, streetgang, gangstercrime, hard trueo, power, geld, php, mysql, html, asp, hulp, win, prijzen, leden ,members, world ,command ,coding, realcrime, crime, streetz ,thug,thugs ,thugz, gun, ak47 ,thugwarz, bulletgame, criminalz, kriminals, kriminalz, krime, crimeclub, Website, statistieken, xylohosting, crimeplanet ,criminalspoint, criminalspoint.nl, google ,wargames, blmgame, belikeme, online criminal, criminal, criminals, spelen, speel, games, online, onlinegames, speel, scripts, limwire, kazaa, kazaalite, downloads, hostting, criminalz, Wargame, RPG, Gangstergame, Pimpgame, Lekker crimineel spelletje spelen voor de fun. mafia video game, mafia game, maffia game, online mafia game, mafiagame, mafia the game, online maffia game, game mafia, mafia pc game, mafia online game, mafie, mafia game online, game maffia, mafia 2 game, mafia full game, mafia save game, pc game mafia, mafis, maffia the game, mafia rpg game, mafia saved game, download mafia game, mafia game download, mafia game music, mafia the game cheats, maafia, mafia game walkthrough, online game mafia, mafia 2 the game, mafia full game download, mafia game patch, save game mafia, game mafia 2, mafia game pc, mafia game soundtrack, www mafia game, game mafia cheats, mafia game downloads, mafia game mods, mafia game saves, mafia 2 pc game, ny mafia game, the mafia game, www mafiagame, mafia game 2, mafia game cheat, mafia game cheats, mafia game map, mafia network game, mafia pc game cheats, mafiagame com, the game mafia, www mafiagame com, for mafia game, mafia boss game, mafia game com, the mafia boss game, www mafia game com, le mafie, mafia card game, mafia game cars, mafia game crack, mafia game demo, mafia game for, mafia game trainer, mafis chess, maffia game, online maffia game, game maffia, maffia the game, criminalz, criminalz game, criminalz online game, criminalz rpg, habbo criminalz, criminalz het spel, red criminalz, het game criminalz, land criminalz, yellow criminalz, online criminalz game, blue criminalz, bedrijf criminalz, bedrijven criminalz, top 50 criminalz, spel criminalz, net gereset, speel criminalz.nl Mafia games , maffia games , online mafia games , online maffia games , maffiagames , mafia games online , games mafia , mafiagames , mafia online games , mafia save games , rpg mafia games , multiplayer mafia games , mafia rpg games , mafia saved games , pc games mafia , based mafia games , mafia games on , mafia pc games criminalz scripts , gratis criminalz script, fun lovin criminalz, fun loving criminalz, britons most wanted criminalz, little criminalz, scripts criminalz, criminalz verkoop, criminalz hacken, free criminalz scripts, criminalz script free, most wanted criminalz, sitekeuring.com criminalz, criminalz php script downloaden, scrip criminalz, art criminalz, coco criminalz, criminalz bug, criminalz free script, criminalz free script, download criminalz script php, koop hier criminalz, script criminalz free, criminalz logo, fun criminalz, fun lovin criminalz 2005, gratis criminalz script php,criminalz hacker, criminalz scripts download, gratis scripts voor criminalz, la vida loca criminalz, my criminalz, criminalz maken, criminalz mycyberchat, criminalz scrip, criminalz script install, criminalz spel net reset, fun love criminalz, nazi war criminalz, treu criminalz, true criminalz, criminals.nl, belikeme.nl, chat, chatbox, chatten, tieners, jongeren, jeugd, kids, kinderen, kindergame, onlinegame, livechat, juegdchat, warchat, nieuwschat, jongerenchat, jongens, meisjes, kriminelen, gangs, wargangs, gangsters, gangsterwar, gangster, wargangsters, online gangsters, veiligspelen, tekst spel, rpg, rpg online, role play, play, playing, fungame, relaxgame, coolgame, supergame gratis GRATIS vuurwerk forum community, wk, euro, geld, snel, gangster nine, gangster 9, gangster, 9 gangster, nine gangsters, nine gangster, gangster IX, gangster ix, ix, nine, gangster script, cheap gangster script, mafia script, rpg mafia script, script for sale, rrpg script, gangster scripts for sale, looking to buy a mafia script, looking to buy a gangster script, rpg gangster script, rpg gangster, gangsters, gangs, online gangster script, online mafia script, online gangster game, script for gansgter rpg, script for mafia rpg, script for gangster online game, script for mafia online game, mafia, ster, rpg, mmorpg, mmorpg gangster game, mmorpg mafia game, maffia online game, maffia rpg script, looking to buy maffia script, lookin to buy gangster script, looking to buy mafia script, buying gangster script, buy gangster script, rpg script, mmorpg script, mmo gangster game, mmo mafia game, mmo maffia game, online mafia game, online gangster game, gangster game, maffia game, mafia game, gangster games, mafia games, maffia games, english gangster scripts, english gangster game, english mafia scripts, english maffia scripts, online english gangster game, online rpg gangster script, online rpg, role playin game, role playing gangster, gangster walk, gangster talk, maffia quotes, mafia quotes, mafia images, gangster images, gang games, crim games, top mafia games, top gangster games, top 10 gangster online games, top10 gangster rpg, top 10 online gangster games, top 10 online mafia games, top 10 mafia rpg, rpgs, rpg's, gangster rpg's, gangster rpgs, mafia rpgs, mafia rpg's, original gangaster, contract gangster, gangster cronicles, gangster crime, crime rpg, crime online game, online crime game, online crime rpg, online crime script, crime scripts, looking to buy crime script, night club script, al capone, al pacino, scarface script, gta rpg script, gta script, grand theft auto script, grand theft auto rpg script, gangster game, the gangster game, gangstergame.com, game gangster, gaming gangster, gangster gaming, browser online gangster game, browser online mafia game, browser gangster rpg, mafia browser rpg, browser mafia rpg, gangster browser rpg,browser based gangster rpg, browser based mafia rpg, browser based gangster game, browser based mafia game, MAFFIA, MAFIA, RPG, MMORPG, GANGSTER, CRIMINAL, CRIME, CRIMES, THUG, text based mafia rpg, texted based mafia game, online mafia text game, online mafia browser game, online gangster bnrowser game, onmline gangster text game, text based gangster rpg, text based gangster game, gangster online mmorpg, mafia online mmorpg, mmorpg gangster, mmorpg mafia, mmorpg gangster game, mmorpg mafia game, text based rpg, browser based rpg, browser rpg, text rpg, text type mafia game, text type gangster game, browser type gangster game, browser type mafia game, browser type gangster rpg, browser tpye mafia rpg, text type mafia rpg, text type gangster rpg, gangster game script, the gangster game script, website script, gangster website script, mafia website script, website game script, website rpg script, i want a mafia rpg script, i want a gangster rpg script, how much are mafia game scripts, how much are mafia rpg scripts, how much are gangster rpg scripts, how much are gangster game scripts, online internet multiplayer games, internet mafia game, internet gangster game, multiplayer gangster game, multiplayer mafia game, free online gangster rpg, free online gangster game, free online mafia rpg, free online mafia game, free multiplayer gangster game, free multiplayer mafia game,">

<META NAME="DESCRIPTION" CONTENT="Start Your Own Online Gangster Game For Only 30 Dollar | Check www.mafiagameshop.com">
<META NAME="ROBOTS" CONTENT="INDEX,FOLLOW">

<META HTTP-EQUIV="EXPIRES" CONTENT="Mon, 31 Dec 2005 00:00:01 PST">
<META HTTP-EQUIV="CHARSET" CONTENT="ISO-8859-1">
<META HTTP-EQUIV="VW96.OBJECT TYPE" CONTENT="Homepage">
<META NAME="RATING" CONTENT="General">
<META NAME="REVISIT-AFTER" CONTENT="4 days">
<base target="mainFrame" />
<meta http-equiv="refresh" content="1">



<?php
header('Location: ' . $sitelink . '/layout/layout' . $page->layout . '');
exit();
?>






<?php

	if($data){

?>	

<?php

	} else {

?>	

<meta http-equiv="refresh" content="0">
<!--  -->

<?php

	}

?>	



</body>
</html> 





<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>