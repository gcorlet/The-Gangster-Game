<?php
error_reporting(0);

include("_include-config.php");
    include("_include-gevangenis.php");

if(! check_login()) {
header("Location: login.php");
exit;
}

?><head>
<meta http-equiv="Content-Language" content="en-us">
<title><?php echo $page->sitetitle; ?></title>

  <link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">





<table align="center" width=70%>
 <tr><td class="subTitle"><b>Redlight district Info Line</b></td>
<?php
  $dbres                                = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$data->login}'");
    $clan                                = mysql_fetch_object($dbres);
$b = $clan->ramen; //
$a = $clan->bitches;
$hoeveel = $a+$b*2;
if ($clan->bitchesgezocht == 0){
$bitches	= "<font color=red><b>Not Ready!<b></font>";
}
if ($clan->bitchesgezocht == 1){
$bitches	= "<font color=green><b>Ready!<b></font>";
}

print <<<ENDHTML

  <tr><td class="mainTxt">
<b><center>Welcome to the Red Light District Info Line! <br>.
<br>
You have $data->bitches bitches in possesion!
<br>You rent $data->ramen boothes.<br>
You have found $bitches this hour.
<center>
</b>
<br>
<tr><td class="mainTxt">
  </table></td></tr>
ENDHTML;
?>

</table>

</body>


</html>