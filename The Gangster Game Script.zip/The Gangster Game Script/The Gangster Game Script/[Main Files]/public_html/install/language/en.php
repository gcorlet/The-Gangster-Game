<?php
//------------------------------------------------------------------------------ 
// English (EN)
//------------------------------------------------------------------------------ 
$arrLang = array();

$arrLang['alert_remove_files']        = "For security reasons, please remove the <b>install/</b> folder from your server!";
$arrLang['error_check_db_connection'] = "Database connection error! Please check your connection parameters.<br />";
$arrLang['database_info']             = "Enter your database details.";
$arrLang['settings_info']             = "Create the 1st Administrator.";

$arrLang['installation_wizard'] = "Installation Setup";
$arrLang['choose_language']     = "Choose a Language";
$arrLang['continue']            = "Continue";
$arrLang['back_to_website']     = "Back to the Website";
$arrLang['requirements']        = "Requirements";
$arrLang['back']                = "Back";
$arrLang['next']                = "Next";
$arrLang['database_host']       = "Database Host";
$arrLang['database_name']       = "Database Name";
$arrLang['database_username']   = "Database Username";
$arrLang['database_password']   = "Database Password";
$arrLang['username']            = "Username";
$arrLang['password']            = "Password";
$arrLang['proceed']             = "<b>Complete</b>";
$arrLang['success_install']     = "<b>The Gangster Game</b> - has been successfully installed!";
?>