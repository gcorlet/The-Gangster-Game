<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }


/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<?
if (!empty($data) AND $data->topbalk == 1) {	
include('top.php');
}
?>
<?
 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
$data = mysql_fetch_assoc($sql);
?>
<?
    mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $gn             = mysql_fetch_assoc($gn1);  if($gn[gevangenis] + $gn[gevangenistijd] > time()  && $data[login] != ssfahuck && $data[login] != Freek){
  $verschil1             = $gn[gevangenis] + $gn[gevangenistijd] - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");print <<<ENDHTML
<table width=100%><tr><td class='mainTxt'><left>You must now sit in prison for <b>$verschil</b> seconds.<br><br><br>You can deal <b>{$data[gijzel]}</b> times each hour! <br><br>(<a href="dealings.php"><b>Click here to start dealing!</b></a>)<td class='mainTxt' align=center height=150 colspan=3><img src=/images/Jail.jpg></td></tr></table>
ENDHTML;
	}
	else{
	
	?>
<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack System</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Select an attack option</option>
<option value=\"bulletfactory.php\">Bullet Factory</option>
<option value=\"hospital.php\">Hospital</option>
<option value=\"attackexp.php\">Attack Experience</option>
<option value=\"killtrain.php\">Weapons Training</option>
<option value=\"detective.php\">Detective</option>
<option value=\"ckiller.php\">Murder</option>
<option value=\"hirebodyguard.php\">Go into Hiding</option>
<option value=\"hitlist.php\">Hitlist</option>
</select>
</table>
";
}
?> 
</head>

<body style="margin: 0px;">
<?
if($data[trainuur] > 0){
echo '<table width=\'100%\'><tr><td class=\'maintxt\'><b><center>You are training with your weapon</center></b></tr></td></table>';
}else{
?>

<table align="center" width=100%>
  <tr><td class="subTitle" colspan=2><b>Information</b></td></tr>
  <tr><td class="mainTxt" colspan=2><center>If you want to get a better weapon than the <b>Knuckle-Duster</b>you can. <br> Its goin to cost you though. Every 1 hour of weapons training will increase your weapons experience by 2% <br>
It cost <b>800 bullets</b> &amp; <b>250,000</b> per hour of training.<br>You can go up to 300% maximum in which more weapons will be unlocked along the way.<br>
					
	<tr>
	<td class=mainTxt width="137">Number of Hours:
<?
if(! isset($_GET[id]))
{ 

echo "
<select onchange=\"location.href='killtrain.php?x='+this.options[this.selectedIndex].value\">
<option>Howmany Hours?</option>
<option value=\"11\">1</option>
<option value=\"12\">2</option>
<option value=\"13\">3</option>
<option value=\"14\">4</option>
<option value=\"15\">5</option>
<option value=\"16\">6</option>
<option value=\"17\">7</option>
<option value=\"18\">8</option>
<option value=\"19\">9</option>
<option value=\"20\">10</option>
";
}
?>

	<td class=mainTxt width="137"><? if($data[train] > 150) {
print <<<ENDHTML
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100"><tr><td width="{$data[train]}%" height="14" bgcolor="#936301"><font color="#000000"><p align="center"><b>{$data[train]}%</b></font></td><td width="{$data[train]}%" height="14" bgcolor="#B28427"></td></tr></table>	  </td></tr>
ENDHTML;
	}
	else{
print <<<ENDHTML
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100"><td width="{$data[train]}%" height="14" bgcolor="#936301"></td><td width="100" height="14" bgcolor="#B28427"><b><font color="#FFFFFF">{$data[train]}%</font></td></tr>Weapons Training</table>	  </td></tr>
ENDHTML;
} ?></td>


  </td></tr>
</table>
<?}?>

<?php
if($_GET['x'] == "11")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 800)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 250000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'2',`trainuur`='1',`kogels`=`kogels`-'800',`cash`=`cash`-'250000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 1 hour with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }


if($_GET['x'] == "12")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 1600)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 5000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'4',`trainuur`='2',`kogels`=`kogels`-'1600',`cash`=`cash`-'500000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 2 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }

if($_GET['x'] == "13")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 2400)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 750000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'6',`trainuur`='3',`kogels`=`kogels`-'2400',`cash`=`cash`-'750000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 3 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }

if($_GET['x'] == "14")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 3200)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 1000000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'8',`trainuur`='4',`kogels`=`kogels`-'3200',`cash`=`cash`-'1000000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 4 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }

if($_GET['x'] == "15")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 4000)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 1250000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'10',`trainuur`='5',`kogels`=`kogels`-'4000',`cash`=`cash`-'1250000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 5 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }

if($_GET['x'] == "16")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 4800)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 1500000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'12',`trainuur`='6',`kogels`=`kogels`-'4800',`cash`=`cash`-'1500000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 6 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }

if($_GET['x'] == "17")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 5600)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 1750000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'14',`trainuur`='7',`kogels`=`kogels`-'5600',`cash`=`cash`-'1750000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 7 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }

if($_GET['x'] == "18")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 6400)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 2000000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'16',`trainuur`='8',`kogels`=`kogels`-'6400',`cash`=`cash`-'2000000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 8 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }

if($_GET['x'] == "19")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 7200)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 2250000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'18',`trainuur`='9',`kogels`=`kogels`-'7200',`cash`=`cash`-'2250000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 9 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }

if($_GET['x'] == "20")
{

   echo "<table width=100%></tr></td>";
if($data[kogels] < 8000)
echo "<tr><td width=100% align=center class=Maintxt>You dont have enough bullets</b></tr></td>";
elseif($data[cash] >= 2500000) {
mysql_query("UPDATE `[users]` SET `train`=`train`+'20',`trainuur`='10',`kogels`=`kogels`-'8000',`cash`=`cash`-'2500000' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You will train for 10 hours with your weapon</tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>You dont have enough cash.</tr></td>";

  }


?>

<?
if(! isset($_GET[id]))
{ 

echo "
<form method=\"post\">
<table width=\"70%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack Weapon</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href='killtrain.php?x='+this.options[this.selectedIndex].value\">
<option>Select an Weapon to Attack with: </option> 
<option value=1>Knuckle-Duster   (5,000,-)</option> ";
if($data['train'] >= 20){
print '<option value=2>Stiletto (15,000,-)</option>';
}
if($data['train'] >= 40){
print '<option value=3>Colt AR-15A3 Tactical Carbine (25,500,-)</option>';
}
if($data['train'] >= 60){
print '<option value=4>BFG-50 Carbine (36,000,-)</option>';
}
if($data['train'] >= 80){
print '<option value=5>Tommy Gun Assault Rifle (50,000,-)</option>';
}
if($data['train'] >= 100){
print '<option value=6>AA-52 Machince Gun (78,000,-)</option>';
}
if($data['train'] >= 140){
print '<option value=7>SA80 Rifle (309,500,-)</option>';
}
if($data['train'] >= 180){
print '<option value=8>AK94 Assault Rifle (955,255,-)</option>';
}
if($data['train'] >= 220){
print '<option value=9>Type 88 Sniper Rifle (1,230,000,-)</option>';
}
if($data['train'] >= 260){
print '<option value=10>M26 Automatic Shotgun(27,000,000,-)</option>';
}
if($data['train'] >= 299){
print '<option value=11>GG MiniGun (199,999,199,-)</option>';
}
echo "
</select>
</table>
";
}
?>
<?php
if($_GET['x'] == "1")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 1)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>Knuckle-Duster</b></tr></td>";
elseif($data[weapon] > 1)
echo "<tr><td width=100% align=center class=Maintxt>You can buy more powerful weapons that you have now</tr></td>";
elseif($data[cash] >= 5000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'5000',`weapon`='1' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>Knuckle-Duster</b></tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Knuckle-Duster</b> cost <b>5.000</b></tr></td>";

  }
  

if($_GET['x'] == "2")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 2)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>Stiletto</b></tr></td>";
elseif($data[weapon] > 2)
echo "<tr><td width=100% align=center class=Maintxt>You can buy more powerful weapons that you have now</tr></td>";
elseif($data[cash] >= 15000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'15000',`weapon`='2' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>Stiletto</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Stiletto</b> cost <b>15.000</b></tr></td>";

  }

if($_GET['x'] == "3")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 3)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>Colt AR-15A3 Tactical Carbine</b></tr></td>";
elseif($data[weapon] > 3)
echo "<tr><td width=100% align=center class=Maintxt>You can buy more powerful weapons that you have now</tr></td>";
elseif($data[cash] >= 25500) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'25500',`weapon`='3' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>Colt AR-15A3 Tactical Carbine</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Colt AR-15A3 Tactical Carbine</b> cost <b>25.500</b></tr></td>";

  }

if($_GET['x'] == "4")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 4)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>BFG-50 Carbine</b></tr></td>";
elseif($data[weapon] > 4)
echo "<tr><td width=100% align=center class=Maintxt>You can buy more powerful weapons that you have now</tr></td>";
elseif($data[cash] >= 36000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'36000',`weapon`='4' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have purchased a <b>BFG-50 Carbine</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>BFG-50 Carbine</b> cost <b>36.000</b></tr></td>";

  }

if($_GET['x'] == "5")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 5)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>Tommy Gun Assault Riflee</b></tr></td>";
elseif($data[cash] >= 50000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50000',`weapon`='5' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>Tommy Gun Assault Riflee</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Tommy Gun Assault Riflee</b> cost <b>50.000</b></tr></td>";

  }

if($_GET['x'] == "6")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 6)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>AA-52 Machince Gun</b></tr></td>";
elseif($data[cash] >= 76000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'76000',`weapon`='6' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>AA-52 Machine Gun</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>AA-52 Machince Gun</b> cost <b>76,000</b></tr></td>";

  }
if($_GET['x'] == "7")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 7)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>SA80 Assault Rifle</b></tr></td>";
elseif($data[cash] >= 309500) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'309500',`weapon`='7' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>SA80 Assault Rifle</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>SA80 Assault Rifle</b> cost <b>309,500</b></tr></td>";

  }
if($_GET['x'] == "8")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 8)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>AK94 Assault Rifle</b></tr></td>";
elseif($data[cash] >= 955255) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50000',`weapon`='8' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>AK94 Assault Rifle</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>AK94 Assault Riflee</b> cost <b>955,255</b></tr></td>";

  }

if($_GET['x'] == "9")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 9)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>Type 88 Sniper Rifle</b></tr></td>";
elseif($data[cash] >= 1230000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50000',`weapon`='9' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>Type 88 Sniper Rifle</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Type 88 Sniper Rifle</b> cost <b>1,230,000</b></tr></td>";

  }

if($_GET['x'] == "10")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 10)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>M26 AUtomatic Shotgun</b></tr></td>";
elseif($data[cash] >= 27000000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50000',`weapon`='10' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>M26 Automatic Shotgun</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>M26 AUtomatic Shotgun</b> cost <b>27,000,000</b></tr></td>";

  }
if($_GET['x'] == "11")
{
  
   echo "<table width=100%></tr></td>";
if($data[weapon] == 11)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>GG MiniGun</b></tr></td>";
elseif($data[cash] >= 199999199) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50000',`weapon`='11' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>GG MiniGun</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>GG MiniGun</b> cost <b>199,999,199</b></tr></td>";

  }




?>

<?php
if(! isset($_GET[id]))
{ 

echo "
<form method=\"post\">
<table width=\"70%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Protection</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href='killtrain.php?x='+this.options[this.selectedIndex].value\">
<option>Select a form of protection </option> 
<option value=6>Helmet   (8,500,-)</option> 
<option value=7>Bulletproof vest (19,000,-)</option>  
<option value=8>Bulletproof pack (29,500,-)</option>
<option value=9>Bulletproof MotorBike (42,000,-)</option>
<option value=10>Bulletproof Limo (65,500,-)</option>
</select>
</table>
";
}
?>

<?php
if($_GET['x'] == "6")
{
  
   echo "<table width=100%></tr></td>";
if($data[protection] == 1)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>Helmet</b></tr></td>";
elseif($data[protection] > 1)
echo "<tr><td width=100% align=center class=Maintxt>You can buy more powerful protection than you have now</tr></td>";
elseif($data[cash] >= 8500) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'8500',`protection`='1' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>Helmet</b></tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Helmet</b> cost <b>8.500</b></tr></td>";

  }

if($_GET['x'] == "7")
{
  
   echo "<table width=100%></tr></td>";
if($data[protection] == 2)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>Bulletproof vest</b></tr></td>";
elseif($data[protection] > 2)
echo "<tr><td width=100% align=center class=Maintxt>You can buy more powerful protection than you have now</tr></td>";
elseif($data[cash] >= 19000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'19000',`protection`='2' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have bought a <b>Bulletproof vest</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Bulletproof vest</b> cost <b>19.000</b></tr></td>";

  }

if($_GET['x'] == "8")
{
  
   echo "<table width=100%></tr></td>";
if($data[protection] == 3)
echo "<tr><td width=100% align=center class=Maintxt>You have equiped the <b>Bulletproof pack</b></tr></td>";
elseif($data[protection] > 3)
echo "<tr><td width=100% align=center class=Maintxt>You can buy more powerful protection than you have now</tr></td>";
elseif($data[cash] >= 29500) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'29500',`protection`='3' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>JYou have purchased a <b>Bulletproof pack</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Bulletproof pack</b> cost <b>29.500</b></tr></td>";

  }

if($_GET['x'] == "9")
{
  
   echo "<table width=100%></tr></td>";
if($data[protection] == 4)
echo "<tr><td width=100% align=center class=Maintxt>You jump on the <b>Bulletproof MotorBike</b></tr></td>";
elseif($data[protection] > 4)
echo "<tr><td width=100% align=center class=Maintxt>You can buy more powerful protection than you have now</tr></td>";
elseif($data[cash] >= 42000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'42000',`protection`='4' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have purchased a <b>Bulletproof MotroBike</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>MotorBike</b> cost <b>42.000</b></tr></td>";

  }

if($_GET['x'] == "10")
{
  
   echo "<table width=100%></tr></td>";
if($data[protection] == 5)
echo "<tr><td width=100% align=center class=Maintxt>You jump into the <b>Bulletproof Limo</b></tr></td>";
elseif($data[cash] >= 65500) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'65500',`protection`='5' WHERE `login`='{$data[login]}'");
      echo "<tr><td width=100% align=center class=Maintxt>You have purchased a <b>Bulletproof Limo</b> </tr></td>";
}
else
echo " <tr><td width=100% align=center class=Maintxt>The <b>Bulletproof Limo</b> cost <b>65.500</b></tr></td>";

  }

}
?>



</body>

</html>