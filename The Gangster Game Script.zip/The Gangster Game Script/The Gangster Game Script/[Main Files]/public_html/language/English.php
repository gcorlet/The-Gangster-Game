<?php
<!--- 
English Language File 
 --->
// MAIN MENU
$MainMenu-1 = "Player Headquarters";
$MainMenu-2 = "Personal Website Links";
$MainMenu-3 = "To earn some extra cash, invite people to sign up and ask them to put your name in the recruiter box.<br>
This way you will earn <b>1,000,000</b> each time your name is entered when another person signs up!";
$MainMenu-4 = "";
$MainMenu-5 = "";
$MainMenu-6 = "";



?>