<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>

<?php
include("../../_include-config.php");

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);


?>
<center>
<title><?php echo $page->sitetitle; ?> - Browser Based Gangster Game/Script</title>



<META NAME="KEYWORDS" CONTENT="free web based rpg,gangs rpg,street rpg,online fun rpg game,online rpg world,free internet rpg,new online rpg game,massive online rpg game ,role playing website,gangsta rpg,rpg gaming  online,new mmorpg games ,play free online mmorpg ,play free mmorpg game,free web based mmorpg,web mmorpg,free browser based mmorpg,free multiplayer web game,online multiplayer rpg game,adventure and role playing game,free gangster game,online gangsta game ,free online gangsta game,free online gangster game, gangster game, gangster rpg script, mafia rpg script, rpg script, mmorpg script, criminals rpg script, crime rpg script, pimp rpg script, thug rpg script, pimp rpg, online pimp game, web pimp,gangster game, rpg, online, criminals, crime, spel, free, gratis, winnen, 123 spel, gratis spel, spel nl, free online gangster game, gangster, mobster, mobstar, mafia, maffia, game, games, drugs, dealer, kill, fight, money, game,rgp,no,name,crime,life,lycos,criminals,barafranca,mobstar,kings,of,chaos,online,php,super,goed,spel,spelletje,spellen,leuk,mooi,Wetenschaper,politie,drugsdealer,junkie,dealer,drugs,freek,massive,multiplayer,online,role,playing,world, mobstar, gangsta, gangster, gang, crew, kill, free, pimp, pimpwar, pimps, rpg, role play, played, based, script, download, mobile, money, gold, digger, world, GRATIS criminals scripts sources bulletstar criminalsloco crime hacking time4crime worldcrime shop route66 misdaden werken mafia maffia american thugwars scripter scriptz thugie mobstar barafranca cola automaat hacken criminalsfanaat xtreme-war spele.nl webfanaat-sg source wmcity source basicwar maralana cheats ciawars source ,bulletstar source, criminal, fanaat, dutchleaders, dutchcrime2005, hosting, bellen, crimetop, funky, crimestar, crime-age, crime-streets, streetgang, gangstercrime, hard trueo, power, geld, php, mysql, html, asp, hulp, win, prijzen, leden ,members, world ,command ,coding, realcrime, crime, streetz ,thug,thugs ,thugz, gun, ak47 ,thugwarz, bulletgame, criminalz, kriminals, kriminalz, krime, crimeclub, Website, statistieken, xylohosting, crimeplanet ,criminalspoint, criminalspoint.nl, google ,wargames, blmgame, belikeme, online criminal, criminal, criminals, spelen, speel, games, online, onlinegames, speel, scripts, limwire, kazaa, kazaalite, downloads, hostting, criminalz, Wargame, RPG, Gangstergame, Pimpgame, Lekker crimineel spelletje spelen voor de fun. mafia video game, mafia game, maffia game, online mafia game, mafiagame, mafia the game, online maffia game, game mafia, mafia pc game, mafia online game, mafie, mafia game online, game maffia, mafia 2 game, mafia full game, mafia save game, pc game mafia, mafis, maffia the game, mafia rpg game, mafia saved game, download mafia game, mafia game download, mafia game music, mafia the game cheats, maafia, mafia game walkthrough, online game mafia, mafia 2 the game, mafia full game download, mafia game patch, save game mafia, game mafia 2, mafia game pc, mafia game soundtrack, www mafia game, game mafia cheats, mafia game downloads, mafia game mods, mafia game saves, mafia 2 pc game, ny mafia game, the mafia game, www mafiagame, mafia game 2, mafia game cheat, mafia game cheats, mafia game map, mafia network game, mafia pc game cheats, mafiagame com, the game mafia, www mafiagame com, for mafia game, mafia boss game, mafia game com, the mafia boss game, www mafia game com, le mafie, mafia card game, mafia game cars, mafia game crack, mafia game demo, mafia game for, mafia game trainer, mafis chess, maffia game, online maffia game, game maffia, maffia the game, criminalz, criminalz game, criminalz online game, criminalz rpg, habbo criminalz, criminalz het spel, red criminalz, het game criminalz, land criminalz, yellow criminalz, online criminalz game, blue criminalz, bedrijf criminalz, bedrijven criminalz, top 50 criminalz, spel criminalz, net gereset, speel criminalz.nl Mafia games , maffia games , online mafia games , online maffia games , maffiagames , mafia games online , games mafia , mafiagames , mafia online games , mafia save games , rpg mafia games , multiplayer mafia games , mafia rpg games , mafia saved games , pc games mafia , based mafia games , mafia games on , mafia pc games criminalz scripts , gratis criminalz script, fun lovin criminalz, fun loving criminalz, britons most wanted criminalz, little criminalz, scripts criminalz, criminalz verkoop, criminalz hacken, free criminalz scripts, criminalz script free, most wanted criminalz, sitekeuring.com criminalz, criminalz php script downloaden, scrip criminalz, art criminalz, coco criminalz, criminalz bug, criminalz free script, criminalz free script, download criminalz script php, koop hier criminalz, script criminalz free, criminalz logo, fun criminalz, fun lovin criminalz 2005, gratis criminalz script php,criminalz hacker, criminalz scripts download, gratis scripts voor criminalz, la vida loca criminalz, my criminalz, criminalz maken, criminalz mycyberchat, criminalz scrip, criminalz script install, criminalz spel net reset, fun love criminalz, nazi war criminalz, treu criminalz, true criminalz, criminals.nl, belikeme.nl, chat, chatbox, chatten, tieners, jongeren, jeugd, kids, kinderen, kindergame, onlinegame, livechat, juegdchat, warchat, nieuwschat, jongerenchat, jongens, meisjes, kriminelen, gangs, wargangs, gangsters, gangsterwar, gangster, wargangsters, online gangsters, veiligspelen, tekst spel, rpg, rpg online, role play, play, playing, fungame, relaxgame, coolgame, supergame gratis GRATIS vuurwerk forum community, wk, euro, geld, snel, gangster nine, gangster 9, gangster, 9 gangster, nine gangsters, nine gangster, gangster IX, gangster ix, ix, nine, gangster script, cheap gangster script, mafia script, rpg mafia script, script for sale, rrpg script, gangster scripts for sale, looking to buy a mafia script, looking to buy a gangster script, rpg gangster script, rpg gangster, gangsters, gangs, online gangster script, online mafia script, online gangster game, script for gansgter rpg, script for mafia rpg, script for gangster online game, script for mafia online game, mafia, ster, rpg, mmorpg, mmorpg gangster game, mmorpg mafia game, maffia online game, maffia rpg script, looking to buy maffia script, lookin to buy gangster script, looking to buy mafia script, buying gangster script, buy gangster script, rpg script, mmorpg script, mmo gangster game, mmo mafia game, mmo maffia game, online mafia game, online gangster game, gangster game, maffia game, mafia game, gangster games, mafia games, maffia games, english gangster scripts, english gangster game, english mafia scripts, english maffia scripts, online english gangster game, online rpg gangster script, online rpg, role playin game, role playing gangster, gangster walk, gangster talk, maffia quotes, mafia quotes, mafia images, gangster images, gang games, crim games, top mafia games, top gangster games, top 10 gangster online games, top10 gangster rpg, top 10 online gangster games, top 10 online mafia games, top 10 mafia rpg, rpgs, rpg's, gangster rpg's, gangster rpgs, mafia rpgs, mafia rpg's, original gangaster, contract gangster, gangster cronicles, gangster crime, crime rpg, crime online game, online crime game, online crime rpg, online crime script, crime scripts, looking to buy crime script, night club script, al capone, al pacino, scarface script, gta rpg script, gta script, grand theft auto script, grand theft auto rpg script, gangster game, the gangster game, gangstergame.com, game gangster, gaming gangster, gangster gaming, browser online gangster game, browser online mafia game, browser gangster rpg, mafia browser rpg, browser mafia rpg, gangster browser rpg,browser based gangster rpg, browser based mafia rpg, browser based gangster game, browser based mafia game, MAFFIA, MAFIA, RPG, MMORPG, GANGSTER, CRIMINAL, CRIME, CRIMES, THUG, text based mafia rpg, texted based mafia game, online mafia text game, online mafia browser game, online gangster bnrowser game, onmline gangster text game, text based gangster rpg, text based gangster game, gangster online mmorpg, mafia online mmorpg, mmorpg gangster, mmorpg mafia, mmorpg gangster game, mmorpg mafia game, text based rpg, browser based rpg, browser rpg, text rpg, text type mafia game, text type gangster game, browser type gangster game, browser type mafia game, browser type gangster rpg, browser tpye mafia rpg, text type mafia rpg, text type gangster rpg, gangster game script, the gangster game script, website script, gangster website script, mafia website script, website game script, website rpg script, i want a mafia rpg script, i want a gangster rpg script, how much are mafia game scripts, how much are mafia rpg scripts, how much are gangster rpg scripts, how much are gangster game scripts, online internet multiplayer games, internet mafia game, internet gangster game, multiplayer gangster game, multiplayer mafia game, free online gangster rpg, free online gangster game, free online mafia rpg, free online mafia game, free multiplayer gangster game, free multiplayer mafia game,">

<META NAME="DESCRIPTION" CONTENT="Start Your Own Online Gangster Game For Only 30 Dollar | Check www.mafiagameshop.com">

<META HTTP-EQUIV="EXPIRES" CONTENT="Mon, 31 Dec 2005 00:00:01 PST">
<META HTTP-EQUIV="CHARSET" CONTENT="ISO-8859-1">
<META HTTP-EQUIV="VW96.OBJECT TYPE" CONTENT="Homepage">
<META NAME="RATING" CONTENT="General">
<META NAME="REVISIT-AFTER" CONTENT="4 days">
<base target="mainFrame" />

<script language="javascript">
function showMenu(id) {
  if(document.getElementById(id).style.visibility == "hidden") {
    document.getElementById(id).style.position		= "static";
    document.getElementById(id).style.visibility	= "visible";
  }
  else {
    document.getElementById(id).style.visibility	= "hidden";
    document.getElementById(id).style.position		= "absolute";
    document.getElementById(id).style.left		= -100;
    document.getElementById(id).style.top		= -100;
  }

  document.getElementById('mainTable').height		= '100%';
}
</script>
<script type="text/javascript"> 

var currenttime = '<? echo date("F d, Y H:i:s"); ?>' 
var serverdate=new Date(currenttime) 

function padlength(what){ 
var output=(what.toString().length==1)? "0"+what : what 
return output 
} 

function displaytime(){ 
serverdate.setSeconds(serverdate.getSeconds()+1) 
var
timestring=padlength(serverdate.getHours())+":"+padlength(serverdate.getMinutes())+":"+padlength(serverdate.getSeconds()) 
document.getElementById("servertime").innerHTML=timestring 
} 

window.onload=function(){ 
setInterval("displaytime()", 1000) 
} 

</script>
<LINK REL="SHORTCUT ICON" href="../../favicon.ico"> 
<style>.shadow1 { color: FFFFFF; position: absolute; left: -1px; top: 1px; } .shadow2 { left: 1px; top: 1px; position: relative; font-size: 10px; font-family: Verdana; font-weight : bold;  color: 000000;}</style>
<link href="<? echo $sitelink;?>/layout/layout001/style.css" type="text/css" rel="stylesheet">



<?
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);
  $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `activated`=1");
  $leden				= mysql_num_rows($dbres);
  $dbres2                                = mysql_query("SELECT `id` FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300");
  $online                                = mysql_num_rows($dbres2);
  $laatstelid = mysql_query("select `login` from `[users]` order by id desc limit 1");
  $laatste = @mysql_result($laatstelid,0,0);
$leven = $data->health;
$cash = number_format($data->cash, 0, '.' , '.');
$bank = number_format($data->bank, 0, '.' , '.');
  $inboxnew = mysql_num_rows(mysql_query("SELECT id FROM `[messages]` WHERE `read`=0 AND `inbox`=1 AND `to`='$data->login'"));
$attack = $data->attack;
$defence = $data->defence;
$clickpower = round($clicks*5);
$power = round($attack+$defence+$clickpower/2);
  $land				= Array("","Nederland","Frankrijk","Cuba","Rusland","Australi�","VS");
  $land				= $land[$data->land];
  $land2			= Array("","nederland","frankrijk","cuba","rusland","australie","vs");
  $land2			= $land2[$data->land];
?>


<meta http-equiv="refresh" content="1000">
<!---->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@5.9.55/css/materialdesignicons.min.css">
<link rel="stylesheet" type="text/css" hjref="css/bootstrap">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@5.9.55/css/materialdesignicons.min.css">

</head><body>

<div id="container" align="top">

	<div id="banner"></div>
	<div id="content">
		<div id="left" class="s">

	
			<div class="side_header"><font color="gold"><i class="fa fa-list fa"></i> MAIN MENU</font></div>
			<div class="side_content_menu">
	<ul class="list_side">
	
	
<li><a class="login" href="../../rankhq.php"><font color="red"><i class="fa fa-user"></i><b> Status</b></font></a> </li>
					
<li><a class="login" href="../../homehelp.php"><i class="fa fa-question-circle"></i> <b>Help</b></a></li>
<li><a class="login" href="../../forum.php"><i class="fa fa-table"></i> <b>Forum</b></a></li>
			<li><a class="login" href="../../stats.php"><i class="fa fa-chart-line"></i> <b>Stats</b></a></li>
			<li><a class="login" href="../../bank.php?x=pinstort"><i class="fa fa-bank"></i><b> Bank</b></a> </li>
			<li><a class="login" href="../../message.php?p=inbox"><i class="fa fa-envelope"></i> <b> Inbox:  <fontcolor=white><?=$inboxnew?>                    </font></b></a> </li>
			<li><a class="login" href="../../list.php?s=online"><i class="fa fa-users"></i><b> Members Online</b></a> </li>
			<li><a class="login" href="../../list.php"><i class="fa fa-users"></i><b> Members List</b></a> </li>
			<li><a class="login" href="../../airport.php"><i class="fa fa-plane"></i><b> Airport</b></a> </li>
			<li><a class="login" href="../../shop.php"><span class="mdi mdi-pistol"></span><b> Weapon Shop</b></a> </li>
					
				</ul>
			</div>


	<div class="side_header"><font color="gold"><i class="fa fa-city"></i> CITY STREETS</font></div>
			<div class="side_content_menu">
				<ul class="list_side">
					<li><a class="login" href="../../nusiness.php"><i class="fa fa-briefcase"></i><b> Business</b></a> </li>
					<li><a class="login" href="../../hospital.php"><i class="fa fa-hospital-symbol"></i><b> Hospital</b></a> </li>
					<li><a class="login" href="../../huwelijk.php"><i class="fa fa-ring"></i><b> Marriage</b></a> </li>
					<li><a class="login" href="../../prison.php"><i class="fa fa-dungeon"></i><b> Prison</b></a> </li>
					<li><a class="login" href="../../mac.php"><i class="fa fa-hamburger"></i><b> MaC Donalds</b></a> </li>
                    <li><a class="login" href="../../house.php"><i class="fa fa-house-user"></i><b> Your House</b></a> </li>
					<li><a class="login" href="../../redlightdistrict.php"><i class="fa fa-money-bill"></i><b> Redlight District</b></a> </li>
					<li><a class="login" href="../../work.php"><i class="fa fa-file-word"></i><b> Work </b></a> </li>
				</ul>
				
				
			</div>

			<div class="side_header"><font color="gold"><i class="fa fa-car-side"></i> CAR OPTIONS</font></div>
			<div class="side_content_menu">
	<ul class="list_side">
					<li><a class="login" href="../../garage.php"><i class="fa fa-warehouse"></i><b> Garage</b></a> </li>
					<li><a class="login" href="../../auto_theft.php"><i class="fa fa-car"></i><b> Steal Cars</b></a> </li>
					<li><a class="login" href="../../missie.php"><i class="fa fa-list"></i><b> Missions</b></a> </li>
					<li><a class="login" href="../../autostore.php?b=1"><i class="fa fa-car"></i><b> Car Dealer</b></a> </li>
					<li><a class="login" href="../../autoveiling.php"><i class="fa fa-gavel"></i><b> Auction</b></a> </li>
					<li><a class="login" href="../../drivingschool.php"><i class="fa fa-id-card"></i><b> Driving License</b></a> </li>
					<li><a class="login" href="../../tunerace.php"><i class="fa fa-flag-checkered"></i><b> Pimp Race</b></a> </li>
				</ul>
			</div>
			<div class="side_header"><font color="gold"><span class="mdi mdi-cards"></span> CASINO</font></div>
			<div class="side_content_menu">
	<ul class="list_side">
	
					<li><a class="login" href="../../lottery.php"><span class="mdi mdi-cards"></span><b> Lottery</b></a> </li>
					<li><a class="login" href="../../5050.php"><span class="mdi mdi-cards"></span><b> 50/50</b></a> </li>
					<li><a class="login" href="../../dice.php"><span class="mdi mdi-cards"></span><b> Dice</b></a> </li>
					<li><a class="login" href="../../scratchcards.php"><span class="mdi mdi-cards"></span><b> Scratch Card</b></a> </li>
					<li><a class="login" href="../../rps.php"><span class="mdi mdi-cards"></span><b> Rock Paper Scissors</b></a> </li>
					<li><a class="login" href="../../roulette.php"><span class="mdi mdi-cards"></span><b> Roulette</b></a> </li>
					<li><a class="login" href="../../numbersgame.php"><span class="mdi mdi-cards"></span><b> Numbers Game</b></a> </li>
					<li><a class="login" href="../../blackjack.php"><span class="mdi mdi-cards"></span><b> Blackjack</b></a> </li>
					<li><a class="login" href="../../bjmulti.php"><span class="mdi mdi-cards"></span><b> Blackjack Multi</b></a> </li>
					<li><a class="login" href="../../highdrawsingle.php"><span class="mdi mdi-cards"></span><b> High Card</b></a> </li>
					
				</ul>
			</div>



</div>

		<div id="center">
		
			<!-- Stats en main screen -->
			
<center>
<iframe src="stats.php" name="stats" noresize="" marginheight="0" marginwidth="0" align="middle" frameborder="0" height="40" width="620">Your browser does not support iFrames.</iframe>

<BR />

<center>
<?php

	if($data){

?>	




<iframe src="<?php echo ($data) ? "../../hq.php" : "../home.php" ?>" name="mainFrame" width=620 frameborder=0 height=1155></iframe>

<?php

	} else {

	$dbres		=	mysql_query("SELECT * FROM `gebruiker`");
	$signups	=	mysql_num_rows($dbres);

	$dbres		=	mysql_query("SELECT * FROM `gebruiker` WHERE (UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300)");
	$online		=	mysql_num_rows($dbres);

?>


<iframe src="<?php echo ($data) ? "../../speler-status.php" : "../../home.php" ?>" name="mainFrame" width=620 frameborder=0 height=1155></iframe>

<?php

	}

?>	

</center>
</div> 



		<div id="right" class="s">
		

	<div class="side_header"><font color="gold"><i class="fa fa-star"></i> VIP MENU</font></div>
			<div class="side_content_menu">
				<ul class="list_side">			
					<li><font color="gold"><i class="fa fa-star"></i><a class="login" href="../../buyrank.php"><b> Rank Increase</b></a> </li>
					<li><i class="fa fa-star"></i> <a class="login" href="../../buycredits.php"><b> VIP Credits</b></a> </li>
					<li><i class="fa fa-star"></i> <a class="login" href="../../creditshop.php"><b> Credits Shop</b></a> </li>
					<li><i class="fa fa-star"></i> <a class="login" href="../../crackthesafe.php"><b> Crack the Safe</b></a> </li>
					<li><i class="fa fa-star"></i> <a class="login" href="../../vip.php"><b> Purchase VIP</b></a> </li>
				
					
				</ul>
			</div>


<?
     if($data->vip > 0) {

      print "        <div class=\"side_header\"><font color=\"gold\"><i class=\"fa fa-star\"></i> VIP MENU</font></div>
			<div class=\"side_content_menu\">
				<ul class=\"list_side\">\n";	
 if($data->vip > 0) 
    
		print "        <li><a class=\"login\" href=\"../../boxing.php\"><span class=\"mdi mdi-boxing-glove\"></span><b> Boxing</b></a> </li>\n";
		print "        <li><a class=\"login\" href=\"../../specialshop.php\"><span class=\"mdi mdi-shopping\"></span><b> Specialised Shop</b></a> </li>\n";
		print "        <li><a class=\"login\" href=\"../../ganja.php\"><i class=\"fa fa-cannabis\"></i><b> Ganja Cultivation</b></a> </li>\n";
		print "        <li><a class=\"login\" href=\"../../drugdeal.php\"><i class=\"fa fa-tablets\"></i><b> Drug Dealing</b></a> </li>\n";
		print "        <li><a class=\"login\" href=\"../../training1.php\"><i class=\"fa fa-screwdriver\"></i><b> Car Stealing Training</b></a> </li>\n";
		print "        <li><a class=\"login\" href=\"../../training2.php\"><span class=\"mdi mdi-account-voice\"></span><b> Crime Training</b></a> </li>\n";
		print "        <li><a class=\"login\" href=\"../../homegrown.php\"><i class=\"fa fa-cannabis\"></i><b> Home Grown</b></a> </li>\n";
		print "        <li><a class=\"login\" href=\"../../cokefactory.php\"><i class=\"fa fa-snowflake\"></i><b> Cocaine Factory</b></a> </li>\n";
			
    }

	      print "       \n";
	
?>		

			<div class="side_header"><center><font color="gold"><i class="fa fa-dollar-sign"></i> PLAYGROUND</font></center></div>
			<div class="side_content_menu">
	<ul class="list_side">			
				    <li><a class="login" href="../../hireprotection.php"><span class="mdi mdi-shield-cross"></span><b> Hire Protection</b></a> </li>
					<li><a class="login" href="../../stocks.php"><span class="mdi mdi-chart-line"></span><b> Stock Market</b></a> </li>
					<li><a class="login" href="../../beginnercrimes.php"><span class="mdi mdi-domino-mask"></span><b> Beginners Crimes</b></a> </li>
					<li><a class="login" href="../../advancedcrimes.php"><span class="mdi mdi-lock-open-check-outline"></span><b> Advanced Crimes</b></a> </li>
					<li><a class="login" href="../../stealp.php"><span class="mdi mdi-account-supervisor"></span><b> Rob Player</b></a> </li>
					<li><a class="login" href="../../attackoptions.php"><span class="mdi mdi-handcuffs"></span><b> Attack Options</b></a> </li>
					<li><a class="login" href="../../bulletfactory.php"><span class="mdi mdi-bullet"></span><b> Bullet Factory</b></a> </li>
					<li><a class="login" href="../../fraud.php"><span class="mdi mdi-cash-lock-open"></span><b> Fraud</b></a> </li>
					<li><a class="login" href="../../heist.php"><span class="mdi mdi-van-utility"></span><b> Transport Heist</b></a> </li>
					<li><a class="login" href="../../orgcrime.php"><span class="mdi mdi-account-group"></span><b> Organised Crime</b></a> </li>
					<li><a class="login" href="../../sail.php"><span class="mdi mdi-pistol"></span><b> Weapons Handling</b></a> </li>
					<li><a class="login" href="../../assault.php"><span class="mdi mdi-handcuffs"></span><b> Assaults</b></a> </li>
					<li><a class="login" href="../../bankrob.php"><span class="mdi mdi-bank"></span><b> Bank Robbery</b></a> </li>
					<li><a class="login" href="../../will.php"><span class="mdi mdi-folder-open"></span><b> Testament</b></a> </li>
				</ul>
			</div>




			<div class="side_header"><center><font color="gold"><i class="fa fa-users"></i> GANG OPTIONS</center></font></div>
			<div class="side_content_menu">
	<ul class="list_side">			
		<li><a class="login" href="../../clanlist.php"><i class="fa fa-users"></i><b> Gang List</b></a> </li>						
<?
if($data->clanlevel == 0) {
      print "        <li><a class=\"login\" href=\"../../clann.php?p=join\"><i class=\"fa fa-users\"></i><b> Join a Gang</b></a> </li>\n";
      if($data->clanlevel == 0)
        print "        <li><a class=\"login\" href=\"../../clan.php?p=new\"><i class=\"fa fa-users\"></i><b> Start a New Gang</b></a> </li>\n";
    }
    else {
      print "        <li><a class=\"login\" href=\"../../clan.php?x={$data->clan}\"><i class=\"fa fa-users\"></i><b> Profile</b></a> </li>\n";
      print "        <li><a class=\"login\" href=\"../../clanforum.php\"><i class=\"fa fa-users\"></i><b> Gang Forum</b></a> </li>\n";             
  print "        <li><a class=\"login\" href=\"../../clanlogs.php\"><i class=\"fa fa-users\"></i><b> Gang Logs</b></a> </li>\n";
  
  
      if($data->clanlevel >= 8 || $data->clanlevel == 6) {
        print "        <li><a class=\"login\" href=\"../../clanbank.php\"><i class=\"fa fa-users\"></i><b> Gang Bank</b></a> </li>\n";
        print "        <li><a class=\"login\" href=\"../../clanshop.php\"><i class=\"fa fa-users\"></i><b> Gang Shops</b></a> </li>\n";
      }
	  
	  
      if($data->clanlevel >= 8 || $data->clanlevel == 2)
        print "        <li><a class=\"login\" href=\"../../clanhq.php?p=recruits\"><i class=\"fa fa-users\"></i><b> Gang Recruits</b></a> </li>\n";
		
		
      if($data->clanlevel >= 8) {
       print "  <li><a class=\"login\" href=\"../../leaderopties.php?x=logs\"><i class=\"fa fa-users\"></i><b> Logs</b></a> </li>\n";       
 print "        <li><a class=\"login\" href=\"../../clanhq.php?p=members\"><i class=\"fa fa-users\"></i><b> Members</b></a> </li>\n";
        print "        <li><a class=\"login\" href=\"../../leaderopties.php\"><i class=\"fa fa-users\"></i><b> Options</b></a> </li>\n";
                print "        <li><a class=\"login\" href=\"../../clanmsg.php?p=msg\"><i class=\"fa fa-users\"></i><b>  Mass Gang Message</b></a> </li>\n";
      }
      if($data->clanlevel > 0) {
        if($data->clanlevel < 9)
          print "  <li><a class=\"login\" href=\"../../clan.php?p=quit\"><i class=\"fa fa-users\"></i><b> Leave this Gang</b></a> </li>\n";
        else
          print "  <li><a class=\"login\" href=\"../../clan.php?p=delete\"><i class=\"fa fa-users\"></i><b> Delete Gang</b></a> </li>\n";
      }
    }
?>		
			
				</ul>
			</div>


			<div class="side_header"><center><font color="gold"><i class="fa fa-user"></i> PERSONAL</center></font></div>
			<div class="side_content_menu">
	<ul class="list_side">
				<ul class="list_side">
<li><a class="login" href="../../profile.php?x=<? echo $data->login ?>"><i class="fa fa-user"></i><b> View Profile</b></a> </li>
					<li><a class="login" href="../../edit.php"><i class="fa fa-user-edit"></i><b> Edit Profile</b></a> </li>

			

					<li><a class="login" href="../../ticket.php"><span class="mdi mdi-ticket"></span><b> Support Ticket</b></a> </li>
					<li><a class="login" href="../../respectpoints.php"><span class="mdi mdi-account-star"></span><b> Respect Points</b></a> </li>
					<li><a class="login" href="../../pimpname.php"><i class="fa fa-user-tie"></i><b> Name Pimpin</b></a> </li>
					<li><a class="login" href="../../log.php"><span class="mdi mdi-account-details"></span><b> Logs</b></a> </li>
<li><a class="login" href="../../login.php?x=logout"><span class="mdi mdi-logout-variant"></span><b>Logout</b></a></li>
				</ul>
				
				
			</ul></div>
			
<?
    if($data->login == $admin2 || $data->login == $admin1) {

      print "        \n";	

    if($data->login == $admin2 || $data->login == $admin1)

		print "       <div class=\"side_header\"><center><font color=\"gold\"><i class=\"fa fa-user-lock\"></i> ADMIN OPTIONS</center></font></div>
			<div class=\"side_content_menu\">
				<ul class=\"list_side\"> <li><a class=\"login\" href=\"../../admin/menu_admin.php\"><i class=\"fa fa-lock\"></i><b> Admin Menu</b></a> </li>\n";
		
    }
    else {
      print "        \n";
  
  
      if($data->hulpadmin == 1) {
		print "        <li><a class=\"login\" href=\"../../hulpadmin/menu_helpadmin.php\"><center><font color=\"gold\"><i class=\"fa fa-user-lock\"></i> Helper-Admin Menu </center></font></b></a> </li>\n";

      }
    }
	      print "        \n";	
?>		

		</div>
	</div>

		</div>		
<center>




<script src="https://kit.fontawesome.com/c63b28a58b.js" crossorigin="anonymous"></script>
</center></body></html>

