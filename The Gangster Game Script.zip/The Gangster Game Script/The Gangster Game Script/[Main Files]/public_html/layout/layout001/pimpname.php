<?php
error_reporting(0);

 
  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");




  
/* ------------------------- */ ?>


<html>
<head>
<title><?=$title; ?></title>
</head>
<body>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<table width="100%">
<tr><td class="SubTitle"><b><font face="Verdana" size="1">Star</font></b></td></tr>
<tr><td class="MainTxt">
	<p align="center">Here you can choose icons and text to follow your name.<br>
	Some are for VIP members only.</td></tr>
</table>



<table width="100%" align="center">
<tr>
<td align=center width=100%>

	<form method="post">
	<table width="271">
	<tr>
	<td class="subTitle" align="center"><b>Icon / Choose Text</b></td>
	</tr>
		
	</table>
	<table width="271">
	<tr>
	<td class="maintxt" align="center">
	<p align="left">
	<Input type="radio" value="V10" name="naam2" onClick="window.location=('pimpname.php?ster=geen')">  
		<b>I dont want any Icon or Text&nbsp;hebben&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </b></td>
	</tr>
		
	</table>
	<table width="270">
	<tr><td class="mainTxt" width="89">
	<Input type="radio" value="V1" name="naam2" onClick="window.location=('pimpname.php?ster=1')">  
		<b>Icon 1</b></td><td width=171 class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/star.gif" width="14" height="15"></td></tr>
	<tr><td class="mainTxt" width="89">
	<Input type="radio" value="V2" name="naam2" onClick="window.location=('pimpname.php?ster=2')">  
		<b>Icon 2</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/ster.gif" width="14" height="15"></td></tr>
	<tr><td class="mainTxt" width="89">
	<Input type="radio" value="V3" name="naam2" onClick="window.location=('pimpname.php?ster=3')"><b>  
		Icon 3</b></td><td class="mainTxt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<img border="0" src="images/smilies/ster1.gif" width="14" height="15"></td></tr>
	<tr><td class="mainTxt" width="89">
	<Input type="radio" value="V4" name="naam2" onClick="window.location=('pimpname.php?ster=4')">  
		<b>Icon 4</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/ster2.gif" width="14" height="15"></td></tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V11" name="naam2" onClick="window.location=('pimpname.php?ster=5')"><b> 
		Icon 5</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src=images/smilies/ster4.gif width="14" height="15"></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V13" name="naam2" onClick="window.location=('pimpname.php?ster=6')" ><b> 
		Icon 6</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/smile3.gif" width="24" height="23"></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V14" name="naam2" onClick="window.location=('pimpname.php?ster=7')"><b> 
		Icon 7</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/static.gif" width="41" height="24"></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V12" name="naam2" onClick="window.location=('pimpname.php?ster=8')"><b> 
		Icon 8</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/rudolf.gif" width="26" height="24"></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V15" name="naam2" onClick="window.location=('pimpname.php?ster=9')"><b> 
		Icon 9</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/michel.gif" width="15" height="18"></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V16" name="naam2" onClick="window.location=('pimpname.php?ster=10')"><b> 
		Icon 10</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/devilish.gif" width="22" height="19"></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V17" name="naam2" onClick="window.location=('pimpname.php?ster=11')"><b> 
		Icon 11</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/dead.gif" width="13" height="16"></td>
	</tr>
		<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V17" name="naam2" onClick="window.location=('pimpname.php?ster=13')"><b> 
		Icon 12</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/star22.jpg" width="16" height="16"></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V18" name="naam2" onClick="window.location=('pimpname.php?ster=12')"><b> 
		Text 1</b></td><td class="mainTxt">
		<p align="center">
		^<b>V.I.P</b>^</td>
	</tr>
		
		
	</td>
	</tr>
	<tr>
		
		</td>
	</tr>
	
	</table>
	</form>
</td>
</tr>

<?
  if (isset($_GET['ster'])) {
	  $sAction = strtolower($_GET['ster']);
	  if ($sAction == 'action') {
		  if ($data->belcredits >= 0) {
		  }
		  else {
			  echo '<center><table><b><font color=red><tr><td class-MainTxt>You dont have enough VIP Credits! Purchase more from the Credit Service</td></tr></font></b></table></center>';
		  }
	  }
	  if ($sAction == 'geen') {
			  mysql_query("UPDATE `[users]` SET `level`='1' WHERE `login`='$data->login'");
			   echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>None</b></center></td></tr></font></b></table></center>';
	  }
	  }
	  if ($sAction == '1') {
			  mysql_query("UPDATE `[users]` SET `level`='80' WHERE `login`='$data->login'");
			  echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>1</b></center></td></tr></font></b></table></center>';
		  } 
	  if ($sAction == '2') {
		      mysql_query("UPDATE `[users]` SET `level`='10' WHERE `login`='$data->login'");
			echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>2</b></center></td></tr></font></b></table></center>';
			  }
			  
	  if ($sAction == '3') {
			  mysql_query("UPDATE `[users]` SET `level`='40' WHERE `login`='$data->login'");
			   	echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>3</b></center></td></tr></font></b></table></center>';
	  	  }
	  	  
	  if ($sAction == '4') {
			mysql_query("UPDATE `[users]` SET `level`='20' WHERE `login`='$data->login'");
			  	echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>4</b></center></td></tr></font></b></table></center>';
		  }
		  
	  if ($sAction == '5') {
			 mysql_query("UPDATE `[users]` SET `level`='30' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>5</b></center></td></tr></font></b></table></center>';
		  }
		  
		  	  if ($sAction == '6') {
			 mysql_query("UPDATE `[users]` SET `level`='70' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>6</b></center></td></tr></font></b></table></center>';
		  }
		  
		  		  	  if ($sAction == '7') {
			 mysql_query("UPDATE `[users]` SET `level`='170' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>7</b></center></td></tr></font></b></table></center>';
		  }
		  
				  		  	  if ($sAction == '8') {
			 mysql_query("UPDATE `[users]` SET `level`='180' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>8</b></center></td></tr></font></b></table></center>';
		  }
		    		  		  	  if ($sAction == '9') {
			 mysql_query("UPDATE `[users]` SET `level`='190' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>9</b></center></td></tr></font></b></table></center>';
		  }
		  
		  		    		  		  	  if ($sAction == '10') {
			 mysql_query("UPDATE `[users]` SET `level`='200' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>10</b></center></td></tr></font></b></table></center>';
		  }
		  	  		    		  		  	  if ($sAction == '11') {
			 mysql_query("UPDATE `[users]` SET `level`='210' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>11</b></center></td></tr></font></b></table></center>';
		  }
		  	  	  		    		  		  	  if ($sAction == '12') {
			 
if($data->vip ==0){
echo 'This is for the VIP Members Only';
exit;
}
mysql_query("UPDATE `[users]` SET `level`='220' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Text 1: <b>1</b></center></td></tr></font></b></table></center>';
		  }
		  	  	  	  		    		  		  	  if ($sAction == '13') {
			 
if($data->vip ==0){
echo 'This is for the VIP Members Only';
exit;
}
mysql_query("UPDATE `[users]` SET `level`='230' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>12</b></center></td></tr></font></b></table></center>';
		  
  
	  }
  ?>


</body>

</html>