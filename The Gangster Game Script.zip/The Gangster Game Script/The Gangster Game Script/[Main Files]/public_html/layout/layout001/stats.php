<?php
include("../../_include-config.php");

#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);


?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@5.9.55/css/materialdesignicons.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/style.css" type="text/css" rel="stylesheet">
&nbsp; &nbsp; &nbsp; &nbsp; 


<?php

    if($data->login == $admin2 || $data->login == $admin1) {

?>


<a target="mainFrame" href="../../admin/menu_admin.php"><b><font color="gold"><i class="fa fa-star fa-2x"></i> Admin Menu</b></a> 

&nbsp; &nbsp; 

<a target="mainFrame" href="../../menu_crime.php"><b><font color="silver"> <span class="mdi mdi-pistol mdi-18px"></span></font><font color="gold"> Crimes</b></a>

&nbsp; &nbsp; 

<a target="mainFrame" href="../../menu_casino.php"><b><font color="silver"><span class="mdi mdi-cards-spade mdi-18px"></span></font><font color="gold">  Casino</b></a>

&nbsp; &nbsp; 
<a target="mainFrame" href="../../menu_car.php"><b><font color="silver"><i class="fa fa-car fa-2x"></i></font><font color="gold"> Car Options</font></b></a>


&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 





<?php

	} else {

?>	


<a target="mainFrame" href="../../menu_crime.php"><b><font color="gold"><i class="fa fa-computer"></i> Crimes</b></a> 

&nbsp; &nbsp;
<a target="mainFrame" href="../../menu_casino.php"><b><font color="gold"> Casino</b></a>

&nbsp; &nbsp;
<img src="icons/monitor.png"><a target="mainFrame" href="../../menu_car.php"><b><font color="gold"> Car Options</b></a>



&nbsp; &nbsp; 
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 



<?php

	}

?>	







<script src="https://kit.fontawesome.com/c63b28a58b.js" crossorigin="anonymous"></script>