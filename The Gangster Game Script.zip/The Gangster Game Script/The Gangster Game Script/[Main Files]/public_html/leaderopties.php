<?php
error_reporting(0);

  $OMNILOG				= 1;
  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }
if(! ($data->clanlevel >= 8 ))
if(! ($data->level >= 255 ))
    exit;
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>


<html>


<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<table width="100%"  border="0" cellspacing="2" cellpadding="2">
<script language="javascript">
var checked = 0;
function checkAll() {
  checked = !checked;
  for(i=0; i<document.form1.elements.length; i++)
    document.form1.elements[i].checked = checked;
}


function newBlock() {
  if(document.form1['block'].value != '')
    document.form2['blocklist[]'].options[document.form2['blocklist[]'].options.length] = new Option(document.form1['block'].value)
  return false;
}

function unBlock() {
  while(document.form2['blocklist[]'].selectedIndex >= 0)
    document.form2['blocklist[]'].options[document.form2['blocklist[]'].selectedIndex] = null;
  return false;
}

function submitList() {
  for(i=0; i<document.form2['blocklist[]'].options.length; i++)
    document.form2['blocklist[]'].options[i].selected = 1;
  return true;
}
</script>
</head>
<?php /* ------------------------- */

  if($_GET['x'] == "centrale") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Centrals</b></td></tr>\n  <tr><td><table width=100%>";
    




   $gegevens = mysql_query("SELECT *  FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='centrale' ORDER BY `datum` DESC LIMIT 0,25");
while($rij = mysql_fetch_object($gegevens)) { 
  


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie has bought
<b>$rij->hoeveel</b> central(s). </td> 
</tr>
"); 

ENDHTML;
    }exit;
      } 

if($_GET['x'] == "belcen") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Centrals Bought via VIP Credits</b></td></tr>\n  <tr><td><table width=100%>";
    




   $gegevens = mysql_query("SELECT *  FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='belcen' ORDER BY `datum` DESC LIMIT 0,25");
while($rij = mysql_fetch_object($gegevens)) { 
  


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie has bought
<b>$rij->hoeveel</b> central(s)   </td> 
</tr>
"); 

ENDHTML;
    }exit;
      } 

  if($_GET['x'] == "aan") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Members Accepted</b></td></tr>\n  <tr><td><table width=100%>";
    




   $gegevens = mysql_query("SELECT *  FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='aang' ORDER BY `datum` DESC LIMIT 0,25");
while($rij = mysql_fetch_object($gegevens)) { 
  


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie :
<b>$rij->wat2</b> members have been accepted into the gang. </td> 
</tr>
"); 
}

    print "  </table><table width=100%><tr><td class=\"subTitle\"><b>Members not accepted</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT *  FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='aann' ORDER BY `datum` DESC LIMIT 0,25");
while($rij = mysql_fetch_object($gegevens)) { 
  


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie :
<b>$rij->wat2</b> members not accepted into the gang. </td> 
</tr>
");
ENDHTML;
    }
      } 
   else if($_GET['p'] == "geblock") {
      print <<<ENDHTML
  <tr><td class="subTitle"><b>Ban list</b></td></tr>
<tr><td class=mainTxt align=center colspan=2 width=100%><b><font color="red"><b>Here you can ban members from your gang.</font></b></font></a></td>
ENDHTML;
  

     
      if(isset($_POST['update_list'])) {
        $newlist			= "";
        if(isset($_POST['blocklist'])) {
          foreach($_POST['blocklist'] as $blocked) {
            if($info = mysql_fetch_object(mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$blocked}'"))) {
              $newlist			= preg_replace("/,{$info->login},/i",'',$newlist);
              $newlist			.= ",{$info->login},";
}
}
}
        mysql_query("UPDATE `[clan]` SET `blocklist`='$newlist' WHERE `name`='{$data->clan}'");
        print "  <tr><td class=\"mainTxt\">The banlist has been updated</td></tr>";
        $blocklist			= $newlist;
      }
      else {
        $dbres				= mysql_query("SELECT `blocklist` FROM `[clan]` WHERE `name`='{$data->clan}'");
        $blocklist			= mysql_fetch_object($dbres);
        $blocklist			= $blocklist->blocklist;
      }

      if(isset($_GET['add'])) {
        $dbres				= mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_GET['add']}'");
        if($sender = mysql_fetch_object($dbres)) {
          $blocklist			= preg_replace("/,{$sender->login},/i",'',$blocklist);
          $blocklist			.= ",{$sender->login},";
          mysql_query("UPDATE `[clan]` SET `blocklist`='$blocklist' WHERE `name`='{$data->clan}'");
          print "  <tr><td class=\"mainTxt\">{$sender->login} is banned</td></tr>\n";
        }
      }
      print <<<ENDHTML
  <tr><td class="mainTxt" align="center"><table><form name="form1">
	<tr><td width="253">Name:<input type="text" class='btn btn-info' name="block" style="width: 100;"> <input type="button" class='btn btn-info' value="Ban" onClick="newBlock()" style="width: 100;"></form></td></tr>

	<form name="form2" method="post" class='btn btn-info' action="leaderopties.php?p=geblock" onSubmit="submitList()">
	<tr><td><select name="blocklist[]" width=200 style="width: 200" size=10 MULTIPLE>
ENDHTML;

      $blocklist			= preg_replace('/(^,|,$)/','',$blocklist);
      if($blocklist != "") {
        $blocklist			= explode(',,',$blocklist);
        sort($blocklist);
        foreach($blocklist as $blocked)
          print "	<option value=\"$blocked\">$blocked</option>\n";
      }
      print "	</select></td>\n	<td><input type=\"button\" class='btn btn-info' value=\"Unban\" onClick=\"unBlock()\" style=\"width: 100;\"></td></tr>\n	<tr><td align=\"center\" width=210><input type=\"submit\" name=\"update_list\" class='btn btn-info' value=\"Opslaan\" style=\"width: 100\"><br></td></tr></form></table></td></tr>\n";
    }
else if($_GET['x'] == "muren") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Walls</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT * FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='def_lvl1' ORDER BY `datum` DESC LIMIT 0,25"); 
while($rij = mysql_fetch_object($gegevens)) { 


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie has bought
<b>$rij->hoeveel</b> walls.</td>
</tr>
"); 

ENDHTML;
    }
      }
else if($_GET['x'] == "kick") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Kick</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT * FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='KICK' ORDER BY `datum` DESC LIMIT 0,500");
while($rij = mysql_fetch_object($gegevens)) { 


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wat2 kicked
<b>$rij->wie</b>.</td>
</tr>
"); 

ENDHTML;
    }
      }
else if($_GET['x'] == "land") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Land</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT * FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='land'ORDER BY `datum` DESC LIMIT 0,25");
while($rij = mysql_fetch_object($gegevens)) { 


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie has bought
<b>$rij->hoeveel</b><b>00 </b>land.</td>
</tr>
"); 

ENDHTML;
    }
      }
else if($_GET['x'] == "huizen") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Houses</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT * FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='homes'ORDER BY `datum` DESC LIMIT 0,25"); 
while($rij = mysql_fetch_object($gegevens)) { 


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie has bought
<b>$rij->hoeveel</b> houses.</td>
</tr>
"); 

ENDHTML;
    }
      }
else if($_GET['x'] == "clickss") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Clicks</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT * FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='clicks'ORDER BY `datum` DESC LIMIT 0,25"); 
while($rij = mysql_fetch_object($gegevens)) { 


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie bought
<b>$rij->hoeveel</b> clicks.</td>
</tr>
"); 

ENDHTML;
    }
      }
else if($_GET['x'] == "Uitstappers") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Gang Quiters</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT * FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='Uitgestapt' ORDER BY `datum` DESC LIMIT 0,25");  
while($rij = mysql_fetch_object($gegevens)) { 

if ($rij->hoeveel == 1){
$hoeveel		= "Had his attack given"; 
}
if ($rij->hoeveel == 2){
$hoeveel		= "Has Paid";
}

echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie
<br> $hoeveel have left the gang </td>
</tr>
"); 

ENDHTML;
    }
      }
else if($_GET['x'] == "verwijderd") {
  include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Edit Gang Profile</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT * FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='info' ORDER BY `datum` DESC LIMIT 0,25"); 
while($rij = mysql_fetch_object($gegevens)) { 


echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie edited the Gang prfile.</td>
</tr>
"); 

ENDHTML;
    }
      }
else if($_GET['x'] == "bank") {
   include("_include-leaderlogs.php");  
    print "  <tr><td class=\"subTitle\"><b>Bank in/out</b></td></tr>\n  <tr><td><table width=100%>";
   $gegevens = mysql_query("SELECT * FROM `[clanlogs]` WHERE  `waar`='$data->clan' AND `wat`='bank'  ORDER BY `datum` DESC LIMIT 0,25"); 
while($rij = mysql_fetch_object($gegevens)) { 
if ($rij->hoeveel == 1){
$hoeveel		= "<b>Out</b> of the bank"; 
}
if ($rij->hoeveel == 2){
$hoeveel		= "<b>In</b> to the bank";
}

echo("
<td width=\"30%\" class=\"mainTxt\"><center>$rij->datum</center> </td> 
<td width=\"70%\" class=\"mainTxt\">$rij->wie  
$rij->wat2 $hoeveel.</td>
</tr>
"); 


ENDHTML;
    }
      }
else if($_GET['x'] == "forum") {
  include("_include-leaderopties.php");  

?>













<table align="center" width=100%>
  <tr><td class="subTitle"><b>Gang members banned from the GangForum.</b></td></tr>
  <tr><td class="mainTxt"><br><center>
	<FORM action="?aa" class='btn btn-info' method="post">
	Name:	<INPUT type="text" class='btn btn-info' name="naam"><BR>
	<INPUT type="submit" class='btn btn-info' value="Add!">
	</FORM>
</td></tr>
</table>
</table>
</body>
<table width=100%>
<td width="100%" class="subTitle"><b>Members that have been cleared</b></td></tr></table>

<?


$gegevens2 = mysql_query("SELECT * FROM `[users]` WHERE  `forumc`='1' AND `clan`='$data->clan'") or die(mysql_error()); 
while($rij2 = mysql_fetch_object($gegevens2)) { 
      echo("

<table width=100%>
<td width=\"50%\" class=\"mainTxt\">$rij2->login</td>
<td width=\"50%\" class=\"mainTxt\"><A href=\"?b=$rij2->login\">Clear Forum Ban</td>

</tr>
"); 
} 
}

else if($_GET['x'] == "clandon") {
  include("_include-leaderopties.php");  
    print "  <tr><td class=\"subTitle\"><b>Gang donation's</b></td></tr>\n  <tr><td><table width=100%>";
  if(isset($_POST['profile'])) {
    $profiel->maandag				= preg_replace('/\</','&#60;',substr($_POST['maandag'],0,20));
    $profiel->dinsdag				= preg_replace('/\</','&#60;',substr($_POST['dinsdag'],0,20));
    $profiel->woensdag				= preg_replace('/\</','&#60;',substr($_POST['woensdag'],0,20));
    $profiel->donderdag				= preg_replace('/\</','&#60;',substr($_POST['donderdag'],0,20));
    $profiel->vrijdag				= preg_replace('/\</','&#60;',substr($_POST['vrijdag'],0,20));
    $profiel->zaterdag				= preg_replace('/\</','&#60;',substr($_POST['zaterdag'],0,20));
    $profiel->zondag				= preg_replace('/\</','&#60;',substr($_POST['zondag'],0,20));	
mysql_query("UPDATE `[clans]` SET `maandag`='{$profiel->maandag}',`donatie`='{$data->login}',`zondag`='{$profiel->zondag}',`dinsdag`='{$profiel->dinsdag}',`zaterdag`='{$profiel->zaterdag}',`woensdag`='{$profiel->woensdag}',`donderdag`='{$profiel->donderdag}',`vrijdag`='{$profiel->vrijdag}' WHERE `name`='{$data->clan}'");
    print "  <tr><td class=\"mainTxt\">Your gang donations has changed</td></tr>\n";
  }  

 $dbres				= mysql_query("SELECT * FROM `[clans]` WHERE `name`='{$data->clan}'");
    if($profiel = mysql_fetch_object($dbres)) {
    
  print <<<ENDHTML
  <tr><td class="mainTxt">
	<form method="post"><table align="center">
	 
	  <tr><td width=300>The gang donations on Monday:</td>	<td>
        <input type="text" class='btn btn-info' name="maandag" value="{$profiel->maandag}"  size="20"></td><p>
	  <tr><td width=300>The gang donations on Tuesday:</td>	<td>
        <input type="text" class='btn btn-info' name="dinsdag" value="{$profiel->dinsdag}"  size="20"></td><p>
	  <tr><td width=300>The gang donations on Wednesday:</td>	<td>
        <input type="text" class='btn btn-info' name="woensdag" value="{$profiel->woensdag}"  size="20"></td><p>
	  <tr><td width=300>The gang donations on Thursday:</td>	<td>
        <input type="text" class='btn btn-info' name="donderdag" value="{$profiel->donderdag}"  size="20"></td><p>
	  <tr><td width=300>The gang donations on Friday:</td>	<td>
        <input type="text" class='btn btn-info' name="vrijdag" value="{$profiel->vrijdag}"  size="20"></td><p>
	  <tr><td width=300>The gang donations on Saturday:</td>	<td>
        <input type="text" class='btn btn-info' name="zaterdag" value="{$profiel->zaterdag}"  size="20"></td><p>
	  <tr><td width=300>The gang donations on Sunday:</td>	<td>
        <input type="text" class='btn btn-info' name="zondag" value="{$profiel->zondag}"  size="20"></td><p>
	  <tr><td width=300>The last gang donation has been changed, by:</td>	<td>
        $profiel->donatie</td><p>

	  <tr><td></td>		<td align="right"><input type="submit" class='btn btn-info' name="profile" value="Change"></td></tr>
	</table></form>



ENDHTML;
    }
   }
else if($_GET['x'] == "logs") {
  include("_include-leaderlogs.php"); 
}
else if($_GET['x'] == "clanban") {
  include("_include-leaderopties.php");  
  if(isset($_POST['del'])) { 
    $id      = $_POST['id']; 

	mysql_query("DELETE FROM `[clanban]` WHERE `speler`='$id' AND `clan`='$data->clan'");
print "<table width=100%>  <tr><td class=\"subTitle\"><b>Gang members banned from the gang.</b></td></tr><tr><td class=\"mainTxt\">on $id can report again.</td></tr></table>\n";
exit;
}
?>
<table align="center" width=100%>
  <tr><td class="subTitle"><b>Gang Members banned from the Gang.</b></td></tr>
  <tr><td class="mainTxt"><br><center>
	<FORM action="?bb" method="post">
	Name:	<INPUT type="text" class='btn btn-info' name="naam"><BR>
	Reason:	<INPUT type="text" class='btn btn-info' maxlength="16" name="reden"><BR>
	<INPUT type="submit" class='btn btn-info' value="Add!">
	</FORM>
</td></tr>
</table>
</table>
</body>
<table width=100%>
<td width="100%" class="subTitle"><b>Members that have been cleared</b></td></tr></table>
<?
echo "


<table align=center width=100%>
<tr>
    <td class=subTitle>#</td>
    <td class=subTitle>User</td>
    <td class=subTitle>By</td>
    <td class=subTitle>Date</td>
    <td class=subTitle>Reason</td>
</tr>";
$query = "SELECT * FROM `[clanban]` WHERE `clan` = '$data->clan'";
$info = mysql_query($query) or die(mysql_error());
$count = 0;
while ($gegeven = mysql_fetch_array($info)) {
$speler = $gegeven["speler"];
$reden  = $gegeven["reden"];
$datum  = $gegeven["datum"];
$door  = $gegeven["door"];
$count++;
echo "
<form method=\"post\"><tr>
    <td width=5% align=center class=mainTxt><input type=\"radio\" name=\"id\" value=\"{$speler}\"></td>
    <td width=20% align=center class=mainTxt>".$speler."</td>
    <td width=20% align=center class=mainTxt>".$door."</td>
    <td width=26% align=center class=mainTxt>".$datum."</td>
    <td width=35% align=center class=mainTxt>".$reden."</td>
</tr>";
}
print"</table><input type=\"submit\" class='btn btn-info' value=\"Delete\" name=\"del\"> 
       </form>";
}



else {
   include("_include-leaderopties.php");  
}
if(isset($_GET["b"]))	{
  mysql_query("UPDATE `[users]` SET `forumc`=0 WHERE `login`='". $_GET["b"] ."'");
	echo "<table align=\"center\" width=100%>
		<tr><td class=\"subTitle\"><b>Removed</b></td></tr>
		<tr><td class=\"mainTxt\"><br>
		Player can enter forum again
		<BR><BR></td></tr>
	</table>";
}


if(isset($_GET["bb"]))	{
	$naam = $_POST['naam'];
  	$reden = $_POST['reden'];
 if($reden ==""||$naam==""){
print "<table width=100%>  <tr><td class=\"subTitle\"><b>Gang members banned from the Gang.</b></td></tr><tr><td class=\"mainTxt\">You have not filled everything in.</td></tr></table>\n";
exit;
}
             

 mysql_query("INSERT INTO `[clanban]` (`speler`, `door`, `clan`, `datum`, `reden`) VALUES ('$naam', '$data->login', '$data->clan', NOW(), '$reden');") or die ("Fout: ". mysql_error());


 print " <table width=100%>  <tr><td class=\"subTitle\"><b>Gang Members banned from the Gang.</b></td></tr><td align=\"center\" class=\"mainTxt\">$naam is cleared from the Gang. </td></tr></table></tr></td></table></td></tr></table>\n";
}


if(isset($_GET["aa"]))	{
	$naam = $_POST['naam'];

  $gegevens2 = mysql_query("SELECT * FROM `[users]` WHERE  `login`='$naam' ") or die(mysql_error()); 
while($member = mysql_fetch_object($gegevens2)) { 
             
if($data->clan != $member->clan) {
                        print " <table width=100%>  <tr><td class=\"subTitle\"><b>Gang Members banned from the GangForum.</b></td></tr><td align=\"center\" class=\"mainTxt\">$naam is not in $data->clan</td></tr></table></tr></td></table></td></tr></table>\n";
              exit;
  }	
  mysql_query("UPDATE `[users]` SET `forumc`=1 WHERE `login`='". $_POST["naam"] ."'" );

 print " <table width=100%>  <tr><td class=\"subTitle\"><b>Gang members banned from the GangForum.</b></td></tr><td align=\"center\" class=\"mainTxt\">$naam is cleared from the GangForum. </td></tr></table></tr></td></table></td></tr></table>\n";
}
}

/* ------------------------- */ ?>
</table>

</body>


</html>
<?
mysql_close();
ob_flush();
?>