<?php
error_reporting(0);
 
 include_once ("_include-config.php");
     include("_include-gevangenis.php");

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

// DEBUG CODE: 
// echo $_SESSION['login'];
// s = kolomnaam
// q = zoekterm

?>
<html>


<head>
<title><?=$title; ?></title>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>
<body style="background-color:#1a1919;">
<table width=100%>
  <tr><td align="center" class="mainTxt">
	<form action="list.php" method="get">
	Example: "<b>a*</b>" will give a list of names begining with the letter A<br>
	<input type="hidden" name="s" value="search"><input type="text" class="btn btn-info" name="q" 
	value="<?php if (isset($_REQUEST['q'])) { echo $_REQUEST['q']; } ?>"> <input type="submit" class="btn btn-info" value="Search!"></form>
	</form>
  </td></tr>
</table>
<table width=100%>
<tr><td align="center" class="subTitle" style="letter-spacing: normal;" width=5><b>#</b></td>
<td class="subTitle" style="letter-spacing: normal;" align="center" width=200><a href="list.php?s=login"><b>Nickname</a></b></td>
<td class="subTitle" style="letter-spacing: normal;" align="center" width=200><a href="list.php?s=clan"><b>Gang</b></a></td>
	<td class="subTitle" style="letter-spacing: normal;" align="center" width=100><a href="list.php?s=contant"><b>Cash</b></a></td>
<td class="subTitle" style="letter-spacing: normal;" align="center" width=100><a href="list.php?s=power"><b>Power</b></a></td></tr>
<?php /* ------------------------- */
if(!empty($_GET['jump']))
{

$dbres27				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
$gegeven_jump2		                = mysql_fetch_object($dbres27);

$attack = $gegeven_jump2["attack"]; 
$defence = $gegeven_jump2["defence"]; 
$clicks = $gegeven_jump2["clicks"];
$clan = $gegeven_jump2["clan"]; 
$power2 = ($attack+$defence)/2+$clicks*5;

$query_jump1				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`cash`,`bank`,`level`,`clan`,`hulpadmin`,`vermoord`,`vip`,`login` FROM `[users]` WHERE  (`attack`+`defence`)/2+`clicks`*5 > '$power2'");
$info_jump1 = mysql_num_rows($query_jump1);  
$page = floor($info_jump1/30);
if(!isset($_GET['p'])) {
$_GET['p'] = $page;
}
}

  $begin				= ($_GET['p'] >= 0) ? $_GET['p']*30 : 0;
  if($_GET['s'] == "login") {
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`cash`,`bank`,`level`,`clan`,`hulpadmin`,`vermoord`,`vip`,`login` FROM `[users]`  ORDER BY `login` LIMIT $begin,30");
	}
  else if($_GET['s'] == "rank") {
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`cash`,`bank`,`level`,`clan`,`rank`,`hulpadmin`,`vermoord`,`vip`,`login` FROM `[users]` ORDER BY `rank` DESC,`login` ASC LIMIT $begin,30");
	}
  else if($_GET['s'] == "cash") {
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`cash`,`bank`,`level`,`clan`,`hulpadmin`,`vermoord`,`vip`,`login` FROM `[users]`  ORDER BY `cash` DESC,`login` ASC LIMIT $begin,30");
	}
  else if($_GET['s'] == "online") {
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`vermoord`,`vip`,`hulpadmin`,`attack`,`defence`,`clicks`,`cash`,`bank`,`level`,`clan`, `rank`,`hulpadmin`,`vermoord`,`vip`,`login` FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300  ORDER BY `login` LIMIT $begin,30");
	}
 else if($_GET['s'] == "gangonline") {
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`vermoord`,`vip`,`hulpadmin`,`attack`,`defence`,`clicks`,`cash`,`bank`,`level`,`clan`, `rank`,`hulpadmin`,`vermoord`,`vip`,`login` FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300  AND `clan`='$data->clan' ORDER BY `login` LIMIT $begin,30");
	}
  else if($_GET['s'] == "clan") {
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`cash`,`bank`,`level`,`clan`,`login` FROM `[users]`  ORDER BY `login`,`clan` LIMIT $begin,30");
	}
  else if($_GET['s'] == "search") {
    $_GET['q']				= preg_replace('/\*/','%',$_GET['q']);
$_GET['q'] = htmlspecialchars($_GET['q']);
$_GET['q'] = addslashes($_GET['q']);
    $dbres				= mysql_query("SELECT `login`,UNIX_TIMESTAMP(`signup`) AS `signup`,`attack`,`defence`,`clicks`,`cash`,`bank`,`level`,`clan`,`login` FROM `[users]` WHERE  `login` LIKE '{$_GET['q']}' ORDER BY `login` LIMIT $begin,30");
  }
  else {
    $dbres				= mysql_query("SELECT * FROM `[users]`  ORDER BY (`attack`+`defence`)/2+`clicks`*5 DESC,`login` ASC LIMIT $begin,30");
}
/*


*/
  for($j=$begin+1; $info = mysql_fetch_object($dbres); $j++) 
{

$login2 = ($info->level > 0 && $data->level == 1000 && $_GET['s'] == "online") ? "{$info->login} *" : $info->login;

$login2 			= ($info->login == admin) ? "<b><font color=\"green\">$login2</b>" : $login2;

$login2 			= ($info->login == naamnaarkeuze) ? "<b><font color=\"blue\">$login2</b>" : $login2;

$login2 			= ($info->login == naamnaarkeuze) ? "<b><font color=\"blue\">$login2</b>" : $login2;

$login2 			= ($info->login == naamnaarkeuze) ? "<b><font color=\"red\">$login2</b>" : $login2; 

$login2 = ($info->hulpadmin == 1) ? "<font color=yellow><b>$login2</b>" : $login2;

$login2 = ($info->level == -1) ? "<b><s><font color=black>$login2</b></s>" : $login2;

$login2 = ($info->vermoord > 0) ? "<b><font color=black>$login2</b> [Dead]" : $login2;

$login2 = ($info->vip == 1) ? "$login2<sup>+</sup>" : $login2;

$login2 = ($info->level == 1) ? "<font color=white>$login2</font></b>" : $login2;

$login2 = ($info->level == 100) ? "<font color=white>$login2</font></b>" : $login2;

$login2 = ($info->level == 10) ? "<font color=white>$login2</font></b><img src=\"images/smilies/ster.gif\" width=14 height=15 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 20) ? "<font color=white>$login2</font></b><img src=\"images/smilies/ster2.gif\" width=13 height=14 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 30) ? "<font color=white>$login2</font></b><img src=\"images/smilies/ster4.gif\" width=14 height=15 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 40) ? "<font color=white>$login2</font></b><img src=\"images/smilies/ster1.gif\" width=14 height=15 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 80) ? "<font color=white>$login2</font></b><img src=\"images/smilies/star.gif\" width=14 height=15 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 70) ? "<font color=white>$login2</font></b><img src=\"images/smilies/smile3.gif\" width=24 height=23 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 170) ? "<font color=white>$login2</font></b><img src=\"images/smilies/static.gif\" width=41 height=24 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 180) ? "<font color=white>$login2</font></b><img src=\"images/smilies/rudolf.gif\" width=26 height=24 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 190) ? "<font color=white>$login2</font></b><img src=\"images/smilies/michel.gif\" width=15 height=18 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 200) ? "<font color=white>$login2</font></b><img src=\"images/smilies/devilish.gif\" width=22 height=19 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level == 210) ? "<font color=white>$login2</font></b><img src=\"images/smilies/dead.gif\" width=13 height=16 border=0 alt=\"ster\">" : $login2;

$login2 = ($info->level== 220) ? "<font color=white>$login2</font></b> ^<b>VIP</b>^" : $login2;

$login2 = ($info->level == 230) ? "<font color=white>$login2</font></b><img src=\"images/smilies/star22.jpg\" width=16 height=16 border=0 alt=\"VIP\">" : $login2;


    $clan				= $clan[$info->clan];
    $power   = number_format(round(($info->attack+$info->defence)/2+$info->clicks*5),0,",",".");
    $money        = number_format(round($info->bank),0,",",".");
    $contant        = number_format(round($info->cash),0,",",".");
    $clan				= ($info->clan == "") ? "None" : $info->clan;

    print ("
  <tr><td align=\"center\" class=\"mainTxt\" width=\"5\">$j</td>
	<td class=\"mainTxt\"><a href=\"profile.php?x=$info->login\" width=\"200\">$login2</a></td>
	<td align=\"center\" class=\"mainTxt\" width=\"200\">$clan</td>
	<td align=\"left\" class=\"mainTxt\" width=\"160\">$contant</td>
	<td align=\"left\" class=\"mainTxt\" width=\"160\">$power</td>

");

  
      print "	<td align=\"center\" class=\"mainTxt\">
	  <a href=\"attack.php?x={$info->login}\" width=\"40\">Attack</a></td></tr>\n\n";
	  }



  if($_GET['s'] == "online") {
    $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300");
	}
  
  else if($_GET['s'] == "clanmembers") {
 
    $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `clan` ='{$data->clan}' AND UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300 ORDER BY `login` LIMIT $begin,30");
	}
  else if($_GET['s'] == "search") {
    $dbres				= mysql_query("SELECT `id` FROM `[users]`  WHERE `login` LIKE '{$_GET['q']}' ORDER BY `login`");
    $_GET['q']				= preg_replace('/%/','*',$_GET['q']);
  }
  else {
    $dbres				= mysql_query("SELECT id FROM `[users]`");
  print "</table>\n\n<table width=100%>\n  <tr><td class=\"mainTxt\" align=\"center\">";
  }
  if(mysql_num_rows($dbres) <= 30) {
    print "&#60; 1 &#62;</td></tr></table>\n";
	}
  else {
    if($begin/30 == 0) {
      print "&#60;&#60; ";
	  }
    else {
      print "<a href=\"list.php?s={$_GET['s']}&q={$_GET['q']}&p=". ($begin/30-1) ."\">&#60;&#60;</a> ";
}
    for($i=0; $i<mysql_num_rows($dbres)/30; $i++) {
      print "<a href=\"list.php?s={$_GET['s']}&q={$_GET['q']}&p=$i\">". ($i+1) ."</a> ";
    }

    if($begin+30 >= mysql_num_rows($dbres)) {
      print "&#62;&#62; ";
	  }
    else {
      print "<a href=\"list.php?s={$_GET['s']}&q={$_GET['q']}&p=". ($begin/30+1) ."\">&#62;&#62;</a>";
  }
  }

  $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300");
  $online				= mysql_num_rows($dbres);


/* ------------------------- */ ?>
</table><br>
<a href=list.php?s=online><center>members online at this current time.</center></a>
</body>


</html>