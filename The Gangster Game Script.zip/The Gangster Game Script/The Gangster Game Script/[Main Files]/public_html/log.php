<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

$gegevens = mysql_query("SELECT * FROM `[logs]` WHERE  `area`='attack' ORDER BY `time` DESC LIMIT 50");  

/* ------------------------- */ ?>

<html>


<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

<body>
<table width=100% colspan=2>
  <tr><td class="subTitle" colspan="3"><b>Quick Menu</b></td></tr>
<tr><td class="mainTxt" colspan="3" align="center">
<a href="?x=attack">Attack Log</a>
 - 
<a href="?x=donate">Donation Log</a>
 - 
<a href="?x=click">Click Log</a>
 - 
<a href="?x=attacks">Last 50 Attacks</a>

</td></tr>
<?php /* ------------------------- */

  if($_GET['x'] == "attack") {
    print "  <tr><td class=\"subTitle\" ><b>Attacks</b></td></tr>\n  <tr><td><table width=100%>";
    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `attacktime` FROM `[logs]` WHERE `login`='{$data->login}' AND `time` >= '{$data->signup}' AND `area`='attack' ORDER BY `time` DESC LIMIT 0,25");
    while($info = mysql_fetch_object($dbres)) {
      $result				= ($info->code & 0x01 == 1) ? "Won" : "Lost";
      $money				= $info->code >> 1;
      print <<<ENDHTML
    <tr><td class="mainTxt" width=125>{$info->attacktime}</td>
	<td class="mainTxt"><a href="profile.php?x={$info->person}">{$info->person}</a></td>
	<td width=100 class="mainTxt" align="center">\$$money</td>
	<td width=100 class="mainTxt" align="center">$result</td></tr>
ENDHTML;
        }

    print "  </table></td></tr>\n  <tr><td><br></td></tr>\n\n  <tr><td class=\"subTitle\"><b>Apologies</b></td></tr>\n";
    print "  <tr><td><table width=100%>\n";
    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `attacktime` FROM `[logs]` WHERE `person`='{$data->login}' AND `time` >= '{$data->signup}' AND `area`='attack' ORDER BY `time` DESC LIMIT 0,25");
    while($info = mysql_fetch_object($dbres)) {
      $result				= ($info->code & 0x01 == 1) ? "Lost" : "Won";
      $money				= $info->code >> 1;
      print <<<ENDHTML
      <tr><td class="mainTxt" width=125>{$info->attacktime}</td>
	<td class="mainTxt"><a href="profile.php?x={$info->login}">{$info->login}</a></td>
	<td width=100 class="mainTxt" align="center">\$$money</td>
	<td width=100 class="mainTxt" align="center">$result</td></tr>
ENDHTML;
    }
  }
  else if($_GET['x'] == "donate") {
    print "  <tr><td class=\"subTitle\" width=100%><b>Sent Donations</b></td></tr>\n  <tr><td><table width=100%>";
    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `donatetime` FROM `[logs]` WHERE `login`='{$data->login}' AND `time` >= '{$data->signup}' AND `area`='donate' ORDER BY `time` DESC LIMIT 0,25");
    while($info = mysql_fetch_object($dbres)) {
      $money				= $info->code;
      print <<<ENDHTML
    <tr><td class="mainTxt" width=125>{$info->donatetime}</td>
	<td class="mainTxt"><a href="profile.php?x={$info->person}">{$info->person}</a></td>
	<td width=100 class="mainTxt" align="center">\$$money</td></tr>
ENDHTML;
    }

    print "  </table></td></tr>\n  <tr><td><br></td></tr>\n\n  <tr><td class=\"subTitle\" colspan=\"2\"><b>Received Donations</b></td></tr>\n";
      
    print "  <tr><td><table width=100% colspan=\"1\">\n";
    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `donatetime` FROM `[logs]` WHERE `person`='{$data->login}' AND `time` >= '{$data->signup}' AND `area`='donate' ORDER BY `time` DESC LIMIT 0,25");
    while($info = mysql_fetch_object($dbres)) {
      $money				= $info->code;
      print <<<ENDHTML
      <tr><td class="mainTxt" width=125>{$info->donatetime}</td>
	<td class="mainTxt"><a href="profile.php?x={$info->login}">{$info->login}</a></td>
	<td width=100 class="mainTxt" align="center">\$$money</td></tr>
ENDHTML;
    }
  }
  else if($_GET['x'] == "click") {
    print "  <tr><td class=\"subTitle\" style=\"letter-spacing: normal;\" width=125><b>Date</b></td>  <td class=\"subTitle\" style=\"letter-spacing: normal;\"><b>Nickname</b></td>  <td class=\"subTitle\" style=\"letter-spacing: normal;\" width=100><b>Number</b></td></tr>\n";
    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `time` FROM `[temp]` WHERE `person`='{$data->login}' AND `time` >= '{$data->signup}' AND `area`='click' ORDER BY `login`");
    while($info = mysql_fetch_object($dbres)) {
      print <<<ENDHTML
  <tr><td class="mainTxt" width=125>{$info->clicktime}</td>
	<td class="mainTxt"><a href="profile.php?x={$info->login}">{$info->login}</a></td>
	<td class="mainTxt" width=100 align="center">{$info->code}</td></tr>
ENDHTML;
    }
  }
  else if($_GET['x'] == "attacks") {
print "
  <tr><td class=\"subTitle\"><b>Last 50 Attacks</b></td></tr>  
  </table>  
  <center><table>  
<tr>
<td width=\"100\" class=\"mainTxt\">Attack</td>
<td width=\"100\" class=\"mainTxt\">Against</td>
<td width=\"100\" class=\"mainTxt\">Defender</td>
</tr>  
";
while($rij = mysql_fetch_object($gegevens)) {  
print "
<tr><td width=\"100\" class=\"mainTxt\"><a href=\"profile.php?x=$rij->login\">$rij->login</a></td>  
<td width=\"100\" class=\"mainTxt\">Aginst</td>  
<td width=\"100\" class=\"mainTxt\"><a href=\"profile.php?x=$rij->person\">$rij->person</a></td></tr>  
";
}
}
  else {
    print <<<ENDHTML
  <tr><td class="subTitle"><b>Logs</b></td></tr>
</table>
ENDHTML;
  }

/* ------------------------- */ ?>
</table>

</body>


</html>
