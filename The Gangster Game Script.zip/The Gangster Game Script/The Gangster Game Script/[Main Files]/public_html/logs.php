<?php
error_reporting(0);

ob_start();
if($ingelogd == 0){
echo top("!");
echo $error[0];
echo bottom();
} elseif(!$user['crew'] || $user['crewrang'] < 2){
echo top("Not elgable!");
echo"You have no Gang or not elgable for this!";
echo bottom();
} else {
include_once("./include/ubb.php");
echo top2("Crew Logs");

if($_GET['actie'] == 'bank'){
echo"<table border='0' cellspacing='0' cellpadding='5'>
<tr>
<td colspan='6'><img src='img/bullet.gif' width='6' height='6' alt='' border='0'> <strong>Donations Received</strong></td>
</tr>
<tr>
<td><strong>From</strong></td>
<td><strong>Ammount</strong></td>
<td><strong>Date</strong></td>
<td><strong>Time</strong></td>
<td><strong>Message</strong></td>
</tr>
";
$log_db = @mysql_query("SELECT id,van,bedrag,datum,bericht,tijd FROM `crew_bank_log` WHERE `naar`='".$user['crew']."' AND `dienst`!='MG Crew Bank Gestort' AND `dienst`!='MG Crew Bank Pin'");
if(mysql_num_rows($log_db) == 0){
echo"<tr>
<td colspan='6'>No paaid or donations yet received.</td>
</tr>";
} else {
while($log = mysql_fetch_assoc($log_db)){	  
echo"<tr>
<td>".$log['van']."</td>
<td>&#8364; ".number_format($log['bedrag'],0,".",".").",-</td>
<td>".$log['datum']."</td>
<td>".$log['tijd']."</td>
<td>".ubb($log['bericht'])."</td>
</tr>";
}
}	
echo"</table><BR>";



echo"<table border='0' cellspacing='0' cellpadding='5'>
<tr>
<td colspan='6'><img src='img/bullet.gif' width='6' height='6' alt='' border='0'> <strong>Sent Donations and Paid</strong></td>
</tr>
<tr>
<td><strong>To</strong></td>
<td><strong>Ammount</strong></td>
<td><strong>Date</strong></td>
<td><strong>Time</strong></td>
<td><strong>Message</strong></td>
</tr>";
$log_db2 = @mysql_query("SELECT id,naar,bedrag,datum,bericht,tijd FROM `crew_bank_log` WHERE `van`='".$user['crew']."' AND `dienst`!='MG Crew Bank Gestort' AND `dienst`!='MG Crew Bank Pin'");
if(mysql_num_rows($log_db2) == 0){
echo"<tr>
<td colspan='6'>Sent no Donations.</td>
</tr>";
} else {
while($log2 = mysql_fetch_assoc($log_db2)){	 
echo"<tr>
<td>".$log2['naar']."</td>
<td>&#8364; ".number_format($log2['bedrag'],0,".",".").",-</td>
<td>".$log2['datum']."</td>
<td>".$log2['tijd']."</td>
<td>".ubb($log2['bericht'])."</td>
</tr>";
    }
   }
echo"</table>";
} elseif($_GET['actie'] == 'bank2'){
echo"<table border='0' cellspacing='0' cellpadding='0' align='center' width='100%'>
  <tr>
    <td><table border='0' cellspacing='0' cellpadding='5' width='100%'>
<tr>
<td colspan='5'><img src='img/bullet.gif' width='6' height='6' alt='' border='0'> <strong>Cash Put in</strong></td>
</tr>
<tr>
<td><strong>Because</strong></td>
<td><strong>Ammount</strong></td>
<td><strong>Date</strong></td>
<td><strong>Time</strong></td>
</tr>";
$log_db3 = @mysql_query("SELECT id,bedrag,datum,tijd,van FROM `crew_bank_log` WHERE `naar`='".$user['crew']."' AND `dienst`='MG Crew Bank Gestort'");
if(mysql_num_rows($log_db3) == 0){
echo"<tr>
<td colspan='5'>Not cash put in.</td>
</tr>";
} else {
while($log3 = mysql_fetch_assoc($log_db3)){	 
$stat = mysql_query("SELECT status FROM `leden` WHERE `nick`='".$log3['van']."'")or die(mysql_error());
$statu 	  = mysql_fetch_assoc($stat);	  
echo"<tr>
<td>".status($log3['van'],$statu['status'])."</td>
<td>&#8364; ".number_format($log3['bedrag'],0,".",".").",-</td>
<td>".$log3['datum']."</td>
<td>".$log3['tijd']."</td>
</tr>";
    }
   }
echo"</table>
</td>
    <td><table border='0' cellspacing='0' cellpadding='5' width='100%'>
<tr>
<td colspan='5'><img src='img/bullet.gif' width='6' height='6' alt='' border='0'> <strong>Cash Taken Out</strong></td>
</tr>
<tr>
<td><strong>Because</strong></td>
<td><strong>Ammount</strong></td>
<td><strong>Date</strong></td>
<td><strong>Time</strong></td>
</tr>";
$log_db4 = @mysql_query("SELECT id,bedrag,datum,tijd,van FROM `crew_bank_log` WHERE `naar`='".$user['crew']."' AND `dienst`='MG Crew Bank Pin'");
if(mysql_num_rows($log_db4) == 0){
echo"<tr>
<td colspan='5'>No cash taken out.</td>
</tr>";
} else {
while($log4 = mysql_fetch_assoc($log_db4)){	
$stat4 = mysql_query("SELECT status FROM `leden` WHERE `nick`='".$log4['van']."'")or die(mysql_error());
$statu4 	  = mysql_fetch_assoc($stat4);	   
echo"<tr>
<td>".status($log4['van'],$statu4['status'])."</td>
<td>&#8364; ".number_format($log4['bedrag'],0,".",".").",-</td>
<td>".$log4['datum']."</td>
<td>".$log4['tijd']."</td>
</tr>";
    }
   }
echo"</table></td>
  </tr>
</table>";
}
if(!$_GET['actie']){
echo"Describe below what you want to do.";
}
echo bottom();


 echo top2("Opties");
 echo"<img src='img/bullet.gif' width='6' height='6' alt='' border='0'> <a href='index.php?T2K=crew/logs&actie=bank'>Bank Logs (Donations)</a><BR>
 <img src='img/bullet.gif' width='6' height='6' alt='' border='0'> <a href='index.php?T2K=crew/logs&actie=bank2'>Bank Logs (Transfers In & Out)</a>";
 echo bottom();
}
ob_end_flush();
?>