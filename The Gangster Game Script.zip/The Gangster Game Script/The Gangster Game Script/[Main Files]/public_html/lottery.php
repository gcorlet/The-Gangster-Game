<?php
error_reporting(0);

  include("_include-jail.php");
      include("_include-gevangenis.php");

$dbres			        = mysql_query("SELECT * FROM `lottery` WHERE `active`='1' ORDER BY `start` DESC LIMIT  0,1");
$lottery			= mysql_fetch_assoc($dbres);

$lol = mysql_query("SELECT * FROM `lottery-tickets` WHERE `login`='".$_SESSION['login']."'");
$sql = mysql_num_rows($lol);

  mysql_query("UPDATE `[users]` SET `online`=NOW(),`page`='Loterij' WHERE `login`='{$data->login}'");

?>


<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<?
if (!empty($data) AND $data->topbalk == 1) {	
include('top.php');
}
?>
<body>

<table width="100%" align="center">
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<?php


        $_POST['amount']		= htmlspecialchars($_POST['amount']);

	if(isset($_POST['buy'],$_POST['amount'])) {
		if($_POST['amount'] > 5000)
                {
                   echo "<tr><td class=maintxt width=90% align=center><font color=black>Maximum of 5000 each time you purchase</font></tr></td>";
                   exit;
                }

                if($_POST['amount'] <= 0 OR !preg_match('/^[0-9]{1,15}$/',$_POST['amount']))
		 echo "<tr><td class=maintxt width=90% align=center>Numbers Only!</font></tr></td>";
		elseif($lottery[ticketprice]*$_POST['amount'] > $data->cash)
		 echo "<tr><td class=maintxt width=90% align=center><font color=red><b>You dont have enough money.</b></font></tr></td>";
		elseif($lottery[active] == 0)
		 echo "<tr><td class=maintxt width=90% align=center><font color=red>There is no active lottery!</font>";
		else {
			for($j=0; $j < $_POST['amount']; $j++) {
			 mysql_query("INSERT INTO `lottery-tickets`(`login`,`lotterynr`,`date`,`IP`) VALUES('{$data->login}','{$lottery[id]}',NOW(),'$IP')");
			 mysql_query("UPDATE `lottery` SET `ticketssold`=`ticketssold`+1, `pot`=`pot`+$lottery[ticketprice] WHERE `id`='{$lottery[id]}'");
		 	}
			if($_POST['amount'] == 1)
			 echo "<tr><td class=maintxt width=90% align=center><font color=black> You have purchased <b>1</b> lottery ticket.</font></tr></td>";
			else
			 echo "<tr><td class=maintxt width=90% align=center><font color=black>You have bought <b>{$_POST['amount']}</b> lottery ticket(s).</font>";
			$data->cash		-= round($_POST['amount']*$lottery[ticketprice]);
			$lottery[pot]	+= round($_POST['amount']*$lottery[ticketprice]);
			$lottery[ticketssold] += $_POST['amount'];
			mysql_query("UPDATE `[users]` SET `cash`='{$data->cash}' WHERE `login`='{$data->login}'");
		}
	}

$ticketssold		        = number_format($lottery[ticketssold],0);
$ticketprice		        = number_format($lottery[ticketprice],0);
$pot				= number_format($lottery[pot],0);

$dbres = mysql_query("SELECT * FROM `lottery` WHERE `active`='0' ORDER BY `start` DESC LIMIT  0,1");
$lw    = mysql_fetch_assoc($dbres);

$winner = $lw[winner];

?>
<table width='100%' cellpadding='2' cellspacing='1' align='center' >
  <tr>
    <td class="subtitle" colspan="7"><b>Lottery</b></td>
  </tr>
<tr><td class=Maintxt colspan=5>
<center>The winner of the lottery was:<font color=red> <b><?=$winner;?></b></font><br>There has been <b><?=$ticketssold;?></b> tickets sold, that jackpot stands at <b><?=$pot;?></b></center>
<center><img src="images/game/lot.jpg" width="200" height="190"></center>
</tr></td>
  <tr>
    <td class="subtitle"><b>Name</b></td><td class="subtitle"><b>Price per ticket</b></td><td class="subtitle"><b>Draw</b></td><td class="subtitle"><b>Buy</b></td>
  </tr>
<?php
if($lottery[active] == 1) {
?>
  <tr>
    <td class="MainTxt"><?=$lottery[name];?></td><td class="MainTxt"><?=$ticketprice;?></td><td class="Maintxt">Every Week</td><form method="post"><td class="Maintxt"><input type="text" class="btn btn-info" name="amount" size=4>x lot <input type="submit" class="btn btn-info" name="buy" value="Buy"></td></form>
  </tr>
<?php
} else
echo "<tr><td class=MainTxt colspan=7 align=center><b>There is no active lottery!</b></td></tr>\n"; 

$yourtickets		= "";
$dbres				= mysql_query("SELECT * FROM `lottery-tickets` WHERE `login`='{$data->login}' AND `lotterynr`='{$lottery[id]}'");
while($yourticket = mysql_fetch_assoc($dbres)) {
	$yourtickets	.= "{$yourticket[id]}, ";
}	
$yourtickets		= ($yourtickets == '') ? "<font color=red><b>Lottery Tickets</b></font>" : $yourtickets;
$yourtickets		= (isset($_GET['show'])) ? $yourtickets : "You have at the moment <b>$sql</b> tickets, <br><a href=\"lottery.php?show\"><b>Click Here</b></a> to see your ticket numbers";


?>
</table><br>
<table border=1 cellspacing=0 cellpadding=0 width=99% bordercolor=#616162 class=sub2>
<table width='100%' cellpadding='2' cellspacing='1' align='center' >
  <tr>
    <td class="subtitle"><b>Drawn Tickets</b></td>
  </tr>
  <tr>
    <td class="MainTxt"><?=$yourtickets;?></td>
  </tr>
</table>
<table width=100%><tr><td class=Maintxt>
<?php mysql_close($db); ?>