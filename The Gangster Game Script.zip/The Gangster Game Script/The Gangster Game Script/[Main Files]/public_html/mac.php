<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");

if(! check_login()) {
    header("Location: login.php");
    exit;
  } 
?>


<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>
<body style="margin: 0px;">
<center>
<table  width=60%><table width=60% cellspacing=0 cellpadding=2><table width=60%> 
  <tr>
  <td width="60%" class=subTitle><b>Fastfood Center</b></td>
<table  width=60%>
<td class="mainTxt"><center><img border=0 src=images/game/macpicture.jpg border=0 width="100%"></center>
</td>
</table></tr></table></table></table></center>







<table align="center" width="60%">
<tr><td class="subTitle"><b>The Mac Donalds</b></td></tr>
<tr><td class="mainTxt">

<?php

print "Welcome to MaC Donalds, may I take your order.<br><br>
<table>
<tr>
<td width=125><b><u>Menu</td>
<td width=75><b><u>Energy</td>
<td width=75><b><u>Price</td>
<td width=75><b><u>Stock</td>
<td><b><u>Options</td>
</tr>";
$rsel = mysql_query("SELECT * FROM `equipment` WHERE `type`='S' AND `status`='U' ORDER BY `cost`");
while($res = mysql_fetch_object($rsel)) {
print "<tr><td>$res->name</td><td>$res->energy</td><td>$res->cost,-</td><td>";
  if($res->voorraad < 499) {
print "<font color=\"red\">$res->voorraad</font>";
} else 
if($res->voorraad > 500) {
print "<font color=\"green\">$res->voorraad</font>";
}
	print "</td><td>- <A href=mac.php?buy=$res->id class='btn btn-info'>Purchase</a></td></tr>";	}	print "</table>";    

if(isset($_GET['buy'])) {
$buy = $_GET['buy'];
$arm1 = mysql_query("SELECT * FROM `equipment` WHERE `id`='$buy'");
while($arm = mysql_fetch_object($arm1)) {	
if (empty ($arm->id)) {
print "<br><br><b>There is no food, return to <a href=mac.php>Mac Donalds</a>.</b>";
}
else if ($arm->cost > $data->cash) {
print "<br><br><b>You cannot permit this!</b>";
}
else if ($data->energie >= 100) {
print "<br><br><b>You finnished eating and you now have 100% energy!</b>";
}
else if ($arm->voorraad <= 0) {
print "<br><br><b>No more stock for this item choice.</b>";
}
else if ($data->energie+$arm->energy > 100) {
print "<br><br>You have paid <b>$arm->cost,-</b> and now you have <b>$arm->energy</b> Energy!";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-$arm->cost,`energie`='100' WHERE `login`='$data->login'");
mysql_query("UPDATE `equipment` SET `voorraad`=`voorraad`-1 WHERE `id`='$buy'");
} else {
print "<br><br>You paid <b>$arm->cost,-</b> and now you have <b>$arm->energy</b> Energie!";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-$arm->cost,`energie`=`energie`+$arm->energy WHERE `login`='$data->login'");
mysql_query("UPDATE `equipment` SET `voorraad`=`voorraad`-1 WHERE `id`='$buy'");}
}
}
?>
</table>
</body>
</html>