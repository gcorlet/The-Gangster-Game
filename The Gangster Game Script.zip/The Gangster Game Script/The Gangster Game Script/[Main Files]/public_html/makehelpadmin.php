<?php
error_reporting(0);


  include("../_include-config.php");
  if(! check_login()) {
    header("Location: ../login.php");
    exit;
  }

  if($data->login != $admin1 && $data->login != $admin2)
  {
  exit;
  }

$dbres	=	mysql_query("SELECT * FROM `spel_statestieken` WHERE `id`='1'");
$link	=	mysql_fetch_object($dbres);


$dbres99	=	mysql_query("SELECT * FROM `[users]` WHERE `level`='255'");
$rows9		=	mysql_num_rows($dbres99);
$dbres1		=	mysql_query("SELECT * FROM `[users]` WHERE `level`='2'");
$rows1		=	mysql_num_rows($dbres1);
$dbres2		=	mysql_query("SELECT * FROM `[users]` WHERE `level`='-2'");
$rows2		=	mysql_num_rows($dbres2);
$dbres3		=	mysql_query("SELECT * FROM `[users]`");
$rows3		=	mysql_num_rows($dbres3);
$dbres4		=	mysql_query("SELECT * FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 86400");
$rows4		=	mysql_num_rows($dbres4);
$dbres5		=	mysql_query("SELECT * FROM `[users]` WHERE `level`='-1'");
$rows5		=	mysql_num_rows($dbres5);
$dbres1		=	mysql_query("SELECT * FROM `[users]` WHERE `sex`='Man'");
$rows6		=	mysql_num_rows($dbres1);
$spelers	=	$rows3;
$levend		=	$spelers-$rows2;
$levendp	=	round((100/$spelers)*$levend);
$man		=	$rows6;
$manp		=	round((100/$spelers)*$man);
$vrouw		=	$spelers-$rows6;
$vrouwp		=	round((100/$spelers)*$vrouw);
$dood		=	$rows2;
$doodp		=	round((100/$spelers)*$dood);
$ban		=	$rows5;
$banp		=	round((100/$spelers)*$ban);
$online		=	$rows4;
$onlinep	=	round((100/$spelers)*$online);
$betalend	=	$rows1;
$betalendp	=	round((100/$spelers)*$betalend);
$dbres		=	mysql_query("SELECT * FROM `betalingen` WHERE `soort`='Bellen'");
$betaal1	=	mysql_num_rows($dbres);
$dbres		=	mysql_query("SELECT * FROM `betalingen` WHERE `soort`='Ideal'");
$betaal2	=	mysql_num_rows($dbres);

?>

<html>
<head>
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
<body bgproperties="fixed">

<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">
		<b>Extra paneel</b>
		</td>
	</tr>
	<tr>
		<td width="600" class="mainTxt" align="center">

<?php

	if(isset($_POST['submit4'])){

	} else if(isset($_POST['submit5'])){
		if($_POST['level'] == 1){
		mysql_query("UPDATE `[users]` SET `level`='255',`admin`='1' WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into an admin.";
		} else if($_POST['level'] == 2){
		mysql_query("UPDATE `[users]` SET `hulpadmin`='1' WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into a Helper Admin.";
		} else if($_POST['level'] == 3){
		mysql_query("UPDATE `[users]` SET `level`='155',`admin`='1' WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into a Moderator.";
		} else if($_POST['level'] == 4){
		mysql_query("UPDATE `[users]` SET `level`='2',`dagen`=`dagen`+'21',`memberdays`=NOW() WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into paying member status.";
		} else if($_POST['level'] == 5){
		mysql_query("UPDATE `[users]` SET `level`='1',`admin`='0',`hulpadmin`='0' WHERE `login`='{$_POST['login']}'");
		echo "You have made {$_POST['login']} into a normal member.";
		}
	} else if(isset($_POST['submit6'])){

	} else {

?>

		<form method="post">
		<table width="70%">
		
		
            
 			<tr>
				<td width="50%">
				Account Level:
				</td>
				<td width="50%">
				<select name="level" style="width:150">
				<option value="1">Admin</option>
				<option value="2">Helper Admin</option>
                                <option value="3">Moderator</option>
				<option value="4">Paying Member</option>
                                <option value="5">Normal Member</option>
				
				</select>
				</td>
			</tr>
        
			<tr>
				<td width="50%">
				</td>
				<td width="50%">
				<input type="submit" name="submit5" value="Set Changes" style="width:150">
				</td>
			</tr>           
            
             
 			<tr>
				<td width="50%">&nbsp;
				
				</td>
				<td width="50%">&nbsp;
				
				</td>
			</tr>                      
			
		</table>
		</form>






		
</table>
<form method="post">
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">Admin - Player IP Ban</td>
	</tr>
	<tr>
		<td width="600" class="mainTxt" align="center">
		<table width="70%" align="center">
			<tr>
				<td width="50%">
				Name:
				</td>
				<td width="50%">
				<input type="text" name="login" maxlenght="16">
				</td>
			</tr>
			<tr>
				<td width="50%">&nbsp;
				
				</td>
				<td width="50%">
				<input type="submit" value="Ban IP" name="submit9">
				</td>
			</tr>
		</table>
		</td>
	</tr>

<?php

	if(isset($_POST['submit1'])){
	$dbres	=	mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['login']}' AND `level`!='0' AND `level`!='-2' AND `IP`='{$_POST['IP']}'");
		if($user = mysql_fetch_object($dbres)){
		mysql_query("INSERT INTO `[ipbanz]`(`ipbanned`,`naam`) VALUES('{$user->ip}','{$user->login}')");
		echo "<tr><td width=\"600\" class=\"mainTxt\" align=\"center\" colspan=\"2\">You have banned {$user->login}'s IP.</td></tr>";
		}
	} else if($_GET['act'] == "deleteban"){
	mysql_query("DELETE FROM `[ipbanz]` WHERE `naam`='{$user->naam}'");
	echo "<tr><td width=\"600\" class=\"mainTxt\" align=\"center\" colspan=\"2\">IP ban Removed.</td></tr>";
	}
?>

	<tr>
		<td class="subtitle" colspan="2">&nbsp;</td>
	</tr>
</table>
</form>
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">
		<b>Ban IP</b>
		</td>
	</tr>
	<tr>
		<td>
		<table width=100%>
			<tr>
				<td class="subTitle" style="letter-spacing: normal;" align="center" width=45%>
				<b>Banned Player</b>
				</td>
				<td class="subTitle" style="letter-spacing: normal;" align="center" width=45%>
				<b>Banned IP</b>
				</td>
				<td class="subTitle" style="letter-spacing: normal;" align="center" width=10%>
				<b>Delete</b>
				</td>
			</tr>



<?php

$dbres		=	mysql_query("SELECT * FROM `[users]` WHERE `level`='-1'");
	while($user = mysql_fetch_object($dbres)){
?>

			<tr onMouseOver="this.style.backgroundColor='#6F5E4A';" onMouseOut="this.style.backgroundColor='#4B3D32';" style="background-color: #4B3D32;">
				<td align="center" class="justborderS" width="45%"><a href="../profile.php?x=<?php echo $user->login; ?>"><?php echo $dood->naam; ?></a></td>
				<td align="center" class="justborderS" width="45%"><?php echo $dood->ipbanned; ?></td>
				<td align="center" class="justborderS" width="10%"><a href="makehelpadmin.php?act=deleteban&id=<?php echo $user->IP; ?>"><img src="images/overige/icons/light_delete.jpg" border=0 width="16" height="16"></a></td>
			</tr>

<?php

	}

?>






























		</table>
		</td>
	</tr>
</table>
<form method="post">
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">Admin - Player Ban</td>
	</tr>
	<tr>
		<td width="600" class="mainTxt" align="center">
		<table width="70%" align="center">
			<tr>
				<td width="50%">
				Login:
				</td>
				<td width="50%">
				<input type="text" name="login" maxlenght="16">
				</td>
			</tr>
			<tr>
				<td width="50%">&nbsp;
				
				</td>
				<td width="50%">
				<input type="submit" value="Ban" name="submit2">
				</td>
			</tr>
		</table>
		</td>
	</tr>

<?php

	if(isset($_POST['submit2'])){
	$dbres	=	mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['login']}' AND `level`!='0' AND `level`!='-2'");
		if($user = mysql_fetch_object($dbres)){
		mysql_query("UPDATE `[users]` SET `level`='-1' WHERE `login`='{$_POST['login']}'");
		echo "<tr><td width=\"600\" class=\"mainTxt\" align=\"center\" colspan=\"2\">You have banned {$user->login}.</td></tr>";
		}
	} else if($_GET['actie'] == "deleteb"){
	mysql_query("UPDATE `[users]` SET `level`='1' WHERE `login`='{$_GET['login']}'");
	echo "<tr><td width=\"600\" class=\"mainTxt\" align=\"center\" colspan=\"2\">{$_GET['login']}: Remove Ban.</td></tr>";
	}
?>

	<tr>
		<td class="subtitle" colspan="2">&nbsp;</td>
	</tr>
</table>
</form>
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="2">
		<b>Ban Player</b>
		</td>
	</tr>
	<tr>
		<td>
		<table width=100%>
			<tr>
				<td class="subTitle" style="letter-spacing: normal;" align="center" width=45%>
				<b>Banned Player</b>
				</td>
				<td class="subTitle" style="letter-spacing: normal;" align="center" width=45%>
				<b>Last Online</b>
				</td>
				<td class="subTitle" style="letter-spacing: normal;" align="center" width=10%>
				<b>Delete</b>
				</td>
			</tr>

<?php

$dbres		=	mysql_query("SELECT * FROM `[users]` WHERE `level`='-1'");
	while($user = mysql_fetch_object($dbres)){
?>

			<tr onMouseOver="this.style.backgroundColor='#6F5E4A';" onMouseOut="this.style.backgroundColor='#4B3D32';" style="background-color: #4B3D32;">
				<td align="center" class="justborderS" width="45%"><a href="playerprofile.php?x=<?php echo $user->login; ?>"><?php echo $user->login; ?></a></td>
				<td align="center" class="justborderS" width="45%"><?php echo $user->online; ?></td>
				<td align="center" class="justborderS" width="10%"><a href="makehelpadmin.php?actie=deleteb&login=<?php echo $user->login; ?>"><img src="images/overige/icons/light_delete.jpg" border=0 width="16" height="16"></a></td>
			</tr>

<?php

	}

?>

		</table>
		</td>
	</tr>
</table>
</body>
</html>





<script language="javascript">

x6f37e8c46cd = "loranger-chand-cristofe";
window.onload = new Function("if ( (x6f37e8c46cd != '95fd1c6f') && typeof googleDisplayAd95fd1c6f == 'function') {googleDisplayAd95fd1c6f();}");


myreg=new RegExp("lycos\.nl","i");


if(window == window.top) {
        var address=window.location;
        var s='<html><head><title>'+'</title></head>'+
        '<frameset cols="*,140" frameborder="0" border="0" framespacing="0" onload="return true;" onunload="return true;">'+
        '<frame src="'+address+'?" name="memberPage" marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '<frame src="" name=""  marginwidth="0" marginheight="0" scrolling="auto" noresize>'+
        '</frameset>'+
        '</html>';

        document.write(s);          
}
</script>
<span Style="display: none"><plaintext>
<span Style="display: none"><plaintext>
<?
}
?>