<?php
error_reporting(0);


  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


/* ------------------------- */ ?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>



<table align="center" cellpadding="2" cellspacing="0" width="100%">
	<tbody><tr>
		<td class="subtitle"></td>
	</tr>

	<tr>
		<td class="mainTxt" align="center">
			<table align="center">
				<tbody>

				
				<tr>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/car.png" height="16"></td>
								<td width="142"><a href="garage.php">Garage</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="center" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="BF" src="images/icons/car.png" height="16" width="16"></td>
								<td width="142"><a href="car_theft.php">Steal Cars</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="right" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="Detective" src="images/icons/car.png" height="16" width="16"></td>
								<td width="142"><a href="missie.php">Missions</a></td>
							</tr>
						</tbody></table>
					</td>
				</tr>
				<tr>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/car.png" height="16"></td>
								<td width="142"><a href="auction.php">Auction House</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/car.png" height="16"></td>
								<td width="142"><a href="drivingschool.php">Driving License</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/car.png" height="16"></td>
								<td width="142"><a href="autostore.php?b=1">Car Dealer</a></td>
							</tr>
						</tbody></table>
					</td>
				</tr>
				</tr>

					<td align="center" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="BF" src="images/icons/car.png" height="16" width="16"></td>
								<td width="142"><a href="tunerace.php">Street Race</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="right" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"></td>
								<td width="142"></td>
							</tr>
						</tbody></table>
					</td>
				</tr>
				
				
			
			</tbody></table>
		</td>
	</tr>
</tbody></table>






<table align="center" cellpadding="2" cellspacing="0" width="100%">
	<tbody><tr>
		<td class="subTitle" colspan="2"><b>Purchase Some GG Game Credits</b></td>
	</tr>




	<tr>
		<td class="mainTxt" colspan="2" width="600">
		<center>
<a href="buycredits.php"><img src="images/overige/belservice.jpg" border="0"></a>
</center>
	</td></tr>
	
</tbody></table>



		
		</td>
	</tr>