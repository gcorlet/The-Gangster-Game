<?php
error_reporting(0);


  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


/* ------------------------- */ ?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>



<table align="center" cellpadding="2" cellspacing="0" width="100%">
	<tbody><tr>
		<td class="subtitle"></td>
	</tr>

	<tr>
		<td class="mainTxt" align="center">
			<table align="center">
				<tbody>

				
				<tr>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/shield.png" height="16"></td>
								<td width="142"><a href="hireprotection.php">Protection</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="center" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="BF" src="images/icons/note.png" height="16" width="16"></td>
								<td width="142"><a href="stocks.php">Stock Market</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="right" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="Detective" src="images/icons/lorry.png" height="16" width="16"></td>
								<td width="142"><a href="beginnercrimes.php">Beginner Crimes</a></td>
							</tr>
						</tbody></table>
					</td>
				</tr>
				<tr>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/report_user.png" height="16"></td>
								<td width="142"><a href="advancedcrimes.php">Advanced Crimes</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/status_online.png.png" height="16"></td>
								<td width="142"><a href="stealp.php">Rob Someone</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/tag_red.png" height="16"></td>
								<td width="142"><a href="attackoptions.php">Attack Options</a></td>
							</tr>
						</tbody></table>
					</td>
				</tr>
				</tr>
								<tr>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/user_add.png" height="16"></td>
								<td width="142"><a href="assault.php">Assaults</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="center" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="BF" src="images/icons/geldd.gif" height="16" width="16"></td>
								<td width="142"><a href="bulletfactory.php">Bullet Factory</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="right" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="Detective" src="images/icons/creditcards.png" height="16" width="16"></td>
								<td width="142"><a href="fraud.php">Fraud</a></td>
							</tr>
						</tbody></table>
					</td>
				</tr>
				
				
								<tr>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"><img src="images/icons/ruby.png" height="16"></td>
								<td width="142"><a href="heist.php">Transport Heist</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="center" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="BF" src="images/icons/bomb.png" height="16" width="16"></td>
								<td width="142"><a href="orgcrime.php">Organised Crime</a></td>
							</tr>
						</tbody></table>
					</td>

						</tbody></table>
					</td>
				</tr>
				
				
												<tr>
					<td align="left" width="200">
						<table align="left" width="200">
							<tbody><tr>
								<td width="30"></td>
								<td width="142"></td>
							</tr>
						</tbody></table>
					</td>
					<td align="center" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"><img alt="BF" src="images/icons/report_user.png" height="16" width="16"></td>
								<td width="142"><a href="bankrob.php">Bank Robbery</a></td>
							</tr>
						</tbody></table>
					</td>
					<td align="right" width="200">
						<table align="right" width="200">
							<tbody><tr>
								<td width="30"></td>
								<td width="142"></td>
							</tr>
						</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
</tbody></table>






<table align="center" cellpadding="2" cellspacing="0" width="100%">
	<tbody><tr>
		<td class="subTitle" colspan="2"><b>Purchase GG Game Credits</b></td>
	</tr>




	<tr>
		<td class="mainTxt" colspan="2" width="600">
		<center>
<a href="buycredits.php"><img src="images/overige/belservice.jpg" border="0"></a>
</center>
	</td></tr>
	
</tbody></table>



		
		</td>
	</tr>