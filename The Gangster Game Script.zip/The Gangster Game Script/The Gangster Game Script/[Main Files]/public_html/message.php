<?php
error_reporting(0);

  include("_include-config.php");
  

    if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<script language="javascript">
var checked = 0;
function checkAll() {
  checked = !checked;
  for(i=0; i<document.form1.elements.length; i++)
    document.form1.elements[i].checked = checked;
}


function newBlock() {
  if(document.form1['block'].value != '')
    document.form2['blocklist[]'].options[document.form2['blocklist[]'].options.length] = new Option(document.form1['block'].value)
  return false;
}

function unBlock() {
  while(document.form2['blocklist[]'].selectedIndex >= 0)
    document.form2['blocklist[]'].options[document.form2['blocklist[]'].selectedIndex] = null;
  return false;
}

function submitList() {
  for(i=0; i<document.form2['blocklist[]'].options.length; i++)
    document.form2['blocklist[]'].options[i].selected = 1;
  return true;
}
</script>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>
<body style="margin: 0px;">
<table width="75%" align="center">
<?php /* ------------------------- */

  if($data->level >= -1) {
    if($_GET['p'] == "inbox") {
      print <<<ENDHTML
  <tr><td class="subTitle"><b>Inbox</b></td></tr>
  <tr><td class="mainTxt">
<a href="message.php?p=inbox">&nbsp;-&nbsp;Inbox</a><br>
<a href="message.php?p=outbox">&nbsp;-&nbsp;Outbox</a><br>
<a href="message.php?p=saved">&nbsp;-&nbsp;Saved Messages</a><br>
<a href="message.php?p=block">&nbsp;-&nbsp;Blocklist</a><br>
<a href="message.php?p=new">&nbsp;-&nbsp;New Message</a><br>
  </td></tr>

ENDHTML;
      print "  <tr><td><form name=\"form1\" method=\"post\" action=\"message.php?p=del\"><table width=100%>\n";
      print "    <tr><td width=10><input type=\"checkbox\" onClick=\"checkAll()\"></td>  <td class=\"mainTxt\" align=\"center\" width=150><i>From:</i></td>  <td class=\"mainTxt\" align=\"center\" width=225><i>Subject:</i></td>  <td class=\"mainTxt\" align=\"center\" width=175><i>Date:</i></td></tr>\n";
      $dbres                                = mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `time` FROM `[messages]` WHERE `to`='{$data->login}' AND `read`=0 AND `inbox`=1 ORDER BY `time` DESC");
      while($message = mysql_fetch_object($dbres)) {
        if(preg_match('/^\s*$/',$message->subject))
          $message->subject                = "(Geen)";
        print "    <tr><td width=10><input type=\"checkbox\" class='btn btn-info' name=\"id[]\" value=\"{$message->id}\"></td>  <td class=\"mainTxt\" width=150><a href=\"profile.php?x={$message->from}\">{$message->from}</a></td>  <td class=\"mainTxt\"><a href=\"message.php?p=read&id={$message->id}\"><b>{$message->subject}</b></a></td>  <td class=\"mainTxt\" width=175>{$message->time}</td></tr>\n";
      }

      $dbres                                = mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `time` FROM `[messages]` WHERE `to`='{$data->login}' AND `read`=1 AND `inbox`=1 ORDER BY `time` DESC");
      while($message = mysql_fetch_object($dbres)) {
        if(preg_match('/^\s*$/',$message->subject))
          $message->subject                = "(Geen)";
        print "    <tr><td width=10><input type=\"checkbox\" class='btn btn-info' name=\"id[]\" value=\"{$message->id}\"></td>  <td class=\"mainTxt\" width=200><a href=\"profile.php?x={$message->from}\">{$message->from}</a></td>  <td class=\"mainTxt\"><a href=\"message.php?p=read&id={$message->id}\">{$message->subject}</a></td>  <td class=\"mainTxt\" width=175>{$message->time}</td></tr>\n";
      }

      print "    </table><input type=\"submit\" class='btn btn-info' value=\"Delete\" style=\"font-size: 10pt\"></form></td></tr>\n";
    }
    else if($_GET['p'] == "saved") {
      print <<<ENDHTML
  <tr><td class="subTitle"><b>Saved Messages</b></td></tr>
  <tr><td class="mainTxt">
<a href="message.php?p=inbox">&nbsp;-&nbsp;Inbox</a><br>
<a href="message.php?p=outbox">&nbsp;-&nbsp;Outbox</a><br>
<a href="message.php?p=saved">&nbsp;-&nbsp;Saved Messages</a><br>
<a href="message.php?p=block">&nbsp;-&nbsp;Blocklist</a><br>
<a href="message.php?p=new">&nbsp;-&nbsp;News Messages</a><br>
  </td></tr>

ENDHTML;
      print "  <tr><td><form name=\"form1\" method=\"post\" action=\"message.php?p=del\"><table width=100%>\n";
      print "    <tr><td width=10><input type=\"checkbox\" onClick=\"checkAll()\"></td>  <td class=\"mainTxt\" align=\"center\" width=150><i>From:</i></td>  <td class=\"mainTxt\" align=\"center\" width=225><i>Subject:</i></td>  <td class=\"mainTxt\" align=\"center\" width=175><i>Date:</i></td></tr>\n";
      $dbres                                = mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `time` FROM `[messages]` WHERE `to`='{$data->login}' AND `inbox`=1 AND `saved`=1 ORDER BY `time` DESC");
      while($message = mysql_fetch_object($dbres)) {
        if(preg_match('/^\s*$/',$message->subject))
          $message->subject                = "(Geen)";
        print "    <tr><td width=10><input type=\"checkbox\" class='btn btn-info' name=\"id[]\" value=\"{$message->id}\"></td>  <td class=\"mainTxt\" width=150><a href=\"profile.php?x={$message->from}\">{$message->from}</a></td>  <td class=\"mainTxt\"><a href=\"message.php?p=read&id={$message->id}\"><b>{$message->subject}</b></a></td>  <td class=\"mainTxt\" width=175>{$message->time}</td></tr>\n";
      }
      print "    </table><input type=\"submit\" class='btn btn-info' value=\"Delete\" style=\"font-size: 10pt\"></form></td></tr>\n";
    }
    else if($_GET['p'] == "outbox") {
      print <<<ENDHTML
  <tr><td class="subTitle"><b>Outbox</b></td></tr>
  <tr><td class="mainTxt">
<a href="message.php?p=inbox">&nbsp;-&nbsp;Inbox</a><br>
<a href="message.php?p=outbox">&nbsp;-&nbsp;Outbox</a><br>
<a href="message.php?p=saved">&nbsp;-&nbsp;Saved Messages</a><br>
<a href="message.php?p=block">&nbsp;-&nbsp;Blocklist</a><br>
<a href="message.php?p=new">&nbsp;-&nbsp;New Messages</a><br>
  </td></tr>
ENDHTML;
      print "  <tr><td><form name=\"form1\" method=\"post\" action=\"message.php?p=del\"><table width=100%>\n";
      print "    <tr><td width=10><input type=\"checkbox\" class='btn btn-info' onClick=\"checkAll()\"></td>  <td class=\"mainTxt\" align=\"center\" width=150><i>To:</i></td>  <td class=\"mainTxt\" align=\"center\" width=225><i>Subject:</i></td>  <td class=\"mainTxt\" align=\"center\" width=175><i>Date:</i></td></tr>\n";
      $dbres                                = mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `time` FROM `[messages]` WHERE `from`='{$data->login}' AND `outbox`=1 ORDER BY `time` DESC");
      while($message = mysql_fetch_object($dbres)) {
        if(preg_match('/^\s*$/',$message->subject))
          $message->subject                = "(Geen)";
        if($message->read == 1)
          print "    <tr><td width=10><input type=\"checkbox\" name=\"id[]\" value=\"{$message->id}\"></td>  <td class=\"mainTxt\" width=200><a href=\"profile.php?x={$message->to}\">{$message->to}</a></td>  <td class=\"mainTxt\"><a href=\"message.php?p=read&id={$message->id}\">{$message->subject}</a></td>  <td class=\"mainTxt\" width=175>{$message->time}</td></tr>\n";
        else
          print "    <tr><td width=10><input type=\"checkbox\" name=\"id[]\" value=\"{$message->id}\"></td>  <td class=\"mainTxt\" width=200><a href=\"profile.php?x={$message->to}\"><b>{$message->to}</b></a></td>  <td class=\"mainTxt\"><a href=\"message.php?p=read&id={$message->id}\"><b>{$message->subject}</b></a></td>  <td class=\"mainTxt\" width=175>{$message->time}</td></tr>\n";
      }

      print "    </table><input type=\"submit\" class='btn btn-info' value=\"Delete\" style=\"font-size: 10pt\"></form></td></tr>\n";
    }
    else if($_GET['p'] == "read" && is_numeric($_GET['id'])) {
      $dbres                        = mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `time` FROM `[messages]` WHERE `id`='{$_GET['id']}' AND (`to`='{$data->login}' OR `from`='{$data->login}')");
      if($message = mysql_fetch_object($dbres)) {
        if($message->to == $data->login)
          mysql_query("UPDATE `[messages]` SET `read`=1 WHERE `id`='{$_GET['id']}'");

        $message->message                = preg_replace('/(http:\/\/\S+)/','<a href="$1" target=\"_blank\">$1</a>',$message->message);
        $message->message                = preg_replace('/\n/',"<br>\n",$message->message);


 $message->message                     = str_replace(":P", "<img src=\"images/smilies/puh.gif\">",$message->message);
 $message->message                     = str_replace(":p", "<img src=\"images/smilies/puh.gif\">",$message->message);
 $message->message                     = str_replace(":)","<img src=\"images/smilies/smilesmile.gif\">",$message->message);
 $message->message                 = str_replace(":D","<img src=\"images/smilies/lol.gif\">",$message->message);
 $message->message                 = str_replace("*D","<img src=\"images/smilies/smileteeth.gif\">",$message->message);
 $message->message                 = str_replace(":^","<img src=\"images/smilies/idea.gif\">",$message->message);
 $message->message                 = str_replace(":w","<img src=\"images/smilies/bye.gif\">",$message->message);
 $message->message                 = str_replace("_o_","<img src=\"images/smilies/worship.gif\">",$message->message);
 $message->message                 = str_replace(":+)","<img src=\"images/smilies/happytears.gif\">",$message->message);
 $message->message                 = str_replace(":(","<img src=\"images/smilies/smileredface.gif\">",$message->message);
 $message->message                 = str_replace(":?","<img src=\"images/smilies/smileconfused.gif\">",$message->message);
 $message->message                 = str_replace(":|","<img src=\"images/smilies/smilehmmm.gif\">",$message->message);
 $message->message                 = str_replace(":'(","<img src=\"images/smilies/tears.gif\">",$message->message);
 $message->message                 = str_replace("8-7","<img src=\"images/smilies/hammer2.gif\">",$message->message);
 $message->message                 = str_replace(":=","<img src=\"images/smilies/applaus.gif\">",$message->message);
 $message->message                 = str_replace(";)","<img src=\"images/smilies/smilewink.gif\">",$message->message);
 $message->message                 = str_replace(":+","<img src=\"images/smilies/clown.gif\">",$message->message);
 $message->message                 = str_replace("o)","<img src=\"images/smilies/smilebounce.gif\">",$message->message);
 $message->message                 = str_replace(":o","<img src=\"images/smilies/blush.gif\">",$message->message);
 $message->message                 = str_replace(":s","<img src=\"images/smilies/smileconfused.gif\">",$message->message);

        $message->message                = preg_replace('/:icon_sad/',"<img src=\"images\smilies\icon_sad.gif\">",$message->message);
        $message->message                = preg_replace('/:smile/',"<img src=\"images\smilies\icon_smile.gif\">",$message->message);
        $message->message                = preg_replace('/:razz/',"<img src=\"images\smilies\icon_razz.gif\">",$message->message);
        $message->message                = preg_replace('/:beer/',"<img src=\"images\smilies\bier.gif\">",$message->message);
        $message->message                = preg_replace('/:mad/',"<img src=\"images\smilies\icon_mad.gif\">",$message->message);
        $message->message                = preg_replace('/:twisted/',"<img src=\"images\smilies\icon_twisted.gif\">",$message->message);
        $message->message                = preg_replace('/:mrgreen/',"<img src=\"images\smilies\icon_mrgreen.gif\">",$message->message);
        $message->message                = preg_replace('/:exclaim/',"<img src=\"images\smilies\icon_exclaim.gif\">",$message->message);
        $message->message                = preg_replace('/:question/',"<img src=\"images\smilies\icon_question.gif\">",$message->message);
        $message->message                = preg_replace('/:exclaim/',"<img src=\"images\smilies\icon_exclaim.gif\">",$message->message);
        $message->message                = preg_replace('/:eek/',"<img src=\"images\smilies\icon_eek.gif\">",$message->message);
        $message->message                = preg_replace('/:cool/',"<img src=\"images\smilies\icon_cool.gif\">",$message->message);
        $message->message                = preg_replace('/:redface/',"<img src=\"images\smilies\icon_redface.gif\">",$message->message);
        $message->message                = preg_replace('/:surprised/',"<img src=\"images\smilies\icon_surprised.gif\">",$message->message);


            $message->message                 = preg_replace("/\[b\](.+?)\[\/b\]/is",'<b>\1</b>', $message->message);  //vette text
                $message->message                 = preg_replace("/\[i\](.+?)\[\/i\]/is",'<i>\1</i>', $message->message);  //schuine text
                $message->message                 = preg_replace("/\[u\](.+?)\[\/u\]/is",'<u>\1</u>', $message->message);  //underlined
                $message->message                 = preg_replace("#\[s\](.*?)\[/s\]#is", "<s>\\1</s>", $message->message); // doorstreepte tekst

$dbres                                = mysql_query("SELECT *,UNIX_TIMESTAMP(`online`) AS `time`,DATE_FORMAT(`online`,'%d-%m-%Y %H:%i') AS `online` FROM `[users]` WHERE `login`='{$message->from}' AND `activated`=1");
if($profiel = mysql_fetch_object($dbres));

        print <<<ENDHTML

  <tr><td class="subTitle"><b></b></td></tr>
  <tr><td class="mainTxt">
<a href="message.php?p=inbox">&nbsp;-&nbsp;Inbox</a><br>
<a href="message.php?p=outbox">&nbsp;-&nbsp;Outbox</a><br>
<a href="message.php?p=saved">&nbsp;-&nbsp;Saved Messages</a><br>
<a href="message.php?p=block">&nbsp;-&nbsp;Blocklist</a><br>
<a href="message.php?p=new">&nbsp;-&nbsp;News Messages</a><br>
  </td></tr>


<table width=70% align=center>

<td class="mainTxt" width="28%"><b>From:</b> <aling=right><a href="profile.php?x={$message->from}">{$message->from}</a>

  <td class="mainTxt">
<b>Date:</b> <aling=right>{$message->time}

  <td class="mainTxt">
<b>Subject:</b> <aling=right> {$message->subject}</td></tr>

<td class="mainTxt" align=center width="100"><center>
<img align=center src="{$profiel->avaurl}" width="130" height="100">

  <td class="mainTxt" colspan=4>
{$message->message}
  </td></tr>




ENDHTML;


        if($message->from != $data->login)
          print "    <tr><td class=\"mainTxt\" align=\"center\" width=100><a href=\"message.php?p=block&add={$message->from}\"><center><b>Block</a></td>  <td class=\"mainTxt\" align=\"center\" width=100><a href=\"message.php?p=new&to={$message->from}&subject=". urlencode("Re: {$message->subject}") ."\"><center><b>Reply</a></td>  ";
        else
          print "    <tr>";

        print "<td class=\"mainTxt\" align=\"center\" width=100><a href=\"message.php?p=del&id[]={$message->id}\"><center><b>Delete</a></td></tr>\n";
      }
    }
    else if($_GET['p'] == "del") {
      if(isset($_GET['id']))
        $_POST['id']                        = $_GET['id'];
      foreach($_POST['id'] as $msgid) {
        $dbres                                = mysql_query("SELECT `outbox`,`inbox`,`from`,`to` FROM `[messages]` WHERE `id`='$msgid' AND (`from`='{$data->login}' OR `to`='{$data->login}')");
        if($message = mysql_fetch_object($dbres)) {
          if($message->from == $data->login)
            mysql_query("UPDATE `[messages]` SET `outbox`=0 WHERE `id`='$msgid'");
          else
            mysql_query("UPDATE `[messages]` SET `inbox`=0 WHERE `id`='$msgid'");
        }
      }
      print <<<ENDHTML
  <tr><td class="subTitle"><b>Inbox</b></td></tr>
  <tr><td class="mainTxt">
<a href="message.php?p=inbox">&nbsp;-&nbsp;Inbox</a><br>
<a href="message.php?p=outbox">&nbsp;-&nbsp;Outbox</a><br>
<a href="message.php?p=saved">&nbsp;-&nbsp;Saved Messages</a><br>
<a href="message.php?p=block">&nbsp;-&nbsp;Blocklist</a><br>
<a href="message.php?p=new">&nbsp;-&nbsp;New Messages</a><br>
  </td></tr>
  <tr><td class="mainTxt">Reported and Removed</td></tr>
ENDHTML;
    }
    else if($_GET['p'] == "block") {
      print <<<ENDHTML
  <tr><td class="subTitle"><b>Blocklist</b></td></tr>
  <tr><td class="mainTxt">
<a href="message.php?p=inbox">&nbsp;-&nbsp;Inbox</a><br>
<a href="message.php?p=outbox">&nbsp;-&nbsp;Outbox</a><br>
<a href="message.php?p=saved">&nbsp;-&nbsp;Saved Messages</a><br>
<a href="message.php?p=block">&nbsp;-&nbsp;Blocklist</a><br>
<a href="message.php?p=new">&nbsp;-&nbsp;New Messages</a><br>
  </td></tr>
ENDHTML;

      if(isset($_POST['update_list'])) {
        $newlist                        = "";
        if(isset($_POST['blocklist'])) {
          foreach($_POST['blocklist'] as $blocked) {
            if($info = mysql_fetch_object(mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$blocked}'"))) {
              $newlist                        = preg_replace("/,{$info->login},/i",'',$newlist);
              $newlist                        .= ",{$info->login},";
            }
          }
        }
        mysql_query("UPDATE `[users]` SET `blocklist`='$newlist' WHERE `login`='{$data->login}'");
        print "  <tr><td class=\"mainTxt\">The Blocklist has been updated</td></tr>";
        $blocklist                        = $newlist;
      }
      else {
        $dbres                                = mysql_query("SELECT `blocklist` FROM `[users]` WHERE `login`='{$data->login}'");
        $blocklist                        = mysql_fetch_object($dbres);
        $blocklist                        = $blocklist->blocklist;
      }

      if(isset($_GET['add'])) {
        $dbres                                = mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_GET['add']}'");
        if($sender = mysql_fetch_object($dbres)) {
          $blocklist                        = preg_replace("/,{$sender->login},/i",'',$blocklist);
          $blocklist                        .= ",{$sender->login},";
          mysql_query("UPDATE `[users]` SET `blocklist`='$blocklist' WHERE `login`='{$data->login}'");
          print "  <tr><td class=\"mainTxt\">{$sender->login} is blocked</td></tr>\n";
        }
      }
      print <<<ENDHTML
  <tr><td class="mainTxt" align="center"><table><form name="form1">
        <tr><td><input type="text" name="block" style="width: 100;"> <input type="button" value="Block" onClick="newBlock()" style="width: 100;"></form></td></tr>

        <form name="form2" method="post" action="message.php?p=block" onSubmit="submitList()">
        <tr><td><select name="blocklist[]" width=200 style="width: 200" size=10 MULTIPLE>
ENDHTML;

      $blocklist                        = preg_replace('/(^,|,$)/','',$blocklist);
      if($blocklist != "") {
        $blocklist                        = explode(',,',$blocklist);
        sort($blocklist);
        foreach($blocklist as $blocked)
          print "        <option value=\"$blocked\">$blocked</option>\n";
      }
      print "        </select></td>\n        <td><input type=\"button\" value=\"Unblock\" onClick=\"unBlock()\" style=\"width: 100;\"></td></tr>\n        <tr><td align=\"center\" width=210><input type=\"submit\" name=\"update_list\" value=\"Update\" style=\"width: 100\"><br>Always store messages when you block/unblock someone.</td></tr>\n  </form></table></td></tr>\n";
    }
    else if($_GET['p'] == "new") {
      print <<<ENDHTML
  <tr><td class="subTitle"><b>New Messages</b></td></tr>
  <tr><td class="mainTxt">
<a href="message.php?p=inbox">&nbsp;-&nbsp;Inbox</a><br>
<a href="message.php?p=outbox">&nbsp;-&nbsp;Outbox</a><br>
<a href="message.php?p=saved">&nbsp;-&nbsp;Saved Messages</a><br>
<a href="message.php?p=block">&nbsp;-&nbsp;Blocklist</a><br>
<a href="message.php?p=new">&nbsp;-&nbsp;New Messages</a><br>
  </td></tr>
        <tr><td class="mainTxt">
<SCRIPT language=javascript>





function icon(theicon) {
document.form1.message.value += ""+theicon;
document.form1.message.focus();
}

function setsmilie(which){
document.form1.message.value = document.form1.message.value + which;
}


</SCRIPT>

<script language="javascript">
function verwijder(bericht, url)
{
    if(confirm(bericht)) location.href = url;
}
function icon(theicon)
{
    document.form1.message.value += ""+theicon;
    document.form1.message.focus();
}
</script>

        <input type="button" value="B" style="font-weight:bold; width: 30px" onClick="javascript:icon(' [b]tekst[/b] ')">
        <input type="button" value="I" style="font-style:italic; width: 30px" onClick="javascript:icon(' [i]tekst[/i] ')">
        <input type="button" value="U" style="text-decoration: underline; width: 30px" onClick="javascript:icon(' [u]tekst[/u] ')">
        <input type="button" value="S" style="width: 30px" onClick="javascript:icon(' [s]tekst[/s] ')">

        </td></tr>
        <tr><td class="mainTxt">
<a href="javascript://" onClick="document.form1.message.value += ' :)'"><img src=images/smilies/smilesmile.gif alt=":)" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' ;)'"><img src=images/smilies/smilewink.gif alt=";)" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :P'"><img src=images/smilies/puh.gif alt="":P" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :D'"><img src=images/smilies/lol.gif alt=":D" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' *D'"><img src=images/smilies/smileteeth.gif alt="*D" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :^'"><img src=images/smilies/idea.gif alt=":^" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :w'"><img src=images/smilies/bye.gif alt=":w" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' _o_'"><img src=images/smilies/worship.gif alt="_o_" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :+)'"><img src="images/smilies/happytears.gif" alt=":+)" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :('"><img src="images/smilies/smileredface.gif" alt=":(" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :?'"><img src="images/smilies/smileconfused.gif" alt=":?" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :|'"><img src="images/smilies/smilehmmm.gif" alt=":|" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' 8-7'"><img src="images/smilies/hammer2.gif" alt="8-7" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :='"><img src="images/smilies/applaus.gif" alt=":=" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' o)'"><img src="images/smilies/smilebounce.gif" alt="o)" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :+'"><img src="images/smilies/clown.gif" alt=":+" border="0"></a>
<a href="javascript://" onClick="document.form1.message.value += ' :o'"><img src="images/smilies/blush.gif" alt=":o" border="0"></a>

  </td></tr>
ENDHTML;
      if(isset($_POST['to'],$_POST['message'])) {
        if(strtolower($_POST['to']) != strtolower($data->login)) {
          $dbres                        = mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_POST['to']}'");
          $info                                = mysql_fetch_object($dbres);
          if($info == false)
            print "  <tr><td class=\"mainTxt\">'{$_POST['to']}' does not exist</td></tr>\n";
          else if($info->Mobieltje == -1111111111111111)
            print "  <tr><td class=\"mainTxt\">{$info->login} has no mobile</td></tr>\n";
          else {
            $_POST['subject']                = preg_replace('/</','&#60;',$_POST['subject']);
            $_POST['message']                = preg_replace('/</','&#60;',$_POST['message']);

            $dbres                        = mysql_query("SELECT `login` FROM `[users]` WHERE `login`='{$_POST['to']}'");
              if($recp = mysql_fetch_object($dbres)) {
              mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'{$data->login}','{$recp->login}','{$_POST['subject']}','{$_POST['message']}')");
              echo "<tr><td class=maintxt>Message Sent</tr></td>";
              exit;
            }
          }
        }
        else
          print "  <tr><td class=\"mainTxt\">You cannot send reported to yourself</td></tr>\n";
      }

      $_REQUEST['message']                = stripslashes($_REQUEST['message']);
      print <<<ENDHTML
  <tr><td class="mainTxt">
        <form name="form1" method="POST" action="message.php?p=new"><table>
        <tr><td width=100>To:</td>                <td><input type="text" class='btn btn-info'  name="to" value="{$_REQUEST['to']}" maxlength=16></td></tr>
        <tr><td width=100>Subject:</td>        <td><input type="text" class='btn btn-info'  name="subject" value="{$_REQUEST['subject']}" maxlength=25></td></tr>
        <tr><td width=100 valign="top">Message:<br><br>
ENDHTML;
      if($data->clanlevel > 0)
        print "                <a href=\"javascript://\" onClick=\"document.form1.message.value += '$sitelink/click.php?clan={$data->clan}'\">Clan link</a>\n";
      print <<<ENDHTML
        </td>                                        <td><textarea name="message" cols=40 rows=10>{$_REQUEST['message']}</textarea></td></tr>
        <tr><td width=100></td>                        <td align="right"><input class="2" type="submit" name="submit" value="Send"></td></tr>
ENDHTML;
    }
    else {
      print <<<ENDHTML
  <tr><td class="subTitle"><b>Report</b></td></tr>
  <tr><td class="mainTxt">
<a href="message.php?p=inbox">&nbsp;-&nbsp;Inbox</a><br>
<a href="message.php?p=outbox">&nbsp;-&nbsp;Outbox</a><br>
<a href="message.php?p=saved">&nbsp;-&nbsp;Saved Messages</a><br>
<a href="message.php?p=block">&nbsp;-&nbsp;Blocklist</a><br>
<a href="message.php?p=new">&nbsp;-&nbsp;New Messages</a><br>
  </td></tr>
ENDHTML;
    }
  }
  else
    print "  <tr><td class=\"mainTxt\">If possible you must have sent/received messages to report</td></tr>\n";

/* ------------------------- */ ?>
</table>
</body>
</html>
