<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }
include('_include-gevangenis.php');
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
?>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<table width=100%>
<tr><td class="subTitle"><b>Missions's</b></td></tr>
<tr><td class="mainTxt"><center><img border=0 src=images/game/missiehq.gif border=0></center></td></tr>
<?php /* ------------------------- */
$missie12 ="To Gain Access: Complete Mission 11";
$missie11 ="To Gain Access: Complete Mission 10";
$missie10 ="To Gain Access: Complete Mission 9";
$missie9 ="To Gain Access: Complete Mission 8";
$missie8 ="To Gain Access: Complete Mission 7";
$missie7 ="To Gain Access: Complete Mission 6";
$missie6 ="To Gain Access: Complete Mission 5";
$missie5 ="To Gain Access: Complete Mission 4";
$missie4 ="To Gain Access: Complete Mission 3";
$missie3 ="To Gain Access: Complete Mission 2";
$missie2 ="To Gain Access: Complete Mission 1";
$missie1 = "Status: Mission Completed";
if($data->missie == 0){
$missie1 = "<a href=\"missie1.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie == 1){
$missie2 = "<a href=\"missie2.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 2){
$missie2 = "Status: Mission Completed";
}
if($data->missie == 2){
$missie3 = "<a href=\"missie3.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 3){
$missie3 = "Status: Mission Completed";
}
if($data->missie == 3){
$missie4 = "<a href=\"missie4.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 4){
$missie4 = "Status: Mission Completed";
}
if($data->missie == 4){
$missie5 = "<a href=\"missie5.php\"> Load Mission</a>";
}
if($data->missie >= 5){
$missie5 = "Status: Mission Completed";
}
if($data->missie == 5){
$missie6 = "<a href=\"missie6.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 6){
$missie6 = "Status: Mission Completed";
}
if($data->missie == 6){
$missie7 = "<a href=\"missie7.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 7){
$missie7 = "Status: Mission Completed";
}
if($data->missie == 7){
$missie8 = "<a href=\"missie8.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 8){
$missie8 = "Status: Mission Completed";
}
if($data->missie == 8){
$missie9 = "<a href=\"missie9.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 9){
$missie9 = "Status: Mission Completed";
}
if($data->missie == 9){
$missie10 = "<a href=\"missie10.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 10){
$missie10 = "Status: Mission Completed";
}
if($data->missie == 10){
$missie11 = "<a href=\"missie11.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 11){
$missie11 = "Status: Mission Completed";
}
if($data->missie == 11){
$missie12 = "<a href=\"missie12.php\" class='btn btn-info'> Load Mission</a>";
}
if($data->missie >= 12){
$missie12 = "Status: Mission Completed";
}
  $dbres				= mysql_query("SELECT missie FROM `[users]` WHERE `missie`='$data->missie' ");
  $missie				= mysql_num_rows($dbres);
 print <<<ENDHTML
  <tr><td class="mainTxt" align="center">
	<table>
		<tr><td width=250><b>Mission 1:</b> A Family Gift:</td>	<td align="right" width="200">$missie1</td></tr>
		<tr><td width=250><b>Mission 2:</b> Transport Cocaine:</td>	<td align="right">$missie2</td></tr>
		<tr><td width=250><b>Mission 3:</b> Love of Paintings:</td>	<td align="right">$missie3</td></tr>
		<tr><td width=250><b>Mission 4:</b> Real Attacks:</td>		<td align="right" width="200">$missie4</td></tr>	
		<tr><td width=250><b>Mission 5:</b> Working for the Mafia:</td>		<td align="right" width="200">$missie5</td></tr>
		<tr><td width=250><b>Mission 6:</b> Jewels Robbery:</td>		<td align="right" width="200">$missie6</td></tr>
		<tr><td width=250><b>Mission 7:</b> Real Attacks Part 2:</td>		<td align="right" width="200">$missie7</td></tr>
		<tr><td width=250><b>Mission 8:</b> A Family Gift Part 2:</td>		<td align="right" width="200">$missie8</td></tr>
		<tr><td width=250><b>Mission 9:</b> The Prison Cell:</td>		<td align="right" width="200">$missie9</td></tr>
		<tr><td width=250><b>Mission 10:</b> The Drag race:</td>		<td align="right" width="200">$missie10</td></tr>
		<tr><td width=250><b>Mission 11:</b> Roll Them Dice:</td>		<td align="right" width="200">$missie11</td></tr>
		<tr><td width=250><b>Mission 12:</b> Weapons Trade:</td>		<td align="right" width="200">$missie12</td></tr>
  <tr><td width=250></td>		<td align="right" width="200"></td></tr>
<tr><td width=250>Mission level:<b> $data->missie</b></td>		<td align="right" width="200"></td></tr>
<tr><td width=250>There are <a href="list.php?s=missie"><b>$missie</b></a> people on the same mission as you.</td>		<td align="right" width="200"></td></tr>
ENDHTML;

/* ------------------------- */ ?>
</table>

</body>


</html><?
mysql_close();
ob_flush();
?>