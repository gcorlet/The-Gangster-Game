<?php
error_reporting(0);

  include('_include-config.php');
include('_include-gevangenis.php');


/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>



<table width=100%>
<tr><td class="subTitle"><b>Mission 1</b></td></tr>
<tr><td class="mainTxt"><center><img border=0 src=images/game/missie1.gif border=0></center></td></tr>
<tr>

<?php
if($data->missie >=1){
print"<tr><td class=\"mainTxt\">Mission 1 has already been done.</td></tr>";
exit;}
if(isset($_POST['profile'])) {
 
 $bel				= preg_replace('/\</','&#60;',substr($_POST['bel'],0,500));
   $dbres			= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='{$data->login}' AND `id`='$bel'");
          $rij				= mysql_fetch_object($dbres);

if($rij <= 0){
 print "<tr><td class=\"mainTxt\">That car is in use.</td></tr>\n";
exit;
}    
else if ($rij->bezig == 1){
print "<tr><td class=\"mainTxt\">This is not your car.</td></tr>";
exit;
}

else if ($rij->soort !=16){
print "<tr><td class=\"mainTxt\">That car is not a mercedes.</td></tr>";
exit;
}
else if ($rij->schade !=0){
print "<tr><td class=\"mainTxt\">That car has not got 0% damage.</td></tr>";
exit;
}
else{
mysql_query("UPDATE `[garage]` SET `owner`='The Toweler' WHERE `id`='$bel'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'1000000', `missie`='1' WHERE `login`='$data->login'");

print "<tr><td class=\"mainTxt\">You have sold your car to Bachini 'The Butcher' Barello.</td></tr>";
exit;
}

}
 print <<<ENDHTML

	<form method="post">
 <td class="mainTxt"> Bachini "The Butcher" Barello is a member of the Mafia Family. He is so rich, that he wants to give his family a mercedes.
But is too lazy to visit the car dealer. He wants to purchase the mercedes off you. He wants to buy it with 0% damages, for 1 million in cash.
</td></tr><tr>
<td class="mainTxt"> 
Your mission:<br>
Get a Mercedes with 0% Damages.<br>
Tip: You could steal a mercedez from the football game,<br>
that way you will receive 100% profit of the 1 million.
 </td></tr>
   <tr><td class="mainTxt"width=50>Car id:<br>
  <input type="text" class="btn btn-info" name="bel" value=""  size="10">
<input type="submit" class="btn btn-info" name="profile" value="Sell"></td></tr></form>
    	</table> 
ENDHTML;
?>