<?php
error_reporting(0);

  include('_include-config.php');

include('_include-gevangenis.php');

/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>



<table width=100%>
<tr><td class="subTitle"><b>Missie 2</b></td></tr>
<tr><td class="mainTxt"><center><img border=0 src=images/game/missie2.gif border=0></center></td></tr>
<tr>

<?php
if($data->missie >=2){
print"<tr><td class=\"mainTxt\">You have already done Mission 2, Sorry!</td></tr>";
exit;}
if($data->missie ==0){
print"<tr><td class=\"mainTxt\">You have to complete Mission 1 first.</td></tr>";
exit;}
if(isset($_POST['profile'])) {
 $kg				= preg_replace('/\</','&#60;',substr($_POST['kg'],0,500));
 $bel				= preg_replace('/\</','&#60;',substr($_POST['bel'],0,500));


 $dbres			= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='{$data->login}' AND `id`='$bel'");
          $rij				= mysql_fetch_object($dbres);

if($rij <= 0){
 print "<tr><td class=\"mainTxt\">You car is busy or in use</td></tr>\n";
exit;
}    
else if ($rij->bezig == 1){
print "<tr><td class=\"mainTxt\">This is not your car.</td></tr>";
exit;
}

else if ($rij->soort !=14){
print "<tr><td class=\"mainTxt\">That is not a jeep.</td></tr>";
exit;
}
$schade = $rij->schade + 2;
$pol = rand(1,$schade);

if($pol == 1){
$geld = $kg * 100000;
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$geld', `missie`='2' WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\">You gave $kg KG`s of cocaine to Proffessor Prasini, you got $geld for the lot.</td></tr>";
exit;
}
else {
$gevang = $kg * 900;

    mysql_query("DELETE FROM `[garage]` WHERE `id`='$bel' AND `owner`='$data->login'"); 

mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='$gevang' WHERE `login` = '$data->login'");
print "<tr><td class=\"mainTxt\">You finnish your chat with Proffessor Prasini, then head for car park. The police grab you before you enter your car and throw you into a cell. Your in there for $gevang seconds. The Police have taken your car into there possession.</td></tr>";
exit;
}
}
 print <<<ENDHTML

	<form method="post">
 <td class="mainTxt">Proffessor Prasini got a message to you.
He said theres 50 kilo`s of cocaine in his lab in the woods, only 
accessable by a Jeep. If you can get the 50 Kilo's without the police
being notified or being suspicous, then you will get your 100,000 per
kilo. 15 minutes per Kilo.</td></tr><tr>
<td class="mainTxt"> 

Your Mission is:<br>
Retreive the cocaine from Proffessor Prasini.<br>
Then when you deliver the drugs on time, you will get your cash.<br>
You can only do this mission in 1 turn.
 </td></tr>
   <tr><td class="mainTxt"width=50>Jeep id:<br>
  <input type="text" name="bel" value=""  size="10"><br>
<select name="kg">
	  			<option selected value="1">1</option>
	  			<option value="2">2</option>
	  			<option value="3">3</option>
				<option value="4">4</option>
	  			<option value="5">5</option>
				<option value="6">6</option>
	  			<option value="7">7</option>
				<option value="8">8</option>
	  			<option value="9">9</option>
				<option value="10">10</option>
	  			<option value="11">11</option>
				<option value="12">12</option>
	  			<option value="13">13</option>
				<option value="14">14</option>
	  			<option value="15">15</option>
				<option value="16">16</option>
	  			<option value="17">17</option>
				<option value="18">18</option>
	  			<option value="19">19</option>
	  			<option value="20">20</option>
	  			<option value="21">21</option>
	  			<option value="22">22</option>
	  			<option value="23">23</option>
	  			<option value="24">24</option>
	  			<option value="25">25</option>
	  			<option value="26">26</option>
	  			<option value="27">27</option>
	  			<option value="28">28</option>
	  			<option value="29">29</option>
	  			<option value="30">30</option>
	  			<option value="31">31</option>
	  			<option value="32">32</option>
	  			<option value="33">33</option>
	  			<option value="34">34</option>
	  			<option value="35">35</option>
	  			<option value="36">36</option>
	  			<option value="37">37</option>
	  			<option value="38">38</option>
	  			<option value="39">39</option>
				<option value="40">40</option>
				<option value="41">41</option>
				<option value="42">42</option>
				<option value="43">43</option>
				<option value="44">44</option>
				<option value="45">45</option>
				<option value="46">46</option>
				<option value="47">47</option>
				<option value="48">48</option>
				<option value="49">49</option>
				<option value="50">50</option></select>KG
<input type="submit" name="profile" value="Get On"></td></tr></form>
    	</table> 
ENDHTML;
?>