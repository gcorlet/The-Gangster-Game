<?php
error_reporting(0);

  include('_include-config.php');

include('_include-gevangenis.php');

/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>



<table width=100%>
<tr><td class="subTitle"><b>Mission 3</b></td></tr>
<tr><td class="mainTxt"><center><img border=0 src=images/game/missie3.gif border=0></center></td></tr>


<?php
if($data->missie >=3){
print"<tr><td class=\"mainTxt\">You have already done mission 3.</td></tr>";
exit;}
if($data->missie <=1){
print"<tr><td class=\"mainTxt\">You have not yet done mission 2.</td></tr>";
exit;}

if(isset($_POST['profile'])) {
 $kg				= preg_replace('/\</','&#60;',substr($_POST['kg'],0,500));
 $bel				= preg_replace('/\</','&#60;',substr($_POST['bel'],0,500));


 $dbres			= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='{$data->login}' AND `id`='$bel'");
          $rij				= mysql_fetch_object($dbres);

if($rij <= 0){
 print "<tr><td class=\"mainTxt\">The car is busy.</td></tr>\n";
exit;
}    
else if ($rij->bezig == 1){
print "<tr><td class=\"mainTxt\">This car does not belong to you.</td></tr>";
exit;
}

else if ($rij->soort !=20){
print "<tr><td class=\"mainTxt\">This is not a Jaguar.</td></tr>";
exit;
}
$schade = $rij->schade + 2;
$pol = rand(0,$schade);

if($pol == 1){
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'2000000', `missie`='3' WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\">You have delivered the stolen painting to Knuckles, and received ;2.000.000.</td></tr>";
exit;
}
if($pol >=2 || $pol <= 12){
    mysql_query("DELETE FROM `[garage]` WHERE `id`='$bel' AND `owner`='$data->login'"); 

mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='900' WHERE `login` = '$data->login'");
 print "<tr><td class=\"mainTxt\">As the painting is passed between hands, 5 policeman appear out of nowhere, they take control of your car and bang you away.</td></tr>";
exit;
}
else{
print "<tr><td class=\"mainTxt\">The robbers came out of the museum empty handed. Mission failed.</td></tr>";
exit;

}
}
 print <<<ENDHTML

	<form method="post">
 <td class="mainTxt">Knuckles tried to buy the painting from the museum,
but they wouldnt sell it to him. So... hes got together a few armed robbers, but he needs a driver.
<br>
<br>
Grab a Jaguar and meet Knuckles at his house. The reward is 2,000,000!
</td></tr><tr>
<td class="mainTxt"> 

Your missions is:<br>
Drive the robbers to and from the museum safely.
Do this and you will be reward 2,000,000.
 </td></tr>
   <tr><td class="mainTxt"width=50>Jaguar id:<br>
  <input type="text" name="bel" value=""  size="10"><br>

<input type="submit" name="profile" value="Submit"></td></tr></form>
    	</table> 
ENDHTML;
?>