<?php
error_reporting(0);

  include('_include-config.php');

include('_include-gevangenis.php');

/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>



<table width=100%>
<tr><td class="subTitle"><b>Mission 4</b></td></tr>
<tr><td class="mainTxt"><center><img border=0 src=images/game/missie4.gif border=0></center></td></tr>

<?php
if($data->missie >=4){
print"<tr><td class=\"mainTxt\">You have already done mission 4.</td></tr>";
exit;}
if($data->missie <=2){
print"<tr><td class=\"mainTxt\">You have not yet done mission 3.</td></tr>";
exit;}

if(isset($_POST['profile'])) {
 $kg				= preg_replace('/\</','&#60;',substr($_POST['kg'],0,500));
 $bel				= preg_replace('/\</','&#60;',substr($_POST['bel'],0,500));
if($data->Dynamite <=4){
print"<tr><td class=\"mainTxt\">You dont have 5 dynamites.</td></tr>";
exit;}
$dbres			= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='{$data->login}' AND `id`='$bel'");
          $rij				= mysql_fetch_object($dbres);

if($rij <= 0){
 print "<tr><td class=\"mainTxt\">This is not your car.</td></tr>\n";
exit;
}    
else if ($rij->bezig == 1){
print "<tr><td class=\"mainTxt\">The car is busy</td></tr>";
exit;
}

else if ($rij->soort !=10){
print "<tr><td class=\"mainTxt\">This is not a volkswagen.</td></tr>";
exit;
}

$schade = $rij->schade + 3;
$pol = rand(0,$schade);

if($pol == 1){


     mysql_query("DELETE FROM `[garage]` WHERE `id`='$bel' AND `owner`='$data->login'"); 
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'2500000', `missie`='4' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET  `Dynamite`=`Dynamite`-'5', `attack`=`attack`-'675', `defence`=`defence`-'675'  WHERE `login` = '$data->login'");

print "<tr><td class=\"mainTxt\">You have parked the volkswagen in the right place, you got your cash.</td></tr>";
exit;
}

if($pol >=8 || $pol <= 30){
 
     mysql_query("DELETE FROM `[garage]` WHERE `id`='$bel' AND `owner`='$data->login'"); 

mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='5400', `Dynamite`=`Dynamite`-'5', `attack`=`attack`-'675', `defence`=`defence`-'675'  WHERE `login` = '$data->login'");

 print "<tr><td class=\"mainTxt\">THe police pull you over for being in a stolen car. They spot the dynamite in the car. They bang you away for 1 and half hours.</td></tr>";
exit;
}
else{
     mysql_query("DELETE FROM `[garage]` WHERE `id`='$bel' AND `owner`='$data->login'"); 

mysql_query("UPDATE `[users]` SET  `Dynamite`=`Dynamite`-'5', `attack`=`attack`-'675', `defence`=`defence`-'675'  WHERE `login` = '$data->login'");

print "<tr><td class=\"mainTxt\">You have parked the car near the wrong lab. Mission Failed!</td></tr>";
exit;
}
}
 print <<<ENDHTML

	<form method="post">
 <td class="mainTxt">The attack is on the lab of the little guy who stole his car.</td></tr><tr>
<td class="mainTxt"> 

Your mission is:<br>
Get a volkswagen with 5 sticks of dynamite.<br>
Then park upside the lab.<br>.
 </td></tr>
   <tr><td class="mainTxt">
You have $data->Dynamite sticks of dynamite<br>
Car id:<br>
  <input type="text" name="bel" value=""  size="10"><br>

<input type="submit" name="profile" value="Park The VOlkswagen"></td></tr></form>
    	</table> 
ENDHTML;
?>