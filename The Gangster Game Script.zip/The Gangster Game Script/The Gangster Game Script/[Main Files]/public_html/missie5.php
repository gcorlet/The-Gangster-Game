<?php
error_reporting(0);

  include('_include-config.php');

include('_include-gevangenis.php');

/* ------------------------- */ ?>
<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>



<table width=100%>
<tr><td class="subTitle"><b>Mission 5</b></td></tr>
<tr><td class="mainTxt"><center><img border=0 src=images/game/missie5.gif border=0></center></td></tr>
<?php
if($data->missie >=5){
print"<tr><td class=\"mainTxt\">You have already done mission 5.</td></tr>";
exit;}
if($data->missie <=3){
print"<tr><td class=\"mainTxt\">You havent done mission 4 yet.</td></tr>";
exit;}

if(isset($_POST['profile'])) {
 $kg				= preg_replace('/\</','&#60;',substr($_POST['kg'],0,500));
 $bel				= preg_replace('/\</','&#60;',substr($_POST['bel'],0,500));
if($data->vlammenwerper <=0){
print"<tr><td class=\"mainTxt\">You dont have a flamethrower.</td></tr>";
exit;}
$dbres			= mysql_query("SELECT * FROM `[garage]` WHERE `owner`='{$data->login}' AND `id`='$bel'");
          $rij				= mysql_fetch_object($dbres);

if($rij <= 0){
 print "<tr><td class=\"mainTxt\">This is not your car.</td></tr>\n";
exit;
}    
else if ($rij->bezig == 1){
print "<tr><td class=\"mainTxt\">This car is busy.</td></tr>";
exit;
}

else if ($rij->soort !=21){
print "<tr><td class=\"mainTxt\">The car is not a viper.</td></tr>";
exit;
}

$schade = $rij->schade + 3;
$pol = rand(0,$schade);

if($pol == 1){


     mysql_query("DELETE FROM `[garage]` WHERE `id`='$bel' AND `owner`='$data->login'"); 
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'3500000', `missie`='5' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET  `Vlammenwerper`=`Vlammenwerper`-'1', `attack`=`attack`-'1790', `defence`=`defence`-'1790'  WHERE `login` = '$data->login'");

print "<tr><td class=\"mainTxt\">You step out of the Viper and begin using your flamethrower. Mission Complete!</td></tr>";
exit;
}

if($pol >=14 || $pol <= 30){
 
     mysql_query("DELETE FROM `[garage]` WHERE `id`='$bel' AND `owner`='$data->login'"); 

mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='3600', `Vlammenwerper`=`Vlammenwerper`-'1', `attack`=`attack`-'1790', `defence`=`defence`-'1790'  WHERE `login` = '$data->login'");

 print "<tr><td class=\"mainTxt\">It all went wrong, now your crammed in a cell for 1 hour!.</td></tr>";
exit;
}
else{
     mysql_query("DELETE FROM `[garage]` WHERE `id`='$bel' AND `owner`='$data->login'"); 

mysql_query("UPDATE `[users]` SET  `Vlammenwerper`=`Vlammenwerper`-'1', `attack`=`attack`-'1790', `defence`=`defence`-'1790'  WHERE `login` = '$data->login'");

print "<tr><td class=\"mainTxt\">You dont have a flamethrower. Mission Failed!.</td></tr>";
exit;
}
}
 print <<<ENDHTML

	<form method="post">
 <td class="mainTxt">The maffia want you on a mission <br>
You need a flamethrower, a Viper, and get to there weed plantations quick!.<br>
You will receive ;3.500.000.</td></tr><tr>
<td class="mainTxt"> 

Your mission is:<br>
Get a viper and falmethrower and burn the weed plantations down.<br>
 </td></tr>
   <tr><td class="mainTxt">
You have $data->Vlammenwerper flamethrower<br>
Car id:<br>
  <input type="text" name="bel" value=""  size="10"><br>

<input type="submit" name="profile" value="Burn it!"></td></tr></form>
    	</table> 
ENDHTML;
?>