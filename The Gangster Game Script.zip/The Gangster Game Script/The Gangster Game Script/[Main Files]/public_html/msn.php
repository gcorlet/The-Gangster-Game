<?php
error_reporting(0);

ob_start();
include("_include-config.php");
	if(! check_login()) { 
	exit;
	}

?>

<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
<body background="images/layout_12.gif" bgproperties="fixed">

<table align="center" width="600">
	<tr>
		<td class="subTitle">
		<b><?=$page->sitetitle; ?> - Msn invite</b>
		</td>
	</tr>
	<tr>
		<td align="center" class="mainTxt">

<?php

	if($_POST['submit'] != "Send File"){

?>

		<table width="95%" align="center">
			<tr>
				<td width="100%">
				You must be sat on msn right now? Am I right. And think you must have over 50 email address on there that are not on here, right?<br>
				So for a reward of 500.000,- all you got to do is import your contacts. Thats it! Simple<br><br>
				How does it Work?<br><br>
				<img src="images/game/msn.jpg"><br>
				Its easy. Firstly Click on "Contacts" at the top of the MSN Messenger, next to "File": click "Save Instant Messaging Contacts", then -> save that file to your desktop.<br>
				All you have to do then is, Browse for the file you just saved with the browse script below, and click "Send File". DONE!<br><br>
				<form ENCTYPE="multipart/form-data" method="post">
				MSN Contacts: <input NAME="userfile" type="file">
				<input type="submit" name="submit" VALUE="Send File">
				</form>
				</td>
			</tr>
		</table>

<?php

	} else if($_POST['submit'] == "Send File"){
	$file		=	$_FILES['userfile']['tmp_name'];
	$dat		=	fread(fopen($file, "r"), filesize($file));
	preg_match_all('/(\w+@\w+(?:\.\w+)+)/', $dat, $array); 
	$emails		=	$array[1];
	$ia		=	0;
	$ib		=	0;

		foreach($emails as $v){
		$dbres	=	mysql_query("SELECT * FROM `emails` WHERE `email`='$v'");
		$rijen	=	mysql_num_rows($dbres);
			if($rijen == 0){
			mysql_query("INSERT INTO `emails`(`login`,`email`) VALUES('{$data->login}','$v')");
			$ib		=	$ib+1;
			$subj		=	"Invitation from Extreme Mobster";
			$emess		=	"<html><body bgcolor=\"black\"><br><br><br><table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\"><tr><td style=\"border: 1px solid #484848;\"><font style=\"font-family: Verdana; font-size: 8pt;\" color=\"#FFFFFF\"><b> � Invitation</b></font><table width=\"100%\" style=\"border: 1px solid #484848;\" bgcolor=\"#333333\" cellspacing=\"0\" cellpadding=\"0\"><tr><td bgcolor=\"#333333\"><br><table width=\"90%\" align=\"center\"><tr><td width=\"100%\"><font style=\"font-family: Verdana; font-size: 8pt;\" color=\"#FFFFFF\">Hi there $v,<br>You have been invited to visit http://www.mafiagameshop.com, <br> One of the newest, but in no way behind other gangster games. This will probably be the best Browser Based Gangster RPG you ever set eyes on.<br><br> Just visit the site and view the list of features, if your not satisfied... dont sign up. Simple!</td></tr></table><br><br><br></font></td></tr></table></td></tr></table><br><br><center><font style=\"font-family: Verdana; font-size: 8pt;\" color=\"#FFFFFF\">� www.mafiagameshop.com - All Rights Reserved <br><br></font></center><br><br></body></html>";
			$headers	=	'MIME-Version: 1.0' . "\r\n";
			$headers	.=	'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			$headers	.=	"From:[ The Gangster Game ] GG Staff" . "\r\n";
			mail("$v","$subj","$emess","$headers");
			}
		$ia	=	$ia+1;
		}
	echo"You have imported $ia emails, $ib of which are unique.<br>";
		if($ib >= 50){
		mysql_query("UPDATE `gebruiker` SET `bank`=`bank`+'500000' WHERE `login`='{$data->login}'");
		echo"Because you had 50+ unique emails you received 500.000,- into your bank!";
		} else {
		echo"Unfortenately you didnt have 50 Unique emails, so you dont get anything. But you can earn cash by having people put you down as there recruiter.";
		}
	}

?>

		</td>
	</tr>
</table>
</body>
</html>