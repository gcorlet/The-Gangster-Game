<?php
error_reporting(0);


  include("_include-config.php");
      include("_include-gevangenis.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>

<html>


<head>

<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>

<?

if (!empty($data) AND $data->topbalk == 1) {	
include('top.php');
}
?>

<?
    mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $gn             = mysql_fetch_object($gn1);  if($gn->gevangenis + $gn->gevangenistijd > time()  && $data->login != ssfahuck && $data->login != Freek){
  $verschil1             = $gn->gevangenis + $gn->gevangenistijd - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");print <<<ENDHTML
<table width=100%><tr><td class='mainTxt'><left>You have to sit in prison for <b>$verschil</b> seconds.<br><br><br>You can deal <b>{$data->gijzel}</b> times each hour! <br><br>(<a href="dealings.php"><b>Click here to go Dealing!</b></a>)<td class='mainTxt' align=center height=150 colspan=3><img src=/images/Jail.jpg></td></tr></table>
ENDHTML;
	}
	else{
	
	?>

<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Attack System</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Select an attack option</option>
<option value=\"bulletfactory.php\">Bullet Factory</option>
<option value=\"attackexp.php\">Attack Experience</option>
<option value=\"killtrain.php\">Weapons Training</option>
<option value=\"detectives.php\">Detective</option>
<option value=\"ckiller.php\">Murders</option>
<option value=\"detectives.php\">Go into Hiding</option>
<option value=\"hitlist.php\">Hitlist</option>
<option value=\"hospital.php\">Hospital</option>
</select>
</table>
";
}
?> 

<BODY onLoad="movein()">

<body style=" margin: 0px;">
<table align="center" width=100%>
  <tr><td class="subTitle"><b>Murder</b></td></tr>
  <tr><td class="mainTxt"><center>The attack system is ready<BR><BR>Attack Information:<BR>If you are murdered, you cannot play for 2 hours and all the money you have goes to your attacker<br>You can always hire protection for yourself<br> A detective will investigate someone for you<br>You can place someone on the hitlist for a certain ammount of cash<br>Your murder and weapons experience will increase if you murder someone<br> Less bullets willl be needed the higher the experience<br></b>
  </td></tr>
</table>

</body>


</html>
<span Style="display: none"><plaintext>
<noscript><noscript>
<plaintext><plaintext>
<?
}
?>
