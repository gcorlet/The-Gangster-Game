<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }


  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?><head> 
<title></title> 


<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel='stylesheet' type='text/css' href='css/bootstrap.css'>
</head>
<body style="margin: 0px;">
<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Number Casino</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/numberpicture.jpg border=0></center>
</td>

<table align=center width=100%>
  <tr><td class=subTitle><b>Nummbers Game</b></td></tr>
  <tr><td class=mainTxt>
<?php /* ------------------------- */

$land1          = array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland","");
$land          = $land1[$data->land];

$spel = "1";

$casino1	= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='$data->land'");
$casino		= mysql_fetch_assoc($casino1);
$totaaal = number_format($casino['maximum'],0,",",".");
$totaaaal = number_format($casino['maximum']/10,0,",",".");


if($casino['owner'] == $data->login){

if(isset($_POST['VA']))
{
$inzet = $_POST['inzet'];
if(! preg_match('/^[0-9]{0,15}$/',$inzet)){
print "<font color=red>Inccorect Input";
}
elseif($inzet < 1000){
echo "Your bet must be higher than $1000!";
}
elseif($inzet > 10000000){
echo "You cant bet higher than $10.000.000";
}
else{
mysql_query("UPDATE `nummerspel` SET `maximum`='$inzet' WHERE `land`='{$data->land}'");
$inzet2 = number_format($inzet, 0, ",", ".");
echo "The maximum bet has been changed to \$$inzet2";
}
echo "</td></tr>";
}

if(isset($_POST['stort']))
{
$inzet = $_POST['bedrag'];
if(! preg_match('/^[0-9]{0,15}$/',$_POST['bedrag'])){
print "<font color=red>Incorrect Input";
}
elseif($inzet < 1){
echo "Must enter atleast 1 !";
}
elseif($data->cash < $inzet){
print "You dont have enough cash!";
}
else{
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$inzet' WHERE `login`='$data->login'");
mysql_query("UPDATE `nummerspel` SET `bank`=`bank`+'$inzet' WHERE `land`='{$data->land}'");
$inzet2 = number_format($inzet, 0, ",", ".");
echo "You have put \$$inzet2 in the casino bank!";
}
echo "</td></tr>";
}

if(isset($_POST['afhalen']))
{
$inzet = $_POST['bedrag'];
if(! preg_match('/^[0-9]{0,15}$/',$_POST['bedrag'])){
print "<font color=red>Incorrect Input";
}
elseif($inzet < 1){
echo "Must enter atleast 1!";
}
elseif($casino['bank'] < $inzet){
print "Not enough money in the casino bank to take on that bet!";
}
else{
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$inzet' WHERE `login`='$data->login'");
mysql_query("UPDATE `nummerspel` SET `bank`=`bank`-'$inzet' WHERE `land`='{$data->land}'");
$inzet2 = number_format($inzet, 0, ",", ".");
echo "You have taken \$$inzet2 from the casino bank!";
}
echo "</td></tr>";
}

if(isset($_POST['afhalen'])){
echo "<tr><td class=\"mainTxt\">";
}
if(isset($_POST['stort'])){
echo "<tr><td class=\"mainTxt\">";
}
if(isset($_POST['VA'])){
echo "<tr><td class=\"mainTxt\">";
}

$casino1	= mysql_query("SELECT * FROM `nummerspel` WHERE `land`='$data->land'");
$casino		= mysql_fetch_assoc($casino1);

echo "
<form method=post>";

$winstt		= number_format($casino['vw'],0);
$casinobank = number_format($casino['bank'], 0, ",", ".");

$cash = number_format($data->cash, 0, ",", ".");
$bank = $casino['vw'];

if($bank > 0){
$fruitwinst = number_format($casino['vw'], 0, ",", ".");
$fruitwinst = '<font color=green>$'.$fruitwinst.'</font>';
}
if($bank < 0){
$fruitwinst = number_format($casino['vw'], 0, ",", ".");
$fruitwinst = '<font color=red>$'.$fruitwinst.'</font>';
}
if($bank == 0){
$fruitwinst = number_format($casino['vw'], 0, ",", ".");
$fruitwinst = '$'.$fruitwinst.'';
}

$blaat =$casino['maximum'];
echo "
You have made $fruitwinst profit with your business: Numbers Game.<br><br>
Cash in the Casino-Bank: $$casinobank <br>
Cash on You : $$cash<br><br>

<input type=hidden name=casino value=>Maximum Bet <input type=text name=inzet value=$blaat><input type=submit name=\"VA\" value=\"Update!\">
<br><br><font color=red>Borrowing money from the state as the casino bank is nearly empty!</font>
<br><br>Ammount of Money to put in or Take from Casino Bank:<br>$ <input type=text name=bedrag><br><Br>
<input type=submit class='btn btn-info' name=stort value=\"Put into Casino Bank\"><input type=submit class='btn btn-info' name=afhalen value=\"Take from Casino Bank\"></form>

</td></tr></tr>";
exit;
}

if($_GET['spel'] == 'koop') {
if($casino['owner'] == '') {
if($_POST['code']) {
$code	 = $_POST['code'];
$maximum = $_POST['maximum'];
$aftrek  = '25000';
if($data->cash >= $aftrek && $code == TRUE && $maximum > 0 && $maximum < 5000) {
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$aftrek',`nummerspel`+'1' WHERE `login`='$data->login'");
mysql_query("UPDATE `nummerspel` SET `owner`='$data->login',`maximum`='$maximum',`code`='$code' WHERE `land`='$data->land' AND `spel`='1'");
echo "You have bought this casino game in $land<br>";
echo "<script language=\"javascript\">setTimeout('window.location=\"numbersgame.php\"',2000)</script>";
}
 else {
echo "You dont have enough money incase you lose!<br> Or your Maximum bet does not lie between 1 and 5000!";
 }
}
 else {
echo "<form method=POST>
Put on: <input name=code class='btn btn-info' maxlength=2 size=2><br>
Put Maximum bet on: <input name=maximum class='btn btn-info' maxlength=4 size=4><br>
<input type=submit value=Raise></form>";
}
}else{ echo "You cannot buy this";
}}
?>
This number game can be found in: <b><?= $land ?></b><br>
The owner of the game is:
<?
if($casino['owner'] == '') {
print <<<ENDHTML
<b>Nobody</b><br>
ENDHTML;
} 
else {
?>
<b><?= $casino['owner'] ?></b><br>
<?
}
?>
The Maximum best is: $<?= $totaaal ?><br>
The minimum bet is: $<?= $totaaaal ?>

<?


$geld1                        = mysql_query("SELECT * FROM `[users]` WHERE `login` = '{$_SESSION['login']}'");
$geld                         = mysql_result($geld1, 0, "cash");  
$land                         = mysql_result($geld1, 0, "land");         
$naam1                        = mysql_query("SELECT * FROM `nummerspel` WHERE `land`='$land'");
$naam                         = mysql_result($naam1, 0, "owner");
$naam2                        = mysql_query("SELECT * FROM `[users]` WHERE `login`='$naam'");

$maximum                      = mysql_result($naam1, 0, "maximum");    
$nummer                       = rand(1,10);
$nummer1                      = $_POST['nummer'];
$inzet                        = $_POST['inzet'];
$inzet1                       = $inzet*9;
$gokgok = number_format($data->cash,0,",",".");

print <<<ENDHTML

  <tr><td class="mainTxt" align="center">
ENDHTML;


echo" 
	<form method=\"POST\"><table height=\"69\">
	<tr><td width=75>Pick: (1-10) </td><td><input type=\"text\" name=\"nummer\" class=\"btn btn-info\" size=8 maxlength=2 value=\"{$_POST['nummer']}\"></td></tr>
    <tr><td width=75>Bet:</td><td> <input type=\"text\" name=\"inzet\" class=\"btn btn-info\" size=8 maxlength=10 value=\"{$_POST['inzet']}\"></td></tr>
	<tr><td height=\"33\"><input type=\"submit\" class=\"btn btn-info\"name=\"submit\" value=\"Ok\" style=\"width: 75px;\"></td></tr>
	</table></form>
";

if(isset($_POST['submit'])) {

if($inzet <0){
print"You cannot put in negative numbers";
exit;
}

$inzet		= $_POST['inzet'];
	if(!preg_match('/^[0-9]{1,15}$/',$_POST['inzet']) OR $_POST['inzet'] < 0){
		echo "<tr><td class=\"mainTxt\" align=\"center\"><font color=red>Invalid Ammount";
		echo "</font></td></tr>";
		exit;
	}

if($maximum/10 > $inzet){
$inzett = $maximum/10;
$inzet4 = number_format($inzett,0,",",".");
print "<tr><td class=\"mainTxt\" align=\"center\"><font color=red>Your bid is lower than the chosen minimum bet \$$inzet4.</td></tr>";
exit;
}

if($maximum >= $inzet){
if($inzet < $geld){

if(!preg_match('/^[0-9]+$/',$_POST['nummer'])){
print "<tr><td class=\"mainTxt\" align=\"center\"><font color=red>Invalid Input</td></tr>";
exit;
}
if($_POST['nummer'] < 0){
print "<tr><td class=\"mainTxt\" align=\"center\">Choose a number between 1 and 10</td></tr>";
exit;
}
if($_POST['nummer'] > 10){
print "<tr><td class=\"mainTxt\" align=\"center\">Choose a number between 1 and 10</td></tr>";
exit;
}

if($nummer == $nummer1){
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$inzet1' WHERE `login`='{$_SESSION['login']}'"); 
mysql_query("UPDATE `nummerspel` SET `bank`=`bank`-'$inzet1' WHERE `land`= '$data->land'");
mysql_query("UPDATE `nummerspel` SET `vw`=`vw`-'$inzet1' WHERE `land`= '$data->land'");
$inzet2 = number_format($inzet1,0,",",".");
print "<tr><td class=\"mainTxt\" align=\"center\">Congratulations! You gammbled on the correct number ($nummer), You have won \$$inzet2 </td></tr>";

$naam2                        = mysql_query("SELECT * FROM `nummerspel` WHERE `land`='$data->land'");
$ncash                        = mysql_result($naam2, 0, "bank"); 
if($ncash <0){
mysql_query("UPDATE `nummerspel` SET `owner`='$data->login',`maximum`='0',`vw`='0',`bank`='0' WHERE `land`='$data->land'");
print "<tr><td class=\"mainTxt\" align=\"center\"><font color=red>The casino owner refused to pay you!<br>So the casino now belongs to you!</td></tr>";
}
}

else {
 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-$inzet WHERE `login`='{$_SESSION['login']}'"); 
mysql_query("UPDATE `nummerspel` SET `bank`=`bank`+'$inzet' WHERE `land`= '$data->land'");
mysql_query("UPDATE `nummerspel` SET `vw`=`vw`+'$inzet' WHERE `land`= '$data->land'");
$inzet2 = number_format($inzet,0,",",".");
print "<tr><td class=\"mainTxt\" align=\"center\">You gammbled on the wrong number[ $nummer1 ], <br> The winning number was $nummer. You lost \$$inzet2.</td></tr>";  
 
   }
  }
  
  else {
  print "<tr><td class=\"mainTxt\" align=\"center\"><font color=red>You dont have enough money on you!</td></tr>";
  
   }
}
 
   else{
   print "<tr><td class=\"mainTxt\" align=\"center\"><font color=red>Its to much money for you.</td></tr>";
   }
  }


/* ------------------------- */ ?>
                  </table></td>
                </tr>
</table>

</body>


</html>

<?PHP

// de site word sloom dus moeten we wel alles afsluiten..

mysql_close();

// zo dat was het dan weer voor vandaag..
?>