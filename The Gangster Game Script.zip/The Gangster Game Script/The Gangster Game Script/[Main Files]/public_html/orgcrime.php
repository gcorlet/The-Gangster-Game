<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>

</head>

<table align=center width=75%>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
  <tr><td class=subTitle><b>Organised Crime</b></td></tr>
  <tr><td class=mainTxt>
<?
   
function stuurbericht ($sVan,$sNaar,$sTitel,$sBericht) {
	mysql_query("INSERT INTO `[messages]`
	(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values
	(NOW(),'0','0','".$sVan."','".$sNaar."','".$sTitel."','".$sBericht."')");
}

if (isset($_GET['do']) AND $_GET['do'] == 'accept' AND isset($_GET['id'])) {
	$iOC = intval($_GET['id']);
	$rOCrime = mysql_query('SELECT wapenexpert,leader,chauffeur,auto,wapen FROM oc WHERE id = '.intval($_GET['id']));
	$iOCrime = mysql_num_rows($rOCrime);	
	if ($iOCrime == 0) {
		echo 'The organised crime does not exist. It also could be that 1 of the teammembers has refused.';
	}
	else {
		$aOCrime = mysql_fetch_object($rOCrime);
		if (strtolower($aOCrime->wapenexpert) == strtolower($data->login)) {
			if (isset($_POST['wapen'])) {
				$iWapen = intval($_POST['wapen']);
				if ($iWapen > $data->cash) {
					echo '<b>You dont have enough cash!</b><p>';
				}
				else {
					mysql_query('UPDATE oc SET wapen = '.$iWapen.' WHERE id = '.intval($_GET['id']));
					mysql_query('UPDATE `[users]` SET cash = cash-'.$iWapen.' WHERE login = "'.$data->login.'"');
					echo '<b>The oC has been accepted, the leader ('.$aOCrime->leader.') can now start the OC</b><p>';
				}
			}
			
			echo 'Select the weaapons you wish to buy:';
			echo '<form method="post" action="'.$_SERVER['REQUEST_URI'].'"><select name="wapen">
				<option value="5000">3 Hand Guns ;5.000,-</option>
				<option value="10000">6 Hand Guns ;10.000,-</option>
				<option value="20000">3 Shot Guns ;20.000,-</option>
				<option value="25000">3 Machine Guns ;25.000,-</option>
				<option value="55000">3 Bazookas ;55.000,-</option>
			</select> <input type="submit" value="Buy">';
		}
		elseif (strtolower($aOCrime->chauffeur) == strtolower($data->login)) {
			if (isset($_POST['auto'])) {
				$iAuto = intval($_POST['auto']);
				if ($iAuto > $data->cash) {
					echo '<b>You dont have enough cash!</b><p>';
				}
				else {
					mysql_query('UPDATE oc SET auto = '.$iAuto.' WHERE id = '.intval($_GET['id']));
					mysql_query('UPDATE `[users]` SET cash = cash-'.$iAuto.' WHERE login = "'.$data->login.'"');
					echo '<b>The OC has been accepted, the leader ('.$aOCrime->leader.') can now start the OC.</b><p>';
				}
			}
			
			echo 'Select the vehicle you will use in the OC:';
			echo '<form method="post" action="'.$_SERVER['REQUEST_URI'].'"><select name="auto">
				<option value="6000">Mini Cooper ;6.000,-</option>
				<option value="12000">Opel Astra ;12.000,-</option>
				<option value="18000">Ford Mondeo ST220 ;18.000,-</option>
				<option value="24000">Mercedes 300CE ;24.000,-</option>
				<option value="30000">BMW 325Ci ;30.000,-</option>
				<option value="36000">Dodge Ram SRT-10 ;36.000,-</option>
				<option value="42000">Porsche Cayenne ;42.000,-</option>
				<option value="48000">Bentley Continental GT ;48.000,-</option>
				<option value="54000">Hummer H2 ;54.000,-</option>
				<option value="60000">Rolls-Royce Silver Seraph ;60.000,-</option>
			</select> <input type="submit" value="Buy"></form>';
		}
		else {
			echo 'Invalid Input!';
		}
	}
}
elseif (isset($_GET['do']) AND $_GET['do'] == 'deny' AND isset($_GET['id'])) {
	$iOC = intval($_GET['id']);
	$rOCrime = mysql_query('SELECT wapenexpert,leader,chauffeur,auto,wapen FROM oc WHERE id = '.intval($_GET['id']));
	$iOCrime = mysql_num_rows($rOCrime);
	
	if ($iOCrime == 0) {
		echo 'The OC does not exist. It could also be that 1 of the teammembers has refused.';
	}
	else {
		$aOCrime = mysql_fetch_object($rOCrime);
		if ($aOCrime->wapenexpert == $data->login) {
			echo '<b>The invitation has been refused.</b>';
			mysql_query('DELETE FROM oc WHERE id = '.intval($_GET['id']));
		}
		elseif ($aOCrime->chauffeur == $data->login) {
			echo '<b>The invitation has been refused.</b>';
			mysql_query('DELETE FROM oc WHERE id = '.intval($_GET['id']));
		}
		else {
			echo 'Invalid Input!';
		}
	}
}
elseif (isset($_GET['do']) AND $_GET['do'] == 'startcrime' AND isset($_GET['id'])) {
	$rCrime = mysql_query('SELECT id,auto,geld,wapen,chauffeur,wapenexpert FROM oc WHERE id = '.intval($_GET['id']).' AND leader = "'.$data->login.'"');
	$aCrime = mysql_fetch_object($rCrime);
	$iCrime = mysql_num_rows($rCrime);
	
	if ($iCrime == 0) {
		echo 'The OC does not exist!<p><a href="orgcrime.php">Go back</a>';
	}
	else {
		if ($aCrime->auto == 0) {
			echo 'The driver has not yet accepted the invitation!<p><a href="orgcrime.php">Go Back</a>';
		}
		elseif ($aCrime->wapen == 0) {
			echo 'The weapons expert has not yet accepted the invitation!<p><a href="orgcrime.php">Go back</a>';
		}
		else {
			$aCrime->auto = $aAutos[$aCrime->auto][1];
			
			function eengetal() {
				return (rand(8,20)/10);
			}
			
			$iGeld = $aCrime->geld*eengetal()+$aCrime->auto*eengetal()+$aCrime->wapen*eengetal()+rand(1,$data->attack);
			
			$aCrimes = Array('Bank Raid','House','Gangster Boss','CashComputer');
			$iRandom = rand(0,(count($aCrimes)-1));
			echo 'Your Target:  '.$aCrimes[$iRandom].'<br>';
			if (rand(1,8) > 4) {
				echo 'Success!<br>';
				echo 'Together you have earned ;'.number_format($iGeld,0,',','.').',-. .$data->login gets a split of ;'.number_format($iGeld/2,0,',','.').',-.';
				
				mysql_query('UPDATE `[users]` SET oc_won = oc_won+1, cash=cash+'.($iGeld/2).' WHERE login = "'.$data->login.'"');
				mysql_query('UPDATE `[users]` SET oc_won = oc_won+1, cash=cash+'.($iGeld/4).' WHERE login = "'.$aCrime->chauffeur.'"');
				mysql_query('UPDATE `[users]` SET oc_won = oc_won+1, cash=cash+'.($iGeld/4).' WHERE login = "'.$aCrime->wapenexpert.'"');
				
				stuurbericht('AutoMessage',$aCrime->chauffeur,'OC '.$data->login.' Well Done','The OC leader is '.$data->login.' and was successful. You have earned '.number_format($iGeld/4,0,',','.').',-.');
				stuurbericht('AutoMessage',$aCrime->wapenexpert,'OC '.$data->login.' Well Done','The OC leader is '.$data->login.' and was successful. You earned '.number_format($iGeld/4,0,',','.').',-.');
				
				
			}
			else {
				echo 'It has all gone wrong! You have to flee and leave everything behind, you also lose 5% health!';
				mysql_query('UPDATE `[users]` SET oc_lost = oc_lost+1 WHERE login = "'.$aCrime->wapenexpert.'" OR login = "'.$aCrime->chauffeur.'" OR login = "'.$data->login.'"');
				mysql_query('UPDATE `[users]` SET energie = energie-22 WHERE login = "'.$aCrime->wapenexpert.'" OR login = "'.$aCrime->chauffeur.'" OR login = "'.$data->login.'"');
				
				stuurbericht('AutoMessage',$aCrime->chauffeur,'OC '.$data->login.' Bad Luck','The OC leader is '.$data->login.' and the OC was a nightmare. Get rid of the car. You have also lost 22% energy');
				stuurbericht('AutoMessage',$aCrime->wapenexpert,'OC '.$data->login.' Bad Luck','The OC leader is '.$data->login.' and the OC was a nightmare. Get rid of the weapons. You have also lost 22% energy');
			}
			mysql_query('DELETE FROM oc WHERE id = '.intval($_GET['id']));
		}
	}
}
elseif (isset($_GET['do']) AND $_GET['do'] == 'newcrime') {
	if ($data->level > 255) {
		echo 'Your have reached the maximum number of Organised Crimes. You can wait until more are allocated or can purchase some from the Credits Store!';
	}
	else {
		if (isset($_POST['chauffeur']) AND isset($_POST['geld']) AND isset($_POST['wapenexpert'])) {
			$iGeld = intval($_POST['geld']);
			
			$sWapenexpert = $_POST['wapenexpert'];
			$rWapenexpert = mysql_query('SELECT Mobieltje FROM `[users]` WHERE login = "'.$sWapenexpert.'"');
			
			$sChauffeur = $_POST['chauffeur'];
			$rChauffeur = mysql_query('SELECT Mobieltje FROM `[users]` WHERE login = "'.$sChauffeur.'"');
			
			if ($iGeld > $data->cash) {
				echo '<b>You dont have enough cash!</b><p>';
			}
			elseif ($iGeld < 5000) {
				echo '<b>Minimum amount is ;5.000,-</b><p>';
			}
			elseif ($iGeld > 50000) {
				echo '<b>Maximum amount is ;50.000,-</b><p>';
			}
			elseif (mysql_num_rows($rWapenexpert) == 0) {
				echo '<b>The weapons expert does not exist!</b><p>';
			}
			elseif (mysql_num_rows($rChauffeur) == 0) {
				echo '<b>The driver does not exist!</b><p>';
			}
			elseif ($sChauffeur == $data->login OR $sWapenexpert == $data->login) {
				echo '<b>You cannot fill 2 roles in the OC.</b><p>';
			}
			elseif (mysql_result($rWapenexpert,0) == 1) {
				echo '<b>The weapons expert has no phone!</b><p>';
			}
			elseif (mysql_result($rChauffeur,0) == 1) {
				echo '<b>The driver has no phone!</b><p>';
			}
			else {
				mysql_query('INSERT INTO oc (leader,wapenexpert,chauffeur,geld) VALUES ("'.$data->login.'","'.$sWapenexpert.'","'.$sChauffeur.'",'.$iGeld.')');
				$iOC = mysql_insert_id();
				
				mysql_query('UPDATE `[users]` SET ocs = ocs+1 WHERE login = "'.$data->login.'"');
				mysql_query('UPDATE `[users]` SET cash = cash-'.$iGeld.' WHERE login = "'.$data->login.'"');
				$sBerichtWapen = 'A organised crime is taking place and you have been asked to take part. To accept the invitation, go to organised crimes. Id: '.$iOC.' | Your Job: WeaponsExpert | The Starter: '.$data->login;
				$sBerichtAuto = 'A organised crime is taking place and you have been asked to take part. To accept the invitation, go to organised crimes. Id: '.$iOC.' | Your Job: Driver | The Starter: '.$data->login;
				mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','{$data->login}','{$sWapenexpert}','OC ".$data->login."','{$sBerichtWapen}')");
				mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`forwardedFor`,`from`,`to`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','$forwardedFor','{$data->login}','{$sChauffeur}','OC ".$data->login."','{$sBerichtAuto}')");
				
				echo 'The OC invitations have been sent to the driver and weapons expert. If they both accept then you can start the OC.';
				echo '</td></tr>
				</table>';
				exit;
			}
		}
		
		echo '<form method="post"><table>';
		echo '<tr><td class=mainTxt width=100% colspan=2><b>To Begin:</b> Fill in the name of the Weapons Expert and Driver. Careful when entering the names, its CaSe SeNsItIvE!</td></tr>';
		echo '<tr><td width=150>Driver</td><td><input type="text" value="" name="chauffeur"></td></tr>';
		echo '<tr><td>Weapons Expert</td><td><input type="text" value="" name="wapenexpert"></td></tr>';
		echo '<tr><td>Cash</td><td><input type="text" value="50000" name="geld" size=7> <small>(Min. ;5.000,-, Max. ;50.000,-)</small></td></tr>';
		echo '<tr><td colspan=2><input type="submit" value="Place Crime" name="submit"></td></tr>';
		echo '</table></form><B>Information:</B> The weapons expert and driver must both accept the crime and share of the cash. The leader receives 50% of the cash, the driver and weapons expert receive 25%.';
	}
}
elseif (isset($_GET['do']) AND $_GET['do'] == 'mycrimes') {
	if (isset($_GET['del'])) {
		mysql_query('DELETE FROM oc WHERE leader = "'.$data->login.'" AND id = '.intval($_GET['del']));
	}
	
	$rCrimes = mysql_query('SELECT id,auto,geld,wapen,chauffeur,wapenexpert,leader FROM oc WHERE leader = "'.$data->login.'"');
	$iCrimes = mysql_num_rows($rCrimes);
	if ($iCrimes > 0) {
		echo 'Search crimes you are leader of and has not yet started:<p>';
		
		echo '<table>';
		echo '<tr style="font-weight: bold;"><td width=100><u>Leader</u></td><td width=150><u>Driver</u></td><td width=150><u>Weapons expert</u></td><td width=100><u>Cash</u></td><td><u>Start</u></td></tr>';
		while ($aCrime = mysql_fetch_object($rCrimes)) {
			if ($aCrime->auto > 0) {
				$sAuto = $aCrime->chauffeur.' <small>(<font color=green>Ready</font>)</small>';
			}
			else {
				$sAuto = $aCrime->chauffeur.' <small>(<font color=red>Not Ready</font>)</small>';
			}
			if ($aCrime->wapen > 0) {
				$sWapen = $aCrime->wapenexpert.' <small>(<font color=green>Ready</font>)</small>';
			}
			else {
				$sWapen = $aCrime->wapenexpert.' <small>(<font color=red>Not Ready</font>)</small>';
			}
			$sGeld = ';'.number_format($aCrime->geld,0,',','.').',-';
			$sLeader = $aCrime->leader;
			
			echo '<tr><td><b>'.$sLeader.'</b></td><td>'.$sAuto.'</td><td>'.$sWapen.'</td><td>'.$sGeld.'</td><td><a href="?do=startcrime&id='.$aCrime->id.'">Start</a>/<a href="?do=mycrimes&del='.$aCrime->id.'">Stop</a></td></tr>';
		}
		echo '</table>';
		
		echo '<p>All crimes which only contain 1 will atutomatically be scrapted.<p><a href="orgcrime.php">Go Back</a>';
	}
	else {
		echo '<b>There are no crimes started yet in which you are leader.</b>';
	}
}
elseif (isset($_GET['do']) AND $_GET['do'] == 'notmycrimes') {
	$rCrimes = mysql_query('SELECT id,auto,geld,wapen,chauffeur,wapenexpert,leader FROM oc WHERE wapenexpert = "'.$data->login.'" OR  chauffeur = "'.$data->login.'"');
	$iCrimes = mysql_num_rows($rCrimes);
	if ($iCrimes > 0) {
		echo 'Search for cimes in which you are an associate has not yet started:<p>';
		
		echo '<table>';
		echo '<tr style="font-weight: bold;"><td width=100><u>Leader</u></td><td width=150><u>Driver</u></td><td width=150><u>Weapons Expert</u></td><td width=100><u>Cash</u></td><td>&nbsp;</td></tr>';
		while ($aCrime = mysql_fetch_object($rCrimes)) {
			if ($aCrime->auto > 0) {
				$sAuto = $aCrime->chauffeur.' <small>(<font color=green>Ready</font>)</small>';
			}
			else {
				$sAuto = $aCrime->chauffeur.' <small>(<font color=red>Not Ready</font>)</small>';
			}
			if ($aCrime->wapen > 0) {
				$sWapen = $aCrime->wapenexpert.' <small>(<font color=green>Ready</font>)</small>';
			}
			else {
				$sWapen = $aCrime->wapenexpert.' <small>(<font color=red>Not Ready</font>)</small>';
			}
			$sGeld = ';'.number_format($aCrime->geld,0,',','.').',-';
			$sLeader = $aCrime->leader;
			
			if (($aCrime->wapenexpert == $data->login AND $aCrime->wapen == 0) OR ($aCrime->chauffeur == $data->login AND $aCrime->auto == 0)) {
				$sAction = '<a href="?do=accept&id='.$aCrime->id.'">Accept</a>/<a href="?do=deny&id='.$aCrime->id.'">Decline</a>';
			}
			else {	
				$sAction = '';
			}
			
			echo '<tr><td><b>'.$sLeader.'</b></td><td>'.$sAuto.'</td><td>'.$sWapen.'</td><td>'.$sGeld.'</td><td>'.$sAction.'</td></tr>';
		}
		echo '</table>';
		
		echo '<p>All crimes with just 1 will be automatically scrapted.<p><a href="orgcrime.php">Go Back</a>';
	}
	else {
		echo '<b>No crimes have started yet in which you are an invited.</b>';
	}
}
else {
	echo '- <a href="?do=mycrimes">Search self started Organised Crimes</a><br>';
	echo '- <a href="?do=notmycrimes">Search for Organised Crimes your invited to.</a><br>';
	echo '- <a href="?do=newcrime">Start new Organised Crime</a><br>';
}


echo '</td></tr>
</table>';
?>

</body>
</html>
