<?php
error_reporting(0);

  include("_include-jail.php");
      include("_include-gevangenis.php");

/* ------------------------- */ ?>

<link rel='stylesheet' type='text/css' href='<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css'>
<TD vAlign=top align=middle width="75%">
<table width='75%' cellpadding='2' cellspacing='1' align='center' ><TR>
<TD class=subtitle align=center colSpan=5><b>Voeg een garage toe</b></TD></TR><BR>
<?
$iSele = mysql_query("SELECT `owner` FROM `[garage]` WHERE `owner`='{$iLogin['login']}'");
$iCount = mysql_num_rows($iSele);
 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='{$data->login}'");
$iLogin = mysql_fetch_assoc($sql);
 $poep  = mysql_query("SELECT `id`,`auto`,`tuning`,`banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='{$_GET['garage']}' AND `owner`='{$iLogin['login']}'");
$check = mysql_fetch_assoc($poep);
$id1             = mysql_query("SELECT * FROM `[garage]` WHERE `id`='$id' AND `owner`='{$data->login}'");
$id1             = mysql_num_rows($id1);
$iSelect = mysql_query("SELECT `id`,`owner`,`soort`,`schade`,`snelheid` FROM `[garage]` WHERE `owner`='{$iLogin['login']}' LIMIT 0,100");



?>
</table><link rel='stylesheet' type='text/css' href='style.css'>
<TD vAlign=top align=middle width="100%">
<table width='75%' cellpadding='2' cellspacing='1' align='center' ><TR>
<TD class=subtitle align=center colSpan=4><b>Pimp Garage</b></TD></TR><BR>
        <td class=subTitle>
          <div align=\"center\"><b>id</b></div></td>
        <td class=subTitle>
          <div align=\"center\"><b>Car</b></div></td>
        <td class=subTitle>
        <div align=\"center\"><b>Upgrade level</b></div></td>
          <td class=subTitle>
          <div align=\"center\"><b>Pimp</b></div></td>
<?
$select = mysql_query("SELECT `id`,`auto`,`tuning`,`banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `owner`='{$iLogin['login']}'");
while($list = mysql_fetch_assoc($select)){
$lvl = $list['banden']+$list['motor']+$list['interieur']+$list['uitlaat']+$list['remmen']+$list['body']+$list['velgen']+$list['nitro']; 
echo "<tr><td class=maintxt><center>{$list['id']}</td><td class=maintxt><center>{$list['auto']}</td><td class=maintxt><center>{$lvl}</td><td class=maintxt><a href=pimpcar.php?garage={$list['id']}><center>Click HERE to see Pimped improvements.</a>";

?>
</table><link rel='stylesheet' type='text/css' href='<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css'>
<TD vAlign=top align=middle width="75%">
<table width='75%' cellpadding='2' cellspacing='1' align='center' ><TR>

<?
print <<<ENDHTML
<TD vAlign=top align=middle width="75%" colSpan=6>
<table width='75%' cellpadding='2' cellspacing='1' align='center' colSpan=6><TR>
<TD class=subtitle align=center colSpan=6><b>Auto</b></TD></TR><BR>
 <tr><td class=mainTxt colSpan=6>
<img src=images/garages/Dodge.gif align=right>
<b>System</b> <img name="garage" src="balkgroen.gif" width="{$check['banden']}" height="12" maxlength="75%" alt="Level {$check['banden']} ",- {$check['banden']}%<br><br><br>
<b>Engine</b> <img name="garage" src="balkgroen.gif" width="{$check['motor']}" height="12" alt="Level {$check['motor']} ",- {$check['motor']}%<br><br><br>
<b>Interior</b> <img name="garage" src="balkgroen.gif" width="{$check['interieur']}" height="12" alt="Level {$check['interieur']} ",- {$check['interieur']}%<br><br><br>
<b>Exhaust</b> <img name="garage" src="balkgroen.gif" width="{$check['uitlaat']}" height="12" alt="Level {$check['uitlaat']} ",- {$check['uitlaat']}%<br><br><br>
<b>Brakes</b> <img name="garage" src="balkgroen.gif" width="{$check['remmen']}" height="12" alt="Level {$check['remmen']} ",- {$check['remmen']}%<br><br><br>
<b>Body</b> <img name="garage" src="balkgroen.gif" width="{$check['body']}" height="12" alt="Level {$check['body']} ",- {$check['body']}%<br><br><br>
<b>Rims</b> <img name="garage" src="balkgroen.gif" width="{$check['velgen']}" height="12" alt="Level {$check['velgen']} ",- {$check['velgen']}%<br><br><br>
<b>Nitro</b> <img name="garage" src="balkgroen.gif" width="{$check['nitro']}" height="12" alt="Level {$check['nitro']} ",- {$check['nitro']}%</td></tr>
</FORM>
  </table></td></tr>
<TD class=subtitle align=center colSpan=4><b>Pimp that Bitch</b></TD></TR><BR>
  <tr><td class="mainTxt"><center>System <td class="mainTxt"><center>
<FORM METHOD=post ACTION="">
<input name="bieden" value="">
<INPUT name="junk" type="submit" VALUE="Pimp that Bitch">
<td class="mainTxt">level: <b>{$check['banden']}</b>
<td class="mainTxt">Cost: <b>50.000</b><center></td></tr>
</form>
  <tr><td class="mainTxt"><center>Engine <td class="mainTxt"><center>
<FORM METHOD=post>
<input name="bieden" value="">
<INPUT name="motor" type="submit" VALUE="Pimp that Bitch">
<td class="mainTxt">level: <b>{$check['motor']}</b>
<td class="mainTxt">Cost: <b>50.000</b><center></td></tr>
</form>
  <tr><td class="mainTxt"><center>Interior <td class="mainTxt"><center>
<FORM METHOD=post ACTION="">
<input name="bieden" value="">
<INPUT name="interieur" type="submit" VALUE="Pimp that Bitch">
<td class="mainTxt">level: <b>{$check['interieur']}</b>
<td class="mainTxt">Cost: <b>50.000</b><center></td></tr>
</form>
  <tr><td class="mainTxt"><center>Exhaust <td class="mainTxt"><center>
<FORM METHOD=post ACTION="">
<input name="bieden" value="">
<INPUT name="uitlaat" type="submit" VALUE="Pimp that Bitch">
<td class="mainTxt">level: <b>{$check['uitlaat']}</b>
<td class="mainTxt">Cost: <b>50.000</b><center></td></tr>
</form>

  <tr><td class="mainTxt"><center>Brakes <td class="mainTxt"><center>
<FORM METHOD=post ACTION="">
<input name="bieden" value="">
<INPUT name="remmen" type="submit" VALUE="Pimp that Bitch">
<td class="mainTxt">level: <b>{$check['remmen']}</b>
<td class="mainTxt">Cost: <b>50.000</b><center></td></tr>
</form>
  <tr><td class="mainTxt"><center>Body <td class="mainTxt"><center>
<FORM METHOD=post ACTION="">
<input name="bieden" value="">
<INPUT name="body" type="submit" VALUE="Pimp that Bitch">
<td class="mainTxt">level: <b>{$check['body']}</b>
<td class="mainTxt">Cost: <b>50.000</b><center></td></tr>
</form>
  <tr><td class="mainTxt"><center>Rims <td class="mainTxt"><center>
<FORM METHOD=post ACTION="">
<input name="bieden" value="">
<INPUT name="velgen" type="submit" VALUE="Pimp that Bitch">
<td class="mainTxt">level: <b>{$check['velgen']}</b>
<td class="mainTxt">Cost: <b>50.000</b><center></td></tr>
</form>

  <tr><td class="mainTxt"><center>Nitro <td class="mainTxt"><center>
  <FORM METHOD=post ACTION="">
<input name="bieden" value="">
<INPUT name="nitro" type="submit" VALUE="Pimp that Bitch">
<td class="mainTxt">level: <b>{$check['nitro']}</b>
<td class="mainTxt">Cost: <b>50.000</b><center></td></tr>
</form></table></td></tr>
ENDHTML;
}

?>
</table><link rel='stylesheet' type='text/css' href='<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css'>
<TD vAlign=top align=middle width="75%">
<table width='75%' cellpadding='2' cellspacing='1' align='center' ><TR>
<?
if ($_POST['motor']){
$kost = 50000;
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b><font color=#FFFFFF>You dont have enough cash, boy!</b></font></td></tr>\n";
}
elseif($bieden < 1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><font color=#FFFFFF><b>You cant purchase less than 1 level</b></font></td></tr>\n";
}
else{
$landz = $bieden*1;
mysql_query("UPDATE `[garage]` SET `motor`=`motor`+'$landz' WHERE `id`='{$_GET['garage']}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1' WHERE `login`='{$iLogin['login']}'");
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b>You have bought $bieden engine levels for {$kost1},-</b></td></tr>\n";
}
ENDHTML;
}
?>
<?
if ($_POST['interieur']){
$kost = 50000;
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b><font color=#FFFFFF>You dont have enough money</b></font></td></tr>\n";
}
elseif($bieden < 1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><font color=#FFFFFF><b>You cant buy less than 1 level</b></font></td></tr>\n";
}
else {
$landz = $bieden*1;
mysql_query("UPDATE `[garage]` SET `interieur`=`interieur`+'$landz' WHERE `id`='{$_GET['garage']}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1' WHERE `login`='{$iLogin['login']}'");
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b>You hae bought $bieden levels for {$kost1},-</b></td></tr>\n";
}
ENDHTML;
}

?>
<?
if ($_POST['uitlaat']){
$kost = 50000;
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b><font color=#FFFFFF>You dont have enough cash!</b></font></td></tr>\n";
}
elseif($bieden < 1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><font color=#FFFFFF><b>You have to purchase atleast 1 level</b></font></td></tr>\n";
}
else{
$landz = $bieden*1;
mysql_query("UPDATE `[garage]` SET `uitlaat`=`uitlaat`+'$landz' WHERE `id`='{$_GET['garage']}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1' WHERE `login`='{$iLogin['login']}'");
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b>You have bought $bieden exhaust levels for {$kost1},-</b></td></tr>\n";
}
ENDHTML;
}
?>
<?
if ($_POST['remmen']){
$kost = 50000;
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b><font color=#FFFFFF>You dont have enough cash!</b></font></td></tr>\n";
}
elseif($bieden < 1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><font color=#FFFFFF><b>You have to purchase atleast 1 level</b></font></td></tr>\n";
}
else{
$landz = $bieden*1;
mysql_query("UPDATE `[garage]` SET `remmen`=`remmen`+'$landz' WHERE `id`='{$_GET['garage']}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1' WHERE `login`='{$iLogin['login']}'");
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b>You have bought $bieden breaks levels for {$kost1},-</b></td></tr>\n";
}
ENDHTML;
}
?>
<?
if ($_POST['body']){
$kost = 50000;
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b><font color=#FFFFFF>You dont have enough cash!</b></font></td></tr>\n";
}
elseif($bieden < 1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><font color=#FFFFFF><b>You have to purchase atleast 1 level</b></font></td></tr>\n";
}
else{
$landz = $bieden*1;
mysql_query("UPDATE `[garage]` SET `body`=`body`+'$landz' WHERE `id`='{$_GET['garage']}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1' WHERE `login`='{$iLogin['login']}'");
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b>You have bought $bieden body levels for {$kost1},-</b></td></tr>\n";
}
ENDHTML;
}
?>
<?
if ($_POST['velgen']){
$kost = 50000;
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b><font color=#FFFFFF>You dont have enough cash!</b></font></td></tr\n";
}
elseif($bieden < 1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><font color=#FFFFFF><b>You have to purchase atleast 1 level</b></font></td></tr>\n";
}
else{
$landz = $bieden*1;
mysql_query("UPDATE `[garage]` SET `velgen`=`velgen`+'$landz' WHERE `id`='{$_GET['garage']}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1' WHERE `login`='{$iLogin['login']}'");
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b>You have bought $bieden rim levels for {$kost1},-</b></td></tr>\n";
}
ENDHTML;
}
?>
<?
if ($_POST['nitro']){
$kost = 50000;
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b><font color=#FFFFFF>You dont have enough cash!</b></font></td></tr>\n";
}
elseif($bieden < 1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><font color=#FFFFFF><b>You have to purchase atleast 1 level</b></font></td></tr>\n";
}
else{
$landz = $bieden*1;
mysql_query("UPDATE `[garage]` SET `nitro`=`nitro`+'$landz' WHERE `id`='{$_GET['garage']}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1' WHERE `login`='{$iLogin['login']}'");
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b>You have bought $bieden nitro levels for {$kost1},-</b></td></tr>\n";
}
ENDHTML;
}
?>
<?
if ($_POST['junk']){
$kost = 50000;
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b><font color=#FFFFFF>You dont have enough cash!</b></font></td></tr>\n";
}
elseif($bieden < 1){
print "  <tr><td class=\"mainTxt\" colSpan=5><center><font color=#FFFFFF><b>You have to purchase atleast 1 level</b></font></td></tr>\n";
}
else{
$landz = $bieden*1;
mysql_query("UPDATE `[garage]` SET `banden`=`banden`+'$landz' WHERE `id`='{$_GET['garage']}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1' WHERE `login`='{$iLogin['login']}'");
print "  <tr><td class=\"mainTxt\" colSpan=5><center><b>You have bought $bieden link levels for {$kost1},-</b></td></tr>\n";
}
ENDHTML;
}
?>