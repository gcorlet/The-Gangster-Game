<?php
error_reporting(0);

 
  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");




  
/* ------------------------- */ ?>


<html>
<head>
<title><?=$title; ?></title>
</head>
<body>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<table width="100%">
<tr><td class="SubTitle"><b><font face="Verdana" size="1">Star</font></b></td></tr>
<tr><td class="MainTxt">
	<p align="center">Here you can choose icons and text to follow your name.<br>
	Some are for VIP members only.</td></tr>
</table>
<table width="100%" align="center">
<tr>
<td align=center width=100%>
	<form method="post">
	<table width="271">
	<tr>
	<td class="subTitle" align="center"><b>Icon / Choose Text</b></td>
	</tr>
		
	</table>
	<table width="271">
	<tr>
	<td class="maintxt" align="center">
	<p align="left">
	<Input type="radio" value="V10" name="naam2" onClick="window.location=('pimpname.php?ster=geen')">  
		<b>I dont want any Icon or Text&nbsp;hebben&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </b></td>
	</tr>
		
	</table>
	<table width="270">
	<tr><td class="mainTxt" width="89">
	<Input type="radio" value="V1"  class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=1')">  
		<b>Icon 1</b></td><td width=171 class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/ster2.gif" width="14" height="15"></td></tr>
	<tr><td class="mainTxt" width="89">
	<Input type="radio" value="V2" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=2')">  
		<b>Icon 2</b></td><td class="mainTxt">
		<p align="center">
		<font color="green"><i class="fa fa-cannabis fa-2x"></i></font></td></tr>
	<tr><td class="mainTxt" width="89">
	<Input type="radio" value="V3" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=3')"><b>  
		Icon 3</b></td><td class="mainTxt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<p align="center">
<font color="gold"><i class="fa fa-trophy fa-2x"></i></font></td></tr>
	<tr><td class="mainTxt" width="89">
	<Input type="radio" value="V4" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=4')">  
		<b>Icon 4</b></td><td class="mainTxt">
		<p align="center">
		<i class="fa fa-skull-crossbones fa-2x"></i></td></tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" class='btn btn-info' value="V11" name="naam2" onClick="window.location=('pimpname.php?ster=5')"><b> 
		Icon 5</b></td><td class="mainTxt">
		<p align="center">
		<i class="fa fa-yin-yang fa-2x"></i></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V13" class='btn btn-info' vname="naam2" onClick="window.location=('pimpname.php?ster=6')" ><b> 
		Icon 6</b></td><td class="mainTxt">
		<p align="center">
		<font color="silver"><i class="fa fa-ankh fa-2x"></i></font></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V14" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=7')"><b> 
		Icon 7</b></td><td class="mainTxt">
		<p align="center">
		<font color="gold"><i class="fa fa-crown fa-2x"></i></font></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V12" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=8')"><b> 
		Icon 8</b></td><td class="mainTxt">
		<p align="center">
		<i class="fa fa-comment fa-2x"></i></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V15" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=9')"><b> 
		Icon 9</b></td><td class="mainTxt">
		<p align="center">
		<font color="lightblue"><i class="fa fa-infinity fa-2x"></i></font></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V16" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=10')"><b> 
		Icon 10</b></td><td class="mainTxt">
		<p align="center">
		<font color="yellow"><i class="fa fa-om fa-2x"></i></font></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V17" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=11')"><b> 
		Icon 11</b></td><td class="mainTxt">
		<p align="center">
		<i class="fa fa-skull"></i></td>
	</tr>
		<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V17" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=13')"><b> 
		Icon 12</b></td><td class="mainTxt">
		<p align="center">
		<img border="0" src="images/smilies/star22.jpg" width="16" height="16"></td>
	</tr>
	<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V18" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=14')"><b> 
		Text 1</b></td><td class="mainTxt">
		<p align="center">
		<font color="green"><i class="fa fa-dollar-sign fa-2x"></i></font></td>
	</tr>
			<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V21" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=15')"><b> 
		Text 2</b></td><td class="mainTxt">
		<p align="center">
		<i class="fa fa-cross fa-2x"></i></td>
	</tr>
					<tr>
		<td class="mainTxt" width="89">
		<Input type="radio" value="V22" class='btn btn-info' name="naam2" onClick="window.location=('pimpname.php?ster=16')"><b> 
		Text 3</b></td><td class="mainTxt">
		<p align="center">
		<font color="red"><i class="fa fa-dragon fa-2x"></i></font></td>
	</tr>
	</td>
	</tr>
	<tr>
		
		</td>
	</tr>
	
	</table>
	</form>
</td>
</tr>

<?
  if (isset($_GET['ster'])) {
	  $sAction = strtolower($_GET['ster']);
	  if ($sAction == 'action') {
		  if ($data->belcredits >= 0) {
		  }
		  else {
			  echo '<center><table><b><font color=red><tr><td class-MainTxt>You dont have enough VIP Credits! Purchase more from the Credit Service</td></tr></font></b></table></center>';
		  }
	  }
	  if ($sAction == 'geen') {
			  mysql_query("UPDATE `[users]` SET `level`='1' WHERE `login`='$data->login'");
			   echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>None</b></center></td></tr></font></b></table></center>';
	  }
	  }
	  if ($sAction == '1') {
			  mysql_query("UPDATE `[users]` SET `level`='80' WHERE `login`='$data->login'");
			  echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>1</b></center></td></tr></font></b></table></center>';
		  } 
	  if ($sAction == '2') {
		      mysql_query("UPDATE `[users]` SET `level`='10' WHERE `login`='$data->login'");
			echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>2</b></center></td></tr></font></b></table></center>';
			  }
			  
	  if ($sAction == '3') {
			  mysql_query("UPDATE `[users]` SET `level`='40' WHERE `login`='$data->login'");
			   	echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>3</b></center></td></tr></font></b></table></center>';
	  	  }
	  	  
	  if ($sAction == '4') {
			mysql_query("UPDATE `[users]` SET `level`='20' WHERE `login`='$data->login'");
			  	echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>4</b></center></td></tr></font></b></table></center>';
		  }
		  
	  if ($sAction == '5') {
			 mysql_query("UPDATE `[users]` SET `level`='30' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Star: <b>5</b></center></td></tr></font></b></table></center>';
		  }
		  
		  	  if ($sAction == '6') {
			 mysql_query("UPDATE `[users]` SET `level`='70' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>6</b></center></td></tr></font></b></table></center>';
		  }
		  
		  		  	  if ($sAction == '7') {
			 mysql_query("UPDATE `[users]` SET `level`='170' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>7</b></center></td></tr></font></b></table></center>';
		  }
		  
				  		  	  if ($sAction == '8') {
			 mysql_query("UPDATE `[users]` SET `level`='180' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>8</b></center></td></tr></font></b></table></center>';
		  }
		    		  		  	  if ($sAction == '9') {
			 mysql_query("UPDATE `[users]` SET `level`='190' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>9</b></center></td></tr></font></b></table></center>';
		  }
		  
		  		    		  		  	  if ($sAction == '10') {
			 mysql_query("UPDATE `[users]` SET `level`='200' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>10</b></center></td></tr></font></b></table></center>';
		  }
		  	  		    		  		  	  if ($sAction == '11') {
			 mysql_query("UPDATE `[users]` SET `level`='210' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>11</b></center></td></tr></font></b></table></center>';
		  }
		  	  	  		    		  		  	  if ($sAction == '12') {
			 
if($data->vip ==0){
echo 'This is for the VIP Members Only';
exit;
}
mysql_query("UPDATE `[users]` SET `level`='220' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Text 1: <b>1</b></center></td></tr></font></b></table></center>';
		  }
		  	  	  	  		    		  		  	  if ($sAction == '13') {
			 
if($data->vip ==0){
echo 'This is for the VIP Members Only';
exit;
}
mysql_query("UPDATE `[users]` SET `level`='230' WHERE `login`='$data->login'");
	echo '<table width=17% align=center><tr><td class=maintxt><center>Icon: <b>12</b></center></td></tr></font></b></table></center>';
		  
  
	  }
  ?>

<script src="https://kit.fontawesome.com/c63b28a58b.js" crossorigin="anonymous"></script>
</body>
</html>