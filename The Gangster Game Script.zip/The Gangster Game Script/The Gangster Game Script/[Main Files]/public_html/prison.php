<?php
error_reporting(0);

  include("_include-config.php");
include("_include-gevangenis.php");
if(! check_login()) { 
    header("Location: login.php"); 
    exit; 
  } 
    $dbres                = mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup`,UNIX_TIMESTAMP(`online`)
AS `online` FROM `[users]` WHERE `login`='{$_SESSION['login']}'"); 
    $data                = mysql_fetch_object($dbres);
	
#
$select = mysql_query("SELECT * FROM `instellingen`");
#
$page = mysql_fetch_object($select);	
	
	?> 

<html> 
<head> 
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head> 

<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Prison</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/jail.jpg border=0></center>
</td>
</head> 

<table width=100%><table width=100%> 
  <tr><td><b><table width=100%><table  width=100% cellspacing=0
cellpadding=2 ><tr><td align=center> 

 <script language="javascript">

    function getKeyCode(eventObject)
    {
      if (!eventObject) keyCode = window.event.keyCode; //IE
      else keyCode = eventObject.which;   //Mozilla
      return keyCode;
    }
      
    function onlyNumeric(eventObject)
    {
      keyCode = getKeyCode(eventObject);
      if (((keyCode > 31) && (keyCode < 48)) || ((keyCode > 57) && (keyCode < 127)))
      {
          if (!eventObject) window.event.keyCode = 0; //IE
          else eventObject.preventDefault(); //Mozilla
          return false;
      }
    }
  </script>
<?php    mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'"); 
  
      
  $gn1            = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'"); 
  $gn             = mysql_fetch_object($gn1);  if($gn->gevangenis + $gn->gevangenistijd > time() && $data->login != micasa001 ){ 
  $verschil1             = $gn->gevangenis + $gn->gevangenistijd - time() - 3600; 
  $verschil              = date("i:s", "$verschil1");print <<<ENDHTML
 
<tr><td class="mainTxt"><center>You anxiously wait to be released in <font color=Red><b>$verschil</b></font></center><tr><td><br></td></tr>
ENDHTML;
    exit;
} 
    else{ 
     
    $man1              = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `gevangenistijd` > '0'"); 
     
     if(isset($_POST['KO'])) { 
    $id      = $_POST['id']; 
    $man1    = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `id`='$id'"); 
    $man     = mysql_fetch_object($man1);  
  $borg	=	$man->gevangenistijd*100;
     print "<tr><td class=\"mainTxt\" align=\"center\">"; 
if($man->login ==""){ 
 
        print "First you must pick someone to Break Out"; 
    
}    

if($data->cash <= $borg){
print"You must have enough for payment of $borg";
exit;
}
       mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$borg'WHERE `login`='$data->login'");
 mysql_query("UPDATE `[users]` SET `gevangenistijd`='0' WHERE `login`='$man->login'");
mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`from`,`to`,`read`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','Prison','{$man->login}','0','Break Out','You lucky bastard! $data->login has busted you out of prison, free as a bird now.')"); 

print"You have broke out $man->login .";
exit;
}






    if(isset($_POST['BU'])) { 
    $id      = $_POST['id']; 
    $man1    = mysql_query("SELECT *,UNIX_TIMESTAMP(`gevangenis`) AS `gevangenis`,0 FROM `[users]` WHERE `id`='$id'"); 
    $man     = mysql_fetch_object($man1); 
   
print "<tr><td class=\"mainTxt\" align=\"center\">"; 
 if($man->bank < $man->uitbreek){
 print "Too much money has been established to risk the break out."; 
exit;
 }
    
     
    if($man->login ==""){ 
 $gtijd6       = $man->gevangenistijd+$man->gevangenis; 
    $gtijd7       = $gtijd6-time(); 
    $gtijd1       = $gtijd7/2; 
    $gtijd        = round($gtijd1); 
    $gtijd3       = $gtijd1-3600; 
    $gtijd2       = date("i:s", "$gtijd3"); 
        print "You blew up the cell wall only to find nobody in there!";
   mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='600' WHERE `login`='$data->login'");
unset($_POST['BU']);
exit;
} 
    else{ 
    if($data->gvu >= $man->gevangenistijd){ 
    $getal       = 1; 
    } 
    else{ 
    $getal2       = 6; 
    } 
    if($getal ==""){ 
    $getal        = rand(1,$getal2); 
    } 
     
    mysql_query("UPDATE `[users]` SET `gvu`=`gvu`+'1', `attack`=`attack`+'50', `defence`=`defence`+'50' WHERE `login`='$data->login'"); 
     
    if($getal == 1){ 
    print "You did it for {$man->login}! Successful Delivery."; 
    mysql_query("UPDATE `[users]` SET `gevangenistijd`='0',`bank`=`bank`-'$man->uitbreek' WHERE `login`='$man->login'"); 
    mysql_query("UPDATE `[users]` SET `j1`=`j1`+'1',`bank`=`bank`+'$man->uitbreek' WHERE `login`='$data->login'");   
       mysql_query("UPDATE `[users]` SET `j13`=`j13`+'1'WHERE `login`='$data->login'");    
    mysql_query("INSERT INTO `[messages]`(`time`,`IP`,`from`,`to`,`read`,`subject`,`message`) values(NOW(),'{$_SERVER['REMOTE_ADDR']}','Prison','{$man->login}','0','Break Out','You lucky bastard! $data->login has busted you out of prison, free as a bird now.')"); 
    unset($_POST['BU']); 
   exit;
} 
    else{ 
    $gtijd6       = $man->gevangenistijd+$man->gevangenis; 
    $gtijd7       = $gtijd6-time(); 
    $gtijd1       = $gtijd7/2; 
    $gtijd        = round($gtijd1); 
    $gtijd3       = $gtijd1-3600; 
    $gtijd2       = date("i:s", "$gtijd3"); 
    print "BadLuck! Now your stuck in prison!"; 
    mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(), `gevangenistijd`='600' WHERE `login`='$data->login'"); 
    unset($_POST['BU']); 
    exit;
} 
    } 
    print "</td></tr"; 
    } 
     
     
    print "    <tr><td><form method=\"post\">"; 
    print "    <table width=\"100%\"><tr><td width=10>&nbsp;</td>  
<td class=\"subTitle\" align=\"center\" width=25%><b>Name:</td>  <td class=\"subTitle\" align=\"center\" width=25%><b>Gang:</td>  <td class=\"subTitle\" align=\"center\" width=25%><b>Length of Time:</td><td class=\"subTitle\" align=\"center\" width=25%><b>Your BreakOut Payment:</td><td class=\"subTitle\" align=\"center\" width=25%><b>Break Out:</td>  "; 
     
     
    while($man = mysql_fetch_object($man1)) { 
     
    $tijd      = $man->gevangenistijd+$man->gevangenis; 
    $tijdg1    = $man->gevangenistijd+$man->gevangenis-time()-3600; 
    $tijdg     = date("i:s", "$tijdg1"); 
 $borg	=	$man->gevangenistijd*100;
   list($uur,$min,$sec)=explode(":",date("H:i:s",$tijdg1));    
    if($tijd < time()){ 
    } 
    else{ 
     
    if($man->clan ==""){ 
    $man->clan   = "(geen)"; 
    } 

    print " <tr><td width=10><input type=\"radio\" name=\"id\" value=\"{$man->id}\"></td>  
<td class=\"mainTxt\" width=25%><a href=\"profile.php?x={$man->login}\">{$man->login}</a></td> 
<td class=\"mainTxt\" width=25%><a href=\"clan.php?x={$man->clan}\">{$man->clan}</a></td> 
   <td class=\"mainTxt\" width=25%><input type=\"text\" size=8 maxlength=8
"; 
?>

 id="timer" value="<?=date("H:i:s",$tijdg1)?>"></td>
<?
print"<td class=\"mainTxt\" width=25%>$borg</td>";
print"<td class=\"mainTxt\" width=25%>$man->uitbreek</td></tr>";
    } 
     
    } 
     
    print " </table><input type=\"submit\" class='btn btn-info' value=\"Risk to Break Out\" name=\"BU\"> <input type=\"submit\" class='btn btn-info' value=\"Paid to Break Out\" name=\"KO\"> 
       </form></td></tr>"; 
     
     

     
    } 

if(isset($_POST['profile'])) {
 print" <table width=100%><tr><td class=\"subTitle\"><b>Edit Break Out Fee</b></td></tr>";
 $bel				= preg_replace('/\</','&#60;',substr($_POST['bel'],0,500));
if($bel <= 0){
print "<tr><td class=\"mainTxt\">Invalid Number.</td></tr>";
exit;
}


if ($data->bank < $bel){
print "<tr><td class=\"mainTxt\">You dont have that kind of money in your bank account.</td></tr>";
exit;
}
mysql_query("UPDATE `[users]` SET `uitbreek`='$bel' WHERE `login`='$data->login'");

print "<tr><td class=\"mainTxt\">Your Break Out Fee has been changed.</td></tr>";
exit;
}



 print <<<ENDHTML
 <table width=100%>
<form method="post">
<tr><td class="subTitle"><b>Edit Break Out</b></td></tr>
   <tr><td class="mainTxt">Cash used to do Break Out:<br>
  <input type="text" name="bel" class=btn btn-info' value="$data->uitbreek" onkeypress="onlyNumeric(arguments[0])" size="10">
<input type="submit" class='btn btn-info' name="profile" value="Change"></td></tr></form>
    	</table> 

ENDHTML;
    ?> 
    
 