<?php
error_reporting(0);

  include("ubb.php");
  include("ubb.inc.php");
  include("_include-config.php");
  
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link ref="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<body style=" margin: 0px;">

<table width=100%>
<?php /* ------------------------- */
if(isset($_GET['x'])) {
  $dbres1 = mysql_query("SELECT * FROM `[users]` WHERE `login`='{$data->login}'");
$dbres                                = mysql_query("SELECT *,UNIX_TIMESTAMP(`online`) AS `time`,DATE_FORMAT(`online`,'%d-%m-%Y %H:%i') AS `online` FROM `[users]` WHERE `login`='{$_GET['x']}' ");
  if($data = mysql_fetch_object($dbres)) {
$com = mysql_query("SELECT * FROM `[comentaar]` WHERE `to`='$data->login' ORDER BY `datum` DESC");
      $online                = ($data->time > time() )    ? "<b>Now</b>" : $data->online;


        
   mysql_query("SELECT * FROM `[comentaar]` WHERE `to`='$data->login' ORDER BY `datum` DESC");

  $type = array("","DrugDealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","Original Gangster","Rude Boy","PeaceKeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Royal Thug","Avenger","Mugger","Capone","Thief","PIMP","Pretty Women","WiseGuy","Mobster","Fella","Gangster Girl","The Daddy" );
  $ctype = $type[$data->ctype];     

    $land1         = Array("","Belgie","Duitsland","England","Frankrijk","Griekenland","Italie","Aruba","");
    $land          = $land1[$data->land];

    $Provincie        = $Provincie[$data->Provincie];
      $criminals      = Array("","Bitches","Gangs","Criminals");
    $criminals      = $criminals[$data->type];
     
      $power        = number_format(round(($data->attack+$data->defence)/2+$data->clicks*5),0,",",".");
      $def        = number_format(round($data->defence),0,",",".");
      $att        = number_format(round($data->attack),0,",",".");
      $bankk        = number_format(round($data->bank),0,",",".");
      $contantt        = number_format(round($data->cash),0,",",".");
      $geldd        = number_format(round($data->cash+$data->bank),0,",",".");
$recruits        = number_format(round($data->recruits),0,",",".");
      $totalattacks      = $data->attwins + $data->attlosses;
      $totaldefends      = $data->defwins + $data->deflosses;
      $data->info           = opmaak($data->info);
    $avaurl            = $data->avaurl;
    $muziek            = $data->muziek;

    $health            = $data->health;

  $clan_name            = preg_replace('/-\[recruit\]/',"",$data->clan);
    $data->info                = preg_replace('/:P/',"<img src=\"images/smilies/icon_razz.gif\">",$data->info);
        $data->info               = preg_replace('/:D/',"<img src=\"images/smilies/icon_biggrin.gif\">",$data->info);
        $data->info        = preg_replace('/\:\o/',"<img src=\"images/smilies/icon_surprised.gif\">",$data->info);
        $data->info        = preg_replace('/:shock:/',"<img src=\"images/smilies/icon_eek.gif\">",$data->info);
        $data->info        = preg_replace('/:lol:/',"<img src=\"images/smilies/icon_lol.gif\">",$data->info);
        $data->info        = preg_replace('/:x/',"<img src=\"images/smilies/icon_mad.gif\">",$data->info);
        $data->info        = preg_replace('/\:\$/',"<img src=\"images/smilies/icon_redface.gif\">",$data->info);
        $data->info        = preg_replace('/\:\*\(/',"<img src=\"images/smilies/icon_cry.gif\">",$data->info);
        $data->info        = preg_replace('/:evil:/',"<img src=\"images/smilies/icon_evil.gif\">",$data->info);
        $data->info        = preg_replace('/:twisted:/',"<img src=\"images/smilies/icon_twisted.gif\">",$data->info);
        $data->info        = preg_replace('/\%\)/',"<img src=\"images/smilies/icon_rolleyes.gif\">",$data->info);
        $data->info        = preg_replace('/:!:/',"<img src=\"images/smilies/icon_exclaim.gif\">",$data->info);
        $data->info        = preg_replace('/:question:/',"<img src=\"images/smilies/icon_question.gif\">",$data->info);
        $data->info        = preg_replace('/:arrow:/',"<img src=\"images/smilies/icon_arrow.gif\">",$data->info);
        $data->info        = preg_replace('/:idea:/',"<img src=\"images/smilies/icon_idea.gif\">",$data->info);
        $data->info        = preg_replace('/:hart:/',"<img src=\"images/smilies/hart.gif\">",$data->info);
        $data->info        = preg_replace('/:o:/',"<img src=\"images/smilies/boe.gif\">",$data->info);
    $data->info        = preg_replace('/:disco:/',"<img src=\"images/smilies/zoek.gif\">",$data->info);
    $data->info        = preg_replace('/:mrgreen:/',"<img src=\"images/smilies/icon_mrgreen.gif\">",$data->info);
        $data->info        = preg_replace('/\:\)/',"<img src=\"images/smilies/icon_smile.gif\">",$data->info);
        $data->info        = preg_replace('/\:\(/',"<img src=\"images/smilies/icon_sad.gif\">",$data->info);
        $data->info        = preg_replace('/\;\)/',"<img src=\"images/smilies/icon_wink.gif\">",$data->info);
        $data->info        = preg_replace('/8\)/',"<img src=\"images/smilies/icon_cool.gif\">",$data->info);
        $data->info        = preg_replace('/\:\|/',"<img src=\"images/smilies/icon_neutral.gif\">",$data->info);
        $data->info        = preg_replace('/\:\?/',"<img src=\"images/smilies/icon_confused.gif\">",$data->info);
    $data->info        = preg_replace('_/-o_',"<img src=\"images/smilies/worshippy.gif\">",$data->info);
    $data->info        = preg_replace('-bonk-',"<img src=\"images/smilies/bonk.gif\">",$data->info);
    $data->info             = preg_replace("/\[EMAIL\](?U)((.|\n|\r)*)\[\/EMAIL\]/", "<a href=mailto:\\1 target=_blank class=content>\\1</a>", $data->info); 
    $data->info             = preg_replace("/\[b\](.+?)\[\/b\]/is",'<b>\1</b>', $data->info);  //vette text
    $data->info = preg_replace("/\[i\](.+?)\[\/i\]/is",'<i>\1</i>', $data->info);  //schuine text
    $data->info = preg_replace("/\[u\](.+?)\[\/u\]/is",'<u>\1</u>', $data->info);  //underlined
    $data->info = preg_replace("#\[s\](.*?)\[/s\]#si", "<s>\\1</s>", $data->info); // doorstreepte tekst  
        $data->info = preg_replace("/\[scroll\](.+?)\[\/scroll\]/is",'<marquee>\1</marquee>', $data->info);  //scrollende text
    $data->info = preg_replace("/\[red\](.+?)\[\/red\]/is",'<font color=red>\1</font>', $data->info);  //rood
      $data->info = preg_replace("/\[blue\](.+?)\[\/blue\]/is",'<font color=blue>\1</font>', $data->info);  //blauw
     $data->info = preg_replace("/\[green\](.+?)\[\/green\]/is",'<font color=green>\1</font>', $data->info);  //groen
      $data->info = preg_replace("/\[yellow\](.+?)\[\/yellow\]/is",'<font color=yellow>\1</font>', $data->info);  //geel
    $data->info = preg_replace ("#\[color=(\#[0-9A-F]{6}|[a-z\-]+)\](.*?)\[/color\]#si", "<font color=\"\\1\">\\2</font>", $data->info);
    $data->info = preg_replace("/\[img\](.+?)\[\/img\]/is",'<img src="\1">', $data->info);                                          
        $data->info = preg_replace("/\[img w=(.+?) h=(.+?)\](.+?)\[\/img\]/is",'<img src="\3" height="\1" width="\2">', $data->info);

if ($data->clanlevel == 1){
$clanrank    = "Member <IMG BORDER=\"0\" src=\"images/icons/1star.gif\">";
}
if ($data->clanlevel == 2){
$clanrank    = "Recruiter<IMG BORDER=\"0\" src=\"images/icons/2stars.gif\">";
}
if ($data->clanlevel == 3){
$clanrank    = "Member<IMG BORDER=\"0\" src=\"images/icons/1star.gif\">";
}
if ($data->clanlevel == 4){
$clanrank    = "Member<IMG BORDER=\"0\" src=\"images/icons/1star.gif\">";
}
if ($data->clanlevel == 5){
$clanrank    = "Member<IMG BORDER=\"0\" src=\"images/icons/1star.gif\">";
}
if ($data->clanlevel == 6){
$clanrank    = "Manager<IMG BORDER=\"0\" src=\"images/icons/3stars.gif\">";
}
if ($data->clanlevel == 7){
$clanrank    = "General<IMG BORDER=\"0\" src=\"images/icons/4stars.gif\">";
}
if ($data->clanlevel == 8){
$clanrank    = "Leader<IMG BORDER=\"0\" src=\"images/icons/5stars.gif\">";
}
if ($data->clanlevel == 9){
$clanrank    = "Owner<img src=\"images/icons/6stars.gif\">";
}
$rank1	                  	= array("","Cafone","LowLife","Shoplifter","Mugger","Pickpocket","Thief","WiseGuy","Associate","Mobster","Gangster","Assassin","Good Fella","Mob Boss","The Don","The Lengendary Don","The Godfather");
$rank = $rank1[$data->rank];


}
$money = $data->cash+$data->bank;
if ($money <= 1999999) {
    $mrank = "Little Skank";
} elseif ($money > 2000000 AND $money <= 12000000) {
    $mrank = "Gutter Class";
} elseif ($money > 12000000 AND $money <= 45000000) {
    $mrank = "Respectable Man";
} elseif ($money > 45000000 AND $money <= 300000000) {
    $mrank = "Middle Class";
} elseif ($money > 300000000 AND $money <= 1000000000) {
    $mrank = "Wealthy";
} elseif ($money > 1000000000 AND $money <= 6500000000) {
    $mrank = "Upper Class";
} elseif ($money > 6500000000 AND $money <= 12900000000) {
    $mrank = "Real Deal";
} elseif ($money > 12900000000 AND $money <= 15000000000) {
    $mrank = "Rich Bitch";
} elseif ($money > 15000000000 AND $money <= 21000000000) {
    $mrank = "Extremely Rich";
} elseif ($money > 35000000000) {
    $mrank = "Filthy Rich";
}
$hhealth = round(100-$data->health);
if ($data->health <= 25) {
    $healthcolor = "red";
} elseif ($data->health > 25 AND $data->health <= 50) {
    $healthcolor = "orange";
} elseif ($data->health > 50 AND $data->health <= 75) {
    $healthcolor = "yellow";
} elseif ($data->health > 75 AND $data->health <= 100) {
    $healthcolor = "green";
}


$level=$data->level;
$hulpadmin=$data->hupladmin;


if ($level == 300) {
    $level = "<font color=red><b> Owner </b></font>";
} elseif ($level == 255) {
    $level= "<font color=green><b> Administrator </b></font>";
} elseif ($level == 200) {
    $level= "<font color=green><b> Helper Admin </b></font>";
} elseif ($level == 155) {
    $level= "<font color=green><b> Moderator </b></font>";
} elseif ($level == 2) {
    $level= "<font color=green><b> Paying Member </b></font>";
	

} elseif ($data->login == admin) {
    $level= "<font color=green><b> Administrator </b></font>";
	
	
} elseif ($level < 255) {
    $level= "<font color=white> Standard Player </font>";
}


  if($data->vip == 0) {
    $vip = "<font color=blue><b>Standard Player</b></font>";
  } 
  
  if($data->vip >= 1) {
    $vip = "<font color=gold><b>VIP</b></font>+";
  } 

  if($data->vip > 9999) {
    $vip = "<font color=gold><b>Royal</b></font>";

{
{
      $clan_name      = preg_replace('/-\[recruit\]/',"",$data->clan);
      $avatarurl            = $data->avatarurl;
      $data->info      = preg_replace('/\n/',"<br>\n",$data->info);
    $data->allies      = preg_replace('/\n/',"<br>\n",$data->allies);
    $data->enemies    = preg_replace('/\n/',"<br>\n",$data->enemies);

if(isset($_SESSION['login']))
              mysql_query("INSERT INTO `[wannabe]`(`time`,`login`,`person`,`code`,`area`) values(NOW(),'{$_SESSION['login']}','{$data->login}',{$data->clicks},'click')");


   if(mysql_num_rows($dbres_paying) == 100) {
   $medaille = " <tr><td width=125>Medal:</td>  <td align=\"right\"><img src=\"images/medaille.gif\"></td></tr>";
   }
   else {
   $medaille = "";
   }
}
}
}
      print <<<ENDHTML

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<table width="100%">
<tr><td class="subTitle"><b>Player Profile</b></td></tr>
<tr><td>
<table width="100%">
<tr>
<td width="200" class="mainTxt">
<img src="{$data->avaurl}" width="200" height="250"><BR><font color="orange">Last Online</font> : {$online} <br><font color="green"> Member Since</font> : {$data->signup}
</td>
<td valign="top">
<table>
<tr>
<td class="subTitle" width="100%" align=center><b>General:</b></td>
<td width="100%"></td>

</tr>
<tr>
<td class="mainTxt" width="100%">
<table width="100%">
<tr valign="top">
<td width="150"><strong>Name:</strong></td> <td width="150">{$data->login}</td>
</tr>
<tr valign="top"> 
<td width="150"><strong>Gang:</strong></td> <td width="150"><a href="clan.php?x=$clan_name">{$data->clan}</td>
</tr>
<tr valign="top"> 
<td width="150"><strong>Gang Rank:</strong></td><td width="150">{$clanrank}</td>
</tr>



<tr valign="top">
<td width="150"><strong>Rank:</strong></td><td width="150">{$rank}</td>
</tr>
<tr valign="top">
<td width="150"><strong>Cash Rank:</strong></td><td width="150">{$mrank}</td>
</tr>
</table>
</td>
</td>
</tr>











<tr>
<td width="150"></td>
<td width="4%"></td>
<td width="150"></td>
</tr>
<tr>
<td class="subTitle" width="100%" align="center"><b>Character Info:</b></td>
<td width="100%"></td>
</tr>


<tr>
<td class="mainTxt" width="100%">
<table width="100%">
<tr valign="top">
<td width="150"><strong>Criminal Type:</strong></td> <td width="150">{$ctype}</td>
</tr>
<tr valign="top">
<td width="150"><strong>Account Type:</strong></td><td width="150">{$vip}</td>
</tr>
<tr valign="top">
<td width="150"><strong>Account Level:</strong></td><td width="150">{$level}</td>
</tr>
</table>
</td>
</td>
</tr>

















<tr>
<td width="150"></td>
<td width="4%"></td>
<td width="150"></td>
</tr>
<tr>
<td class="subTitle" width="100%" align="center"><b>Info:</b></td>
<td width="100%"></td>

</tr>
<tr>
<td class="mainTxt" width="100%">
<table width="100%">
<tr valign="top">
<td width="150"><strong>Bank:</strong></td><td width="150">{$bankk},-</td>
</tr>
<tr valign="top">
<td width="150"><strong>Wallet:</strong></td><td width="150">{$contantt},-</td>
</tr>
<tr valign="top">
<td width="150"><strong>Referrals:</strong></td><td width="150">{$recruits}</td>
</tr>
</table>
</td>
</td>
</tr>

<tr>
<td width="300"></td>
<td width="4%"></td>
<td width="300"></td>
</tr>
<tr>
<td class="subTitle" width="100%" align="center"><b>Power:</b></td>
<td width="100%"></td>
</tr>
<tr>
<td class="mainTxt" width="100%">
<table width="100%">
<tr valign="top">
<td width="150"><strong>Attack Power:</strong></td><td width="150">{$att}</td>
</tr>
<tr valign="top">
<td width="150"><strong>Defence Power:</strong></td><td width="150">{$def}</td>
</tr>
<tr valign="top">
<td width="150"><strong>Total Power:</strong></td><td width="150">{$power}</td>
</tr>
</table>
</td>
</td>
</tr>
<tr>
<td width="300"></td>
<td width="4%"></td>
<td width="300"></td>
</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
  <tr><td class="mainTxt" width="96%"> <b>Friends:</b>
  {$data->allies}

     <tr><td class="mainTxt" width="96%"> <b>Enemies:</b>
     $data->enemies
<tr>
<td valign="top">
<table align="right">
<tr>

ENDHTML;
      if($data->Mobieltje == 1)
        echo"<td class=\"mainTxt\" align=\"center\" width=100><a href=\"message.php?p=new&to={$data->login}\" class='btn btn-info'><b>Message</b></a></td>";

      print <<<ENDHTML
    
      <td width=5> </td>
    <td class="mainTxt" align="center" width=100><a href="donate.php?x={$data->login}" class='btn btn-info'><b>Donate</b></a></td>
      <td width=5> </td>
      <td class="mainTxt" align="center" width=100><a href="attack.php?x={$data->login}" class='btn btn-info'><b>Attack</b></a></td>
      <td width=5> </td>
      <td class="mainTxt" align="center" width=100><a href="message.php?p=new&to={$data->login}" class='btn btn-info'><b>Message</b></a></td>
</tr>
</table>
</td>
</tr>
<tr>
<tr><td class="subTitle"><b>Information</b></td></tr>
<td class="mainTxt">{$data->info}
</tr>
</table>
<table width="100%">


ENDHTML;
    }

?>
</table>

</body>


</html>

