<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

    $dbres				= mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup`,UNIX_TIMESTAMP(`online`) AS `online` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

if($data->ontslag > 1) {
$dagdagen = dagen; }
elseif($data->ontslag == 1) {
$dagdagen = dag; }

    $dbres				= mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup`,UNIX_TIMESTAMP(`online`) AS `online` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);

      if($data->ontslag >= 1){
    print <<<ENDHTML

<html>


<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body style="margin: 0px;"> 
  <table width=100% height=10%>
    <tr><td class="subTitle"><b>Discharge</b></td></tr>
    <tr><td class="mainTxt">
	<center>You have discharged yourself and must now {$data->ontslag} watch the {$dagdagen} until you get your job back.</center>
    </td></tr>
  </table>
</body>
</html>
ENDHTML;
    exit;
    }


?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

<body style="margin: 0px;">
<table width=100%>
  <tr><td class="subTitle" colspan=2><b>Take Discharge</b></td></tr>
<?php    mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

	if($data->baan == 0){
	print "<tr><td class=\"mainTxt\" align=\"center\"><center>You have no total job and so will you take the discharge?</center></td></tr>";
	}else{

	if(!isset($_POST['B'])){
print <<<ENDHTML
<tr><td class="mainTxt" colspan=2>
<form method="POST">
	<p><input type="radio" value="1" name="B1" checked>Discharge Yourself</p>
	<p><input type="submit" value="Quit this job!" name="B"></p>
</form>
</td></tr>
<tr><td class="subTitle">Carry On</tr></td>
<tr><td class="mainTxt">If you take discharge you will have to wait 2 days until you get a new job.</tr></td>
ENDHTML;

	}

if(isset($_POST['B'])){
	$b1         = $_POST['B1'];
	
if($b1 == 1){
mysql_query("UPDATE `[users]` SET `dagenwerken`='0', `werk2`='1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `baan`='0' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `ontslag`='2' WHERE `login`='$data->login'");
}

if($b1 == 1){
print "<tr><td class=\"mainTxt\">You have taken discharge and must now wait 2 days for a new job.</td></tr>";
}

	}
	
	
	
	}
/* ------------------------- */ ?>

</body>
</html>
