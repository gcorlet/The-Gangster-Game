<b><?php
error_reporting(0);





  $UPDATE_DB                = 1; 
  include("_include-config.php"); 
      include("_include-gevangenis.php");
  if(! check_login()) { 
    header("Location: login.php"); 
    exit; 
  } 

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'"); 

     $dbres				= mysql_query("SELECT * FROM `[redlight]` WHERE `id`='{$clan->id}'");
$clan = mysql_fetch_object($dbres);


/* ------------------------- */ ?> 

<?
$kost2	                  	= array("","69.95","9.50","15.50","4.59","25.75","51.13","1.59","11.69","72.09","22.17");
$kost                		= $kost2[$data->land];
$land1	                  	= array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland");
$land                 		= $land1[$data->land];
$geld                		= $data->hoeren;
$geld2                                      = $geld*5;
$geld3               		= $data->hoerenwerkend;
$geld4                                      = $geld3*15;
$geld5                                      = $geld4+$geld2;
$inkomen                                   = $geld5; 
			
?>
<head> 
<title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

</head>
<body>
<table class=table cellspacing=0 cellpadding=2 colspan="2" width="60%" align=center>
	<tr>
 	 <td colspan="2" class=subtitle>Redlight District</td>

 <tr><td align="center" colspan="1" class=maintxt>Redlight District is about Ho' Pimpin!... Recruit Ho's, then hire booths for each of them.... then get yo cash!<br><br>
<br>
<br><br>

There are <font color="red">`<?= $data->hoeren; ?>` Ho's</font> waiting for you to put them in a booth. <br><br>

<b> Your Income: <?= $inkomen; ?> </b> 

<table class=table cellspacing=0 cellpadding=2 colspan="2" width="60%" align=center>
<tr>
 	 <td colspan="2" class=subtitle>Options</td>
<?
if($data->pimpdiploma == 0){
print <<<ENDHTML
<tr><td colspan="2" class=maintxt>
</strong><center><img src="images/icons/light_pass.jpg"><strong><a href="redlightdistrict.php?show=pimpdiploma" class='btn btn-info' name="30">Obtain PIMP Diploma</a></strong></td></tr>
ENDHTML;
}
elseif($data->pimpdiploma == 1){
print <<<ENDHTML
<table class=table cellspacing=0 cellpadding=2 colspan="2" width="60%" align=center>
<tr><td colspan="1" class=maintxt>
<img src="images/icons/light_raam.jpg" width="16" height="16"><a href="redlightdistrict.php?show=raam" class="btn btn-info"><strong>Booth Rental</strong></a></left>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;
<td colspan="1" class=maintxt><img src="images/icons/light_werk.jpg" width="16" height="16"><strong><a href="redlightdistrict.php?show=zetachter" class="btn btn-info">Manage Ho's</a></strong>
<tr><td colspan="1" class=maintxt>
<img src="images/icons/light_smack.jpg" width="16" height="16"><strong><a href="redlightdistrict.php?show=pimp" class="btn btn-info">Ho' Pimpin</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;
</strong><td colspan="1" class=maintxt><img src="images/icons/light_bussines.jpg" width="16" height="16"><strong><a href="redlightdistrict.php?show=info" name="30" class="btn btn-info">Booth Prices</a></strong></td></tr>
ENDHTML;
}
?>
<?
if($_GET['show'] == "raam")
{
if($_POST['junk']) {
$bieden = $_POST['bieden'];
$bieden = htmlspecialchars($_POST['bieden']);
$bieden = substr($_POST['bieden'],0,11);
$kost1 = $kost*$_POST['bieden'];
if($data->cash < $kost1) {
print "  <tr><td class=\"mainTxt\" colspan=\"2\"><font color=\"red\"><center>You dont have enough cash!</font></td></tr>\n";
}
elseif($bieden < 0 OR !preg_match('/^[0-9]{1,15}$/',$_POST['bieden'])) {
print "  <tr><td class=\"mainTxt\" colspan=\"2\"><center>Numbers only, you Cafone!.</td></tr>\n";
}
elseif($bieden < 1) {
print "  <tr><td class=\"mainTxt\" colspan=\"2\"><font color=\"red\"><center>You have to purchase atleast 1 booth</font></td></tr>\n";
}
else {
$landz = $bieden*1;
mysql_query("UPDATE `[redlight]` SET `ramen`=`ramen`-'$bieden' WHERE `land`='{$data->land}'")or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1',`ramen`=`ramen`+'$landz' WHERE `login`='{$data->login}'") or die(mysql_error());
print "  
<tr><td class=\"mainTxt\" colspan=\"2\"><font color=\"red\"><center>You have purchased $bieden booths for {$kost1},-<script language=\"javascript\">setTimeout('self.window.location.href=\"redlightdistrict.php?show=raam\"',1100)</script></font></td></tr>\n";


}
}
print <<<ENDHTML
<table class=table cellspacing="0" cellpadding="0"  colspan="2" width="60%" align=center>
<tr><td class="subtitle" colspan="2" >The City</tr></td>
<tr><td class="mainTxt" colspan="2">
<left>
Hi  $data->login,
Since you are in the city, hows
about doing abit of pimpin work.
You need to look for booths to rent 
out for your Ho's to make business.

<tr><td class="mainTxt" colspan="1" >Bitches without Booths: <td class="mainTxt" colspan="1">$data->hoeren  
<tr><td class="mainTxt"  colspan="1" >Bitches with Booths: <td class="mainTxt" colspan="1">$data->hoerenwerkend 
<tr><td class="subtitle"  colspan="2" >Hiring Booths</tr></td>
<tr><td class="mainTxt"  colspan="2" > 
<left>
These boothes here are for rent, at a cost of <b>$kost</b>,- per booth.<br>
<FORM METHOD=post ACTION="">
<center>
<b>Number of Booths:<br><input name="bieden" value=""><br>
<INPUT type=submit  name="junk" type="submit" VALUE="Hire"><br><br>
</FORM>
  </table></td></tr>
ENDHTML;
}
?>
<?
if($_GET['show'] == "zetachter")
{
  $dbres                                = mysql_query("SELECT * FROM `[redlight]` WHERE `land`='{$data->land}'");
    $redlicht                               = mysql_fetch_object($dbres);
if($_POST['zetachter']) {
$raam = $_POST['raam'];
$raam = htmlspecialchars($_POST['raam']);
$raam = substr($_POST['raam'],0,11);
$kost1 = $kost*$_POST['raam'];
if($data->hoeren < $raam) {
print "  <tr><td class=\"mainTxt\" colspan=\"2\"><font color=\"red\"><center>PIMPIN!!</font></td></tr>\n";
}
elseif($raam < 0 OR !preg_match('/^[0-9]{1,15}$/',$_POST['raam'])) {
print "  <tr><td class=\"mainTxt\" colspan=\"2\"><center>Figures only you caFone.</td></tr>\n";
}
elseif($raam < 1) {
print "  <tr><td class=\"mainTxt\" colspan=\"2\"><font color=\"red\"><center> Place atleast one Ho' in each rental Booth!</font></td></tr>\n";
}
else {
$landz = $raam*1;
mysql_query("UPDATE `[redlight]` SET `ramen`=`ramen`-'$bieden'")or die(mysql_error());
mysql_query("UPDATE `[users]` SET `hoeren`=`hoeren`-'$landz' WHERE `login`='{$data->login}'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$kost1',`hoerenwerkend`=`hoerenwerkend`+'$landz' WHERE `login`='{$data->login}'") or die(mysql_error());
print "  <tr><td class=\"mainTxt\" colspan=\"2\"><font color=\"red\"><center>You have filled an extra {$raam} booths out of a possible {$data->ramen}!<script language=\"javascript\">setTimeout('self.window.location.href=\"redlightdistrict.php?show=zetachter\"',1400)</script></font></td></tr>\n";
}
}
print <<<ENDHTML
<table class=table cellspacing="0" cellpadding="0"  colspan="2" width="60%" align=center>
<tr><td class="subtitle" colspan="2" >Ho' Humping</tr></td>
<tr><td class="mainTxt" colspan="2">
<left>
Hi  $data->login,
Since you are in the city, hows
about doing abit of pimpin work.
You need to look for booths to rent 
out for your Ho's to make business. 

<tr><td class="mainTxt" colspan="1" >Bitches without Booths: <td class="mainTxt" colspan="1">$data->hoeren  
<tr><td class="mainTxt"  colspan="1" >Bitches in booths; <td class="mainTxt" colspan="1">$data->hoerenwerkend 
<tr><td class="subtitle"  colspan="2" >Get to work Bitch!</tr></td>
<tr><td class="mainTxt"  colspan="2" > 
<center>
Here put your Ho's in Booths, <br>You deserve good money from them!!
<FORM METHOD=post ACTION="">
<center>
<b><br><input name="raam" value=""><br>
<INPUT type=submit  name="zetachter" type="submit" VALUE="Enter"><br><br>
</FORM>
  </table></td></tr>
ENDHTML;
}
?>
<?
if($_GET['show'] == "pimp")
{
if(!empty($_POST['zoek'])) {
$rand=rand(1,90);
$gevonden=rand(1,199);
$luckymofo=rand(209,409);
$tijd=rand(1,165);
if($data->hoerpimped > 0){
print "<tr><td colspan=3 class=\"mainTxt\"><center><font color=green>You've pimped all the ho's on the street! Try again in the next hour.</font></b></font></td></tr>\n";
}
elseif($rand > 65) { 
 mysql_query("UPDATE `[users]` SET `hoeren`=hoeren+'$gevonden' WHERE `login`='$data->login'");
 mysql_query("UPDATE `[users]` SET `hoerpimped`='1' WHERE `login`='$data->login'");
print " <tr><td colspan=3 class=\"mainTxt\" colspan=\"2\"><center><b><b>You picked up <font color=red>$gevonden ho's</font> off the street!<script language=\"javascript\">setTimeout('self.window.location.href=\"redlightdistrict.php?show=pimp\"',1400)</script></b></font></td></tr>\n";
}
elseif($rand > 50){
 mysql_query("UPDATE `[users]` SET `hoeren`=hoeren+'$gevonden' WHERE `login`='$data->login'");
 mysql_query("UPDATE `[users]` SET `hoerpimped`='1' WHERE `login`='$data->login'");
print "<tr><td colspan=3 class=\"mainTxt\" colspan=\"2\"><center>Phewww, You was almost confronted by the police.You also picked up <font color=red>$gevonden ho's</font> off the street.<script language=\"javascript\">setTimeout('self.window.location.href=\"redlightdistrict.php?show=pimp\"',1400)</script></b></font></td></tr>\n";
}
elseif($rand > 40){
 mysql_query("UPDATE `[users]` SET `hoerpimped`='1' WHERE `login`='$data->login'");
print "<tr><td colspan=3 class=\"mainTxt\" colspan=\"2\"><center>Its not always the best solution to kick the shit out of a copper. But you come out on top, accept a broken kneee.. <script language=\"javascript\">setTimeout('self.window.location.href=\"redlightdistrict.php?show=pimp\"',1400)</script></b></font></td></tr>\n";
}
elseif($rand > 30){
 mysql_query("UPDATE `[users]` SET `hoerpimped`='1' WHERE `login`='$data->login'");
print "<tr><td colspan=3 class=\"mainTxt\" colspan=\"2\"><center>Run motherfucker!! As soon as your saw the police, you fucking ran as fast as a mofo cheetah.<script language=\"javascript\">setTimeout('self.window.location.href=\"redlightdistrict.php?show=pimp\"',1400)</script></b></font></td></tr>\n";
}
elseif($rand > 20){
mysql_query("UPDATE `[users]` SET `hoerpimped`='1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `gevangenis`=NOW(),`gevangenistijd`='$tijd'  WHERE `login`='{$data->login}'");
print "<tr><td colspan=3 class=\"mainTxt\" colspan=\"2\"><center>Apprehended, you sit on the cell floor and wait $tijd seconds.<script language=\"javascript\">setTimeout('self.window.location.href=\"prison.php\"',1500)</script></b></font></td></tr>\n";
}
elseif($rand > 9){
mysql_query("UPDATE `[users]` SET `hoeren`=hoeren+'$luckymofo' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `hoerpimped`='1' WHERE `login`='$data->login'");
print "<tr><td colspan=3 class=\"mainTxt\" colspan=\"2\"><center>With no luck with any Ho's you take a shortcut back to the square. HOLY SHIT... there must be atleast 500 ho's chilling! You manage to bring back <script language=\"javascript\">setTimeout('self.window.location.href=\"redlightdistrict.php?show=pimp\"',1700)</script><font color=red>$luckymofo</font> of them! </b></font></td></tr>\n";

}
}
print <<<ENDHTML
<form method=post>
<table class=table cellspacing=0 cellpadding=2 colspan="2" width="60%" align=center>
   <tr><td class=subtitle colspan="2" align=center> PiMPiN Ho'S</tr></td>
 <tr><td class=maintxt colspan="2" align=center>
Here you can pimp some ho's!
You can pimp 1 time every hour. The ho' who has the customer gets to go into the booth, but remember... booths cost cash.
GoodLuck With Pimpin
 <tr><td class=maintxt colspan="2" align=center>
<br><input type=submit name=zoek value="GO PiMPiN" size=200>    </form>
  </table></td></tr>
ENDHTML;
}
?>
 <? 
if($_GET['show'] == "info")
$gegevens = mysql_query("SELECT * FROM `[redlight]`") or die(mysql_error()); 
while($rij = mysql_fetch_object($gegevens)) { 
$prijs = number_format($rij->maximum,0,",",".");

if ($rij->land == 1){
$land = "Amsterdam, Netherlands";
$landprijs =  "69.69";
}
if ($rij->land == 2){
$land = "Paris, France";
$landprijs =  "9.50";
}
if ($rij->land == 3){
$land = "Havana, Cuba";
$landprijs =  "15.50";
}
if ($rij->land == 4){
$land = "Moscow, Russia";
$landprijs =  "4.59";
}
if ($rij->land == 5){
$land =  "Sydney, Australia";
$landprijs =  "25.75";
}
if ($rij->land == 6){
$land =  "New York, USA";
$landprijs =  "51.13";
}
if ($rij->land == 7){
$land =  "Berlin, Germany";
$landprijs =  "1.59";
}
if ($rij->land == 8){
$land =  "Brussels, Belgium";
$landprijs =  "11.69";
}
if ($rij->land == 9){
$land =  "London, England";
$landprijs =  "72.09";
}
if ($rij->land == 10){
$land =  "Dublin, Ireland";
$landprijs =  "22.17";
}






  $dbres                = mysql_query("SELECT * FROM `[redlight]`");
    $aantal                = mysql_fetch_object($dbres);

echo(" 
<tr><td  class=\"tabel\" witdh=\"60%\" align=\"center\">
<tr><td width=\"2%\" class=\"mainTxt\">$land</td>
<td width=\"2%\" class=\"mainTxt\">Prices: $landprijs</td> "); 
}
?>

<?
if($_GET['show'] == "pimpdiploma")
{
echo"<table class=table cellspacing=0 cellpadding=2 colspan=2 width=60% align=center>";
if($data->hoermissie == 0){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/pimp/1.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question 1:</B>  What does P.I.M.P stand for?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp1a>Player in main Plaza</a></TD>
   <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp1b>People in my Pant's</a></TD>
   <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp1c>Peering at my poo!</a></TD>
    ";
     }
    if($data->hoermissie == 1){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/pimp/2.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question 2:</B> What is the name of this gangster game website?</TD></TR>
  <TR>

   <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp2b>A Thugs Independence</a></TD>
   <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp2c>UK Urban Crime</a></TD>
    <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp2a>The Gangster Game</a></TD>
    ";
     }
if($data->hoermissie == 2){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/pimp/3.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Question 3:</B>  Who are P.I.M.P's?</TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp3b>Your Grandad</a></TD>
   <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp3a>Playa's</a></TD>
   <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp3c>Postman</a></TD>
    ";
     }
if($data->hoermissie == 3){
echo"  <TR>
    <TD align=middle class=mainTxt colSpan=3><img src='images/pimp/4.jpg' height=200 width=300></TD></TR>
  <TR>
    <TD class=mainTxt colspan=3 align=center><B>Final Question:</B> Is P.I.M.P a proffesion? </TD></TR>
  <TR>
    <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp4a>Yes</a></TD>
   <TD vAlign=top class=mainTxt><a href=redlightdistrict.php?x=pimp4b>No</a></TD>
    ";
     }
     }
echo"<table width=60% align=center>";

if($_GET['x'] == "pimp1a")
{
if($data->hoermissie != 0){
echo "<tr><td class=mainTxt colspan=2 align=center>Congratulations! We'll make a pimp out of you yet!";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center> Question <b>1</b> is <font color=green><b>CORRECT</b></font>. Still <b>3</b> more to go.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `hoermissie`=`hoermissie`+'1' WHERE `login`='{$data->login}'");
}
}
if($_GET['x'] == "pimp1b")
{
if($data->hoermissie!= 0){
echo "<tr><td class=mainTxt colspan=2 align=center>What brings you here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>1</b> is <font color=red><b>WRONG</b></font>. That cost you <b>50</b>. Oh well, you can always try again.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "pimp1c")
{
if($data->hoermissie != 0){
echo "<tr><td class=mainTxt colspan=2 align=center>What brings you here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>1</b> is <font color=red><b>WRONG</b></font>. That cost you <b>50</b>. Oh well, you can always try again.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50' WHERE `login`='{$data['login']}'");
}
}


if($_GET['x'] == "pimp2b")
{
if($data->hoermissie != 1){
echo "<tr><td class=mainTxt colspan=2 align=center>What brings you here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>2</b> is <font color=red><b>WRONG</b></font>. That cost you <b>50</b>. Oh well, you can always try again.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "pimp2a")
{
if($data->hoermissie != 1){
echo "<tr><td class=mainTxt colspan=2 align=center>OOOOoooOOOoOooOo... Someones been studying abit of PIMPOLOGY";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>2</b> is <font color=green><b>CORRECT</b></font>. Just <b>2</b> more to go.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `hoermissie`=`hoermissie`+'1' WHERE `login`='{$data->login}'");
}
}
if($_GET['x'] == "pimp2c")
{
if($data->hoermissie != 1){
echo "<tr><td class=mainTxt colspan=2 align=center>What brings you here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>2</b> is <font color=red><b>WRONG</b></font>. That cost you <b>50</b>. Oh well, you can always try again.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "pimp3c")
{
if($data->hoermissie != 2){
echo "<tr><td class=mainTxt colspan=2 align=center>What brings you here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>3</b> is <font color=red><b>WRONG</b></font>. That cost you <b>50</b>. Oh well, you can always try again.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "pimp3b")
{
if($data->hoermissie != 2){
echo "<tr><td class=mainTxt colspan=2 align=center>What brings you here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>3</b> is <font color=red><b>WRONG</b></font>. That cost you <b>50</b>. Oh well, you can always try again.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "pimp3a")
{
if($data->hoermissie != 2){
echo "<tr><td class=mainTxt colspan=2 align=center>GO GO GO!!!! YE BABY GOGOGO";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>3</b> is <font color=green><b>CORRECT</b></font>. On to the <b>Final</b> question.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `hoermissie`=`hoermissie`+'1' WHERE `login`='{$data->login}'");
}
}

if($_GET['x'] == "pimp4b")
{
if($data->hoermissie != 3){
echo "<tr><td class=mainTxt colspan=2 align=center>What brings you here ??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>4</b> is <font color=red><b>WRONG</b></font>. That cost you <b>50</b>. Oh well, you can always try again.";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=pimpdiploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'50' WHERE `login`='{$data['login']}'");
}
}
if($_GET['x'] == "pimp4a")
{
if($data->hoermissie != 3){
echo "<tr><td class=mainTxt colspan=2 align=center>WOOOOAH! You made the test look piss easy! Are you sure your not a born pimp??";
}else{
echo "<tr><td class=mainTxt colspan=2 align=center>Question <b>4</b> is <font color=green><b>CORRECT</b></font> Congratulations: You have recieved the PIMP Diploma!";
echo "<tr><td class=mainTxt colspan=2 align=center><img src='images/pimp/diploma.jpg'>";
echo "<script language=\"javascript\">setTimeout('window.location=\"redlightdistrict.php?show=diploma\"',1300)</script>";
mysql_query("UPDATE `[users]` SET `hoermissie`=`hoermissie`+'1' WHERE `login`='{$data->login}'");
mysql_query("UPDATE `[users]` SET `pimpdiploma`='1' WHERE `login`='{$data->login}'");
}
}
?>
</table></body>

</html>

<?PHP

// de site word sloom dus moeten we wel alles afsluiten..

mysql_close();

// zo dat was het dan weer voor vandaag..
?><b></b>
</b>