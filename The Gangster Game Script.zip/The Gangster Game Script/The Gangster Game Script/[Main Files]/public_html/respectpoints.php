<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">
<center>
<table width=75%>
<tr><td class=subtitle><b>Respect Points</b></td></tr>
<td class=maintxt>


<?php
if ($_POST['submit'] && preg_match('/^[0-9]+$/',$_POST['aantal'])) {
$naar = strtolower($_POST['to']);
$van = strtolower($data->login);
$aantal = $_POST['aantal'];
$user = mysql_fetch_object(mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['to']}'"));

if ($data->rp < $_POST['aantal']) { print "You dont have enough points to give $van $naar\n"; }

elseif ($_POST['aantal'] <= 0) { print "You dont have any more points to give away\n"; } 
elseif ($naar == $van) { print "You cant give yourself Respect Points\n"; } 
elseif (!$user->login) { print "This user does not exist\n"; } 


else {
if ($_POST['type'] == e){
	mysql_query("UPDATE `[users]` SET `respect`=`respect`+'$aantal' WHERE `login`='{$_POST['to']}'");
	mysql_query("INSERT INTO `[respect]`(`time`,`login`,`person`,`code`,`area`,`com`) values(NOW(),'{$data->login}','{$_POST['to']}','{$_POST['aantal']}','respect','{$_POST['com']}')");
    }
 else {
	mysql_query("UPDATE `[users]` SET `respect`=`respect`-'$aantal' WHERE `login`='{$_POST['to']}'");
	mysql_query("INSERT INTO `[respect]`(`time`,`login`,`person`,`code`,`area`,`com`) values(NOW(),'{$data->login}','{$_POST['to']}','-{$_POST['aantal']}','respect','{$_POST['com']}')");
      }
    mysql_query("UPDATE `[users]` SET `rp`=`rp`-'$aantal' WHERE `login`='{$data->login}'");

}
}
$newr = mysql_fetch_object(mysql_query("SELECT *,UNIX_TIMESTAMP(`time`) AS `time` FROM `[cron]` WHERE `name`='week'"));
$new = date('d-m H:i',$newr->time+604800);
print <<<ENDHTML
<center><b>You have yet to give away $data->rp ! Respect Points. You will receive 10 new points every hour!</b></center>

<br><br><div align='center'><b>Send Respect Points</b><br><br>
<form method="post" class='btn btn-info' style="text-align: center">
To:<br><input type="text" class='btn btn-info' name="to" maxlength="16"><br>
Points:<br><input type=text class='btn btn-info' name="aantal" value=""><br>
Added Notes:<br><input type=text class='btn btn-info' name="com" value=""><br>
<input type=radio class='btn btn-info' name=type value=e checked>Respect&nbsp;&nbsp;<input type=radio name=type value=s>Shame<br>
<br><input type=submit class='btn btn-info' name=submit value=Send><br>
	</form>

ENDHTML;
    print "  <tr>
    <td class=subTitle><b>Last 10 Respect Points received</b></td>
  </tr>
  <tr> 
    <td class=mainTxt><table width=100%>";
print "      <tr><td class=subtitle width=125><b>From</b></td>
	<td class=subtitle><b>Points</b></td>
	<td class=subtitle width=200 align=\"center\"><b>Time</b></td>
		<td class=subtitle width=100 align=\"center\"><b>Added Note</b></td></tr>
<tr><td class=maintxt width=100 align=\"center\">";
    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `donatetime` FROM `[respect]` WHERE `person`='{$data->login}' AND `time` >= '{$data->signup}' AND `area`='respect' ORDER BY `time` DESC LIMIT 0,10");
    $bl				= mysql_query("SELECT * FROM `[respect]` WHERE `person`='{$data->login}' AND `area`='respect'");
$bla = mysql_num_rows($bl);
if ($bla == 0) {
      print <<<ENDHTML
<tr><td class=maintxt width=100 align=center>
    <tr><td width=125>You have not received any Respect Points</td>
ENDHTML;
}
    while($info = mysql_fetch_object($dbres)) {
$com = $info->com;
if (!$info->com) { $com = Geen; }
      print <<<ENDHTML
      <tr><td class=maintxt width=125>$info->login</td>
	<td class=maintxt><center><b>{$info->code}</center></b></td>
	<td class=maintxt width=200 align="center">{$info->donatetime}</td>
		<td class=maintxt width=100 align="center">$com</td></tr>
ENDHTML;
    }

    print "  </table></td></tr><tr>
    <td class=subTitle><b>Last 10 Respect Points Sent</b></td>
  </tr>
  <tr> 
    <tr><td class=mainTxt>";
    print "  <table width=100%>\n";
print "      <tr><td class=subtitle width=125><b>To</b></td>
	<td class=subtitle><b>Points</b></td>
	<td class=subtitle width=200 align=\"center\"><b>Time</b></td>
		<td class=subtitle width=100 align=\"center\"><b>Added Note</b></td></tr>";

    $dbres				= mysql_query("SELECT *,DATE_FORMAT(`time`,'%d-%m-%Y %H:%i') AS `donatetime` FROM `[respect]` WHERE `login`='{$data->login}' AND `time` >= '{$data->signup}' AND `area`='respect' ORDER BY `time` DESC LIMIT 0,10");
    $bl				= mysql_query("SELECT * FROM `[respect]` WHERE `login`='{$data->login}' AND `area`='respect'");
$bla = mysql_num_rows($bl);
if ($bla == 0) {
      print <<<ENDHTML
    <tr><td width=125>No Respect Points Sent</td>
ENDHTML;
}
    while($info = mysql_fetch_object($dbres)) {
$com = $info->com;
if (!$info->com) { $com = Geen; }
      print <<<ENDHTML

      <tr><td class=maintxt width=125>$info->person</td>
	<td class=maintxt><center><b>{$info->code}</center></b></td>
	<td class=maintxt width=200 align="center">{$info->donatetime}</td>
		<td class=maintxt width=100 align="center">$com</td></tr>
ENDHTML;
    }
?>
	</table></table></body></html>