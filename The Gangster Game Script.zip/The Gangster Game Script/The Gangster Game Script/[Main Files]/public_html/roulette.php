<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }


  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

  $jegeld = number_format($data->cash,0,",",".");

?>

<head> 
<title></title> 

<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>


<body style="margin: 0px;"> 
<table width=100%  align=center>
<?php   
   
    $casino       = mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='{$data->land}'"); 
    $casino       = mysql_fetch_object($casino);    
    $maxxx = number_format($casino->maximum,0,",",".");
if($casino->owner =="Obay"){
print"
<tr><td class=subTitle><b>Roulette</b></td></tr> 
<tr><td class=mainTxt><b>Sorry the roulette table is on Obey setting, which means you cannot play at this time.</b></td></tr>
";
exit;
}
if($casino->owner == ""){ 
print "
<table width=87% align=center>
<tr><td class=subTitle>Purchase Roulette</td></tr>
<tr><td class=mainTxt align=center>There is no owner of this Roulette</td></tr>
<tr><td class=mainTxt align=center><a href=\"buyr.php\">Click HERE to purchase the Roulette Table!</a>
<center>
</td></tr>
</table>
";
} 
else{ 
print <<<ENDHTML
<tr><td class=subTitle><b>Roulette</b></td></tr> 
ENDHTML;
if($data->login == $casino->owner){ 

if(isset($_POST['erop'])){
$hoeveel = $_POST['hoeveel'];
if(! preg_match('/^[0-9]{0,15}$/',$_POST['hoeveel'])){
print "><tr><td class=\"mainTxt\"><font color=red>Incorrect input</font></td></tr>";
exit;
}
elseif($hoeveel == ''){
print "<tr><td class=\"mainTxt\"><font color=red>Incorrect input</font></td></tr>";
exit;
}
elseif($data->cash < $hoeveel){
print "<tr><td class=\"mainTxt\"><font color=red>You dont have enough cash!</font></td></tr>";
}
else{
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$hoeveel' WHERE `login`='$data->login'");
mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`+'$hoeveel' WHERE `spel`='2' AND `land`='{$data->land}'");
print "<tr><td class=\"mainTxt\"><font color=red>Cash Transfered!</font></td></tr>";
}
}
if(isset($_POST['eraf'])){
$hoeveel = $_POST['hoeveel'];
if(! preg_match('/^[0-9]{0,15}$/',$_POST['hoeveel'])){
print "><tr><td class=\"mainTxt\"><font color=red>Incorrect Input</font></td></tr>";
exit;
}
elseif($hoeveel == ''){
print "<tr><td class=\"mainTxt\"><font color=red>Incorrect Input</font></td></tr>";
exit;
}
elseif($casino->vw < $hoeveel){
print "<tr><td class=\"mainTxt\"><font color=red>There is not enough money the Casino Bank</font></td></tr>";
}
else{
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$hoeveel' WHERE `login`='$data->login'");
mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`-'$hoeveel' WHERE `spel`='2' AND `land`='{$data->land}'");
print "<tr><td class=\"mainTxt\"><font color=red>Cash Transfered!</font></td></tr>";
}
}
    $dbres				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);
    $casinooo       = mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='{$data->land}'");  
    $casinoo       = mysql_fetch_object($casinooo);    
    $ba = number_format($casinoo->vw,0,",",".");
    $cash = number_format($data->cash,0,",",".");
if($casino->bank > 0){
$winst = number_format($casino->bank,0,",",".");
$winst = "<font color=green>\$$winst</font>";
}
if($casino->bank < 0){
$winst = number_format($casino->bank,0,",",".");
$winst = "<font color=red>\$$winst</font>";
}

if($casino->bank == 0){
$winst = number_format($casino->bank,0,",",".");
$winst = "\$$winst";
}


if(isset($_POST['VA'])){ 
if($_POST['inzet'] <1000){ 
print "<tr><td class=\"mainTxt\" align=\"center\" width=100%>You must enter atleast 1000</td></tr>"; 
} 
elseif($_POST['inzet'] >10000000){ 
print "<tr><td class=\"mainTxt\" align=\"center\" width=100%>You cannot bet higher than \$$10.000.000 zijn.</td></tr>"; 
} 
else{ 
$inzet    = $_POST['inzet']; 
$inzett  = number_format($inzet,0,",",".");
mysql_query("UPDATE `[casino]` SET `maximum`='$inzet' WHERE `spel`='2' AND `land`='{$data->land}'");  
print "<tr><td class=\"mainTxt\">The maximum bet has changed to $$inzett.</td></tr>"; 
} 
} 

print <<<ENDHTML

<tr><td class="mainTxt"> 
<form method="POST"> 

You have made $winst profit with your roulette table.<br><br>
Cahs in the Casino Bank: $$ba <br>
Cash on You : $$cash<br><br>

<form method=post>
<input type=hidden name=casino value=>Maximum Bet <input type=text name=inzet value=$casino->maximum><input type=submit name=VA value="Update!">
</form>

<font color=red>Borrowing cash from the state as theres no money left in the Casino Bank!</font><br><br>

<form method=post>
 Ammount of Cash to Put or Take from Casino<br>$ <input type=text name=hoeveel><br><br>
<input type=submit name=erop value="Put money in Casino Bank"><input type=submit name=eraf value="Take money from the Casino Bank">

</form></td></tr> 
ENDHTML;
} 


if(isset($_POST['Gok'])){ 
$getal           = rand(0,36); 


$aftrek          =
$_POST['1']+$_POST['2']+$_POST['3']+$_POST['4']+$_POST['5']+$_POST['6']+$_POST['7']+$_POST['8']+$_POST['9']+$_POST['10']+$_POST['11']+$_POST['12']+$_POST['13']+$_POST['14']+$_POST['15']+$_POST['16']+$_POST['17']+$_POST['18']+$_POST['19']+$_POST['20']+$_POST['21']+$_POST['22']+$_POST['23']+$_POST['24']+$_POST['25']+$_POST['26']+$_POST['27']+$_POST['28']+$_POST['29']+$_POST['30']+$_POST['31']+$_POST['32']+$_POST['33']+$_POST['34']+$_POST['35']+$_POST['36']+$_POST['r']+$_POST['b']+$_POST['e']+$_POST['o']+$_POST['eta']+$_POST['ntz']+$_POST['ett']+$_POST['dtv']+$_POST['vtz']+$_POST['ek']+$_POST['tk']+$_POST['dk']; 

$_POST['1']+$_POST['2']+$_POST['3']+$_POST['4']+$_POST['5']+$_POST['6']+$_POST['7']+$_POST['8']+$_POST['9']+$_POST['10']+$_POST['11']+$_POST['12']+$_POST['13']+$_POST['14']+$_POST['15']+$_POST['16']+$_POST['17']+$_POST['18']+$_POST['19']+$_POST['20']+$_POST['21']+$_POST['22']+$_POST['23']+$_POST['24']+$_POST['25']+$_POST['26']+$_POST['27']+$_POST['28']+$_POST['29']+$_POST['30']+$_POST['31']+$_POST['32']+$_POST['33']+$_POST['34']+$_POST['35']+$_POST['36']+$_POST['r']+$_POST['b']+$_POST['e']+$_POST['o']+$_POST['eta']+$_POST['ntz']+$_POST['ett']+$_POST['dtv']+$_POST['vtz']+$_POST['ek']+$_POST['tk']+$_POST['dk']; 
if(0 >=$aftrek){ 
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
} 
elseif ($_POST['1'] != is_numeric($_POST['1'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['2'] != is_numeric($_POST['2'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['3'] != is_numeric($_POST['3'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['4'] != is_numeric($_POST['4'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['5'] != is_numeric($_POST['5'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['6'] != is_numeric($_POST['6'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['7'] != is_numeric($_POST['7'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['8'] != is_numeric($_POST['8'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['9'] != is_numeric($_POST['9'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['10'] != is_numeric($_POST['10'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['11'] != is_numeric($_POST['11'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['12'] != is_numeric($_POST['12'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['13'] != is_numeric($_POST['13'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['14'] != is_numeric($_POST['14'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['15'] != is_numeric($_POST['15'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['16'] != is_numeric($_POST['16'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['17'] != is_numeric($_POST['17'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['18'] != is_numeric($_POST['18'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['19'] != is_numeric($_POST['19'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['20'] != is_numeric($_POST['20'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['21'] != is_numeric($_POST['21'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['22'] != is_numeric($_POST['22'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['23'] != is_numeric($_POST['23'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['24'] != is_numeric($_POST['24'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['25'] != is_numeric($_POST['25'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['26'] != is_numeric($_POST['26'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['27'] != is_numeric($_POST['27'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['28'] != is_numeric($_POST['28'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['29'] != is_numeric($_POST['29'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['30'] != is_numeric($_POST['30'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['31'] != is_numeric($_POST['31'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['32'] != is_numeric($_POST['32'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['33'] != is_numeric($_POST['33'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['34'] != is_numeric($_POST['34'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['35'] != is_numeric($_POST['35'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['36'] != is_numeric($_POST['36'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['r'] != is_numeric($_POST['r'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['b'] != is_numeric($_POST['b'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['e'] != is_numeric($_POST['e'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['o'] != is_numeric($_POST['o'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['eta'] != is_numeric($_POST['eta'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['ntz'] != is_numeric($_POST['ntz'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['ett'] != is_numeric($_POST['ett'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['dtv'] != is_numeric($_POST['dtv'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['vtz'] != is_numeric($_POST['vtz'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['ek'] != is_numeric($_POST['ek'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['tk'] != is_numeric($_POST['tk'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['dk'] != is_numeric($_POST['dk'])) {
print "<tr><td class=\"mainTxt\" align=\"center\">Numbers Only</td></tr>"; 
}
elseif ($_POST['1'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['2'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['3'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['4'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['5'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['6'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['7'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['8'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['9'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['10'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['11'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['12'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['13'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['14'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['15'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['16'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['17'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['18'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['19'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['20'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['21'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['22'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['23'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['24'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['25'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['26'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['27'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['28'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['29'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['30'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['31'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['32'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['33'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['34'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['35'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['36'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['r'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['b'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['e'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['o'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['eta'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['ntz'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['r'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['b'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['vtz'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['ek'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['tk'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif ($_POST['dk'] < 0) {
print "<tr><td class=\"mainTxt\" align=\"center\">A lead number above 0.</td></tr>"; 
}
elseif($aftrek > $data->cash){
print "<tr><td class=\"mainTxt\" align=\"center\">You dont have enough cash on you.</td></tr>"; 
}
elseif($aftrek < $casino->maximum/10){ 
$pr1 = $casino->maximum/10;
$geld = number_format($pr1,0,",",".");
print "<tr><td class=\"mainTxt\" align=\"center\">You cannot go lower than the mimimum stakes \$$geld!</td></tr>"; 
} 
elseif($aftrek > $casino->maximum){ 
print "<tr><td class=\"mainTxt\" align=\"center\">You dont have enough cash on you.</td></tr>"; 
} 
else{ 
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$aftrek' WHERE `login`='$data->login'"); 
mysql_query("UPDATE `[casinoo]` SET `bank`=`bank`-'$aftrek' WHERE `land`='{$data->land}' AND`spel`='2'"); 
mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`-'$aftrek' WHERE `land`='{$data->land}' AND`spel`='2'"); 

$prijs           = $_POST[$getal]*36; 

if($getal ==1 || $getal ==4 || $getal ==7 || $getal ==10 || $getal ==13 || $getal ==16 || $getal
==19 || $getal ==22 || $getal ==25 || $getal ==28 || $getal ==31 || $getal ==34){ 
$rij       = 'ek'; 
} 
elseif($getal ==2 || $getal ==5 || $getal ==8 || $getal ==11 || $getal ==14 || $getal ==17 ||
$getal ==20 || $getal ==23 || $getal ==26 || $getal ==29 || $getal ==32 || $getal ==35){ 
$rij       = 'tk'; 
} 
else{ 
$rij       = 'dk'; 
} 

$rij       = $_POST[$rij]*3; 
$prijs     = $prijs+$rij; 



if($getal <13){ 
$et        = 'ett'; 
} 
elseif($getal > 24){ 
$et        = 'vtz'; 
} 
else{ 
$et        = 'dtv'; 
} 

$et        = $_POST[$et]*3; 
$prijs     = $prijs+$et; 

if($getal ==1 || $getal ==3 || $getal ==5 || $getal ==7 || $getal ==9 || $getal ==12 || $getal ==14
|| $getal ==16 || $getal ==18 || $getal ==19 || $getal ==21 || $getal ==23 || $getal ==25 || $getal
==27 || $getal ==30 || $getal ==32 || $getal ==34 || $getal ==36){ 
$kleur     ='r'; 
} 
else{ 
$kleur     ='b'; 
} 

$kleur     = $_POST[$kleur]*2; 
$prijs     = $prijs+$kleur; 



if($getal <19){ 
$koos      = 'eta'; 
} 
else{ 
$koos      = 'ntz'; 
} 

$koos      = $_POST[$koos]*2; 
$prijs     = $prijs+$koos; 

if($getal ==2 || $getal ==4 || $getal ==6 || $getal ==8 || $getal ==10 || $getal ==12 || $getal
==14 || $getal ==16 || $getal ==18 || $getal ==20 || $getal ==22 || $getal ==24 || $getal ==26 ||
$getal ==28 || $getal ==30 || $getal ==32 || $getal ==34 || $getal ==36){ 
$even      = 'e'; 
} 
else{ 
$even      = 'o'; 
} 

if($getal ==1 || $getal ==3 || $getal ==5 || $getal ==7 || $getal ==9 || $getal ==12 || $getal ==14 || $getal ==16 || $getal ==18 || $getal ==19 || $getal ==21 || $getal ==23 || $getal ==25 || $getal ==27 || $getal ==30 || $getal ==32 || $getal ==34 || $getal ==36){
$bgcolor = "red";
}elseif($getal ==0){
$bgcolor = "green";
}else{
$bgcolor = "black";
}

$even      = $_POST[$even]*2; 
$prijs     = $even+$prijs; 
$prijs1    = $prijs; 
$prijs2    = $aftrek-$prijs; 
    $totalin = number_format($aftrek,0,",",".");
    $totalinn= number_format($prijs1,0,",",".");

if($prijs1 <0){
print "<tr><td class=\"mainTxt\" align=\"center\"><table width=70 height=70 border=1 cellpadding=\"2\" cellspacing=\"0\" bordercolor=\"#000000\" bgColor=$bgcolor>
  <tr><td bordercolor=black align=center><b><font size=7 color=white>$getal</font></b></td></tr></table> <br>You put in a bet of <b>$$totalin</b> And won <b>\$0.</b></td></tr>";
}
else{
print "<tr><td class=\"mainTxt\" align=\"center\"><table width=70 height=70 border=1 cellpadding=\"2\" cellspacing=\"0\" bordercolor=\"#000000\" bgColor=$bgcolor>
  <tr><td bordercolor=black align=center><b><font size=7>$getal</font></b></td></tr></table> <br> You have bet a total of <b>$$totalin</b> And won <b>\$$totalinn</b></td></tr>";
}

if($prijs1 == $aftrek){ 
} 
elseif($prijs1 >0){ 
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$prijs1' WHERE `login`='$data->login'"); 
} 
else{ 
mysql_query("UPDATE `[casinoo]` SET `vw`=`vw`+'{$aftrek}' WHERE `spel`='2' AND `land`='{$data->land}'");  
mysql_query("UPDATE `[casinoo]` SET `bank`=`bank`+'{$aftrek}' WHERE `spel`='2' AND `land`='{$data->land}'");  
} 


$naam2                        = mysql_query("SELECT * FROM `[users]` WHERE `login`='$casino->owner'"); 
$ncash                        = mysql_result($naam2, 0, "bank"); 
$nscash = $casino->vw;
if($nscash-$prijs1 <0){ 
$land          = $land[$data->land]; 
$land1          = array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland","");
$landd          = $land1[$data->land];
mysql_query("UPDATE `[casinoo]` SET `bank`='0',`maximum`='0'"); 
mysql_query("UPDATE `[casinoo]` SET `owner`='$data->login' WHERE `land`='$data->land' AND `spel`='2'"); 
print "<tr><td class=\"mainTxt\" align=\"center\">The owner of the Casino Roulette refused to pay you...<br> Now the roulette table belongs to you</td></tr>"; 
exit;
} 
} 
} 

$casino       = mysql_query("SELECT * FROM `[casinoo]` WHERE `spel`='2' AND `land`='{$data->land}'"); ; 
    $casino       = mysql_fetch_object($casino);    
if($data->login == $casino->owner){ 
} 
else{ 
print <<<ENDHTML
<form method="post"> 
    <center> 
<table width=100%  align=center><tr><td class="mainTxt"><center>The Roulette Table is in possesion of $casino->owner and the maximum bet is \$$maxxx</td></tr></table>
<table width=100%  align=center>
        <tr> 
            <td align="middle" width="35%" class="mainTxt" border=0> 
                       <img src="images/gokken/roulette.jpg" border="0"></td> 
            <td align="middle" class="mainTxt"><input type="hidden" name="casino"> 
 <input type="hidden" size="2" value="1" name="x"> 
<table width=100% align=center >
                <tr> 
                    <td align="right">01:</td> 
                    <td><input size="5" name="1"></td> 
                    <td align="right">02:</td> 
                    <td><input size="5" name="2"></td> 
                    <td align="right">03:</td> 
                    <td><input size="5" name="3"></td> 
                    <td align="right">04:</td> 
                    <td><input size="5" name="4"></td> 
                </tr> 
                <tr> 
                    <td align="right">05:</td> 
                    <td><input size="5" name="5"></td> 
                    <td align="right">06:</td> 
                    <td><input size="5" name="6"></td> 
                    <td align="right">07:</td> 
                    <td><input size="5" name="7"></td> 
                    <td align="right">08:</td> 
                    <td><input size="5" name="8"></td> 
                </tr> 
                <tr> 
                    <td align="right">09:</td> 
                    <td><input size="5" name="9"></td> 
                    <td align="right">10:</td> 
                    <td><input size="5" name="10"></td> 
                    <td align="right">11:</td> 
                    <td><input size="5" name="11"></td> 
                    <td align="right">12:</td> 
                    <td><input size="5" name="12"></td> 
                </tr> 
                <tr> 
                    <td align="right">13:</td> 
                    <td><input size="5" name="13"></td> 
                    <td align="right">14:</td> 
                    <td><input size="5" name="14"></td> 
                    <td align="right">15:</td> 
                    <td><input size="5" name="15"></td> 
                    <td align="right">16:</td> 
                    <td><input size="5" name="16"></td> 
                </tr> 
                <tr> 
                    <td align="right">17:</td> 
                    <td><input size="5" name="17"></td> 
                    <td align="right">18:</td> 
                    <td><input size="5" name="18"></td> 
                    <td align="right">19:</td> 
                    <td><input size="5" name="19"></td> 
                    <td align="right">20:</td> 
                    <td><input size="5" name="20"></td> 
                </tr> 
                <tr> 
                    <td align="right">21:</td> 
                    <td><input size="5" name="21"></td> 
                    <td align="right">22:</td> 
                    <td><input size="5" name="22"></td> 
                    <td align="right">23:</td> 
                    <td><input size="5" name="23"></td> 
                    <td align="right">24:</td> 
                    <td><input size="5" name="24"></td> 
                </tr> 
                <tr> 
                    <td align="right">25:</td> 
                    <td><input size="5" name="25"></td> 
                    <td align="right">26:</td> 
                    <td><input size="5" name="26"></td> 
                    <td align="right">27:</td> 
                    <td><input size="5" name="27"></td> 
                    <td align="right">28:</td> 
                    <td><input size="5" name="28"></td> 
                </tr> 
                <tr> 
                    <td align="right">29:</td> 
                    <td><input size="5" name="29"></td> 
                    <td align="right">30:</td> 
                    <td><input size="5" name="30"></td> 
                    <td align="right">31:</td> 
                    <td><input size="5" name="31"></td> 
                    <td align="right">32:</td> 
                    <td><input size="5" name="32"></td> 
                </tr> 
                <tr> 
                    <td align="right">33:</td> 
                    <td><input size="5" name="33"></td> 
                    <td align="right">34:</td> 
                    <td><input size="5" name="34"></td> 
                    <td align="right">35:</td> 
                    <td><input size="5" name="35"></td> 
                    <td align="right">36:</td> 
                    <td><input size="5" name="36"></td> 
                </tr> 
                <tr> 
                </tr> 
                <tr> 
		      <td align="right">Red:</td>
		      <td><input size="5" name="r" value="{$_POST['r']}"></td>
		      <td align="right">Black:</td>
		      <td><input size="5" name="b" value="{$_POST['b']}"></td>
                    <td align="right">1-18:</td> 
                    <td><input size="5" name="eta"></td> 
                    <td align="right">19-36:</td> 
                    <td><input size="5" name="ntz"></td> 
                </tr> 
                <tr> 
                    <td align="right">25-36:</td> 
                    <td><input size="5" name="vtz"></td> 
                    <td align="right">1st Rij:</td> 
                    <td><input size="5" name="ek"></td> 
                    <td align="right">2nd Rij:</td> 
                    <td><input size="5" name="tk"></td> 
                    <td align="right">3rd Rij:</td> 
                    <td><input size="5" name="dk"></td> 
                </tr> 
                <tr> 
                    <td align="middle" colSpan="4"> 
                    <input type="submit" value="Spin that Shit" name="Gok">     <input type="reset"
value="Reset"></td> 
                </tr> 
                <tr> 
                    <td align="middle" colSpan="4">You have <b>$$jegeld</b> 
                    to gamble away...</td> 
                </tr> 
            </table> 
            </td> 
        </tr> 
    </table> 
    </center> 
</form> 
ENDHTML;
     
}
     
    } 
    ?> 
<table>
    </table> 
</body> 
</html>

<?PHP

// de site word sloom dus moeten we wel alles afsluiten..

mysql_close();

// zo dat was het dan weer voor vandaag..
?>