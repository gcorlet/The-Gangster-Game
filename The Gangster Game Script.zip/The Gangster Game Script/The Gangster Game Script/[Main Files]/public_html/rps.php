<?php
error_reporting(0);

 include("_include-config.php");
     include("_include-gevangenis.php");


  mysql_query("UPDATE `[users]` SET `online`=NOW(),`page`='SPS' WHERE `login`='{$data->login}'");

 if(!($_SESSION))
{ 
  header("Location: login.php");
}
 $begin = ($_GET['p'] >= 0) ? $_GET['p']*10 : 0;
echo'
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<table width=100%><form method=post>
<tr><td class=Subtitle>Rock Papier Scissors</tr></td>


<tr><td class=MainTxt>Welcome to the Casino Game: Rock, Paper, Scissors. <br />
Here you can start you own game or acccept a challenge. 
<br />
<br /><b>Start a game of RPS</b><br />

Bet: &nbsp; <input type=text name=inzet value="" size=6 max lenght=7>
<br /><br />
I choose &nbsp; Rock <input type="radio" name="action"  value="Rock" checked>&nbsp;
			 Scissors <input type="radio" name="action"  value="Scissors"> &nbsp;
			  Paper <input type="radio" name="action"  value="Paper">&nbsp; <br>
			  <br /><input type=submit name=papier value=Play! size=5> &nbsp;
</table></tr></td></form>';


if(isset($_POST['action']) && isset($_POST['inzet']) > 0 && isset($_POST['inzet']) != 0)
{
	if(!is_numeric($_POST['inzet']))
	{
	  echo '<table width=100%><tr><td class=Maintxt>Please start with a valid bet</tr></td></table>';
	  exit();
	}
	 if($data->bank < $_POST['inzet'])
	{
	 echo '<table width=100%><tr><td class=Maintxt>You dont have enough cash to place that bet!</b></tr></td></table>';
	 exit;
	}
	 if($_POST['inzet'] < 5000 OR $_POST['inzet'] > 10000000)
	{
	 echo '<table width=100%><tr><td class=Maintxt>The game has a minimum bet size of 5,000 and maximum of 9,999,999</b></tr></td></table>';
	 exit;
	}
	 else 
	 {			
	   mysql_query("INSERT INTO `[SPS]` ( `id` , `uitdager` , `aannemer` , `inzet` , `soort` ) VALUES ('', '".$data->login."', '', '".$_POST['inzet']."', '".$_POST['action']."');") or die(mysql_error());
	   mysql_query("UPDATE `[users]` SET `bank`=`bank`-'".$_POST['inzet']."' WHERE `login`='".$data->login."'") or die(mysql_error());
		 echo "<table width=100%><tr><td class=Maintxt>You have been added to the game and choose <b>".$_POST['action']."</b> The bet is <b>".$_POST['inzet']."</b></tr></td>
		       <meta http-equiv=Refresh content=3;url=RPS.php></table>";
	 }
}
if($_POST['submit'] && $_POST['action'] == "schaar" && $_POST['inzet'] > 0 && $_POST['inzet'] != 0)
{
	if(!is_numeric($_POST['inzet']))
	{
	  echo '<tr><td class=Maintxt>Please start with a valid bet</tr></td>';
	  exit();
	}
	 if($data->bank < $_POST['inzet'])
	{
	 echo '<tr><td class=Maintxt>You dont have enough cash to place that bet!</b></tr></td>';
	 exit;
	}
	 if($_POST['inzet'] < 5000 OR $_POST['inzet'] > 10000000)
	{
	 echo '<tr><td class=Maintxt>The game has a minimum bet size of 5,000 and maximum of 9,999,999</b></tr></td>';
	 exit;
	}
	 else 
	 {
	 mysql_query("INSERT INTO [SPS] ( id, uitdager , aannemer , inzet , soort ) VALUES ( '', '".$data->login."', '', '".$_POST['inzet']."', 'schaar');") or die(mysql_error());
	   mysql_query("UPDATE [users] SET bank=bank-'".$_POST['inzet']."' WHERE login=".$data->login) or die(mysql_error());
		 echo "<tr><td class=Maintxt>You have been added to the game and choose <b>scissors</b>. The bet is  <b>".$_POST['inzet']."</b></tr></td>
		       <meta http-equiv=Refresh content=3;url=RPS.php>";
	 }
}
if($_POST['submit'] && $_POST['action'] == "papier" && $_POST['inzet'] > 0 && $_POST['inzet'] != 0)
{
	if(!is_numeric($_POST['inzet']))
	{
	  echo '<tr><td class=Maintxt>Please start with a valid bet</tr></td>';
	  exit();
	}
	 if($data->bank < $_POST['inzet'])
	{
	 echo '<tr><td class=Maintxt>You dont have enough cash to place that bet!</b></tr></td>';
	 exit;
	}
	 if($_POST['inzet'] < 5000 OR $_POST['inzet'] > 10000000)
	{
	 echo '<tr><td class=Maintxt>The game has a minimum bet size of 5,000 and maximum of 9,999,999</b></tr></td>';
	 exit;
	}
	 else 
	 {
	 mysql_query("INSERT INTO [SPS] ( id, uitdager , aannemer , inzet , soort ) VALUES ( '', '".$data->login."', '', '".$_POST['inzet']."', 'papier');") or die(mysql_error());
	   mysql_query("UPDATE [users] SET bank=bank-'".$_POST['inzet']."' WHERE login=".$data->login) or die(mysql_error());
		 echo "<tr><td class=Maintxt>You have been added to the game and choose <b>paper</b>. The bet is <b>".$_POST['inzet']."</b></tr></td>
		       <meta http-equiv=Refresh content=3;url=RPS.php>";
	 }
}




echo "
<table width=70% align=center colspan=4>
<tr><td class=Subtitle colspan=3>RPS Game</tr></td>";

$dbres = mysql_query("SELECT * FROM `[SPS]`");
print "</table>\n\n<table width=70% align=center>\n <tr><td class=\"mainTxt\" align=\"center\">"; 

if(mysql_num_rows($dbres) <= 10) 
print "< 1 ></td></tr></table>\n"; 

else 
{ 
if($begin/10 == 0) 
print "<< "; 

else 
print '<a href="rps.php?s="'.$_GET['s'].'&q='.$_GET['q'].'&p='.
($begin/10-1) .'"> << </a> '; 


for($i=0; $i<mysql_num_rows($dbres)/10; $i++) 
{ 
print '<a href="rps.php?s='.$_GET['s'].'&q='.$_GET['q'].'&p='.$i.'">'.
($i+1) .'</a> '; 
} 

if($begin+10 >= mysql_num_rows($dbres)) 
print ">> "; 

else 
print '<a href=\"rps.php?s='.$_GET['s'].'&q='.$_GET['q'].'&p='.
($begin/10+1) .'"> >> </a>'; 
} 


$aHoeveel = mysql_query("SELECT `id` FROM `[SPS]`");
$niks     = mysql_num_rows($aHoeveel);    
if($niks == 0)
{
echo '<table width=70% align=center><tr><td class=Maintxt colspan=3>There are currently no populated games</tr></td>';
}
if(!isset($_POST['schaar']) && !isset($_POST['steen']) && !isset($_POST['papier']))
{
?>
</table><table width=70% align=center>


<tr>
        <td class=subTitle  align=center>
        <b>#</b></td>
        <td class=subTitle align=center>
        <b>Starter</b></td>
        <td class=subTitle align=center>
        <b>Bet</b></td>
      </tr><?php
		  $aWat         = mysql_query("SELECT * FROM `[SPS]` LIMIT $begin, 10");
		  while($db     = mysql_fetch_assoc($aWat))
		  
		{ $soort = $db['soort']
		?><form method=post action=""> 
		<tr>
		  <td class=Maintxt><input type="radio" name="id" value="<?=$db['id']?>"></td>
		  <td class=MainTxt align="center"><?=$db['uitdager']?></td>
		  <td class=MainTxt><?=number_format($db['inzet'])?></td>
		</tr><?php } ?>	
		  </table><table width=70% align=center><td class=Maintxt colspan=4><input type="submit" name="steen" value="Rock">
						  <input type="submit" name="schaar" value="scissors">
						  <input type="submit" name="papier" value="papper"></form></td>
		</tr>
		<?php
		

}  
else {
		     $no         = mysql_query("SELECT * FROM `[SPS]` WHERE `id` = '".$_POST['id']."' LIMIT $begin, 10");
		  	 $ab   	     = mysql_fetch_assoc($no);
			 $soort      = $ab['soort'];
			 $inzet      = $ab['inzet'];
			 $uitdager   = $ab['uitdager'];
			 
			 if($ab['uitdager'] == "$data->login")
       {
         echo '<tr><td class=MainTxt colspan=3><b><font color=red>You cannot play yourself</b></font></tr></td><meta http-equiv=Refresh content=3;url=RPS.php>';
         exit;
       }
	    if($ab['inzet'] > "$data->bank")
       {
         echo '<tr><td class=MainTxt>You dont have enough cash</tr></td><meta http-equiv=Refresh content=3;url=RPS.php>';
         exit;
	    }
			 
if($soort == "schaar" && isset($_POST['schaar'])){
	mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Draw','Its a draw! You both lose your money!')") or die(mysql_error());
        mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
	echo '<tr><td class=Maintxt colspan=3>Its a draw! You both lose your money!</tr></td>';
	exit;
	}
	if($soort == "papier" && isset($_POST['papier'])){
	mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Draw','Its a draw! You both lose your money!')") or die(mysql_error());
        mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
	echo '<tr><td class=Maintxt colspan=3>Its a draw! You both lose your money!</tr></td>';
	exit;
	}
	if($soort == "steen" && isset($_POST['steen'])){ 
	mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Draw','Its a draw! You both lose your money!')") or die(mysql_error());
        mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
	echo '<tr><td class=Maintxt colspan=3>Its a draw! You both lose your money!</tr></td>';
	exit;
	}
	
  //geen gelijkspelle nu winaar bepalen

 //steen > schaar
 //papier > steen
 //schaar > papier
 
 if($soort == "steen" && isset($_POST['schaar']))
 {
 	   $winst = $inzet; //uitdaher wint
 $winmoney = round($ab['inzet']/5);
 $gewonnen = number_format($winmoney);
       mysql_query("UPDATE `[users]` SET `bank`=`bank`-'$inzet' WHERE `login`='".$data->login."'") or die(mysql_error());
       mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winmoney' WHERE `login`='".$uitdager."'") or die(mysql_error());
    mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winst' WHERE `login`='".$uitdager."'") or die(mysql_error());
       mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Win','You have won Rock, Paper, Scissors! You have received a profit of [b]".$winst."[/b] from [b]".$data->login."[/b].')") or die(mysql_error());
       mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
       echo '<tr><td class=Maintxt colspan=3>You have lost to <b>'.$uitdager.'</b>, You lost <b>'.number_format($inzet).'</b></tr></td><meta http-equiv=Refresh content=3;url=rps.php>';
       exit;
 }
 elseif($soort == "steen" && isset($_POST['papier']))
 {
       $winst = $inzet; //aanemer wint
 $winmoney = round($ab['inzet']/5);
 $gewonnen = number_format($winmoney);
       mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winmoney' WHERE `login`='".$data->login."'") or die(mysql_error());
    mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winst' WHERE `login`='".$data->login."'") or die(mysql_error());
       mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Lost','You have lost Rock, Paper, Scissors! You have lost [b]".$inzet."[/b]')") or die(mysql_error());
       mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
       echo '<tr><td class=Maintxt colspan=3>You have beaten <b>'.$uitdager.'</b>, You have won <b>'.$gewonnen.'</b></tr></td><meta http-equiv=Refresh content=3;url=RPS.php>';
       exit;
 }
 elseif($soort == "papier" && isset($_POST['steen']))
 {
 $winst = $inzet; //uitdaher wint
 $winmoney = round($ab['inzet']/5);
 $gewonnen = number_format($winmoney);
       mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winmoney' WHERE `login`='".$uitdager."'") or die(mysql_error());
mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winst' WHERE `login`='".$uitdager."'") or die(mysql_error());
        mysql_query("UPDATE `[users]` SET `bank`=`bank`-'$inzet' WHERE `login`='".$data->login."'") or die(mysql_error());
       mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Win','You have won Rock, Paper, Scissors! You have received a profit of [b]".$winst."[/b]')") or die(mysql_error());
       mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
       echo '<tr><td class=Maintxt colspan=3>You have lost to <b>'.$uitdager.'</b>, You lost <b>'.number_format($inzet).'</tr></td><meta http-equiv=Refresh content=3;url=RPS.php>';
       exit; }
 elseif($soort == "papier" && isset($_POST['schaar']))
 {
 $winst = $inzet; //aanemer wint
 $winmoney = round($ab['inzet']/5);
 $gewonnen = number_format($winmoney);
  mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winmoney' WHERE `login`='".$data->login."'") or die(mysql_error());
    mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winst' WHERE `login`='".$data->login."'") or die(mysql_error());
       mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Lost','You have lost Rock, Paper, Scissors! You have lost [b]".$inzet."[/b]')") or die(mysql_error());
       mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
       echo '<tr><td class=Maintxt colspan=3>You have beaten <b>'.$uitdager.'</b>, You have won <b>'.$gewonnen.'</tr></td><meta http-equiv=Refresh content=3;url=RPS.php>';
       exit;
 }
 elseif($soort == "schaar" && isset($_POST['papier']))
 {
 $winst = $inzet; //uitdaher wint
 $winmoney = round($ab['inzet']/5);
 $gewonnen = number_format($winmoney);
       mysql_query("UPDATE `[users]` SET `bank`=`bank`-'$inzet' WHERE `login`='".$data->login."'") or die(mysql_error());
       mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winmoney' WHERE `login`='".$uitdager."'") or die(mysql_error());
       mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winst' WHERE `login`='".$uitdager."'") or die(mysql_error());
       mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Win','You have won Rock, Paper, Scissors! You have received a profit of [b]".$winst."[/b]')") or die(mysql_error());
       mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
       echo '<tr><td class=Maintxt colspan=3>You have lost to <b>'.$uitdager.'</b>, You lost <b>'.number_format($inzet).'</b> verloren.</tr></td><meta http-equiv=Refresh content=3;url=RPS.php>';
       exit;  
 }
 elseif($soort == "schaar" && isset($_POST['steen']))
 {
 $winst = $inzet; //aanemer wint
 $winmoney = round($ab['inzet']/5);
 $gewonnen = number_format($winmoney);
       mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winmoney' WHERE `login`='".$data->login."'") or die(mysql_error());
        mysql_query("UPDATE `[users]` SET `bank`=`bank`+'$winst' WHERE `login`='".$data->login."'") or die(mysql_error());
       mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) values(NOW(),'Casino', '".$uitdager."','Lost','You have lost Rock, Paper, Scissors! You have lost [b]".$inzet."[/b]')") or die(mysql_error());
       mysql_query("DELETE FROM `[SPS]` WHERE `id`=".$_POST['id']) or die(mysql_error());
       echo '<tr><td class=Maintxt colspan=3>You have beaten <b>'.$uitdager.'</b>, You have won <b>'.$gewonnen.'</tr></td><meta http-equiv=Refresh content=3;url=RPS.php>';
       exit;
 }
 

}