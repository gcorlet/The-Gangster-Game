<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);

$boot1	                  	= array("NONE","Canoe","Rubber Dingy","Cigarette Boat","Sailing Boat","Fishermans Boat","yacht");
$boot = $boot1[$data->boot];
$boot2 = $data->boot;
$bootwapens = $data->m60b+$data->krieg550b+$data->sig552b+$data->m16b+$data->ak47b+$data->c4b;

$oppakken = rand(1,8);

if($boot2 == 0) {
$maxwapens = 0;
$prijs = 0;
$tijdvaren = 0;
} else if($boot2 == 1) {
$maxwapens = 15;
$prijs = 5000;
$tijdvaren = 1800;
} else if($boot2 == 2) {
$maxwapens = 35;
$prijs = 15000;
$tijdvaren = 1500;
} else if($boot2 == 3) {
$maxwapens = 100;
$prijs = 50000;
$tijdvaren = 1200;
} else if($boot2 == 4) {
$maxwapens = 300;
$prijs = 400000;
$tijdvaren = 900;
} else if($boot2 == 5) {
$maxwapens = 1000;
$prijs = 1000000;
$tijdvaren = 600;
} else if($boot2 == 6) {
$maxwapens = 6000;
$prijs = 5000000;
$tijdvaren = 600;
}

$m60b 		= $data->m60b;
$krieg550b 	= $data->krieg550b;
$sig552b 	= $data->sig552b;
$m16b 		= $data->m16b;
$ak47b 		= $data->ak47b;
$c4b 		= $data->c4b;

?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">
<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Weapons Handling Options</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\" class='btn btn-info'>Select a Weapons Handling Option</option>
<option value=\"sail.php\" class='btn btn-info'>Sail</option>
<option value=\"wepshandling.php\" class='btn btn-info'>Weapons Handling</option>
<option value=\"loading.php\" class='btn btn-info'>loading</option>
</select>
</table>
";
}
?> 

<BODY onLoad="movein()">
<table align="center" width="50%">
<tr><td class="subTitle" colspan="2">Sail</td></tr>
<?
	  $data2            = mysql_query("SELECT *,UNIX_TIMESTAMP(`vaartijd`) AS `vaartijd`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
	  $data1            = mysql_fetch_object($data2);
  $verschil1             = $data1->vaartijd + $tijdvaren - time() - 3600;
  $verschil              = date("H:i:s", "$verschil1");
	if($data1->vaartijd + $tijdvaren > time()){
?>
<tr><td class="mainTxt" colspan="2" align="center">You may go Sail again in <?=$verschil?> </td></tr>
<tr><td class="mainTxt" width="50%">Canoe:</td><td class="mainTxt">30 Minutes</td></tr>
<tr><td class="mainTxt" width="50%">Rubber Dingy:</td><td class="mainTxt">25 Minutes</td></tr>
<tr><td class="mainTxt" width="50%">Cigarette Boat:</td><td class="mainTxt">20 Minutes</td></tr>
<tr><td class="mainTxt" width="50%">Sailing Boat:</td><td class="mainTxt">15 Minutes</td></tr>
<tr><td class="mainTxt" width="50%">Fishermans Boat:</td><td class="mainTxt">10 Minutes</td></tr>
<tr><td class="mainTxt" width="50%">Yacht:</td><td class="mainTxt">10 Minutes</td></tr>
<?
exit;
}
?>
<?
if($data->boot == 0) {
?>
<tr><td class="mainTxt" colspan="2">
You cannot sail with no boat. You dont have a boat.<br>

</td></tr>
<form method="post">
<tr>
<td class="mainTxt" align="center"><b>Canoe</b></td>
<td class="mainTxt" align="center"><b>Rubber Dingy</b></td>
<tr>
<td class="mainTxt" align="center"><img src="images/boten/boot1.jpg" width="194" height="136"></td>
<td class="mainTxt" align="center"><img src="images/boten/boot2.jpg" width="194" height="136"></td>
</tr>
<tr>
<td class="mainTxt" align="center">Max. amount of Weapons: 15</td>
<td class="mainTxt" align="center">Max. amount of Weapons: 35</td>
</tr>
<tr>
<td class="mainTxt" align="center">Wait time: 30 minutes</td>
<td class="mainTxt" align="center">Wait time: 25 minutes</td>
</tr>
<tr>
<td class="mainTxt" align="center">Price: ;5.000</td>
<td class="mainTxt" align="center">Price: ;15.000</td>
</tr>
<tr>
<td class="mainTxt" align="center"><input value="1" class='btn btn-info' name="boot" type="radio" checked></td>
<td class="mainTxt" align="center"><input value="2"  class='btn btn-info' name="boot" type="radio"></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td class="mainTxt" align="center"><b>Cigarette Boat</b></td>
<td class="mainTxt" align="center"><b>Sailing Boat</b></td>
<tr>
<tr>
<td class="mainTxt" align="center"><img src="images/boten/boot3.jpg" width="194" height="136"></td>
<td class="mainTxt" align="center"><img src="images/boten/boot4.jpg" width="194" height="136"></td>
</tr>
<tr>
<td class="mainTxt" align="center">Max. amount of Weapons: 100</td>
<td class="mainTxt" align="center">Max. amount of Weapons: 300</td>
</tr>
<tr>
<td class="mainTxt" align="center">Wait time: 20 minutes</td>
<td class="mainTxt" align="center">Wait time: 15 minutes</td>
</tr>
<tr>
<td class="mainTxt" align="center">Price: ;50.000</td>
<td class="mainTxt" align="center">Price: ;400.000</td>
</tr>
<tr>
<td class="mainTxt" align="center"><input value="3" class='btn btn-info' name="boot" type="radio"></td>
<td class="mainTxt" align="center"><input value="4" class='btn btn-info' name="boot" type="radio"></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td class="mainTxt" align="center"><b>Fishermans Boat</b></td>
<td class="mainTxt" align="center"><b>Yacht</b></td>
<tr>
<tr>
<td class="mainTxt" align="center"><img src="images/boten/boot5.jpg" width="194" height="136"></td>
<td class="mainTxt" align="center"><img src="images/boten/boot6.jpg" width="194" height="136"></td>
</tr>
<tr>
<td class="mainTxt" align="center">Max. amount of Weapons: 1.000</td>
<td class="mainTxt" align="center">Max. amount of Weapons: 6.000</td>
</tr>
<tr>
<td class="mainTxt" align="center">Price: ;1.000.000</td>
<td class="mainTxt" align="center">Price: ;5.000.000</td>
</tr>
<tr>
<td class="mainTxt" align="center">Wait time: 10 minutes</td>
<td class="mainTxt" align="center">Wait time: 10 minutes</td>
</tr>
<tr>
<td class="mainTxt" align="center"><input value="5" class='btn btn-info' name="boot" type="radio"></td>
<td class="mainTxt" align="center"><input value="6" class='btn btn-info' name="boot" type="radio"></td>
</tr>
<tr><td class="mainTxt" colspan="2" align="center"><input type="submit" class='btn btn-info' value="Purchase" name="koopboot"></td></tr>
</form>
<?
} else if($data->eilanden != 1) {
if($data->boot == 1) {
?>
<tr><td class="mainTxt" align="center" colspan="2"><img src="images/boten/boot1.jpg"></td></tr>
<?
}
if($data->boot == 2) {
?>
<tr><td class="mainTxt" align="center" colspan="2"><img src="images/boten/boot2.jpg"></td></tr>
<?
}
if($data->boot == 3) {
?>
<tr><td class="mainTxt" align="center" colspan="2"><img src="images/boten/boot3.jpg"></td></tr>
<?
}
if($data->boot == 4) {
?>
<tr><td class="mainTxt" align="center" colspan="2"><img src="images/boten/boot4.jpg"></td></tr>
<?
}
if($data->boot == 5) {
?>
<tr><td class="mainTxt" align="center" colspan="2"><img src="images/boten/boot5.jpg"></td></tr>
<?
}
if($data->boot == 6) {
?>
<tr><td class="mainTxt" align="center" colspan="2"><img src="images/boten/boot6.jpg"></td></tr>
<?
}
?>
<tr><td class="mainTxt">Boat:</td><td class="mainTxt"><?=$boot?></td></tr>
<tr><td class="mainTxt">Max. Weapons:</td><td class="mainTxt"><?=$maxwapens?></td></tr>
<tr><td class="mainTxt">Weapons on the boat:</td><td class="mainTxt"><?=$bootwapens?></td></tr>
<tr><td class="mainTxt">Bought for <?=$prijs?>:</td><td class="mainTxt"><form method="POST"><input type="submit" value="Sell" name="verkoopboot"></form></td></tr>
<tr><td class="mainTxt" colspan="2">Do you want to sell to the islands?</td></tr>
<form method="POST">
<tr><td class="mainTxt" colspan="2" align="center"><input type="submit" class='btn btn-info' name="naareilanden" value="Go"></td></tr>
</form>
<?
} else if($data->eilanden == 1) {
?>
<tr><td class="mainTxt">Boat:</td><td class="mainTxt"><?=$boot?></td></tr>
<tr><td class="mainTxt">Max. Weapons:</td><td class="mainTxt"><?=$maxwapens?></td></tr>
<tr><td class="mainTxt">Weapons on the Boat:</td><td class="mainTxt"><?=$bootwapens?></td></tr>
<tr><td class="mainTxt" colspan="2">Do you want to sail back to the main island?</td></tr>
<form method="POST">
<tr><td class="mainTxt" colspan="2" align="center"><input type="submit" class='btn btn-info' name="naarvasteland" value="Go"></td></tr>
</form>
<?
}
?>
<?
if(isset($_POST['verkoopboot'])){
mysql_query("UPDATE `[users]` SET `boot`='0', `cash`=`cash`+$prijs WHERE `login`='$data->login'");
    mysql_query("UPDATE `[users]` SET `m60b`='0',`krieg550b`='0',`sig552b`='0',`m16b`='0',`ak47b`='0',`c4b`='0' WHERE `login`='{$data->login}'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You have sold your boat for ;$prijs.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',600)</script></td></tr>";
}

if(isset($_POST['koopboot'])){
	$boot         = $_POST['boot'];
if($boot == 1){
if($data->cash < 5000) {
print "<tr><td class=\"mainTxt\" colspan=\"2\">You dont have enough cash on you.</td></tr>";
} else {
mysql_query("UPDATE `[users]` SET `boot`='1', `cash`=`cash`-5000 WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You have bought a canoe for ;5.000.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',600)</script></td></tr>";
}
}
if($boot == 2){
if($data->cash < 15000) {
print "<tr><td class=\"mainTxt\" colspan=\"2\">You dont have enough cash on you.</td></tr>";
} else {
mysql_query("UPDATE `[users]` SET `boot`='2', `cash`=`cash`-15000 WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You have bought a rubber dingy for ;15.000.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',600)</script></td></tr>";
}
}
if($boot == 3){
if($data->cash < 50000) {
print "<tr><td class=\"mainTxt\" colspan=\"2\">You dont have enough cash on you.</td></tr>";
} else {
mysql_query("UPDATE `[users]` SET `boot`='3', `cash`=`cash`-50000 WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You have bought a Cigerette Boat for ;50.000.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',600)</script></td></tr>";
}
}
if($boot == 4){
if($data->cash < 400000) {
print "<tr><td class=\"mainTxt\" colspan=\"2\">You dont have enough cash on you.</td></tr>";
} else {
mysql_query("UPDATE `[users]` SET `boot`='4', `cash`=`cash`-400000 WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You have bought a Sailing Boat for ;300.000.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',600)</script></td></tr>";
}
}
if($boot == 5){
if($data->cash < 1000000) {
print "<tr><td class=\"mainTxt\" colspan=\"2\">You dont have enough cash on you.</td></tr>";
} else {
mysql_query("UPDATE `[users]` SET `boot`='5', `cash`=`cash`-1000000 WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You have bought a Fishermans Boat for ;1.000.000.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',600)</script></td></tr>";
}
}
if($boot == 6){
if($data->cash < 5000000) {
print "<tr><td class=\"mainTxt\" colspan=\"2\">You dont have enough cash on you.</td></tr>";
} else {
mysql_query("UPDATE `[users]` SET `boot`='6', `cash`=`cash`-5000000 WHERE `login`='$data->login'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You have bought a Yacht for ;6.000.000.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',600)</script></td></tr>";
}
}

}

  if(isset($_POST['naareilanden'])) {
    mysql_query("UPDATE `[users]` SET `vaartijd`=NOW(), `eilanden`='1' WHERE `login`='{$data->login}'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You are now on the islands.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',500)</script></td></tr>";
}

  if(isset($_POST['naarvasteland'])) {
    mysql_query("UPDATE `[users]` SET `eilanden`='0' WHERE `login`='{$data->login}'");
if($bootwapens > 0 AND $oppakken == 5) {
    mysql_query("UPDATE `[users]` SET `vaartijd`=NOW(), `m60b`='0',`krieg550b`='0',`sig552b`='0',`m16b`='0',`ak47b`='0',`c4b`='0' WHERE `login`='{$data->login}'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You are wanted. The coast watched you smuggle the weapons out.</td></tr>";
print "<tr><td class=\"mainTxt\" colspan=\"2\">You are now on the mainland.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',1200)</script></td></tr>";
} else {
    mysql_query("UPDATE `[users]` SET `vaartijd`=NOW(), `m60v`=`m60v`+'$m60b' WHERE `login`='{$data->login}'");
    mysql_query("UPDATE `[users]` SET `krieg550v`=`krieg550v`+'$krieg550b' WHERE `login`='{$data->login}'");
    mysql_query("UPDATE `[users]` SET `sig552v`=`sig552v`+'$sig552b' WHERE `login`='{$data->login}'");
    mysql_query("UPDATE `[users]` SET `m16v`=`m16v`+'$m16b' WHERE `login`='{$data->login}'");
    mysql_query("UPDATE `[users]` SET `ak47v`=`ak47v`+'$ak47b' WHERE `login`='{$data->login}'");
    mysql_query("UPDATE `[users]` SET `c4v`=`c4v`+'$c4b' WHERE `login`='{$data->login}'");
    mysql_query("UPDATE `[users]` SET `m60b`='0',`krieg550b`='0',`sig552b`='0',`m16b`='0',`ak47b`='0',`c4b`='0' WHERE `login`='{$data->login}'");
print "<tr><td class=\"mainTxt\" colspan=\"2\">You are now on the mainland.<script language=\"javascript\">setTimeout('self.window.location.href=\"sail.php\"',500)</script></td></tr>";
}
}

?>
</table>
</body>
</html>