<?php
error_reporting(0);

include("_include-config.php");
    include("_include-gevangenis.php");

mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
?>

<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<script language="javascript">
	function showPrize(id,what) {
	document.getElementById(id).src = what;
	}
</script>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>
<?php

	if(isset($_POST['submit'])){

?>

<form method="post">
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="3"><b>Scratch and Win</b></td>
	</tr>
	<tr>
		<td class="mainTxt" width="600" align="center" colspan="2">

<?php

		if($data->cash < 10000){

		echo "You dont have enough cash.";

		} else {

		mysql_query("UPDATE `[users]` SET `cash`=`cash`-'10000' WHERE `login`='{$data->login}'");
		$worl1	=	mt_rand(1,2);

			if($worl1 == 1){
			$worl	=	mt_rand(1,2);
			} else {
			$worl	=	0;
			}

			if($worl == 1){
			$prijs1	=	mt_rand(1,100);

				if($prijs1 >= 1 && $prijs1 <= 54){
				$prijs	=	"&#8364;5.000,-";
				$prijs1	=	"5000";
				} else  if($prijs1 >= 55 && $prijs1 <= 84){
				$prijs	=	"&#8364;50.000,-";
				$prijs1	=	"50000";
				} else  if($prijs1 >= 85 && $prijs1 <= 89){
				$prijs	=	"&#8364;100.000,-";
				$prijs1	=	"100000";
				} else  if($prijs1 >= 90 && $prijs1 <= 95){
				$prijs	=	"50 kogels";
				$prijs1	=	"50kogels";
				} else  if($prijs1 >= 96 && $prijs1 <= 99){
				$prijs	=	"100 kogels";
				$prijs1	=	"100kogels";
				} else  if($prijs1 === 100){
				$prijs	=	"&#8364;1.000.000,-";
				$prijs1	=	"1000000";
				}

			$prijs2	=	rand(1,5);
			$prijs3	=	rand(1,5);
			$prijs4	=	rand(1,5);

				if($prijs == "&#8364;5.000,-"){
					if($prijs2 == 1){
					$prijs2	= "50000";
					} else if($prijs2 == 2){
					$prijs2 = "100000";
					} else if($prijs2 == 3){
					$prijs2 = "1000000";
					} else if($prijs2 == 4){
					$prijs2 = "50kogels";
					} else if($prijs2 == 5){
					$prijs2 = "100kogels";
					}
				} else if($prijs == "&#8364;50.000,-"){
					if($prijs2 == 1){
					$prijs2 = "5000";
					} else if($prijs2 == 2){
					$prijs2 = "100000";
					} else if($prijs2 == 3){
					$prijs2 = "1000000";
					} else if($prijs2 == 4){
					$prijs2 = "50kogels";
					} else if($prijs2 == 5){
					$prijs2 = "100kogels";
					}
				} else if($prijs == "&#8364;100.000,-"){
					if($prijs2 == 1){
					$prijs2 = "5000";
					} else if($prijs2 == 2){
					$prijs2 = "50000";
					} else if($prijs2 == 3){
					$prijs2 = "1000000";
					} else if($prijs2 == 4){
					$prijs2 = "50kogels";
					} else if($prijs2 == 5){
					$prijs2 = "100kogels";
					}
				} else if($prijs == "&#8364;1.000.000,-"){
					if($prijs2 == 1){
					$prijs2 = "5000";
					} else if($prijs2 == 2){
					$prijs2 = "50000";
					} else if($prijs2 == 3){
					$prijs2 = "100000";
					} else if($prijs2 == 4){
					$prijs2 = "50kogels";
					} else if($prijs2 == 5){
					$prijs2 = "100kogels";
					}
				} else if($prijs == "50 kogels"){
					if($prijs2 == 1){
					$prijs2 = "5000";
					} else if($prijs2 == 2){
					$prijs2 = "50000";
					} else if($prijs2 == 3){
					$prijs2 = "100000";
					} else if($prijs2 == 4){
					$prijs2 = "1000000";
					} else if($prijs2 == 5){
					$prijs2 = "100kogels";
					}
				} else if($prijs == "100 kogels"){
					if($prijs2 == 1){
					$prijs2 = "5000";
					} else if($prijs2 == 2){
					$prijs2 = "50000";
					} else if($prijs2 == 3){
					$prijs2 = "100000";
					} else if($prijs2 == 4){
					$prijs2 = "1000000";
					} else if($prijs2 == 5){
					$prijs2 = "50kogels";
					}
				}
				if($prijs == "&#8364;5.000,-"){
					if($prijs3 == 1){
					$prijs3 = "50000";
					} else if($prijs3 == 2){
					$prijs3 = "100000";
					} else if($prijs3 == 3){
					$prijs3 = "1000000";
					} else if($prijs3 == 4){
					$prijs3 = "50kogels";
					} else if($prijs3 == 5){
					$prijs3 = "100kogels";
					}
				} else if($prijs == "&#8364;50.000,-"){
					if($prijs3 == 1){
					$prijs3 = "5000";
					} else if($prijs3 == 2){
					$prijs3 = "100000";
					} else if($prijs3 == 3){
					$prijs3 = "1000000";
					} else if($prijs3 == 4){
					$prijs3 = "50kogels";
					} else if($prijs3 == 5){
					$prijs3 = "100kogels";
					}
				} else if($prijs == "&#8364;100.000,-"){
					if($prijs3 == 1){
					$prijs3 = "5000";
					} else if($prijs3 == 2){
					$prijs3 = "50000";
					} else if($prijs3 == 3){
					$prijs3 = "1000000";
					} else if($prijs2 == 4){
					$prijs3 = "50kogels";
					} else if($prijs3 == 5){
					$prijs3 = "100kogels";
					}
				} else if($prijs == "&#8364;1.000.000,-"){
					if($prijs3 == 1){
					$prijs3 = "5000";
					} else if($prijs3 == 2){
					$prijs3 = "50000";
					} else if($prijs3 == 3){
					$prijs3 = "100000";
					} else if($prijs3 == 4){
					$prijs3 = "50kogels";
					} else if($prijs3 == 5){
					$prijs3 = "100kogels";
					}
				} else if($prijs == "50 kogels"){
					if($prijs3 == 1){
					$prijs3 = "5000";
					} else if($prijs3 == 2){
					$prijs3 = "50000";
					} else if($prijs3 == 3){
					$prijs3 = "100000";
					} else if($prijs3 == 4){
					$prijs3 = "1000000";
					} else if($prijs3 == 5){
					$prijs3 = "100kogels";
					}
				} else if($prijs == "100 kogels"){
					if($prijs3 == 1){
					$prijs3 = "5000";
					} else if($prijs3 == 2){
					$prijs3 = "50000";
					} else if($prijs3 == 3){
					$prijs3 = "100000";
					} else if($prijs3 == 4){
					$prijs3 = "1000000";
					} else if($prijs3 == 5){
					$prijs3 = "50kogels";
					}
				}
				if($prijs3 == "5000"){
					if($prijs4 == 1){
					$prijs4 = "50000";
					} else if($prijs4 == 2){
					$prijs4 = "100000";
					} else if($prijs4 == 3){
					$prijs4 = "1000000";
					} else if($prijs4 == 4){
					$prijs4 = "50kogels";
					} else if($prijs4 == 5){
					$prijs4 = "100kogels";
					}
				} else if($prijs3 == "50000"){
					if($prijs4 == 1){
					$prijs4 = "5000";
					} else if($prijs4 == 2){
					$prijs4 = "100000";
					} else if($prijs4 == 3){
					$prijs4 = "1000000";
					} else if($prijs4 == 4){
					$prijs4 = "50kogels";
					} else if($prijs4 == 5){
					$prijs4 = "100kogels";
					}
				} else if($prijs3 == "100000"){
					if($prijs4 == 1){
					$prijs4 = "5000";
					} else if($prijs4 == 2){
					$prijs4 = "50000";
					} else if($prijs4 == 3){
					$prijs4 = "1000000";
					} else if($prijs4 == 4){
					$prijs4 = "50kogels";
					} else if($prijs4 == 5){
					$prijs4 = "100kogels";
					}
				} else if($prijs3 == "1000000"){
					if($prijs4 == 1){
					$prijs4 = "5000";
					} else if($prijs4 == 2){
					$prijs4 = "50000";
					} else if($prijs4 == 3){
					$prijs4 = "100000";
					} else if($prijs4 == 4){
					$prijs4 = "50kogels";
					} else if($prijs4 == 5){
					$prijs4 = "100kogels";
					}
				} else if($prijs3 == "50kogels"){
					if($prijs4 == 1){
					$prijs4 = "5000";
					} else if($prijs4 == 2){
					$prijs4 = "50000";
					} else if($prijs4 == 3){
					$prijs4 = "100000";
					} else if($prijs4 == 4){
					$prijs4 = "1000000";
					} else if($prijs4 == 5){
					$prijs4 = "100kogels";
					}
				} else if($prijs3 == "100kogels"){
					if($prijs4 == 1){
					$prijs4 = "5000";
					} else if($prijs4 == 2){
					$prijs4 = "50000";
					} else if($prijs4 == 3){
					$prijs4 = "100000";
					} else if($prijs4 == 4){
					$prijs4 = "1000000";
					} else if($prijs3 == 5){
					$prijs4 = "50kogels";
					}
				}

			$a1	=	$prijs1;
			$a2	=	$prijs1;
			$a3	=	$prijs2;
			$a4	=	$prijs3;
			$a5	=	$prijs1; 
			$a6	=	$prijs4;

				if($prijs == "&#8364;5.000,-"){
				mysql_query("UPDATE `krassen` SET `a`=`a`+'1'");
				mysql_query("UPDATE `[users]` SET `cash`=`cash`+'5000' WHERE `login`='{$data->login}'");
				} else if($prijs == "&#8364;50.000,-"){
				mysql_query("UPDATE `krassen` SET `b`=`b`+'1'");
				mysql_query("UPDATE `[users]` SET `cash`=`cash`+'50000' WHERE `login`='{$data->login}'");
				} else if($prijs == "&#8364;100.000,-"){
				mysql_query("UPDATE `krassen` SET `c`=`c`+'1'");
				mysql_query("UPDATE `[users]` SET `cash`=`cash`+'100000' WHERE `login`='{$data->login}'");
				} else if($prijs == "&#8364;1.000.000,-"){
				mysql_query("UPDATE `krassen` SET `d`=`d`+'1'");
				mysql_query("UPDATE `[users]` SET `cash`=`cash`+'1000000' WHERE `login`='{$data->login}'");
				} else if($prijs == "50 kogels"){
				mysql_query("UPDATE `krassen` SET `e`=`e`+'1'");
				mysql_query("UPDATE `[users]` SET `kogels`=`kogels`+'50' WHERE `login`='{$data->login}'");
				} else if($prijs == "100 kogels"){
				mysql_query("UPDATE `krassen` SET `f`=`f`+'1'");
				mysql_query("UPDATE `[users]` SET `kogels`=`kogels`+'100' WHERE `login`='{$data->login}'");
				}
			} else {
			$verlies	=	rand(1,12);
				if($verlies == 1){
				$a1 = "5000";
				$a2 = "1000000";
				$a3 = "50000";
				$a4 = "5000";
				$a5 = "1000000";
				$a6 = "100000";
				} else if($verlies == 2){
				$a1 = "5000";
				$a2 = "50kogels";
				$a3 = "50kogels";
				$a4 = "50000";
				$a5 = "100kogels";
				$a6 = "50000";
				} else if($verlies == 3){
				$a1 = "100kogels";
				$a2 = "100000";
				$a3 = "100000";
				$a4 = "50000";
				$a5 = "50kogels";
				$a6 = "1000000";
				} else if($verlies == 4){
				$a1 = "5000";
				$a2 = "50kogels";
				$a3 = "50000";
				$a4 = "50kogels";
				$a5 = "5000";
				$a6 = "1000000";
				} else if($verlies == 5){
				$a1 = "50000";
				$a2 = "50000";
				$a3 = "100000";
				$a4 = "5000";
				$a5 = "50kogels";
				$a6 = "5000";
				} else if($verlies == 6){
				$a1 = "100kogels";
				$a2 = "5000";
				$a3 = "100kogels";
				$a4 = "50000";
				$a5 = "1000000";
				$a6 = "50kogels";
				} else if($verlies == 7){
				$a1 = "100000";
				$a2 = "100kogels";
				$a3 = "1000000";
				$a4 = "50000";
				$a5 = "50000";
				$a6 = "50kogels";
				} else if($verlies == 8){
				$a1 = "50000";
				$a2 = "100kogels";
				$a3 = "5000";
				$a4 = "5000";
				$a5 = "50kogels";
				$a6 = "1000000";
				} else if($verlies == 9){
				$a1 = "50kogels";
				$a2 = "1000000";
				$a3 = "1000000";
				$a4 = "50000";
				$a5 = "100kogels";
				$a6 = "100kogels";
				} else if($verlies == 10){
				$a1 = "100kogels";
				$a2 = "5000";
				$a3 = "100kogels";
				$a4 = "100000";
				$a5 = "100000";
				$a6 = "50kogels";
				} else if($verlies == 11){
				$a1 = "100kogels";
				$a2 = "50000";
				$a3 = "50kogels";
				$a4 = "50kogels";
				$a5 = "5000";
				$a6 = "1000000";
				} else if($verlies == 12){
				$a1 = "50kogels";
				$a2 = "50000";
				$a3 = "50000";
				$a4 = "1000000";
				$a5 = "1000000";
				$a6 = "100000";
				}

			}


?>

<table width="500" height="150" background="images/gokken/krassen/krassen.jpg" align="center" cellpadding="0" cellspacing="0">
	<tr>
		<td width="550" height="150"><br><br><table height="10" cellpadding="0" cellspacing="0">
			<tr>
				<td height="28"></td>
			</tr>
		</table>
		<table align="right" cellpadding="0" cellspacing="0">
			<tr>
				<td width="100" height="40">
				<a style="cursor: hand;" onClick="showPrize('pic1','images/gokken/krassen/<?php echo $a1; ?>.jpg')"><img id="pic1" src="images/gokken/krassen/vol.jpg" width="100" height="38"></a>
				</td>
				<td width="8" height="40">
				</td>
				<td width="100" height="40">
				<a style="cursor: hand;" onClick="showPrize('pic2','images/gokken/krassen/<?php echo $a2; ?>.jpg')"><img id="pic2" src="images/gokken/krassen/vol.jpg" width="100" height="38"></a>
				</td>
				<td width="8" height="40">
				</td>
				<td width="100" height="40">
				<a style="cursor: hand;" onClick="showPrize('pic3','images/gokken/krassen/<?php echo $a3; ?>.jpg')"><img id="pic3" src="images/gokken/krassen/vol.jpg" width="100" height="38"></a>
				</td>
				<td width="8" height="40">
				</td>
			</tr>
			<tr>
				<td width="100" height="5">
				</td>
				<td width="5" height="5">
				</td>
				<td width="100" height="5">
				</td>
				<td width="5" height="5">
				</td>
				<td width="100" height="5">
				</td>
				<td width="5" height="5">
				</td>
			</tr>
			<tr>
				<td width="100" height="40">
				<a style="cursor: hand;" onClick="showPrize('pic4','images/gokken/krassen/<?php echo $a4; ?>.jpg')"><img id="pic4" src="images/gokken/krassen/vol.jpg" width="100" height="40"></a>
				</td>
				<td width="8" height="40">
				</td>
				<td width="100" height="40">
				<a style="cursor: hand;" onClick="showPrize('pic5','images/gokken/krassen/<?php echo $a5; ?>.jpg')"><img id="pic5" src="images/gokken/krassen/vol.jpg" width="100" height="40"></a>
				</td>
				<td width="8" height="40">
				</td>
				<td width="100" height="40">
				<a style="cursor: hand;" onClick="showPrize('pic6','images/gokken/krassen/<?php echo $a6; ?>.jpg')"><img id="pic6" src="images/gokken/krassen/vol.jpg" width="100" height="40"></a>
				</td>
				<td width="8" height="40">
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td class="mainTxt" width="600" align="center" colspan="2">Click to Win!(Click on the boxes to reveal each prize)<br>Match 3 and you win that prize</td>
	</tr>

<?php

		}

?>

		</td>
	</tr>
	<tr>
		<td class="mainTxt" width="250">Scratch Again(&#8364;10,000)!</td>
		<td class="mainTxt" width="350"><input type=submit class=btn btn-info name=submit value=Scratch! style="width: 100;"></td>
	</tr>
</table>
</form>

<?php
	} else {

?>

<form method="post">
<table align="center" width="600">
	<tr>
		<td class="subTitle" colspan="3">
		<b>Scratch and Win</b>
		</td>
	</tr>
	<tr>
		<td width="170" class="maintxt" rowspan="3" align="center"><img src="images/gokken/kraskaart2.jpg"></td>
		<td class="mainTxt" colspan="2">Buy a Scratch Card! Click on the boxes to reveal your destiny</td>
	</tr>
	<tr>
		<td class="mainTxt" width="330">&nbsp;&nbsp;Price per Scratch Card</td>
		<td class="mainTxt" width="350">&nbsp;&nbsp;;10.000</td>
	</tr>
	<tr>
		<td class="mainTxt" colspan="2">&nbsp;&nbsp;<input type="submit" class="btn btn-info" name="submit" value="Buy Scratch Card" style="width: 200;"></td>
	</tr>
	<tr>
		<td class="subtitle" colspan="3">&nbsp;</td>
	</tr>
</table>
</form>

<?php

	}

?>

</body>
</html>
