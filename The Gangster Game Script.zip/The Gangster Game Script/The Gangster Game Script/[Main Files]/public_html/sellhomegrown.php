<?php
error_reporting(0);

 include_once("_include-config.php");
     include("_include-gevangenis.php");

 
 
 
 $deal			                        = mysql_query("SELECT * FROM `[dealen]` WHERE `prijs`='".$data->land."'");
 $drugs				                    = mysql_fetch_assoc($deal);
 
 $total = $data->hasj  + $data->coke;
 $max = $data->rank * 3;

 if(isset($_POST['submit3']) && preg_match('/^[0-9]+$/',$_POST['aantal3']))
 {
  if($data->wiet < $_POST['aantal3'])
  {
   Die("
   <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
   <table width=100% align=center><tr><td class=maintxt align=center><font color=red>You dont have that many K's of dope!</font></tr></td>");
  }
  $wiet_totaal = $drugs['wiet']*$_POST['aantal3'];
  mysql_query("UPDATE `[users]` SET wiet=wiet-'".$_POST['aantal3']."', cash=cash+'$wiet_totaal' WHERE login='".$_SESSION['login']."'");
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><p align=center><font color=red><b>You have sold ".$_POST['aantal3']."kg for ".number_format($wiet_totaal)."</b></font></p></tr></td>");
  
 }
 
 if($_POST['submit1'])
 {
 
  if($_POST['sell'] == '1')
  {
  
  $totaalhasjprijs = $drugs[hash]*$_POST['aantalx'];
  
  if($data->cash < $totaalhasjprijs)
  {
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=Maintxt><b><font color=red>Go first and get your pin number..</b></font></tr></td>");
  }
  if($_POST['aantalx'] < 1){
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=maintxt align=center><font color=red><b>Error, minimum of 1 purchase!</font></b></tr></td>");
  }
  if($data->coke + $data->hasj + $_POST[aantalx] > $max)
  {
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=Maintxt><b><font color=red>You already have shit loads of coke elsewhere!</b></font></tr></td>");
  }
  mysql_query("UPDATE `[users]` SET cash=cash-'$totaalhasjprijs', hasj=hasj+'".$_POST['aantalx']."' WHERE login='".$_SESSION['login']."'");
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=maintxt>You have bought".$_POST['aantalx']."kg for ".number_format($totaalhasjprijs)."</tr></td>");
  }
 
 
  elseif($_POST['sell'] == '2')
  {
  
  $totaalhasjprijs = $drugs[hash]*$_POST['aantalx'];

  if($data->hasj < $_POST['aantalx'])
  {
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=Maintxt><b><font color=red>Minimum of 1 Kg</b></font>");
  }
  if($_POST['aantalx'] < 1){
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=maintxt align=center><font color=red><b>Minimum of 1 kg!!</font></b></tr></td>");
  }
  mysql_query("UPDATE `[users]` SET cash=cash+'$totaalhasjprijs', hasj=hasj-'".$_POST['aantalx']."' WHERE login='".$_SESSION['login']."'");
  Die("
   <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=maintxt>You have sold ".$_POST['aantalx']."kg for ".number_format($totaalhasjprijs)."</tr></td>");
  }
  
 }

  if($_POST['cokesell'])
  {

   if($_POST['sellx'] == 1){
   // coke kopen
   $cokeprijs = $drugs[heroine]*$_POST['aantal2'];
   if($data->cash < $cokeprijs)
   {
   Die("
<link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
<table width=100% align=center><tr><td class=maintxt align=center><tr><td class=Maintxt><b><font color=red>Go find a bank, because you dont have enough cash on you...</b></font></tr></td>");
 }
  if($_POST['aantal2'] < 1){
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=maintxt align=center><font color=red><b>Error, minimum of 1 kg!</font></b></tr></td>");
  }
  if($data->coke + $data->hasj + $_POST[aantal2] > $max)
  {
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=Maintxt><b><font color=red>you have loads of coke somewhere else!</b></font></tr></td>");
  }
   mysql_query("UPDATE `[users]` SET cash=cash-'$cokeprijs', coke=coke+'".$_POST['aantal2']."' WHERE login='".$_SESSION['login']."'");
   Die("
   <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center> <tr><td class=maintxt>You have bought ".$_POST['aantal2']."kg for ".number_format($cokeprijs)."</tr></td>");
   }
  
   if($_POST['sellx'] == 2){
   //coke verkopen
   $cokeprijs = $drugs[heroine]*$_POST['aantal2'];
   if($data->coke < $_POST['aantal2'])
   {
   Die("
<link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
<table width=100% align=center><tr><td class=maintxt align=center><tr><td class=Maintxt><b><font color=red>Fuck Sake... you dont have coke on you...</b></font></tr></td>");
   }
  if($_POST['aantal2'] < 1){
  Die("
  <link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
  <table width=100% align=center><tr><td class=maintxt align=center><tr><td class=maintxt align=center><font color=red><b>Error, minimum of 1 kg!</font></b></tr></td>");
  }
   mysql_query("UPDATE `[users]` SET cash=cash+'$cokeprijs', coke=coke-'".$_POST['aantal2']."' WHERE login='".$_SESSION['login']."'");
   Die("
<link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
<table width=100% align=center><tr><td class=maintxt align=center><tr><td class=maintxt>You have sold ".$_POST['aantal2']."kg for ".number_format($cokeprijs)."</tr></td>");
   }

  }
 
?>
<BODY>
<link rel=stylesheet type=text/css href=<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css>
<TABLE width=600 align=center>
  <TBODY>
  <TR>
    <TD class=subTitle background=images/topic2.gif height=23 colSpan=3><B>Drug Handling</B></TD></TR>
  <TR>
    <TD class=mainTxt colSpan=3>You have [<FONT color=#00ff00><B><?=$data->wiet;?> kilo's of 
      Weed</B></FONT>] 
     </SPAN><BR> Homegrown Weed! The name says it all...Why cant you get into home grown!</TD></TR>
  <TR>
    <TD>&nbsp;</TD></TR>
  <FORM name=drugs3 method=post>
  <TR>
    <TD class=mainTxt align=middle width=150 rowSpan=4><IMG 
      src="images/game/wiet.jpg"><BR><BR>Homegrown Weed</TD>
    <TD class=mainTxt width=230>Street Value per kilo in </TD>
    <TD class=mainTxt width=220><?=$drugs[wiet];?></TD>
  <TR>
    <TD class=mainTxt width=230>I will</TD>
    <TD class=mainTxt width=220><INPUT type=radio value=verkoop name=sel3 checked> 
      Sell</TD></TR>
  <TR>
    <TD class=mainTxt width=230>Total kilo's</TD>
    <TD class=mainTxt width=220>
	<INPUT style="WIDTH: 135;" maxLength=7 size=9 
      name=aantal3></TD></TR>
  <TR>
    <TD class=mainTxt width=230>Do the Deal</TD>
    <TD class=mainTxt width=220>
	<INPUT style="WIDTH: 65;" type=submit value=Deal name=submit3></TD></TR></FORM>
  <</FORM></TBODY></TABLE></BODY></HTML>
