<?php
error_reporting(0);

   include("_include-config.php");
       include("_include-gevangenis.php");
 

 
?>
<html>
<head>
<link href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>
<body style="margin: 0px;">

<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
  <tr>
  <td width="96%" class=subTitle><b>Protect Yourself</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/shoppicture.jpg border=0></center>
</td>


<table width="100%" align="center">
<BR>
<tr><td class="subTitle" colspan="3"><b>Shops</b></td></tr>
<tr><td class="mainTxt" colspan="3" align="center">
<a href="?b=1" class="btn btn-info">&nbsp;Weapons</a>&nbsp;<br>&nbsp;<a href="?b=2" class="btn btn-info">Protection</a>
</td></tr>
<tr><td class="mainTxt">
<?

if($_GET['b'] == 1) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1']) AND $_POST['a1'] != -9e9) {
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*35);
		$prijs = round($_POST['a1']*4000);
		$aantal	= round($data->wapens+$_POST['a1']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
		if($_POST['a1'] == 1) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "<center>You have bought 1 Desert Eagle.</center>\n";
		}
		else{
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "<center>You have bought {$_POST['a1']} desert eagle's.</center>\n";
		}
		}
		else {
			print "<center>You dont have enough cash</center>\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2']) AND $_POST['a2'] != -9e9) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*50);
		$prijs = round($_POST['a2']*6000);
		$aantal	= round($data->wapens+$_POST['a2']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
		if($_POST['a2'] == 1) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "<center>You have bought 1 Uzi.</center>\n";
		}
		else{
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "<center>You have bought {$_POST['a2']} uzi's.</center>\n";
		}
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['3']) && preg_match('/^[0-9]+$/',$_POST['a3']) AND $_POST['a3'] != -9e9) {
		$guns = $_POST['a3'];
		$power = round($_POST['a3']*100);
		$prijs = round($_POST['a3']*10000);
		$aantal	= round($data->wapens+$_POST['a3']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
		if($_POST['a3'] == 1) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "<center>You have bought 1 MP5K.</center>\n";
		}
		else{
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "<center>You have bough {$_POST['a3']} MP5K's.</center>\n";
		}
		}
		else {
			print "You dont have enough money.\n";
		}
	}
	if(isset($_POST['4']) && preg_match('/^[0-9]+$/',$_POST['a4']) AND $_POST['a4'] != -9e9) {
		$guns = $_POST['a4'];
		$power = round($_POST['a4']*200);
		$prijs = round($_POST['a4']*15000);
		$aantal	= round($data->wapens+$_POST['a4']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
		if($_POST['a4'] == 1) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "<center>You have bought 1 Shotgun.</center>\n";
		}
		else{
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "<center>You have bought {$_POST['a4']} shotgun's.</center>\n";
		}
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['5']) && preg_match('/^[0-9]+$/',$_POST['a5']) AND $_POST['a5'] != -9e9) {
		$guns = $_POST['a5'];
		$power = round($_POST['a5']*280);
		$prijs = round($_POST['a5']*22000);
		$aantal	= round($data->wapens+$_POST['a5']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a5']} g36c's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['6']) && preg_match('/^[0-9]+$/',$_POST['a6']) AND $_POST['a6'] != -9e9) {
		$guns = $_POST['a6'];
		$power = round($_POST['a6']*350);
		$prijs = round($_POST['a6']*27500);
		$aantal	= round($data->wapens+$_POST['a6']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a6']} sig 552's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['7']) && preg_match('/^[0-9]+$/',$_POST['a7']) AND $_POST['a7'] != -9e9) {
		$guns = $_POST['a7'];
		$power = round($_POST['a7']*410);
		$prijs = round($_POST['a7']*32000);
		$aantal	= round($data->wapens+$_POST['a7']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a7']} ak47's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['8']) && preg_match('/^[0-9]+$/',$_POST['a8']) AND $_POST['a8'] != -9e9) {
		$guns = $_POST['a8'];
		$power = round($_POST['a8']*500);
		$prijs = round($_POST['a8']*36000);
		$aantal	= round($data->wapens+$_POST['a8']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a8']} m4a1's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['9']) && preg_match('/^[0-9]+$/',$_POST['a9']) AND $_POST['a9'] != -9e9) {
		$guns = $_POST['a9'];
		$power = round($_POST['a9']*600);
		$prijs = round($_POST['a9']*40000);
		$aantal	= round($data->wapens+$_POST['a9']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a9']} ak beta's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['10']) && preg_match('/^[0-9]+$/',$_POST['a10']) AND $_POST['10'] != -9e9) {
		$guns = $_POST['a10'];
		$power = round($_POST['a10']*700);
		$prijs = round($_POST['a10']*45000);
		$aantal	= round($data->wapens+$_POST['a10']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a10']} scherpschut guns.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['11']) && preg_match('/^[0-9]+$/',$_POST['a11']) AND $_POST['a11'] != -9e9) {
		$guns = $_POST['a11'];
		$power = round($_POST['a11']*820);
		$prijs = round($_POST['a11']*50000);
		$aantal	= round($data->wapens+$_POST['a11']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power,`m4`=`m4`+'$aantal' WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a11']} m4's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['12']) && preg_match('/^[0-9]+$/',$_POST['a12']) AND $_POST['a12'] != -9e9) {
		$guns = $_POST['a12'];
		$power = round($_POST['a12']*950);
		$prijs = round($_POST['a12']*55000);
		$aantal	= round($data->wapens+$_POST['a12']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a12']} m82a1's.<BR>\n";
		}
		else {
			print "you dont have enough cash.\n";
		}
	}
	if(isset($_POST['13']) && preg_match('/^[0-9]+$/',$_POST['a13']) AND $_POST['a13'] != -9e9) {
		$guns = $_POST['a13'];
		$power = round($_POST['a13']*1050);
		$prijs = round($_POST['a13']*60000);
		$aantal	= round($data->wapens+$_POST['a13']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a13']} granaat lanceerders.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['14']) && preg_match('/^[0-9]+$/',$_POST['a14']) AND $_POST['a14'] != -9e9) {
		$guns = $_POST['a14'];
		$power = round($_POST['a14']*1250);
		$prijs = round($_POST['a14']*70000);
		$aantal	= round($data->wapens+$_POST['a14']);
	$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a14']} m3m .50cal's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['15']) && preg_match('/^[0-9]+$/',$_POST['a15']) AND $_POST['a15'] != -9e9) {
		$guns = $_POST['a15'];
		$power = round($_POST['a15']*1550);
		$prijs = round($_POST['a15']*80000);
		$aantal	= round($data->wapens+$_POST['a15']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a15']} bazooka's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['16']) && preg_match('/^[0-9]+$/',$_POST['a16']) AND $_POST['a16'] != -9e9) {
		$guns = $_POST['a16'];
		$power = round($_POST['a16']*1800);
		$prijs = round($_POST['a16']*90000);
		$aantal	= round($data->wapens+$_POST['a16']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a16']} miniguns.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['17']) && preg_match('/^[0-9]+$/',$_POST['a17']) AND $_POST['a17'] != -9e9) {
		$guns = $_POST['a17'];
		$power = round($_POST['a17']*180);
		$prijs = round($_POST['a17']*80000);
		$aantal	= round($data->wapens+$_POST['a17']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
		if($_POST['a17'] == 1) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power,`Dynamite`=`Dynamite`+'$aantal' WHERE `login`='{$data->login}'");
			print "<center>You have bought 1 dynamite stick.</center>\n";
		}
		else{
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power,`Dynamite`=`Dynamite`+'$aantal' WHERE `login`='{$data->login}'");
			print "<center>You have bought {$_POST['a17']} dynamite sticks.</center>\n";
		}
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['18']) && preg_match('/^[0-9]+$/',$_POST['a18']) AND $_POST['a18'] != -9e9) {
		$guns = $_POST['a18'];
		$power = round($_POST['a18']*50);
		$prijs = round($_POST['a18']*200000);
		$aantal	= round($data->wapens+$_POST['a18']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
		if($_POST['a18'] == 1) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power,`vlammenwerper`=`vlammenwerper`+'$aantal' WHERE `login`='{$data->login}'");
			print "<center>You have bought 1 vlammenwerper.</center>\n";
		}
		else{
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power,`vlammenwerper`=`vlammenwerper`+'$aantal' WHERE `login`='{$data->login}'");
			print "<center>You have bought {$_POST['a18']} vlammenwerpers.</center>\n";
		}
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="100%" align="center">


<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Desert Eagle</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Uzi</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>MP5k</b></td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-deagle.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-Uzi.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-MP5k.gif"></td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">35</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">50</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">100</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">35</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">50</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">100</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">4.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">6.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">10.000</td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a1" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="1" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="2" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a3" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="3" value="Purchase"></td>
</tr>


<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Shotgun</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>G36C</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>SIG 550</b></td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-Shotgun.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-G36C.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-SIG_550.gif"></td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">200</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">280</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">350</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">200</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">280</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">350</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">15.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">22.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">27.500</td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a4" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="4" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a5" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="5" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a6" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="6" value="Purchase"></td>
</tr>


<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Ak47</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>M4a1</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Ak Beta</b></td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-Ak47.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-m4a1.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-Ak_Beta.gif"></td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">410</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">500</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">600</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">410</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">500</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">600</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">32.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">36.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">40.000</td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a7" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="7" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a8" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="8" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a9" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="9" value="Purchase"></td>
</tr>


<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Scherpschut Gun</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>M4</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>M82a1</b></td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-Sniper_rifle.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-M4.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-m82a1.gif"></td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">700</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">820</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">950</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">700</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">820</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">950</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">45.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">50.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">55.000</td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a10" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="10" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a11" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="11" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a12" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="12" value="Purchase"></td>
</tr>


<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Granaat Lanceerder</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>M3M .50 Cal</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Bazooka</b></td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-Grenade_Launcher.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-machinegun.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-Bazooka.gif"></td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">1050</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">1250</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">1550</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">1050</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">1250</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">1550</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">60.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">70.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">80.000</td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a13" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="13" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a14" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="14" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a15" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="15" value="Purchase"></td>
</tr>


<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Minigun</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Dynamite</b></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><b>Vlammenwerper</b></td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-minigun.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-Dynamite.gif"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><img src="images/wapens/item-vlammenwerper.gif"></td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">1800</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">180</td>
<td width="100" align="center" style="border: 1px solid #000000;">Attack:</td>
<td width="100" align="center" style="border: 1px solid #000000;">50</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">1800</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">180</td>
<td width="100" align="center" style="border: 1px solid #000000;">Defence:</td>
<td width="100" align="center" style="border: 1px solid #000000;">50</td>
</tr>
<tr>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">90.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">80.000</td>
<td width="100" align="center" style="border: 1px solid #000000;">Price:</td>
<td width="100" align="center" style="border: 1px solid #000000;">200.000</td>
</tr>
<tr>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a16" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="16" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a17" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="17" value="Purchase"></td>
<td width="200" align="center" colspan="2" style="border: 1px solid #000000;"><input type="text" class="btn btn-info" name="a18" maxlength="5" size="5" value="1" style="text-align:center;"> <input type="submit" class="btn btn-info" name="18" value="Purchase"></td>
</tr>
</table>

</form>
ENDHTML;
}
elseif($_GET['b'] == 2) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1']) AND $_POST['a1'] != -9e9) {
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*100);
		$prijs = round($_POST['a1']*7500);
		$aantal	= round($data->bescherming+$_POST['a1']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a1']} Bulletproof vests.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2']) AND $_POST['a2'] != -9e9) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*200);
		$prijs = round($_POST['a2']*15000);
		$aantal	= round($data->bescherming+$_POST['a2']);
		$type1 = array("","Drugdealer","Thug","Pretty Boy","Officer","Gangster Wanabee","Hired Gun","Ho","Hustler","Playa","original Gangster","Rude Boy","Peacekeeper","Street Doll","Gangster Bitch","Drug Runner","Hoodie","Criminal","Lady Bitch","Real Thug","Avenger");
		
		$type  = $type1[$data->type];
		if($prijs <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$prijs,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a2']} bodyguard's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>BulletProof vest</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/wapens/item-Bulletproof_vest.gif" width="200" height="150"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">75</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">150</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">7.500</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" name="a1" class="btn btn-info" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit"  class="btn btn-info" name="1" value=" Purchase "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Bodyguard</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/wapens/item-bodyguard.gif" width="200" height="150"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">150</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">300</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">15.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Purchase "></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
ENDHTML;
}
?>
</td></tr>
</table>
</body>
</html>
