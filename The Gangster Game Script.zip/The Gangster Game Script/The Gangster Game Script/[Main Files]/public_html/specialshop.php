<?php
error_reporting(0);

  include("_include-config.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<table width="100%" cellspacing="0">
<BR>
<tr><td class="subTitle" colspan="3"><b>Shop</b></td></tr>
<tr><td class="mainTxt" colspan=3>

<table width="100%" align="center" colspan=3>
<tr><td align="center" colspan=3>
<?


   if($_GET['GOMASTER'] == "JA")
   {
     echo 'Ok, Ready. <br>- <b>Click <a href="specialshop.php" class="btn btn-info">HERE</a> </b>to enter the shop - ';
     mysql_query("INSERT INTO `[userinfo]` (`login`) VALUES ('$data->login')");
     exit;
   }

   $dbres2        = mysql_query("SELECT * FROM `[userinfo]` WHERE `login`='$data->login'");
   if(mysql_num_rows($dbres2) == 0) 
   {
     print "If you want to continue, click on the link!<br><br><a href='specialshop.php?GOMASTER=JA' class='btn btn-info'><b>HERE</b></a></td></tr></table>\n";
     exit;
   }
    
if($_GET['b'] == 1) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*35);
		$Price = round($_POST['a1']*4000);
		$aantal	= round($data->wapens+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']} desert eagle's.<BR>\n";
		}
		else {
			print "You dont have enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*50);
		$Price = round($_POST['a2']*6000);
		$aantal	= round($data->wapens+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have bought {$_POST['a2']} uzi's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['3']) && preg_match('/^[0-9]+$/',$_POST['a3'])) {
		$guns = $_POST['a3'];
		$power = round($_POST['a3']*100);
		$Price = round($_POST['a3']*10000);
		$aantal	= round($data->wapens+$_POST['a3']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a3']} mp5k's<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['4']) && preg_match('/^[0-9]+$/',$_POST['a4'])) {
		$guns = $_POST['a4'];
		$power = round($_POST['a4']*200);
		$Price = round($_POST['a4']*15000);
		$aantal	= round($data->wapens+$_POST['a4']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a4']} shotgun's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['5']) && preg_match('/^[0-9]+$/',$_POST['a5'])) {
		$guns = $_POST['a5'];
		$power = round($_POST['a5']*280);
		$Price = round($_POST['a5']*22000);
		$aantal	= round($data->wapens+$_POST['a5']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a5']} g36c's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['6']) && preg_match('/^[0-9]+$/',$_POST['a6'])) {
		$guns = $_POST['a6'];
		$power = round($_POST['a6']*350);
		$Price = round($_POST['a6']*27500);
		$aantal	= round($data->wapens+$_POST['a6']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a6']} sig 552's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['7']) && preg_match('/^[0-9]+$/',$_POST['a7'])) {
		$guns = $_POST['a7'];
		$power = round($_POST['a7']*410);
		$Price = round($_POST['a7']*32000);
		$aantal	= round($data->wapens+$_POST['a7']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a7']} ak47's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['8']) && preg_match('/^[0-9]+$/',$_POST['a8'])) {
		$guns = $_POST['a8'];
		$power = round($_POST['a8']*500);
		$Price = round($_POST['a8']*36000);
		$aantal	= round($data->wapens+$_POST['a8']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a8']} m4a1's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['9']) && preg_match('/^[0-9]+$/',$_POST['a9'])) {
		$guns = $_POST['a9'];
		$power = round($_POST['a9']*600);
		$Price = round($_POST['a9']*40000);
		$aantal	= round($data->wapens+$_POST['a9']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a9']} ak beta's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['10']) && preg_match('/^[0-9]+$/',$_POST['a10'])) {
		$guns = $_POST['a10'];
		$power = round($_POST['a10']*700);
		$Price = round($_POST['a10']*45000);
		$aantal	= round($data->wapens+$_POST['a10']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a10']} scherpschut geweren.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['11']) && preg_match('/^[0-9]+$/',$_POST['a11'])) {
		$guns = $_POST['a11'];
		$power = round($_POST['a11']*820);
		$Price = round($_POST['a11']*50000);
		$aantal	= round($data->wapens+$_POST['a11']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a11']} m4's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['12']) && preg_match('/^[0-9]+$/',$_POST['a12'])) {
		$guns = $_POST['a12'];
		$power = round($_POST['a12']*950);
		$Price = round($_POST['a12']*55000);
		$aantal	= round($data->wapens+$_POST['a12']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a12']} m82a1's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['13']) && preg_match('/^[0-9]+$/',$_POST['a13'])) {
		$guns = $_POST['a13'];
		$power = round($_POST['a13']*1050);
		$Price = round($_POST['a13']*60000);
		$aantal	= round($data->wapens+$_POST['a13']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a13']} granaat lanceerders.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['14']) && preg_match('/^[0-9]+$/',$_POST['a14'])) {
		$guns = $_POST['a14'];
		$power = round($_POST['a14']*1250);
		$Price = round($_POST['a14']*70000);
		$aantal	= round($data->wapens+$_POST['a14']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a14']} m3m .50cal's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['15']) && preg_match('/^[0-9]+$/',$_POST['a15'])) {
		$guns = $_POST['a15'];
		$power = round($_POST['a15']*1550);
		$Price = round($_POST['a15']*80000);
		$aantal	= round($data->wapens+$_POST['a15']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a15']} bazooka's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['16']) && preg_match('/^[0-9]+$/',$_POST['a16'])) {
		$guns = $_POST['a16'];
		$power = round($_POST['a16']*1800);
		$Price = round($_POST['a16']*90000);
		$aantal	= round($data->wapens+$_POST['a16']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a16']} miniguns.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Desert Eagle</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-deagle.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">35</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">35</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">4.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" name="a1" class="btn btn-info" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="1" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Uzi</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Uzi.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">50</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">50</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">6.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>MP5K</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-MP5k.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">100</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">100</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">10.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a3" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="3" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Shotgun</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Shotgun.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">200</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">200</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">15.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a4" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="4" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>G36C</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-G36C.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">280</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">280</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">22.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a5" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="5" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>SIG 552</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-SIG_552.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">350</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">350</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">27.500</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a6" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="6" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Ak47</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Ak47.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">410</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">410</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">32.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a7" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="7" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>M4A1</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-m4a1.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">500</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">500</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">36.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a8" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="8" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Ak Beta</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Ak_Beta.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">600</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">600</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">40.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a9" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="9" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Scherpschut geweer</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Sniper_rifle.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">700</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">700</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">45.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a10" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="10" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>M4</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-M4.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">820</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">820</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">50.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a11" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="11" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>M82A1</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-m82a1.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">950</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">950</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">55.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a12" maxlength="5" size="5" class="btn btn-info" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="12" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Granaat Lanceerder</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Grenade_Launcher.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">1050</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">1050</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">60.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a13" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="13" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>M3M .50Cal</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-machinegun.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">1250</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">1250</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">70.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" name="a14" class="btn btn-info" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="14" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Bazooka</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Bazooka.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">1550</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">1550</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">80.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" name="a15" class="btn btn-info" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="15" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Minigun</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-minigun.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">1800</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">1800</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">90.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a16" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="16" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
ENDHTML;
}
elseif($_GET['b'] == 2) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*100);
		$Price = round($_POST['a1']*7500);
		$aantal	= round($data->bescherming+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']} Bulletproof Vest.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*200);
		$Price = round($_POST['a2']*15000);
		$aantal	= round($data->bescherming+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a2']} bodyguard's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Bulletproof Vest</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Bulletproof_vest.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">75</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">150</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">7.500</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a1" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="1" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Bodyguard</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-bodyguard.gif" width="200" height="150"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">150</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">300</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">15.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
ENDHTML;
}
elseif($_GET['b'] == 3) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*30);
		$Price = round($_POST['a1']*2500);
		$aantal	= round($data->verdediging1+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']} dogs.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*100);
		$Price = round($_POST['a2']*8000);
		$aantal	= round($data->verdediging2+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a2']} camera's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['3']) && preg_match('/^[0-9]+$/',$_POST['a3'])) {
		$guns = $_POST['a3'];
		$power = round($_POST['a3']*180);
		$Price = round($_POST['a3']*15000);
		$aantal	= round($data->verdediging3+$_POST['a3']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a3']} fences.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['4']) && preg_match('/^[0-9]+$/',$_POST['a4'])) {
		$guns = $_POST['a4'];
		$power = round($_POST['a4']*250);
		$Price = round($_POST['a4']*20000);
		$aantal	= round($data->verdediging4+$_POST['a4']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a4']} walls.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Bulldog</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Bulldog.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">10</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">30</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">2.500</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a1" size="5" maxlength="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="1" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Camera</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Cam.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">20</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">100</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">8.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>fence</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Barbed_wire.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">15</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">180</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">15.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info"name="a3" size="5" maxlength="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="3" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Wall</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Stone_wall.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">15</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">250</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">20.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a4" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="4" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
ENDHTML;
}
elseif($_GET['b'] == 3) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*30);
		$Price = round($_POST['a1']*2500);
		$aantal	= round($data->verdediging1+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']} dogs.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*100);
		$Price = round($_POST['a2']*8000);
		$aantal	= round($data->verdediging2+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a2']} camera's.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['3']) && preg_match('/^[0-9]+$/',$_POST['a3'])) {
		$guns = $_POST['a3'];
		$power = round($_POST['a3']*180);
		$Price = round($_POST['a3']*15000);
		$aantal	= round($data->verdediging3+$_POST['a3']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a3']} fences.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['4']) && preg_match('/^[0-9]+$/',$_POST['a4'])) {
		$guns = $_POST['a4'];
		$power = round($_POST['a4']*250);
		$Price = round($_POST['a4']*20000);
		$aantal	= round($data->verdediging4+$_POST['a4']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a4']} walls.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Bulldog</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Bulldog.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">10</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">30</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">2.500</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a1" size="5" maxlength="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="1" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Camera</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Cam.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">20</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">100</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">8.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>fence</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-Barbed_wire.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">15</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">180</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">15.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a3" size="5" maxlength="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="3" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Mobile</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/mobiel.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">15</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">250</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">20.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a4" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="4" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
ENDHTML;
}
elseif($_GET['koop'] == special) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*30);
		$Price = round($_POST['a1']*2500);
		$aantal	= round($data->verdediging1+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
					    mysql_query("UPDATE `[users]` SET `cash`=`cash`-50000 WHERE `login`='{$data->login}'");
		    mysql_query("UPDATE `[users]` SET `maffiamode`='1' WHERE `login`='$data->login'");
			print "You have purchased a phone!.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*100);
		$Price = round($_POST['a2']*50000);
		$aantal	= round($data->verdediging2+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($data->maffiamode == 1){
		echo "Your already under protection from the Mafia this hour!";
		exit;
		}
	    if($data->attack+$data->defence > 500000){
		echo "Your abit weak... The Mafia want to protect you for a while!";
		exit;
		}
		if($Price <= $data->cash) {
		    mysql_query("UPDATE `[users]` SET `cash`=`cash`-50000 WHERE `login`='{$data->login}'");
		    mysql_query("UPDATE `[users]` SET `maffiamode`='1' WHERE `login`='$data->login'");
			print "You have purchased MaFFia Mode!!<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Maffia Mode</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/maffiamode.gif"></td>
				</tr>
				<tr>
					<td width="100">Max:</td>
					<td width="100">1 per uur</td>
				</tr>
				<tr>
	
					<td width="100">Price:</td>
					<td width="100">50.000</td>
				</tr>
				<tr>
				
					<td colspan="2" align="center" width="200"><br><input type="text" name="a2" class="btn btn-info" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Buy "></td>
				</tr>
				
			</table>
		</td>
	</tr>
	<tr>
			</table>
		</td>
	</tr>
</table>
</form>
If you have MafiaMode, you cannot be attacked until the following hour!</td></tr></table>
ENDHTML;
}
elseif($_GET['b'] == 5) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$Price = round($_POST['a1']*195000);
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*2500);
		$aantal	= round($data->tank1+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']} tanks.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*3400);
		$Price = round($_POST['a2']*265000);
		$aantal	= round($data->tank2+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a2']} tanks.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>M3A1</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-m4a1tank.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">2500</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">2500</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">195.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a1" size="5" maxlength="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="1" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Leopard 2</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-leopard2.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">3400</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">3400</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">265.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
ENDHTML;
}
elseif($_GET['b'] == 6) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$Price = round($_POST['a1']*495000);
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*5100);
		$aantal	= round($data->tank1+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']}x Speedboot.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*8700);
		$Price = round($_POST['a2']*785000);
		$aantal	= round($data->tank2+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a2']}x Cruiser.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="50" algin="center"><b>Speedboot</b></td>
				</tr>
				<tr>
					<td colspan="2" width="50%"><img src="images/winkel/item-auto4.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">5100</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">5100</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">495.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a1" size="5" maxlength="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="1" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Cruiser</b></td>
				</tr>
				<tr>
					<td colspan="2" width="110"><img src="images/winkel/item-Cruiser.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">8700</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">8700</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">785.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Buy "></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
ENDHTML;
}
elseif($_GET['b'] == 7) {
	if(isset($_POST['1']) && preg_match('/^[0-9]+$/',$_POST['a1'])) {
		$Price = round($_POST['a1']*695000);
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*7100);
		$aantal	= round($data->tank1+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']}x Helicopter.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['2']) && preg_match('/^[0-9]+$/',$_POST['a2'])) {
		$guns = $_POST['a2'];
		$power = round($_POST['a2']*9700);
		$Price = round($_POST['a2']*950000);
		$aantal	= round($data->tank2+$_POST['a2']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a2']}x F15.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
	if(isset($_POST['3']) && preg_match('/^[0-9]+$/',$_POST['a3'])) {
		$Price = round($_POST['a1']*1455000);
		$guns = $_POST['a1'];
		$power = round($_POST['a1']*11900);
		$aantal	= round($data->tank1+$_POST['a1']);
		$type1 = array("","gangsters","terroristen","agenten");
		$type  = $type1[$data->type];
		if($Price <= $data->cash) {
			mysql_query("UPDATE `[users]` SET `cash`=`cash`-$Price,`attack`=`attack`+$power,`defence`=`defence`+$power WHERE `login`='{$data->login}'");
			print "You have purchased {$_POST['a1']}x F16.<BR>\n";
		}
		else {
			print "Sorry man, you aint got enough cash.\n";
		}
	}
print <<<ENDHTML
<form method="post">
<table width="420">
	<tr>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>Helicopter</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-heli.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">7100</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">7100</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">695.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a1" size="5" maxlength="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="1" value=" Buy "></td>
				</tr>
			</table>
		</td>
		<td width="40">&nbsp;</td>
		<td width="200" class="subTxt">
			<table width="200">
				<tr>
					<td colspan="2" width="200" algin="center"><b>F15</b></td>
				</tr>
				<tr>
					<td colspan="2" width="200"><img src="images/winkel/item-f15.gif"></td>
				</tr>
				<tr>
					<td width="100">Attack:</td>
					<td width="100">9700</td>
				</tr>
				<tr>
					<td width="100">Defence:</td>
					<td width="100">9700</td>
				</tr>
				<tr>
					<td width="100">Price:</td>
					<td width="100">950.000</td>
				</tr>
				<tr>
					<td colspan="2" align="center" width="200"><input type="text" class="btn btn-info" name="a2" maxlength="5" size="5" value="1" style="text-align:center;"><input type="submit" class="btn btn-info" name="2" value=" Buy "></td>
			
		</form>
ENDHTML;
}else {
print <<<ENDHTML
</td></tr>
<tr><td><b>
<img border=0 src=images/winkel/rightpicture.gif width=200 height=200 align=right border=0>
Welcome to the Store! Buy and compete... then you will gain more power! <br><br> Therefore you will grow stronger.</b>
<br>
<br>
<br>
  <li><a href="specialshop.php?b=1" class="btn btn-info">Weapons</a></li>
  <li><a href="specialshop.php?b=2" class="btn btn-info">Protection</a></li>
  <li><a href="specialshop.php?b=3" class="btn btn-info">Home Protection</a></li>
      <li><a href="specialshop.php?koop=special" class="btn btn-info">Mafia Mode</a></li>
    <li><a href="specialshop.php?b=6" class="btn btn-info">Boats</a></li></font>
     <li><a href="specialshop.php?b=7" class="btn btn-info">Flight Transport</a></li> </font>
  <li><a href="specialshop.php?b=5" class="btn btn-info">Tanks</a></li> <b></font>

<li><a href="specialshop.php?special=VIP" class="btn btn-info">VIP Shop</a></li><BR><BR>


ENDHTML;
}
?>

<?PHP

 if(isset($_POST['wapenkopen']))
 {
   echo '</table><tr><td class=Subtitle>Purchase Weapon</tr></td><tr><td class=maintxt>Soon';
   exit;
 }

   $aLijfwachten = mysql_query("SELECT lijfwachten FROM `[userinfo]` WHERE `login`='$data->login'");
   while ($list = mysql_fetch_assoc($aLijfwachten))
{ 

if($_GET['special'] == "VIP")
{

if($data->vip == 0){
echo 'Only VIP Members';
exit;
}

  echo '</table><br><table width=100%><tr><a href="specialshop.php?vip=special" class="btn btn-info">VIP Specials</a>';
  exit;
}
if($_GET['vip']== "wapens")
{

if($data->vip == 0){
echo 'Only VIP Members';
exit;
}

  echo '</table><tr><td class=Subtitle colspan=3>VIP Weapons</tr></td><tr>
  <form method="post">
	<td class="mainTxt" border=0 width=40%><input type="radio" name="wapen" value="1" checked>  Walter PPK</td><td width=25% class="mainTxt">Price: 25.000 </td><td width=25% class="mainTxt"> Power: 400 </td></tr>
	<td class="mainTxt"><input type="radio" class="btn btn-info" name="wapen" value="2"> Tommygun </td><td class="mainTxt">Price: 60.000</td><td width=25% class="mainTxt"> Power: 1400 </td></tr>
	<td class="mainTxt"><input type="radio" class="btn btn-info" name="wapen" value="3">  AK 47</td><td class="mainTxt">Price: 95.500</td> <td width=25% class="mainTxt"> Power: 2200 </td></tr>
	<td class="mainTxt"><input type="radio" class="btn btn-info" name="wapen" value="4"> Uzi</td><td class="mainTxt">Price: 200.000</td> <td width=25% class="mainTxt"> Power: 5300 </td></tr>
	<td class="mainTxt"><input type="radio" class="btn btn-info" name="wapen" value="5"> M-16</td><td class="mainTxt">Price: 350.500</td> <td width=25% class="mainTxt"> Power: 9600 </td></tr>
	<td class="mainTxt" colspan=3 align=left>ammount: <input type=text size=3  class=btn btn-info name=hoeveel value=0> <input type="submit" class="btn btn-info" name="wapenkopen" value="Purchase"></td></tr>
	</table>
	</form>
  
  
  ';
  exit;
}
elseif($_GET['vip']== "voertuigen")
{

if($data->vip == 0){
echo 'Only VIP Members';
exit;
}
  echo '</table><tr><td class=Subtitle>VIP Protection</tr></td><tr><td class=maintxt>Soon';
  exit;
}
elseif($_GET['vip']== "special")
{

if($data->vip == 0){
echo 'Only VIP Members';
exit;
}

  echo "</table><tr><td class=Subtitle>VIP Special</tr></td><tr><td class=maintxt>You have <b> ".$list['lijfwachten']." </b> bodyguard that will protect you against Murder/Attack attempts.<br />A bodyguard costs <b>1.000.000</b> p/s<br /><form method=post> Ammount: <input type=text name=lijfwachten value=0 size=5><br /><br /><input type=submit class=btn btn-info name=x value='Buy Bodyguard'></form>";
 }
 

 if(isset($_POST['x']))
 {
 


 
 if($data->cash < $kost1)
 {
   $kost   = 1000000;
   $kost1  = $kost*$_POST['lijfwachten'];
   echo "</table><table width=100%><tr><td class=MainTxt>Sorry man, you aint got enough cash</tr></td>";
   exit;
 }
 
 if($_POST['lijfwachten'] == 0)
 {
   echo "</table><table width=100%><tr><td class=MainTxt>You must buy a bodyguard</tr></td>";
   exit;
 }
 
 if($_POST['lijfwachten'] < 0)
 {
   echo "</table><table width=100%><tr><td class=MainTxt>You must buy a bodyguard</tr></td>";
   exit;
 }

 if($_POST['lijfwachten'] > 999999999999999999999999999)
 {
   echo "</table><table width=100%><tr><td class=MainTxt>No Cheating... Cunt!</tr></td>";
   exit;
 }
 
  $bieden = $_POST['lijfwachten'];
  $bieden = htmlspecialchars($_POST['lijfwachten']);
  $bieden = substr($_POST['lijfwachten'],0,11);
  $landz  = $bieden*1;
  $kost   = 1000000;
  $kost1  = $kost*$_POST['lijfwachten'];
  
   if($data->cash < $kost1)
 {
   echo "</table><table width=100%><tr><td class=MainTxt>Sorry man, you aint got enough cash</tr></td>";
   exit;
 }
 
  echo "</table><table width=100%><tr><td class=MainTxt>You have bought <b>{$_POST['lijfwachten']}</b> bodyguards for <b>".number_format(1000000*$_POST['lijfwachten'],0,',','.')."</b></tr></td>";
  mysql_query("UPDATE `[users]` SET `cash`=`cash`-$kost1 WHERE `login`='$data->login'");
  mysql_query("UPDATE `[userinfo]` SET `lijfwachten`=`lijfwachten`+$landz WHERE `login`='$data->login'");
  exit;
}

} // 


?>

</tr></td>
</table>
</td></tr>
</table>
