<?php
error_reporting(0);

	include("_include-config.php");
?><head>
<title></title>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" content="nl">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

</head>


<body style="background-color:#1a1919;">
<table width=75% align=center>
<tr><td class=subtitle>Statistics</td></tr>
<tr><td class=maintxt>
        <CENTER>
                                      <input type="btn btn-button" class="btn btn-info" style="width: 150;" value=" General "onClick="window.self.location=('stats.php?x=algemeen');"></form>
		<input type="btn btn-button" class="btn btn-info" style="width: 150;" value=" Richest Players "onClick="window.self.location=('stats.php?x=geld');">
		
		<input type="btn btn-button" class="btn btn-info" style="width: 150;" value=" Top Power"onClick="window.self.location=('stats.php?x=speler');"> 
		<input type="btn btn-button" class="btn btn-info" style="width: 150;" value=" Top Rank"onClick="window.self.location=('stats.php?x=rank');">
		<input type="btn btn-button" class="btn btn-info" style="width: 150;" value=" Top Referrals"onClick="window.self.location=('stats.php?x=ref');">
</td></tr></table>
<?PHP
$queries= 0;

 
if($_GET['x'] == 'algemeen')
{


 $select1 = mysql_query("SELECT `id` FROM `[users]`");
 $queries++; 
 $leden = mysql_num_rows($select1); 
  
 $select5 = mysql_query("SELECT `id` FROM `[garage]`"); 
 $queries++; 
 $car = mysql_num_rows($select5);

 $select2 = mysql_query("SELECT `name` FROM `[clans]`"); 
 $queries++; 
 $clans = mysql_num_rows($select2); 
  
 $select3 = mysql_query("SELECT `id` FROM `[messages]`"); 
 $berichten = mysql_num_rows($select3); 

 $select4 = mysql_query("SELECT SUM(`cash`) AS `cash` FROM `[users]`");
 $cash    = mysql_fetch_assoc($select4);

 $online244 = mysql_query("SELECT `id` FROM `[users]` WHERE `online` LIKE '".date('Y-m-d',(time()-3600*24))."%'");
 $online24 = mysql_num_rows($online244);

 $hhhh = mysql_query("SELECT `id` FROM `[users]` WHERE `signup` LIKE '".date('Y-m-d',(time()-3600*24))."%'");
 $join = mysql_num_rows($hhhh);

 $dbres                                 = mysql_query("SELECT `id` FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300");
 $online                                = mysql_num_rows($dbres);

echo "<table width=75% align=\"center\"><td class=subTitle width=8%><b>Statistics </b></td>
  </tr>
  <tr>
    <td class=mainTxt width=75% align=center>
  	  <table width=75% align=center>
		<tr>
		  <td width=50% class=mainTxt><b>Number of Players:</b></td>
		
		  <td width=50% class=mainTxt>
$leden
</td>
		</tr>
		<tr>
		  <td width=50% class=mainTxt><b>Number of Gangs:</b></td>
		  <td width=50% class=mainTxt>
$clans
</td>
		</tr>
		<tr>
		  <td width=50% class=mainTxt><b>Messages Sent:</b></td>
		  <td width=50% class=mainTxt>
$berichten
</td>
		</tr>
		<tr>
		  <td width=50% class=mainTxt><b>Player Signups in the Last 24 Hours:</b></td>
		  <td width=50% class=mainTxt>$join</td>
		</tr>
		<tr>
		  <td width=50% class=mainTxt><b>Players Online:</b></td>
		  <td width=50% class=mainTxt>
$online
</td>
		</tr>
		<tr>
		  <td width=50% class=mainTxt><b>Players Online in the Last 24 Hours:</b></td>
		  <td width=50% class=mainTxt>
$online24
</td>
		
		</tr>
		<tr>
		  <td width=50% class=mainTxt><b>Cars in The Game:</b></td>
		  <td width=50% class=mainTxt>$car</td>
		</tr>
		</table>";

}

if($_GET['x'] == "geld")
{

          $dbres				= mysql_query("SELECT `cash` FROM `[users]` WHERE `level` > '0' AND `level` < '256'");
          $cash					= 0;
          while($user1 = mysql_fetch_assoc($dbres))
            $cash				+= $user1['cash'];
            $cash1 = number_format($cash,0);

          $dbres				= mysql_query("SELECT `bank` FROM `[users]` WHERE `level` > '0' AND `level` < '256'");
          $bank					= 0;
          while($user = mysql_fetch_assoc($dbres))
            $bank				+= $user['bank'];
            $bank1 = number_format($bank,0);

         $select = mysql_query("SELECT * FROM `[users]`");
    $members = mysql_num_rows($select);
    $total1 = round($bank+$cash);
    $total = number_format($total1,0);
    $totalplayer = round($total1/$members);
    $totalplayer = number_format($totalplayer,0);
   echo "<table width=75% align=\"center\"><td class=subTitle colspan=2><b>Most Cash</b></tr></td>";
   echo "<tr><td class=Maintxt colspan=2><center>Bank Cash in The Game <b>$bank1</b><center></tr></td>";
   echo "<tr><td class=Maintxt colspan=2><center>Wallet Cash in The Game <b>$cash1</b><center></tr></td>";
   echo "<tr><td class=Maintxt colspan=2><center>Total Cash<b> $total</b>, Average Per Player is <b>$totalplayer</b> <center></tr></td>";
      $select = mysql_query("SELECT * FROM `[users]` ORDER BY `cash`+`bank` DESC LIMIT 0,10"); 
      while($list = mysql_fetch_assoc($select)) 
     
    { 

    
        $money = round($list[bank]+$list[cash]); 
	$money = number_format($money, 0, ",", ".");
      echo "<tr><td width=70% align=left class=Maintxt><p align=left><b><a href=profile.php?x=$list[login]>$list[login]</a></b> <td class=maintxt width=30% align=right> <p align=right><b>$money</b></p></tr></td>";

}
}


if($_GET['x'] == "rank")
{

          $dbres				= mysql_query("SELECT `cash` FROM `[users]` WHERE `level` > '0' AND `level` < '256'");
          $cash					= 0;
          while($user1 = mysql_fetch_assoc($dbres))
            $cash				+= $user1['cash'];
            $cash1 = number_format($cash,0);

          $dbres				= mysql_query("SELECT `bank` FROM `[users]` WHERE `level` > '0' AND `level` < '256'");
          $bank					= 0;
          while($user = mysql_fetch_assoc($dbres))
            $bank				+= $user['bank'];
            $bank1 = number_format($bank,0);

         $select = mysql_query("SELECT * FROM `[users]`");
    $members = mysql_num_rows($select);
    $total1 = round($bank+$cash);
    $total = number_format($total1,0);
    $totalplayer = round($total1/$members);
    $totalplayer = number_format($totalplayer,0);
   echo "<table width=75% align=\"center\"><td class=subTitle colspan=2><b>Highest Ranks</b></tr></td>";
      $select = mysql_query("SELECT * FROM `[users]` ORDER BY `rank`+`rank` DESC LIMIT 0,10"); 
      while($list = mysql_fetch_assoc($select)) 
     
    {
$rank1	                  	= array("","Cafone","LowLife","Pickpocket","Shoplifter","Mugger","Thief","WiseGuy","Associate","Mobster","Gangster","Assassin","Good Fella","Mob Boss","The Don","The Legendary Don","The Godfather");
$rank                 		= $rank1[$list[rank]]; 
      echo "<tr><td width=70% align=left class=Maintxt><p align=left><b><a href=profile.php?x=$list[login]>$list[login]</a></b> <td class=maintxt width=30% align=right> <p align=right><b>$rank</b></p></tr></td>";

}
}

if($_GET['x'] == "speler")
{
  
   echo "<table width=75% align=\"center\"><td class=subTitle colspan=2><b>Most Power</b></tr></td>";

      $select = mysql_query("SELECT * FROM `[users]` ORDER BY  (`attack`+`defence`)/2+`clicks`*5 DESC LIMIT 0,10"); 
      while($list = mysql_fetch_assoc($select)) 
     
    { 

    $power                = round(($list[attack]+$list[defence])/2+$list[clicks]*5); 
    $power = number_format($power, 0, ",", ".");
    
    
      echo "<tr><td width=70% align=left class=Maintxt><p align=left><b><a href=profile.php?x=$list[login]>$list[login]</a></b> <td class=maintxt width=30% align=right> <p align=right><b>$power power</b></p></tr></td>";

}
}

if($_GET['x'] == "ref")
{
  
   echo "<table width=75% align=\"center\"><td class=subTitle colspan=2><b>Most Referrals</b></tr></td>";

{

$select = mysql_query("SELECT * FROM `[users]` ORDER BY `recruits`+`recruits` DESC LIMIT 0,10"); 
      while($list = mysql_fetch_assoc($select)) 
     
    {
$ref	                  	= round($list[recruits]);
$ref                 		= number_format($ref, 0, ",", ".");
      echo "<tr><td width=70% align=left class=Maintxt><p align=left><b><a href=profile.php?x=$list[login]>$list[login]</a></b> <td class=maintxt width=30% align=right> <p align=right><b>$ref</b></p></tr></td>";


}
}
}
?>
