<?php
error_reporting(0);

  include("_include-config2.php");
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);
  $dbres				= mysql_query("SELECT `id` FROM `[users]` WHERE `activated`=1");
  $dbres2                                = mysql_query("SELECT `id` FROM `[users]` WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(`online`) < 300");
  $online                                = mysql_num_rows($dbres2);
  $laatstelid = mysql_query("select `login` from `[users]` order by id desc limit 1");
  $laatste = @mysql_result($laatstelid,0,0);
$leven = $data->health;
$cash = number_format($data->cash, 0, '.' , '.');
$bank = number_format($data->bank, 0, '.' , '.');
  $inboxnew = mysql_num_rows(mysql_query("SELECT id FROM `[messages]` WHERE `read`=0 AND `inbox`=1 AND `to`='$data->login'"));
$attack = $data->attack;
$defence = $data->defence;
$clickpower = round($clicks*5);
$power = round($attack+$defence+$clickpower/2);
  $land				= Array("","Netherlands","France","Cuba","Russia","Australia","USA","Germany","Belgium","England","Ireland");
  $land				= $land[$data->land];
$leven = $data->health;
$eraf3 = $leven-1;
$eraf4 = $leven-33;
$eraf5 = $leven-57;
$eraf6 = $leven-59;
$eraf7 = $leven-61;
$eraf8 = $leven-63;
$eraf12 = $leven-68;
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<base target="mainFrame" \>
<script>
<!--

// Refresh time
var limit="2:30"

if (document.images){
var parselimit=limit.split(":")
parselimit=parselimit[0]*60+parselimit[1]*1
}
function beginrefresh(){
if (!document.images)
return
if (parselimit==1)
window.location.reload()
else{ 
parselimit-=1
curmin=Math.floor(parselimit/60)
cursec=parselimit%60
if (curmin!=0)
curtime="Welkom, op onze website"
else
curtime="Welkom, op onze website"
window.status=curtime
setTimeout("beginrefresh()",1000)
}
}

window.onload=beginrefresh
//-->
</script>
</head>
<body style="margin: 0px;">
<center>
<table align="center" width="950" height="21" style="background: url() no-repeat;">
<tr>
<td style="position: absolute; left: 15;"><font color="white">Life:</font></td>
<td style="position: relative; left: 65; top: 0; background: url(/images/leven/leven2.png) no-repeat;">
<?
if($data->leven == 0) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png">
<?
} else if($leven == 1) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png">
<?
} else if($leven > 1 AND $leven < 33) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png" width="<?=$eraf3?>">
<?
} else if($leven > 33 AND $leven < 58) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png" width="<?=$eraf4?>">
<?
} else if($leven == 58 OR $leven == 59) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png" width="<?=$eraf5?>">
<?
} else if($leven == 60 OR $leven == 61) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/6.png" width="<?=$eraf6?>">
<?
} else if($leven == 62 OR $leven == 63) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/6.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/7.png" width="<?=$eraf7?>">
<?
} else if($leven == 64 OR $leven == 65) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/6.png"><img style="position: relative; top: -1; left: -1;" height="12" src="<? echo $sitelink;?>/layout/layout<?php ech/images/leven/o $page->layout; ?>/images/leven/7.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/8.png" width="<?=$eraf8?>">
<?
} else if($leven == 66) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/6.png"><img style="position: relative; top: -1; left: -1;" height="12" src="<? echo $sitelink;?>/layout/layout<?php ech/images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images/o $page->layout; ?>/images/leven/7.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/8.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/9.png">
<?
} else if($leven == 67) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/6.png"><img style="position: relative; top: -1; left: -1;" height="12" src="<? echo $sitelink;?>/layout/layout<?php ech/images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images//images/leven/o $page->layout; ?>/images/leven/7.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/8.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/9.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/10.png">
<?
} else if($leven == 68) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/6.png"><img style="position: relative; top: -1; left: -1;" height="12" src="<? echo $sitelink;?>/layout/layout<?php ech/images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images//images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images/o $page->layout; ?>/images/leven/7.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/8.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/9.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/10.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/11.png">
<?
} else if($leven > 68 AND $leven < 100) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/6.png"><img style="position: relative; top: -1; left: -1;" height="12" src="<? echo $sitelink;?>/layout/layout<?php ech/images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images//images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images//images/leven/o $page->layout; ?>/images/leven/7.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/8.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/9.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/10.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/11.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/12.png" width="<?=$eraf12?>">
<?
} else if($leven == 100) {
?>
<img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/1.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/2.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/3.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/4.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/5.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/6.png"><img style="position: relative; top: -1; left: -1;" height="12" src="<? echo $sitelink;?>/layout/layout<?php ech/images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images//images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images//images/leven/<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/images//images/leven/o $page->layout; ?>/images/leven/7.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/8.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/9.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/10.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/11.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/12.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/13.png"><img style="position: relative; top: -1; left: -1;" height="12" src="images/leven/14.png">
<?
}
?>
</td>
<td class="levenTxt" style="position: absolute; left: 139; top: 5;"><font color="white"><?=$leven?>%</font></td>
<td style="position: absolute; left: 230;"><font color="white"><a href="bank.php?x=pinstort"><img border="0" title="Cash" src="/images/leven/cash.png"> ;<?=$cash?></font></a></td>
<td style="position: absolute; left: 360;"><font color="white"><a href="bank.php?x=pinstort"><img border="0" title="Bank" src="/images/leven/bank.png"> ;<?=$bank?></font></a></td>
<td style="position: absolute; left: 490;"><font color="white"><a href="airport.php"><img border="0" title="Land" src="/images/leven/land.png"> <?=$land?></font></a></td>
</tr>
</table>
</center>
</body>
</html>