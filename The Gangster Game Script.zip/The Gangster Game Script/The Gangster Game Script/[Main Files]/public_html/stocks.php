<?php
error_reporting(0);

  include("_include-config.php"); 
      include("_include-gevangenis.php"); 
  if(! check_login()) 
  {
    header("Location: login.php");
    exit;
  } 

  $db  = mysql_query("SELECT * FROM `[users]` WHERE `login`='$data->login'");
$sql = mysql_fetch_assoc($db);

    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);

?>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<html>
<body> 
<br><br>
<table  width=100%><table width=100% cellspacing=0 cellpadding=2><table width=100%> 
<tr>
<td width="96%" class=subTitle><b>Make Some Money</b></td>
<table  width=100%>
<td class="mainTxt"><center><img border=0 src=images/game/stockpicture.jpg border=0></center>
</td>


<table width='100%' cellpadding='2' cellspacing='1' align='center' >
<tr><td class="subtitle"colspan="8" align=center>The Shares</td></tr>
<tr><td class=Maintxt colspan=8>Here you can purchase shares in different companies.<br> Its a gambling way to make some quick cash. You could either gain profit, or a loss.<br>Stock prices alter around each purchase of stock by all the website members.</tr></td>
<tr><td class=subtitle>#</td><td class=subtitle>Price</td><td class=subtitle>Amount</td><td class=subtitle>Value</td><td class=subtitle>Balance</td><td class=subtitle>Business</td><td class=subtitle>Options</td></tr> 


<?php  




$select1 = mysql_query("SELECT SUM(`beurs1`) FROM `[users]`");
$sb1 = mysql_fetch_assoc($select1);

$data2            = mysql_query("SELECT *,UNIX_TIMESTAMP(`beurstijd`) AS `beurstijd`,0 FROM `[beurs]` WHERE `id`='1'");
$data1            = mysql_fetch_object($data2);
if($data1->beurstijd + 600 < time())
{
mysql_query("UPDATE `[beurs]` SET `beurstijd`=NOW() WHERE `id`='1'");

$datu1            = mysql_query("SELECT * FROM`[beurs]` WHERE `id`='1'");
$dato1           = mysql_fetch_object($datu1);
if($dato1->waarde < 100){$var1 = 1;}
else{$var1 = rand(1,3);}
$datu2            = mysql_query("SELECT * FROM`[beurs]` WHERE `id`='2'");
$dato2           = mysql_fetch_object($datu2);
if($dato2->waarde < 100){$var2 = 1;}
else{$var2 = rand(1,3);}
$datu3            = mysql_query("SELECT * FROM`[beurs]` WHERE `id`='3'");
$dato3           = mysql_fetch_object($datu3);
if($dato3->waarde < 100){$var3 = 1;}
else{$var3 = rand(1,3);}
$datu4            = mysql_query("SELECT * FROM`[beurs]` WHERE `id`='4'");
$dato4           = mysql_fetch_object($datu4);
if($dato4->waarde < 100){$var4 = 1;}
else{$var4 = rand(1,3);}

if($var1 ==1){$var1 = rand(1,100);
mysql_query("UPDATE `[beurs]` SET `waarde`=`waarde`+'$var1' WHERE `id`='1'");
mysql_query("UPDATE `[beurs]` SET `positie`='1' WHERE `id`='1'");}
if($var1 ==2){mysql_query("UPDATE `[beurs]` SET `positie`='0' WHERE `id`='1'");}
if($var1 ==3){$var1 = rand(1,100);
mysql_query("UPDATE `[beurs]` SET `waarde`=`waarde`-'$var1' WHERE `id`='1'");
mysql_query("UPDATE `[beurs]` SET `positie`='-1' WHERE `id`='1'");}
if($var2 ==1){$var2 = rand(1,100);
mysql_query("UPDATE `[beurs]` SET `waarde`=`waarde`+'$var2' WHERE `id`='2'");
mysql_query("UPDATE `[beurs]` SET `positie`='1' WHERE `id`='2'");}
if($var2 ==2){mysql_query("UPDATE `[beurs]` SET `positie`='0' WHERE `id`='2'");}
if($var2 ==3){$var2 = rand(1,100);
mysql_query("UPDATE `[beurs]` SET `waarde`=`waarde`-'$var2' WHERE `id`='2'");
mysql_query("UPDATE `[beurs]` SET `positie`='-1' WHERE `id`='2'");}
if($var3 ==1){$var3 = rand(1,100);
mysql_query("UPDATE `[beurs]` SET `waarde`=`waarde`+'$var3' WHERE `id`='3'");
mysql_query("UPDATE `[beurs]` SET `positie`='1' WHERE `id`='3'");}
if($var3 ==2){mysql_query("UPDATE `[beurs]` SET `positie`='0' WHERE `id`='3'");}
if($var3 ==3){$var3 = rand(1,100);
mysql_query("UPDATE `[beurs]` SET `waarde`=`waarde`-'$var3' WHERE `id`='3'");
mysql_query("UPDATE `[beurs]` SET `positie`='-1' WHERE `id`='3'");}
if($var4 ==1){$var4 = rand(1,100);
mysql_query("UPDATE `[beurs]` SET `waarde`=`waarde`+'$var4' WHERE `id`='4'");
mysql_query("UPDATE `[beurs]` SET `positie`='1' WHERE `id`='4'");}
if($var4 ==2){mysql_query("UPDATE `[beurs]` SET `positie`='0' WHERE `id`='4'");}
if($var4 ==3){$var4 = rand(1,100);
mysql_query("UPDATE `[beurs]` SET `waarde`=`waarde`-'$var4' WHERE `id`='4'");
mysql_query("UPDATE `[beurs]` SET `positie`='-1' WHERE `id`='4'");}}
$date1            = mysql_query("SELECT * FROM`[beurs]` WHERE `id`='1'");
$data1            = mysql_fetch_object($date1);
if($data1->positie == 1){ $image1 = 'up'; }
if($data1->positie == -1){ $image1 = 'down'; }
if($data1->positie == 0){ $image1 = 'not'; }
$date2            = mysql_query("SELECT * FROM`[beurs]` WHERE `id`='2'");
$data2            = mysql_fetch_object($date2);
if($data2->positie == 1){ $image2 = 'up'; }
if($data2->positie == -1){ $image2 = 'down'; }
if($data2->positie == 0){ $image2 = 'not'; }
$date3            = mysql_query("SELECT * FROM`[beurs]` WHERE `id`='3'");
$data3            = mysql_fetch_object($date3);
if($data3->positie == 1){ $image3 = 'up';}
if($data3->positie == -1){ $image3 = 'down';}
if($data3->positie == 0){ $image3 = 'not';}
$date4            = mysql_query("SELECT * FROM`[beurs]` WHERE `id`='4'");
$data4            = mysql_fetch_object($date4);
if($data4->positie == 1){ $image4 = 'up'; }
if($data4->positie == -1){ $image4 = 'down'; }
if($data4->positie == 0){ $image4 = 'not'; }


$totaall1 = ($sql[beursw1] * $sql[beurs1]);
$totaal1 = number_format($totaall1,0);
$totaall2 = ($sql[beursw2] * $sql[beurs2]);
$totaal2 = number_format($totaall2,0);
$totaall3 = ($sql[beursw3] * $sql[beurs3]);
$totaal3 = number_format($totaall3,0);
$totaall4 = ($sql[beursw4] * $sql[beurs4]);
$totaal4 = number_format($totaall4,0);
$cash = number_format($data->cash,0);
if($sql[beurs1] == 0){($pecent1 = 0);}
else{$pecent1 = round(((($data1->waarde / $sql[beursw1]) * 100)-100));}
if($sql[beurs2] == 0){($pecent2 = 0);}
else{$pecent2 = round(((($data2->waarde / $sql[beursw2]) * 100)-100));}
if($sql[beurs3] == 0){($pecent3 = 0);}
else{$pecent3 = round(((($data3->waarde / $sql[beursw3]) * 100)-100));}
if($sql[beurs4] == 0){($pecent4 = 0);}
else{$pecent4 = round(((($data4->waarde / $sql[beursw4]) * 100)-100));}
$totaa1 = number_format($data1->waarde,0);
$totaa2 = number_format($data2->waarde,0);
$totaa3 = number_format($data3->waarde,0);
$totaa4 = number_format($data4->waarde,0);
$totaallv1 = ($sql[beurs1] * $data1->waarde);
$totaalv1 = number_format($totaallv1,0);
$totaallv2 = ($sql[beurs2] * $data2->waarde);
$totaalv2 = number_format($totaallv2,0);
$totaallv3 = ($sql[beurs3] * $data3->waarde);
$totaalv3 = number_format($totaallv3,0);
$totaallv4 = ($sql[beurs4] * $data4->waarde);
$totaalv4 = number_format($totaallv4,0);
$txt_datageld = "Cash in Hand";



print <<<ENDHTML
<form method=post>
        
<tr><td class=maintxt align=center><img src=images/beurs/$image1.gif></td><td class=maintxt>$totaa1</td><td class=maintxt>$sql[beurs1]</td><td class=maintxt>$totaalv1</td><td class=maintxt>$pecent1%</td><td class=maintxt>G&C Bullet Factory</td><td class=maintxt><p align=center>Amount <input type=tekst class='btn btn-info' name=beurs1 size=3></p></td></tr>
		

<tr><td class=maintxt align=center><img src=images/beurs/$image2.gif></td><td class=maintxt>$totaa2</td><td class=maintxt>$sql[beurs2]</td><td class=maintxt>$totaalv2</td><td class=maintxt>$pecent2%</td><td class=maintxt>Auto-Dealers</td><td class=maintxt><p align=center>Amount <input type=tekst class='btn btn-info' name=beurs2 size=3></p></td></tr>
		

<tr><td class=maintxt align=center><img src=images/beurs/$image3.gif></td><td class=maintxt>$totaa3</td><td class=maintxt>$sql[beurs3]</td><td class=maintxt>$totaalv3</td><td class=maintxt>$pecent3%</td><td class=maintxt>SDC Licensing  </td><td class=maintxt><p align=center>Amount <input type=tekst class='btn btn-info' name=beurs3 size=3></p></td></tr>
		


<tr><td class=maintxt align=center><img src=images/beurs/$image4.gif></td><td class=maintxt>$totaa4</td><td class=maintxt>$sql[beurs4]</td><td class=maintxt>$totaalv4</td><td class=maintxt>$pecent4%</td><td class=maintxt>'Hit us and We Hit You' Insurance</td><td class=maintxt><p align=center>Amount <input type=tekst class='btn btn-info' name=beurs4 size=3></p></td></tr>		
<tr><td class=maintxt colspan=6>$txt_datageld: $data->cash</td><td class=maintxt><p align=center><input type="submit" class="btn btn-info" name="koop"  value="Purchase">&nbsp;<input type="submit" name="verkoop" class="btn btn-info" value="Sell"></p></td></tr>
</form>
</table>
ENDHTML;

if(isset($_POST['koop'])){ 	  	
					 if( $_POST['beurs1'] ){
					 if(!preg_match('/^[0-9]{1,10}$/',$_POST['beurs1'])){
    echo "<table width=100% align=center><tr><td class=MainTxt><font color=red>Error!</font></tr></td>"; exit;}	  	 
    			if($sql[beurs1] > 0) {
    			print "<table width=100% align=center><tr><td class=MainTxt>You cant purchase anymore shares as you already have shares in your possesion</tr></td>";
    			exit;}
    			if($data->cash < (($data1->waarde)*($_POST['beurs1']))){
    			print "<table width=100% align=center><tr><td class=MainTxt>You dont have enough cash</tr></td>";
    			exit;}
    			if($sql[beurs1] + $_POST['beurs1'] > 1000 OR $_POST['beurs1'] > 1000){
    			print "<table width=100% align=center><tr><td class=MainTxt>You cannot buy that many shares, the limit is 1000 per business.</tr></td>";
    			exit;}
    			else{
    			$price = (($data1->waarde)*($_POST['beurs1']));
    			$price1 = number_format($price,0);
    			mysql_query("UPDATE `[users]` SET `cash`=`cash`-'{$price}' WHERE `login`='{$data->login}'");
                        mysql_query("UPDATE `[users]` SET `beurs1`=`beurs1`+'{$_POST['beurs1']}',`beursw1`='{$data1->waarde}' WHERE `login`='$data->login'");
    			print "<table width=100% align=center><tr><td class=MainTxt align=center width=100%>You have purchased $beurs1 shares in G&C Bullet Factory for $price1<script language=\"javascript\">setTimeout('self.window.location.href=\"stocks.php\"',1500)</script></tr></td>";}
    			}
    				if( $_POST['beurs2'] ){	 
    				if(!preg_match('/^[0-9]{1,10}$/',$_POST['beurs2'])){
    echo "<table width=100% align=center><tr><td class=MainTxt><font color=red>error!</font></tr></td>"; exit;} 
        			if($sql[beurs2] > 0) {
    			print "<table width=100% align=center><tr><td class=MainTxt>You cant buy anymore shares as you already have some shares in your possesion.</tr></td>";
    			exit;}	 
    			if($data->cash < (($data2->waarde)*($_POST['beurs2']))){
    			print "<table width=100% align=center><tr><td class=MainTxt>You dont have enough cash</tr></td>";
    			exit;}
    			if($sql[beurs2] + $_POST['beurs2'] > 1000 OR $_POST['beurs2'] > 1000){
    			print "<table width=100% align=center><tr><td class=MainTxt>You cant buy that many shares, the maximum ammount is 1000 shares per company</tr></td>";
    			exit;}
    			else{
    			$price = (($data2->waarde)*($_POST['beurs2']));
    			$price1 = number_format($price,0);
    			mysql_query("UPDATE `[users]` SET `cash`=`cash`-'{$price}' WHERE `login`='{$data->login}'");
                        mysql_query("UPDATE `[users]` SET `beurs2`=`beurs2`+'{$_POST['beurs2']}',`beursw2`='{$data2->waarde}' WHERE `login`='$data->login'");
    			print "<table width=100% align=center><tr><td class=MainTxt>You have purchased $beurs2 shares for Auto-Dealer, for $price1 <script language=\"javascript\">setTimeout('self.window.location.href=\"stocks.php\"',1500)</script></tr></td>";}
    			}
    				if( $_POST['beurs3'] ){	  
    				if(!preg_match('/^[0-9]{1,10}$/',$_POST['beurs3'])){
    echo "<table width=100% align=center><tr><td class=MainTxt><font color=red>* error!</font></tr></td>"; exit;}	
        			if($sql[beurs3] > 0) {
    			print "<table width=100% align=center><tr><td class=MainTxt>You cant buy anymore shares as you already have some in your possesion</tr></td>";
    			exit;} 
    			if($data->cash < (($data3->waarde)*($_POST['beurs3']))){
    			print "<table width=100% align=center><tr><td class=MainTxt>You dont have enough cash</tr></td>";
    			exit;}
    			if($sql[beurs3] + $_POST['beurs3'] > 1000 OR $_POST['beurs3'] > 1000){
    			print "<table width=100% align=center><tr><td class=MainTxt>You cant buy that many shares, the maximum is 1000 per company</tr></td>";
    			exit;}
    			else{
    			$price = (($data3->waarde)*($_POST['beurs3']));
    			$price1 = number_format($price,0);
    			mysql_query("UPDATE `[users]` SET `cash`=`cash`-'{$price}' WHERE `login`='{$data->login}'");
                        mysql_query("UPDATE `[users]` SET `beurs3`=`beurs3`+'{$_POST['beurs3']}',`beursw3`='{$data1->waarde}' WHERE `login`='$data->login'");
    			print "<table width=100% align=center><tr><td class=MainTxt>You purchased $beurs3 shares of SDC Licensing for $price1<script language=\"javascript\">setTimeout('self.window.location.href=\"stocks.php\"',1500)</script></tr></td>";}
    			}
    				if( $_POST['beurs4'] ){	  	
    				if(!preg_match('/^[0-9]{1,10}$/',$_POST['beurs4'])){
    echo "<table width=100% align=center><tr><td class=MainTxt><font color=red>* error!</font></tr></td>"; exit;} 
        			if($sql[beurs4] > 0) {
    			print "<table width=100% align=center><tr><td class=MainTxt>You cant buy any shares, you already have some</tr></td>";
    			exit;}
    			if($data->cash < (($data4->waarde)*($_POST['beurs4']))){
    			print "<table width=100% align=center><tr><td class=MainTxt>You dont have enough cash.</tr></td>";
    			exit;}
    			if($sql[beurs4] + $_POST['beurs4'] > 1000 OR $_POST['beurs4'] > 1000){
    			print "<table width=100% align=center><tr><td class=MainTxt>You cant buy that many shares, the limit is 1000 per business</tr></td>";
    			exit; }
    			else{
    			$price = (($data4->waarde)*($_POST['beurs4']));
    			$price1 = number_format($price,0);
    			mysql_query("UPDATE `[users]` SET `cash`=`cash`-'{$price}' WHERE `login`='{$data->login}'");
                        mysql_query("UPDATE `[users]` SET `beurs4`=`beurs4`+'{$_POST['beurs4']}',`beursw4`='{$data1->waarde}' WHERE `login`='$data->login'");
    			print "<table width=100% align=center><tr><td class=MainTxt>You have bought $beurs4 shares of 'Hit us and We Hit You' Insurance for $price1<script language=\"javascript\">setTimeout('self.window.location.href=\"stocks.php\"',1500)</script></tr></td>";}
    			}
  				}
  				
if(isset($_POST['verkoop'])){ 
				if( $_POST['beurs1'] ){
				if(!preg_match('/^[0-9]{1,10}$/',$_POST['beurs1'])){
    echo "<table width=100% align=center><tr><td class=MainTxt><font color=red>error!</font></tr></td>"; exit;}
  				if($sql[beurs1] < $_POST['beurs1']){
  				print "<table width=100% align=center><tr><td class=MainTxt>You dont have any shares for G&C Bullet Factory</tr></td>";}
  				else{		  	 
				$price	= (($data1->waarde)*($_POST['beurs1']));
				$price1 = number_format($price,0);
    			mysql_query("UPDATE `[users]` SET `cash`=`cash`+'{$price}' WHERE `login`='{$data->login}'");
                        mysql_query("UPDATE `[users]` SET `beurs1`=`beurs1`-'{$_POST['beurs1']}' WHERE `login`='$data->login'");
    			print "<table width=100% align=center><tr><td class=MainTxt>You sold $beurs1 shares of G&C Bullet Factory for $price1<script language=\"javascript\">setTimeout('self.window.location.href=\"stocks.php\"',1500)</script></tr></td>";}
  				}
  				
				if( $_POST['beurs2'] ){
				if(!preg_match('/^[0-9]{1,10}$/',$_POST['beurs2'])){
    echo "<table width=100% align=center><tr><td class=MainTxt><font color=red>Error!</font></tr></td>";
    exit;
    }
  				if($sql[beurs2] < $_POST['beurs2']){
  				print "<table width=100% align=center><tr><td class=MainTxt>You dont have any shares for Auto-Dealer</tr></td>";}
  				else{		  	 
				$price	= (($data2->waarde)*($_POST['beurs2']));
				$price1 = number_format($price,0);
    			mysql_query("UPDATE `[users]` SET `cash`=`cash`+'{$price}' WHERE `login`='{$data->login}'");
                        mysql_query("UPDATE `[users]` SET `beurs2`=`beurs2`-'{$_POST['beurs2']}' WHERE `login`='$data->login'");
    			print "<table width=100% align=center><tr><td class=MainTxt>You sold $beurs2 Auto-Dealer shares for $price1<script language=\"javascript\">setTimeout('self.window.location.href=\"stocks.php\"',1500)</script></tr></td>";}
  				}
  				
  				if( $_POST['beurs3'] )
                                {

  				if(!preg_match('/^[0-9]{1,10}$/',$_POST['beurs3']))
                                {
                                    echo "<table width=100% align=center><tr><td class=MainTxt><font color=red>Error!</font></tr></td>"; 
                                    exit;
                                }

  				if($sql[beurs3] < $_POST['beurs3'])
                                {
  				    print "<table width=100% align=center><tr><td class=MainTxt>You dont have any shares for SDC Licensing</tr></td>";}
  				else{		  	 
				$price	= (($data3->waarde)*($_POST['beurs3']));
				$price1 = number_format($price,0);
    			mysql_query("UPDATE `[users]` SET `cash`=`cash`+'{$price}' WHERE `login`='{$data->login}'");
                        mysql_query("UPDATE `[users]` SET `beurs3`=`beurs3`-'{$_POST['beurs3']}' WHERE `login`='$data->login'");
    			print "<table width=100% align=center><tr><td class=MainTxt>You sold $beurs3 SDC Licensing shares for $price1<script language=\"javascript\">setTimeout('self.window.location.href=\"stocks.php\"',1500)</script></tr></td>";}
  				}
  				
  				if( $_POST['beurs4'] )
                                {
  				
                                if(!preg_match('/^[0-9]{1,10}$/',$_POST['beurs4']))
                                {
                                   echo "<table width=100% align=center><tr><td class=MainTxt><font color=red>Error!</font></tr></td>"; 
                                   exit;
                                }
 
  				if($sql[beurs4] < $_POST['beurs4'])
                                {
  				    print "<table width=100% align=center><tr><td class=MainTxt>You dont have any shares for 'Hit Us and We Hit You' Insurance</tr></td>";
                                }
  				else{		  	 
				$price	= (($data4->waarde)*($_POST['beurs4']));
				$price1 = number_format($price,0);
    			mysql_query("UPDATE `[users]` SET `cash`=`cash`+'{$price}' WHERE `login`='{$data->login}'");
                        mysql_query("UPDATE `[users]` SET `beurs4`=`beurs4`-'{$_POST['beurs4']}' WHERE `login`='$data->login'");
    			print "<table width=100% align=center><tr><td class=MainTxt>You sold $beurs4 'Hit Us and We Hit You' Insurance shares for $price1<script language=\"javascript\">setTimeout('self.window.location.href=\"stocks.php\"',1500)</script></tr></td>";
                        }
  		      }
  		    }


?>
