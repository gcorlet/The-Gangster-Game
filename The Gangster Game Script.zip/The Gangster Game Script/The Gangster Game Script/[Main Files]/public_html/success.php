<?php
error_reporting(0);

  include("_include-config.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
</td>
</td>
<table width="441">
</td></tr>
</table>

<?PHP




echo " 



 <tr><td class=\"mainTxt\" align=\"left\"><font color=green><b><center>Success!</b></font>

<br>
<br>
Congratulations and thank you for purchasing VIP Credits.<br>
Please dont hesitate to contact an admin incase of any problems, thank you.
</td></tr>";
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`+1500 where `login`='$data->login'");
exit;


?>
