<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<?php
error_reporting(0);
 


$diff5                                = ($moord->getaway + 1800)-time();
  $diff50                               = date("i:s", "$diff5");

  $data2                                = mysql_query("SELECT *,UNIX_TIMESTAMP(`auto`) AS `auto`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $data1                                = mysql_fetch_object($data2);
  $diff3                                = ($data1->auto + 240) - time();
  $diff30                               = date("i:s", "$diff3");

  $data2                                = mysql_query("SELECT *,UNIX_TIMESTAMP(`misdaad`) AS `misdaad`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $data1                                = mysql_fetch_object($data2);
  $diff                                 =($data1->misdaad+120)-time();
  $diff0                                = date("i:s", "$diff");

  $data42                                = mysql_query("SELECT *,UNIX_TIMESTAMP(`opdruktijd`) AS `opdruktijd`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
  $data4                                = mysql_fetch_object($data42);
  $opdruktijd1 = $data4->opdruktijd1;
  $diff4                                 =($data4->opdruktijd+$opdruktijd1)-time();
  $diff40                                = date("i:s", "$diff4");



  if ($diff2 <= -1){
$diff2 = Available;
}
if ($diff <= -1){
$diff = Available;
}
if ($diff3 <= -1){
$diff3 = Available;
}
if ($tijd1 <= -1){
$tijd1 = Now;
}
if ($diff4 <= -1){
$diff4 = Available;
}
if ($diff5 <= -1){
$diff5 = Now;
}














	$data2            = mysql_query("SELECT *,UNIX_TIMESTAMP(`auto`) AS `auto`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
	  $data1            = mysql_fetch_object($data2);
	$tijdverschil1        = $data1->auto-3360-time(); 
	if($data1->auto + 240 > time()){
   list($uur,$min,$sec)=explode(":",date("i:s",$tijdverschil1));
?>
<script type="text/javascript">
 <?echo 'var u='.$uur.';var m='.$min.';var s='.$sec.'+1;';?>
 function settimer(i){return (i>9)?i:"0"+i;}
 function timer(){s--;
 if((s==0)&&(m==0)&&(u==0)){document.getElementById('timeout').submit();}
 if((s==0)&&(m==0)&&(u!=0)){u--;m=59;}
 if((s==-1)&&(m!=0)){m--;s=59;}
 if(s>=0){document.getElementById('timer').value=settimer(u)+':'+settimer(m)+':'+settimer(s);}}
 setInterval("timer()",1000);
</script>
<form id="timeout">
<table width=100%>
 <tr><td class="subTitle"><b>Car Theft</b></td></tr>
 <tr>
  <td class="mainTxt" align="center" >
You can only steal a car every 4 minutes.<br>
You now have to wait - <? if ($diff3 >= -1){print "{$diff30}";} ?>
	</td>
 </tr>
</form>

</table>
</body>
</html>
<?
exit;
}

?>