<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<?php
error_reporting(0);

	$data2            = mysql_query("SELECT *,UNIX_TIMESTAMP(`getaway`) AS `getaway`,0 FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
	  $data1            = mysql_fetch_object($data2);
	$tijdverschil1        = $data1->getaway-time(); 
	if($data1->getaway + 3600 > time()){
   list($uur,$min,$sec)=explode(":",date("H:i:s",$tijdverschil1));
?>
<script type="text/javascript">
 <?echo 'var u='.$uur.';var m='.$min.';var s='.$sec.'+1;';?>
 function settimer(i){return (i>9)?i:"0"+i;}
 function timer(){s--;
 if((s==0)&&(m==0)&&(u==0)){document.getElementById('timeout').submit();}
 if((s==0)&&(m==0)&&(u!=0)){u--;m=59;}
 if((s==-1)&&(m!=0)){m--;s=59;}
 if(s>=0){document.getElementById('timer').value=settimer(u)+':'+settimer(m)+':'+settimer(s);}}
 setInterval("timer()",1000);
</script>
<form id="timeout">
<table width=100%>
 <tr><td class="subTitle"><b>Transport Heist</b></td></tr>
 <tr>
  <td class="mainTxt" align="center" >
You can only do a Heist once every hour<br>Check back in a while!

	</td>
 </tr>
</form>

</table>
</body>
</html>
<?
exit;
}

?>