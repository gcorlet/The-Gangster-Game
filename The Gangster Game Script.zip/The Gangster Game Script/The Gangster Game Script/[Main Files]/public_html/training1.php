<?php
error_reporting(0);

  include("_include-config.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
</head>
  <?php
// PageView Limit
// No more than X pageviews in one minute.

Function PageViewLimit(){

   $PvlViews=20; // Number of pageviews.
   $error="<center><b><BR>Error:<BR>There is a limit of 20 pageviews per minute on this page.</b></center>"; // Change in the error in something you want.

   session_start();
   if(!isset($_SESSION['Pvl'])){
      $_SESSION['Pvl']['Time']=time();
      $_SESSION['Pvl']['Views']=1;
   }
   else{
      // delete if excists longer than 60 seconds, and make a new one
      if((time()-$_SESSION['Pvl']['Time']) >= 60){

     $_SESSION['Pvl'] = null;

     $_SESSION['Pvl']['Time']=time();
     $_SESSION['Pvl']['Views']=1;
      }
      else{
         $_SESSION['Pvl']['Views']++;

     if($_SESSION['Pvl']['Views']>=$PvlViews){
           exit($error);
         }
      }
   }
}
PageViewLimit();
?> 

</head>
<table width="630" align="center">
<tr><td class="subTitle"><b>Train to Steal Cars</b></td></tr>
<tr><td class="mainTxt">
<?php   	
$boksen1           = mysql_query("SELECT *,UNIX_TIMESTAMP(`opdruktijd`) AS `opdruktijd`,0 FROM `[users]` WHERE `login`='$data->login'");
$boksen            = mysql_fetch_object($boksen1);
	
if($boksen->opdruktijd + $boksen->opdruktijd1 > time()){
	print "You are already busy training!.";
	print "</tr></td></table>";
}
else{
	if(isset($_POST['B'])) {
		$T         = $_POST['T'];
		if($T == 1){
			print "You will begin training now... The training lasts 5 minutes.</td></tr></table>";
			mysql_query("UPDATE `[users]` SET `training1`=`training1`+'2' WHERE `login`='$data->login'");
			mysql_query("UPDATE `[users]` SET `opdruktijd1`='300', `opdruktijd`=NOW() WHERE `login`='$data->login'");
		}
		elseif($T == 2){
			print "You will begin training now... The training lasts 10 minutes.</td></tr></table>";
			mysql_query("UPDATE `[users]` SET `training1`=`training1`+'3' WHERE `login`='$data->login'");
			mysql_query("UPDATE `[users]` SET `opdruktijd1`='600', `opdruktijd`=NOW() WHERE `login`='$data->login'");
		}
		elseif($T == 3){
			print "You will begin training now... The training lasts 15 minutes.</td></tr></table>";
			mysql_query("UPDATE `[users]` SET `training1`=`training1`+'4' WHERE `login`='$data->login'");
			mysql_query("UPDATE `[users]` SET `opdruktijd1`='900', `opdruktijd`=NOW() WHERE `login`='$data->login'");
		}
	}
	else {
		print <<<ENDHTML
		<form method="POST">
  <table border=0 cellspacing=0 cellpadding=2 width=90% align=center>
  <tr>
  <td class=subTitle align=center>Activity</td>
  <td class=subTitle align=center>Time</td>
  </tr>
  <tr>
  <td width=50% class=mainTxt><input type="radio" value="1" name="T" class="normalRadio"> Breaking Windows.</td>
  <td class=mainTxt>5 Min.</td>
  </tr>
  <tr>
  <td width=50% class=mainTxt><input type="radio" value="2" name="T" class="normalRadio"> Alarm Imobolising.</td>
  <td class=mainTxt>10 Min.</td>
  </tr>
  <tr>
  <td width=50% class=mainTxt><input type="radio" value="3" name="T" class="normalRadio"> Hot Wiring a Car.</td>
  <td class=mainTxt>15 Min.</td>
  </tr>
  <tr>
  <td class=mainTxt colspan=2 align=center><input type="submit" class="btn btn-info" value=" Lets Do It! " name="B"></td>
  </tr>
  </table>
  </form>



ENDHTML;
	}
}
	
/* ------------------------- */ ?>
</table>
</td></tr>
</table>

</body>

</html>