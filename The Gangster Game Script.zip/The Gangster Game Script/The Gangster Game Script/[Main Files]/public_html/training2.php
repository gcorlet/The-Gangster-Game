<?php
error_reporting(0);

  include("_include-config.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link ref="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
  <?php
// PageView Limit
// No more than X pageviews in one minute.

Function PageViewLimit(){

   $PvlViews=20; // Number of pageviews.
   $error="<center><b><BR>Error:<BR>This page is limited to 20 pageviews a minute.</b></center>"; // Change in the error in something you want.

   session_start();
   if(!isset($_SESSION['Pvl'])){
      $_SESSION['Pvl']['Time']=time();
      $_SESSION['Pvl']['Views']=1;
   }
   else{
      // delete if excists longer than 60 seconds, and make a new one
      if((time()-$_SESSION['Pvl']['Time']) >= 60){

     $_SESSION['Pvl'] = null;

     $_SESSION['Pvl']['Time']=time();
     $_SESSION['Pvl']['Views']=1;
      }
      else{
         $_SESSION['Pvl']['Views']++;

     if($_SESSION['Pvl']['Views']>=$PvlViews){
           exit($error);
         }
      }
   }
}
PageViewLimit();
?> 

</head>
<table width="630" align="center">
<tr><td class="subTitle"><b>Training For Crimes</b></td></tr>
<tr><td class="mainTxt">
<?php   	
$boksen1           = mysql_query("SELECT *,UNIX_TIMESTAMP(`opdruktijd`) AS `opdruktijd`,0 FROM `[users]` WHERE `login`='$data->login'");
$boksen            = mysql_fetch_object($boksen1);
	
if($boksen->opdruktijd + $boksen->opdruktijd1 > time()){
	print "Your busy training at the moment!.";
	print "</tr></td></table>";
}
else{
	if(isset($_POST['B'])) {
		$T         = $_POST['T'];
		if($T == 4){
			print "You will now begin training... The tranin lasts 5 minutes.</td></tr></table>";
			mysql_query("UPDATE `[users]` SET `training2`=`training2`+'3' WHERE `login`='$data->login'");
			mysql_query("UPDATE `[users]` SET `opdruktijd1`='300', `opdruktijd`=NOW() WHERE `login`='$data->login'");
		}
		elseif($T == 5){
			print "You will now begin training... The tranin lasts 10 minutes.</td></tr></table>";
			mysql_query("UPDATE `[users]` SET `training2`=`training2`+'4' WHERE `login`='$data->login'");
			mysql_query("UPDATE `[users]` SET `opdruktijd1`='600', `opdruktijd`=NOW() WHERE `login`='$data->login'");
		}
		elseif($T == 6){
			print "You will now begin training... The tranin lasts 15 minutes.</td></tr></table>";
			mysql_query("UPDATE `[users]` SET `training2`=`training2`+'5' WHERE `login`='$data->login'");
			mysql_query("UPDATE `[users]` SET `opdruktijd1`='900', `opdruktijd`=NOW() WHERE `login`='$data->login'");
		}
		elseif($T == 7){
			print "You will now begin training... The tranin lasts 20 minutes.</td></tr></table>";
			mysql_query("UPDATE `[users]` SET `training2`=`training2`+'5' WHERE `login`='$data->login'");
			mysql_query("UPDATE `[users]` SET `opdruktijd1`='1200', `opdruktijd`=NOW() WHERE `login`='$data->login'");
		}
	}
	else {
		print <<<ENDHTML
		<form method="POST">
  <table border=0 cellspacing=0 cellpadding=2 width=90% align=center>
  <tr>
  <td class=subTitle align=center>Activity</td>
  <td class=subTitle align=center>Time</td>
  </tr>
  <tr>
  <td width=50% class=mainTxt><input type="radio" class="btn btn-info" value="4" name="T"> Pickpocket Training</td>
  <td class=mainTxt>5 Min.</td>
  </tr>
  <tr>
  <td width=50% class=mainTxt><input type="radio" class="btn btn-info" value="5" name="T""> Attacking Practice Dummy</td>
  <td class=mainTxt>10 Min.</td>
  </tr>
  <tr>
  <td width=50% class=mainTxt><input type="radio" class="btn btn-info" value="6" name="T"> Opening Cash Registers</td>
  <td class=mainTxt>15 Min.</td>
  </tr>
  <tr>
  <td width=50% class=mainTxt><input type="radio" value="7" name="T" class="btn btn-info"> Dealing Drugs Practice</td>
  <td class=mainTxt>20 Min.</td>
  </tr>
  <tr>
  <td class=mainTxt colspan=2 align=center><input type="submit" class="btn btn-info" value="Train" name="B"></td>
  </tr>
  </table>
  </form>



ENDHTML;
	}
}
	
/* ------------------------- */ ?>
</table>
</td></tr>
</table>

</body>

</html>