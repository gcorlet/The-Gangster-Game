<?php
error_reporting(0);

  include("_include-jail.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

/* ------------------------- */ ?>
<link rel='stylesheet' type='text/css' href='<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css'>
<link rel="stylesheet" type='text/css' href='css/bootstrap.css'>

<?
if (!empty($data) AND $data->topbalk == 1) {	
include('top.php');
}
?>


<TD vAlign=top align=middle width="60%">
<table width='60%' cellpadding='0' cellspacing='0' align='center' ><TR>
<TD class=subtitle align=center colSpan=3><b>Tune Race</b></TD></TR><BR>
<form method=post>
<?

 $sql  = mysql_query("SELECT * FROM `[users]` where `login`='$data->login'");
$iLogin = mysql_fetch_assoc($sql);
$iGet = mysql_query("SELECT `owner`,`rijbewijs` FROM `[garage]` WHERE `id`='{$_POST['autoid']}' AND `owner`='{$iLogin['login']}'");
$iCount = mysql_num_rows($iGet);
$iSelect = mysql_query("SELECT `id`,`auto`,`tuning`,`banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `owner`='{$iLogin['login']}'");
echo"<TR><TD class=maintxt colspan=2><center><b>Circuit</b></td>";
echo"<TR><TD class=maintxt colspan=1><img border='0' src='images/autos/route66.jpg' width='150' height='120'></td><TD class=maintxt colspan=1><img border='0' src='images/autos/downtown.jpg' width='150' height='120'>
<TR><TD class=maintxt colspan=1>
<input type=radio name=route value='Route 66'>Route 66</td>
<TD class=maintxt colspan=1><input type=radio name=route value='Down Town'>Down Town
</tr></td><br>
<TR><TD class=maintxt colspan=1><img border='0' src='images/autos/highway.jpg' width='150' height='120'></td><td class=maintxt colspan=1><img border='0' src='images/autos/bridge.jpg' width='150' height='120'>
<TR><TD class=maintxt colspan=1><input type=radio class='btn btn-info' name=route value='High Way Race'>High Way Race<td class=maintxt colspan=1><input type=radio class='btn btn-info' name=route value='Bridge Race'>Bridge Race</center></td>";
echo"<TR><TD class=maintxt><b>Bet type</b></td><td class=maintxt><select name=type><option value='geld'>Cash</option</select>";
echo"<TR><Td class=maintxt><b>Bet Ammount</b></td><td class=maintxt><input type=text class='btn btn-info' name=geld>";
echo"<TR><Td class=maintxt><b>Car</b></td><td class=maintxt>
<select name=autoid>";
	while($iList = mysql_fetch_assoc($iSelect)) {
echo "<option value={$iList['id']}>{$iList['id']}  {$iList['auto']}</option>";
}
echo"<tr><td class=maintxt colspan=3><center><input type=submit class='btn btn-info' name=start value=\"Place Invitation\"></table>";
?>
<?
if(isset($_POST['start']))
{

$ii = mysql_query("SELECT `naam1` FROM `dragrace` WHERE `naam1`='{$iLogin['login']}'");
$Cc = mysql_num_rows($ii);
if($Cc >='1')
{
Die ("<table width=100%><tr><td class=mainTxt><tr><td class=maintxt> You have already started a Race</td>");
}

if($_POST['autoid'] == '')
{
Die ("<table width=100%><tr><td class=mainTxt><tr><td class=maintxt> You have no car in the garage/td>");
}

if($_POST['route'] == '')
{
Die ("<table width=100%><tr><td class=mainTxt><tr><td class=maintxt> You must choose a cercuit</td>");
}

if($_POST['type'] == 'geld')
{

if($_POST['geld'] <= 0)
{
Die ("<table width=100%><tr><td class=maintxt>Invalid ammount of {$_POST['geld']}</td>");
}

if(!preg_match('/^[0-9]{1,10}$/',$_POST['geld']))
{
Die ("<table width=100%><tr><td class=maintxt>Invalid ammount of {$_POST['geld']}</td>");
}
if($_POST['geld'] >= $iLogin['cash'])
{
Die("<table width=100%><tr><td class=maintxt>You dont have enough cash</td>");
}
mysql_query("INSERT INTO `dragrace`(`naam1`,`id1`,`deelnemers`,`type`,`bedrag`,`route`)VALUES('{$iLogin['login']}','{$_POST['autoid']}','2','{$_POST['type']}','{$_POST['geld']}','{$_POST['route']}')");
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'{$_POST['geld']}' WHERE `login`='{$iLogin['login']}'");
echo "<table width=100%><tr><td class=maintxt colspan=5>You have successfully started a race<br>Just waitintg for an other player to accept it</tr></td></table>";
}

if($_POST['type'] !='auto' AND $_POST['type'] !='geld')
{
Die("You have an invalid race type!");
}

}
?>

	</form>

<form method=post>
<TD vAlign=top align=middle width="100%">
<table width='100%' cellpadding='2' cellspacing='1' align='center' ><TR>
<TD class=subtitle align=center colSpan=7><b>Pimp Race</b></TD></TR><BR>
<tr><td class=maintxt>#</td><td class=maintxt>Circuit</td><td class=maintxt>Starter</td><td class=maintxt>Status</td><td class=maintxt>Bet</td><td class=maintxt>Options</td>
<?
$SQL = mysql_query("SELECT * FROM `dragrace`  ");
while($list = mysql_fetch_assoc($SQL))
{
$status = ($list['naam2'] == "") ?  "<B><FONT COLOR=#66ccff3>Open</FONT></b>" : "<B><FONT COLOR=#cc3333>Closed</FONT></b>" ;
echo "<tr><td class=maintxt>{$list['id']}</td><td class=maintxt>{$list['route']}</td><td class=maintxt>{$list['naam1']}</td><td class=maintxt>{$status}</td><td class=maintxt>{$list['bedrag']},-</td><td class=maintxt><a href='tunerace.php?id={$list['id']}'><b>Race Options</b></a></td>";
if($list['naam1'] == $iLogin['login']){
echo"<table width='100%'><tr><td class=maintxt colspan=7><center><a href='tunerace.php?id1={$list['id']}'><b>Begin the Race</b></a></td>";
}
}
echo"</table></form></tr></td>";
?><?
if(isset($_GET['id'])) {

echo"<form method=post>";
echo"<TD vAlign=top align=middle width='100%'>";
echo"<table width='100%' cellpadding='2' cellspacing='1' align='center' ><TR>";
echo"<TR><TD class=subtitle colspan=6><center><b>Race opties</b></b></TD></TR><BR>";
$iSelect = mysql_query("SELECT `id`,`auto`,`tuning`,`banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `owner`='{$iLogin['login']}'");
$iSelect2 = mysql_query("SELECT `id1`,`id2`,`id3`,`naam1`,`naam2`,`naam3` FROM `dragrace` WHERE `id`='{$_GET['id']}'");
$iCheck = mysql_query("SELECT `naam1`,`naam2` FROM `dragrace` WHERE `naam1`='{$iLogin['login']}' OR `naam2`='{$iLogin['login']}'");
$iCount = mysql_num_rows($iCheck);
$iGet = mysql_query("SELECT `owner` FROM `[garage]` WHERE `id`='{$_POST['autooid']}' AND `owner`='{$iLogin['login']}'");
$iCount2 = mysql_num_rows($iGet);


echo"<TR><Td class=maintxt><b>Auto</b></td><td class=maintxt><select name=autooid>";
	while($iList = mysql_fetch_assoc($iSelect)) {
echo "<option value={$iList['id']}>{$iList['id']}  {$iList['auto']}</option>";
}
echo"<td class=maintxt><input type=submit class='btn btn-info' name=doemee value='Enter Race'></td>";
echo"<TR><Td class=maintxt><b>Stop </b></td><td class=maintxt><input type=submit class='btn btn-info' name=annuleer value='Cancel Race'>";
echo"<td class=maintxt><input type=submit class='btn btn-info' name=stapuit value='Withdraw'></td>";



if(isset($_POST['doemee'])) { 

$in = mysql_query("SELECT * FROM `dragrace` WHERE `id`='{$_GET['id']}'");
$list = mysql_Fetch_assoc($in);

if($_POST['autooid'] == '')
{
Die ("<table width=100%><tr><td class=mainTxt><tr><td class=maintxt> You dont have a car in the garage</td>");
}

if($iCount >='1'){ Die("<tr><td class=maintxt colspan=5>You have already started a race or<br> you have already taken part in a race"); }
if($list['bedrag'] > $iLogin['cash']){ Die("<tr><td class=maintxt colspan=5>You do not have enough money"); }

echo "<tr><td class=maintxt colspan=5>Success, {$list['bedrag']} has been paid<br> The person who opened the race is to start the race.!";
mysql_query("UPDATE `[users]` SET `cash`=`cash`-'{$list['bedrag']}' WHERE `login`='{$iLogin['login']}'");
mysql_query("UPDATE `dragrace` SET `deelnemer`=`deelnemer`-'1' WHERE `id`='{$_GET['id']}'");

mysql_query("UPDATE `[garage]` SET `tuning`='1' WHERE `id`='{$_POST['autooid']}'");
mysql_query("UPDATE `dragrace` SET `naam2`='{$iLogin['login']}',`id2`='{$_POST['autooid']}' WHERE `id`='{$_GET['id']}'")or die( mysql_error() );
}
}


if(isset($_POST['stapuit']))
{
$check = mysql_query("SELECT `naam2` FROM `dragrace` WHERE `naam2`='{$iLogin['login']}' AND `type`='geld'");
$count = mysql_num_rows($check);

$in = mysql_query("SELECT * FROM `dragrace` WHERE `id`='{$_POST['id']}'");
$list = mysql_Fetch_assoc($in);

if($count <='0'){ Die ("<tr><td class=maintxt colspan=5>You are not the owner of the race"); }
echo "<tr><td class=maintxt colspan=5>You have successfully withdrawn from the race."; 
mysql_query("UPDATE `dragrace` SET `naam2`='' WHERE `naam2`='{$iLogin['login']}' AND `type`='geld'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'{$list['bedrag']}' WHERE `login`='{$iLogin['login']}'");

}


if(isset($_POST['annuleer']))
{
$check = mysql_query("SELECT `naam1` FROM `dragrace` WHERE `naam1`='{$iLogin['login']}'");
$count = mysql_num_rows($check);

$in = mysql_query("SELECT * FROM `dragrace` WHERE `id`='{$_POST['id']}'");
$list = mysql_Fetch_assoc($in);

if($count <='0'){ Die ("<tr><td class=maintxt colspan=5>You are not the owner of the race"); }
echo "<tr><td class=maintxt colspan=5>You have successfully cancelled the race."; 
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'{$list['bedrag']}' WHERE `login`='{$iLogin['login']}'");
mysql_query("UPDATE `[users]` SET `cash`=`cash`+'{$list['bedrag']}' WHERE `login`='{$list['naam2']}'");
mysql_query("DELETE FROM `dragrace` WHERE `naam1`='{$iLogin['login']}'");
}

if(isset($_GET['id1'])) {

$xx = mysql_query("SELECT * FROM `dragrace` WHERE `id`='{$_GET['id1']}'");
$x = mysql_fetch_assoc($xx);

if($x['naam2'] == '')
{
Die ("<table width=100%><tr><td class=mainTxt><tr><td class=maintxt>There is still no second driver</td>");
}


// Waardes van Gebruiker 1 bepalen
$gebr1 =  mysql_query("SELECT `banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='{$x['id1']}'");
$gebr1 = mysql_fetch_assoc($gebr1);
$e = explode("-", $kkhomo);
$t = rand(0,7);
$waarde1 = $e['0']+$e['1']+$e['2']+$e['3']+$e['4']+$e['5']+$e['6']+$e['7']+$t;
$kkhomo = $gebr1['banden']+$gebr1['motor']+$gebr1['interieur']+$gebr1['uitlaat']+$gebr1['remmen']+$gebr1['body']+$gebr1['velgen']+$gebr1['nitro'];
// Waarde is bepaald, en kan weergeven worden door $waarde1

//waardes van gebruiker2 bepalen
$gebr2 =  mysql_query("SELECT `banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='{$x['id2']}'");
$gebr2 = mysql_fetch_assoc($gebr2);
$f = explode("-", $kkhomo3);
$r = rand(0,7);
$kkhomo2 = $gebr2['banden']+$gebr2['motor']+$gebr2['interieur']+$gebr2['uitlaat']+$gebr2['remmen']+$gebr2['body']+$gebr2['velgen']+$gebr2['nitro'];
$waarde2 = $f['0']+$f['1']+$f['2']+$f['3']+$f['4']+$f['5']+$f['6']+$f['7']+$r;
// oke dat ook klaar

//waardes van gebruiker3 bepalen
$gebr3 =  mysql_query("SELECT `banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='id`='{$x['id3']}'");
$gebr3 = mysql_fetch_assoc($gebr3);
$a = explode("-", $kkhomo3);
$b = rand(0,7);
$kkhomo3 = $gebr1['banden']+$gebr1['motor']+$gebr1['interieur']+$gebr1['uitlaat']+$gebr1['remmen']+$gebr1['body']+$gebr1['velgen']+$gebr1['nitro'];
$waarde3 = $a['0']+$a['1']+$a['2']+$f['3']+$a['4']+$a['5']+$a['6']+$a['7']+$b;
// oke dat ook klaar

//waardes van gebruiker4 bepalen
$gebr4 =  mysql_query("SELECT `banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='{$x['id4']}'");
$gebr4 = mysql_fetch_assoc($gebr4);
$c = explode("-", $kkhomo4);
$d = rand(0,7);
$kkhomo4 = $gebr1['banden']+$gebr1['motor']+$gebr1['interieur']+$gebr1['uitlaat']+$gebr1['remmen']+$gebr1['body']+$gebr1['velgen']+$gebr1['nitro'];
$waarde4 = $c['0']+$c['1']+$c['2']+$c['3']+$c['4']+$c['5']+$c['6']+$c['7']+$d;
// oke dat ook klaar

//waardes van gebruiker5 bepalen
$gebr5 =  mysql_query("SELECT `banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='{$x['id5']}'");
$gebr5 = mysql_fetch_assoc($gebr5);
$aa = explode("-", $kkhomo5);
$bb = rand(0,7);
$kkhomo5 = $gebr1['banden']+$gebr1['motor']+$gebr1['interieur']+$gebr1['uitlaat']+$gebr1['remmen']+$gebr1['body']+$gebr1['velgen']+$gebr1['nitro'];
$waarde5 = $aa['0']+$aa['1']+$aa['2']+$aa['3']+$aa['4']+$aa['5']+$aa['6']+$aa['7']+$bb;
// oke dat ook klaar

//waardes van gebruiker6 bepalen
$gebr6 =  mysql_query("SELECT `banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='{$x['id6']}'");
$gebr6 = mysql_fetch_assoc($gebr6);
$cc = explode("-", $kkhomo6);
$dd = rand(0,7);
$kkhomo6 = $gebr1['banden']+$gebr1['motor']+$gebr1['interieur']+$gebr1['uitlaat']+$gebr1['remmen']+$gebr1['body']+$gebr1['velgen']+$gebr1['nitro'];
$waarde6 = $cc['0']+$cc['1']+$cc['2']+$cc['3']+$cc['4']+$cc['5']+$cc['6']+$cc['7']+$dd;
// oke dat ook klaar

//waardes van gebruiker7 bepalen
$gebr7 =  mysql_query("SELECT `banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='{$x['id7']}'");
$gebr7 = mysql_fetch_assoc($gebr7);
$tss = explode("-", $kkhomo7);
$tzz = rand(0,7);
$kkhomo7 = $gebr1['banden']+$gebr1['motor']+$gebr1['interieur']+$gebr1['uitlaat']+$gebr1['remmen']+$gebr1['body']+$gebr1['velgen']+$gebr1['nitro'];
$waarde7 = $tss['0']+$tss['1']+$tss['2']+$tss['3']+$tss['4']+$tss['5']+$tss['6']+$tss['7']+$tzz;
// oke dat ook klaar

//waardes van gebruiker8 bepalen
$gebr8 =  mysql_query("SELECT `banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE `id`='{$x['id8']}'");
$gebr8 = mysql_fetch_assoc($gebr8);
$lolza = explode("-", $kkhomo8);
$lolka = rand(0,7);
$kkhomo8 = $gebr1['banden']+$gebr1['motor']+$gebr1['interieur']+$gebr1['uitlaat']+$gebr1['remmen']+$gebr1['body']+$gebr1['velgen']+$gebr1['nitro'];
$waarde8 = $lolza['0']+$lolza['1']+$lolza['2']+$lolza['3']+$lolza['4']+$lolza['5']+$lolza['6']+$lolza['7']+$lolka;
// oke dat ook klaar

// Sudden death
$s = rand(1,2);
if($s = '1'){$rand = "{$x['naam1']}"; }
if($s = '2'){$rand = "{$x['naam2']}"; }
// Sudden death

if($kkhomo > $kkhomo2){ $winner = "{$x['naam1']}"; }
if($kkhomo < $kkhomo2){ $winner = "{$x['naam2']}"; }
if($kkhomo == $kkhomo2){ $winner = "{$rand}"; }
//teksten
//teksten
$txrand = rand(0,5);
$skill = array("techinique","potential","look","determination","luck","experience");
$skill = $skill[$txrand];

$tx2rand = rand(0,6);
$race = array("tense","fast","laborious","prostspectlous","unfortunate","telentless","telented");
$race = $race[$tx2rand];
//teksten
$geld = $x['bedrag']*2;
$geld = round($geld);
//bericht
$txt = "By the general <b>$skill</b> of <b>$winner</b> it was quite obvious he had this in the bag and so...<br><b>$winner</b> has won the race!!<BR>";
$txt2 = "It was a <b>$race</b> race, but <b>$winner</b> had control of it. And so they are the winner and is rewarded $geld .<Br>Congratulations $winner!";
//bericht

$gebr21 =  mysql_query("SELECT `rijbewijs`,`id`,`auto`,`tuning`,`banden`,`motor`,`interieur`,`uitlaat`,`remmen`,`body`,`velgen`,`nitro` FROM `[garage]` WHERE  `owner`='{$iLogin['login']}'");
$hoop = mysql_fetch_assoc($gebr21);

mysql_query("UPDATE `[users]` SET `cash`=`cash`+'$geld' WHERE `login`='$winner'");

if($hoop['rijbewijs'] == 1){
mysql_query("UPDATE `[users]` SET `rijbewijsauto`=`rijbewijsauto`+'1' WHERE `login`='$winner'");
}
mysql_query("INSERT INTO `[messages]` (`time`,`from`,`to`,`subject`,`message`) values(NOW(),'PIMP Race','{$x['naam1']}','Information',' $txt $txt2')");
mysql_query("INSERT INTO `[messages]` (`time`,`from`,`to`,`subject`,`message`) values(NOW(),'PIMP Race','{$x['naam2']}','Information',' $txt $txt2')");
mysql_query("DELETE FROM `dragrace` WHERE `id`='{$_GET['id1']}'");

Die("<table><tr><td class=maintxt colspan=5><b>The race is now finished.<br>The result is in the mail. CHeck your inbox.</b></td></tr></table>");
}
?>