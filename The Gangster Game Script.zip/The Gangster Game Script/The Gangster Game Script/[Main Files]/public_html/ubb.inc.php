<?php
error_reporting(0);

function opmaak($string,$html="0",$smilies="1",$gescheld="1") {
	// [code] -> omzetten
	$GLOBALS['phphighlite'] = array("dummy");
	$string = preg_replace("_\[code\](.*?)\[/code\]_ise", "phphighlite_replace('\\1')", $string);

	// html
	if($html == "1")
	{
		$string=htmlentities($string, ENT_QUOTES);
 	}
 	else
 	{
	 	$string=htmlspecialchars($string);
 	}
 	
 	if($gescheld == "1") {  

 }
        $string = str_replace("&gt;", ">", $string); 
        $string = str_replace("&#60;", "<", $string); 
        $string = str_replace("&quot;", "\"", $string); 
        $string = str_replace("&lt;", "<", $string); 
        $string = str_replace("&amp;", "&", $string);

	// smilies
	if($smilies == "1") {
		$search = array(
	  ":(",
	  ":)" ,
	  ":-)" ,
      ":D",
      ":d",
      ";)",
      ":P",
      ":p",
      ":S",
      ":s",
      "(b)",
      ":@",
      "(8)",
      "(-)",
      "(!)",
      ":|",
      "(?)",
      ":$",
      "(b)",
      "(c)",
      "(e)",
      "(n)",
      "(v)",
      "(r)",
	  "(l)",
	  "(k)",
      "(slot)",
      "(h)");
		$replace = array(
	  "<img src=images/smilies/icon_sad.gif border=0>",
	  "<img src=images/smilies/icon_smile.gif border=0>",
      "<img src=images/smilies/icon_smile.gif border=0>",
      "<img src=images/smilies/icon_biggrin.gif border=0>",
      "<img src=images/smilies/icon_biggrin.gif border=0>",
      "<img src=images/smilies/icon_wink.gif border=0>",
      "<img src=images/smilies/icon_razz border=0>",
      "<img src=images/smilies/icon_razz border=0>",
      "<img src=images/smilies/icon_confused.gif border=0>",
      "<img src=images/smilies/icon_confused.gif border=0>",
      "<img src=images/smilies/icon_mrgreen.gif border=0>",
      "<img src=images/smilies/icon_mad.gif border=0>",
      "<img src=images/smilies/icon_evil.gif border=0>",
      "<img src=images/smilies/icon_arrow.gif border=0>",
      "<img src=images/smilies/icon_exclaim.gif border=0>",
      "<img src=images/smilies/icon_surprised.gif border=0>",
      "<img src=images/smilies/icon_question.gif border=0>",
      "<img src=images/smilies/icon_redface.gif border=0>",
      "<img src=images/smilies/icon_mrgreen.gif border=0>",
      "<img src=images/smilies/icon_twisted.gif border=0>",
      "<img src=images/smilies/icon_cry border=0>",
      "<img src=images/smilies/icon_neutral.gif border=0>",
      "<img src=images/smilies/icon_lol.gif border=0>",
      "<img src=images/smilies/icon_rolleyes.gif border=0>",
	  "<img src=images/heart.gif border=0>",
	  "<img src=images/kiss.gif border=0>",
      "<img src=images/slot.gif border=0>",
      "<img src=images/smilies/icon_cool.gif border=0>"
      );

		$string = str_replace($search, $replace, $string);
	}

	// bb codes


 // bb codes
	$search = array(
	"#\[center\](.*?)\[\/center\]#si",
	"#\[s\](.*?)\[\/s\]#si",
	"#\[u\](.*?)\[\/u\]#si",
	"#\[i\](.*?)\[\/i\]#si",
	"#\[b\](.*?)\[\/b\]#si",
	"#\[c\](.*?)\[\/c\]#si",
	"#\[quote\](.*?)\[\/quote\]#si",

	"#\[font color=(.*?)\](.*?)\[/font\]#si",
	"#\[size=(.*?)\](.*?)\[/size\]#si",
	"#\[align=(.*?)\](.*?)\[/align]#si",
	"#\[li\](.*?)\[/li\]#si"
	);
	$replace = array(
	"<center>\\1</center>",
	"<s>\\1</s>",
	"<u>\\1</u>",
	"<i>\\1</i>",
	"<b>\\1</b>",
	"<center>\\1</center>",
	"<blockquote>Quote:<hr>\\1<hr></blockquote>",
	"<a href=\"\\1\\2\" target=\"_blank\">\\1\\2</a>",
	"<a href=\"http://\\1\" target=\"_blank\">\\1</a>",
	"<a href=\"\\1\\2\" target=\"_blank\">\\3</a>",
	"<a href=\"http://\\1\" target=\"_blank\">\\2</a>",
	"<font color=\"\\1\">\\2</font>",
	"<div align=\"\\1\">\\2</div>",
	"<li>\\1</li>"
	);
	$string = preg_replace($search, $replace, $string);
		$string = str_replace("[img]","<img src=\"",$string);
	$string = str_replace("[/img]","\">",$string);

	// str bb codes
	$search = array(
	"[gesloten]",
	"[GESLOTEN]",
	"[quote]",
	"[/quote]"
	);
	$replace = array(
	"<img src='images/slotje.gif' border='0'> <b>Topic Gesloten</b>",
	"<img src='images/slotje.gif' border='0'> <b>Topic Gesloten</b>",
	"<blockquote>Quote:<hr>",
	"<hr></blockquote>"
	);
	$string = str_replace($search, $replace, $string);
		
	// auto url + email

	$string = eregi_replace("([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})", "<a href=\"mailto:\\1\">\\1</a>", $string);

	$string = nl2br($string);

	// [code] -> weer omzetten
	$string = preg_replace("_\[code\]([0-9])\[/code\]_ise", "phphighlite('\\1')", $string);

	// return
	return $string;
}

// ###################### Start img_check #######################
function img_check($string) {
	$string = trim($string);
	if(preg_match("/^(ht|f)tp:\/\/([a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z0-9]{1,4})(\/[\w%~!*().\'[:space:]-]+)+\.(jpe?g|png|gif|bmp)(\?[=&+\w%@:\/.~!*()\'-]*)?$/ix", $string)) {
		return "<img src=\"".$string."\" border=\"0\">";
	} else {
		return "<img src=\"images/slotje.gif\" border=\"0\"> <b>Error: ongeldige afbeelding source!</b>";
	}
}

###################### Start phphighlite #######################
function phphighlite_replace($code) {
	$code = trim(str_replace("\\\"", "\"", $code));
        $code = str_replace("&gt;", ">", $code); 
         $code = str_replace("&#60;", "<", $code); 
        $code = str_replace("&quot;", "\"", $code); 
        $code = str_replace("&lt;", "<", $code); 
        $code = str_replace("&amp;", "&", $code); 
        $code = str_replace('$', '\$', $code); 
	$code = str_replace("€ ", "", $code); 
	if(empty($code)) {
		return "[code] [/code]";
	} else {
		array_push($GLOBALS['phphighlite'], $code);
		return "[code]".(count($GLOBALS['phphighlite'])-1)."[/code]";
	}
}

function phphighlite($id, $fixed=1) {
	$code = $GLOBALS['phphighlite'][$id];
	$splitted = explode("\n", $code);
	$grootte = count($splitted)+1;
	if(!strpos($code,"<?") && substr($code,0,2)!="<?") {
		$code="<?".trim($code)."?>";
		$addedtags=1;
	}
	ob_start();
	$oldlevel=error_reporting(0);
	highlight_string($code);
	error_reporting($oldlevel);
	$buffer = ob_get_contents();
	ob_end_clean();
	if(!empty($addedtags)) {
		$openingpos = strpos($buffer,'&lt;?');
		$closingpos = strrpos($buffer, '?');
		$buffer = substr($buffer, 0, $openingpos).substr($buffer, $openingpos+5, $closingpos-($openingpos+5)).substr($buffer, $closingpos+5);
	}
	$page_popup = "";
	
	
	// popup
	if(isset($GLOBALS['phphighlite_tabel']) && isset($GLOBALS['phphighlite_id'])) {
		GLOBAL $page;
		if(isset($page)) {
			$page_popup = "&page=".$page;
		}
		$code = $buffer;
	
		$extra = "<td width=\"10\" align=\"right\"><a href=\"code.php?tabel=".$GLOBALS['phphighlite_tabel']."&id=".$GLOBALS['phphighlite_id']."&code_id=".$id."&type=1\"  onclick=\"popup(this.href,'code','','');return false;\" title=\"Deze code in een nieuw venster\"><img src=\"images/bekijk.gif\" border=\"0\"></a></td><td width=\"10\" align=\"right\"><a href=\"code.php?tabel=".$GLOBALS['phphighlite_tabel']."&id=".$GLOBALS['phphighlite_id']."&code_id=".$id."&type=2\" onclick=\"popup(this.href,'code','','');return false;\" title=\"Deze code in een tekstveld\"><img src=\"images/txt.gif\" border=\"0\"></a></td><td width=\"10\" align=\"right\">&nbsp;</td>";
	} else {
		$extra = "";
		$GLOBALS['phphighlite_id'] = 0;
	}

	
	$return = "<table class=\"vak\" cellspacing=\"0\" cellpadding=\"3\" border=\"0\" width=\"100%\" bgcolor=\"#638BA1\" align=\"center\"><tr><td class=\"vak\" width=\"10\">&nbsp;</td><td class=\"vak\" valign=\"middle\"><b>Code</b></td>".$extra."</tr></table>\n\n<!-- code table -->\n<table class=\"vak\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\"><tbody id=\"code".$GLOBALS['phphighlite_id']."_".$id."\"><tr><td>\n<table class=\"vak\" cellspacing=\"0\" cellpadding=\"3\" border=\"0\" width=\"100%\" bgcolor=\"#638BA1\" style=\"border-left: 1px solid #638BA1; border-right: 1px solid #638BA1; border-bottom: 1px solid #638BA1;\">\n<tr><td width=\"1\" valign=\"middle\" align=\"right\">\n";
	for($i=1; $i<$grootte; $i++) { 
	echo "<font size='1'>";
		$return .= $i."<br>\n</font>";
	}
	$return .= "</td><td valign=\"top\" bgcolor=\"#F7f7f4\">\n<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\"";
	if($fixed==1) {
		$return .= " style=\"table-layout: fixed;\"";
	}
	$return .= ">\n<tr><td valign=\"top\" nowrap>".$buffer."</td></tr>\n</table>\n</td></tr></table>\n</td></tr></tbody></table>";
	return $return;
}
function phphighliteappart($code) {
	$splitted = explode("\n", $code);
	$grootte = count($splitted)+1;
	if(!strpos($code,"<?") && substr($code,0,2)!="<?") {
		$code="<?".trim($code)."?>";
		$addedtags=1;
	}
	ob_start();
	$oldlevel=error_reporting(0);
	highlight_string($code);
	error_reporting($oldlevel);
	$buffer = ob_get_contents();
	ob_end_clean();
	if(!empty($addedtags)) {
		$openingpos = strpos($buffer,'&lt;?');
		$closingpos = strrpos($buffer, '?');
		$buffer = substr($buffer, 0, $openingpos).substr($buffer, $openingpos+5, $closingpos-($openingpos+5)).substr($buffer, $closingpos+5);
	}

	
	$return = "<table class=\"vak\" cellspacing=\"0\" cellpadding=\"3\" border=\"0\" width=\"100%\" bgcolor=\"#638BA1\"><tr><td class=\"vak\" width=\"10\">&nbsp;</td><td class=\"vak\" valign=\"middle\"><b>Code</b></td></tr></table>\n\n<!-- code table -->\n<table class=\"vak\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\"><tr><td>\n<table class=\"vak\" cellspacing=\"0\" cellpadding=\"3\" border=\"0\" width=\"100%\" bgcolor=\"#638BA1\" style=\"border-left: 1px solid #D6D6D6; border-right: 1px solid #D6D6D6; border-bottom: 1px solid #D6D6D6;\">\n<tr><td width=\"1\" valign=\"top\" align=\"right\">\n";
	for($i=1; $i<$grootte; $i++) { 
		$return .= $i."<br>\n";
	}
	$return .= "</td><td valign=\"top\" bgcolor=\"#FFFFFF\">\n<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"90%\"";
	$return .= ">\n<tr><td nowrap>".$buffer."</td></tr>\n</table>\n</td></tr></table>\n</td></tr></table>";
	return $return;
}

?>
<?
function knoppen()
{
?>
<SCRIPT language=JavaScript>
function icon(theicon) {
document.message.bericht.value += ""+theicon;
document.message.bericht.focus();
}
</script>
<?
echo "
<input type=\"button\" value=\"B\" style=\"font-weight:bold; width: 30px\" onClick=\"javascript:icon('[b] [/b]')\">
<input type=\"button\" value=\"i\" style=\"font-style:italic; width: 30px\" onClick=\"javascript:icon('[i] [/i]')\">
<input type=\"button\" value=\"u\" style=\"text-decoration: underline; width: 30px\" onClick=\"javascript:icon('[u] [/u]')\">
<input type=\"button\" value=\"Code\" style=\"text-decoration: none; width: 30px\" onClick=\"javascript:icon('[php] [/php]')\">
<input type=\"button\" value=\"Figuur\" style=\"text-decoration: none; width: 50px\" onClick=\"javascript:icon('[img] [/img]')\">
<input type=\"button\" value=\"URL\" style=\"text-decoration: none; width: 40px\" onClick=\"javascript:icon('[url=http://] [/url]')\">
<input type=\"button\" value=\"Quote\" style=\"text-decoration: none; width: 40px\" onClick=\"javascript:icon('[quote] [/quote]')\">";
}
function smilietoevoegen() {
?>
<SCRIPT language="JavaScript" type="text/javascript">
<!--
function setsmilie(which){
document.form1.message.value = document.message.bericht.value + which;
}
//-->
</SCRIPT>
<A HREF="javascript:setsmilie(' :(')" ONFOCUS="filter:blur()"><img src="images/verdrietig.gif" alt=":(" border="0"></a>
<A HREF="javascript:setsmilie(' :)')" ONFOCUS="filter:blur()"><img src="images/lach.gif" alt=":)" border="0"></a>
<A HREF="javascript:setsmilie(' ;)')" ONFOCUS="filter:blur()"><img src="images/knipoog.gif" alt=";)" border="0"></a>
<A HREF="javascript:setsmilie(' :s')" ONFOCUS="filter:blur()"><img src="images/verward.gif" alt=":s" border="0"></a>
<A HREF="javascript:setsmilie(' :p')" ONFOCUS="filter:blur()"><img src="images/tong.gif" alt=":p" border="0"></a>
<A HREF="javascript:setsmilie(' (b)')" ONFOCUS="filter:blur()"><img src="images/bier.gif" alt="(b)" border="0"></a>
<A HREF="javascript:setsmilie(' :@')" ONFOCUS="filter:blur()"><img src="images/boos.gif" alt=":@" border="0"></a>
<A HREF="javascript:setsmilie(' (8)')" ONFOCUS="filter:blur()"><img src="images/duivel.gif" alt="(8)" border="0"></a>
<A HREF="javascript:setsmilie(' :d')" ONFOCUS="filter:blur()"><img src="images/lach_tanden.gif" alt=":d" border="0"></a>
<A HREF="javascript:setsmilie(' (-)')" ONFOCUS="filter:blur()"><img src="images/pijl.gif" alt="(-)" border="0"></a>
<A HREF="javascript:setsmilie(' (!)')" ONFOCUS="filter:blur()"><img src="images/uitroepteken.gif" alt="(!)" border="0"></a>
<A HREF="javascript:setsmilie(' :|')" ONFOCUS="filter:blur()"><img src="images/verbaasd.gif" alt=":|" border="0"></a>
<A HREF="javascript:setsmilie(' (?)')" ONFOCUS="filter:blur()"><img src="images/vraagteken.gif" alt="(?)" border="0"></a>
<A HREF="javascript:setsmilie(' :$')" ONFOCUS="filter:blur()"><img src="images/beschaamd.gif" alt=":$" border="0"></a>
<A HREF="javascript:setsmilie(' (h)')" ONFOCUS="filter:blur()"><img src="images/bril.gif" alt="(h)" border="0"></a>
<A HREF="javascript:setsmilie(' (c)')" ONFOCUS="filter:blur()"><img src="images/cocktail.gif" alt="(c)" border="0"></a>
<A HREF="javascript:setsmilie(' (e)')" ONFOCUS="filter:blur()"><img src="images/engel.gif" alt="(e)" border="0"></a>
<A HREF="javascript:setsmilie(' (n)')" ONFOCUS="filter:blur()"><img src="images/neutraal.gif" alt="(n)" border="0"></a>
<A HREF="javascript:setsmilie(' (v)')" ONFOCUS="filter:blur()"><img src="images/verlegen.gif" alt="(v)" border="0"></a>
<A HREF="javascript:setsmilie(' (r)')" ONFOCUS="filter:blur()"><img src="images/verrast.gif" alt="(r)" border="0"></a>
<A HREF="javascript:setsmilie(' (l)')" ONFOCUS="filter:blur()"><img src="images/heart.gif" alt="(h)" border="0"></a>
<A HREF="javascript:setsmilie(' (k)')" ONFOCUS="filter:blur()"><img src="images/kiss.gif" alt="(l)" border="0"></a>
<?
}
?>