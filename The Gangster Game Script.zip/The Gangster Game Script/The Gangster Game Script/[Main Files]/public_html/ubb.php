<?php
error_reporting(0);

	{
        $text = htmlspecialchars($text);
        $text = nl2br($text);

	$text = str_replace(":grin:","<img src=images/smiles/icon_biggrin.gif>", $text);
	$text = str_replace(":S","<img src=images/smiles/icon_confused.gif>", $text);
	$text = str_replace("8)","<img src=images/smiles/icon_cool.gif>", $text);
	$text = str_replace(":.(","<img src=images/smiles/icon_cry.gif>", $text);
	$text = str_replace(":eek:","<img src=images/smiles/icon_eek.gif>", $text);

	$text = str_replace(":lol:","<img src=images/smiles/icon_lol.gif>", $text);
	$text = str_replace(":@","<img src=images/smiles/icon_mad.gif>", $text);
	$text = str_replace(":D","<img src=images/smiles/icon_mrgreen.gif>", $text);
	$text = str_replace(":|","<img src=images/smiles/icon_neutral.gif>", $text);
	$text = str_replace(":P","<img src=images/smiles/icon_razz.gif>", $text);
	$text = str_replace(":$","<img src=images/smiles/icon_redface.gif>", $text);
	
	$text = str_replace(":(","<img src=images/smiles/icon_sad.gif>", $text);
	$text = str_replace(":)","<img src=images/smiles/icon_smile.gif>", $text);
	$text = str_replace(":o","<img src=images/smiles/icon_surprised.gif>", $text);

	$text = str_replace(";)","<img src=images/smiles/icon_wink.gif>", $text);
	$text = str_replace(":{","<img src=images/smiles/icon_dracula.gif>", $text);



        $text = preg_replace("#\[center\](.*?)\[/center\]#si","<center>\\1</center>", $text);
        $text = preg_replace("#\[right\](.*?)\[/right\]#si","<p align=right>\\1</p>", $text);
        $text = preg_replace("#\[b\](.*?)\[/b\]#si","<b>\\1</b>", $text);
        $text = preg_replace("#\[u\](.*?)\[/u\]#si","<u>\\1</u>", $text);
        $text = preg_replace("#\[i\](.*?)\[/i\]#si","<i>\\1</i>", $text);
        $text = preg_replace("#\[left\](.*?)\[/left\]#si","<left>\\1</left>", $text);
        $text = preg_replace("#\[center\](.*?)\[/center\]#si","<center>\\1</center>", $text);
        $text = preg_replace("#\[right\](.*?)\[/right\]#si","<p align=right>\\1</p>", $text);
        $text = preg_replace("#\[url\](.*?)\[/url\]#si","<a href=\\1 target=_blank>\\1</a>", $text);
        $text = preg_replace("#\[url=(.*?)\](.*?)\[/url\]#si","<a href=\\1 target=_blank>\\2</a>", $text);
        $text = preg_replace("#\[img\](.*?)\[/img\]#si","<img src=\\1>", $text);
        $text = preg_replace("#\[color=(.*?)\](.*?)\[/color\]#si","<font color=\\1>\\2</font>", $text);
        $text = preg_replace("#\[move\](.*?)\[/move\]#si","<marquee>\\1</marquee>", $text);
        $text = preg_replace("#\[edit\](.*?)\[/edit\]#si","<font color=orange><b>Edit</b></font>:<i> \\1</i><br>", $text);

	return $text;
	}

?>
