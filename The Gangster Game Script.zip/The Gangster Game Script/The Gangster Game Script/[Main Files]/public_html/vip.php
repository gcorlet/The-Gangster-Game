<?php
error_reporting(0);

  include("_include-config.php");
 
  if(!($_SESSION)) 
  {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

?>
<html> 


<head> 
<title></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
</head>
</td>
</td>
<table width="441" align="center">
</td></tr>
</table>

<?PHP

if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`=0 where `login`='$data->login'");
exit;
}

?>
<?PHP
if($_GET['x'] == 'credits') {








}
?>
<form method="post" action="vip.php" name="f">
<table width=100%> 
  <tr><td class=subTitle colspan=3><b>VIP Account</b></td></tr>
  
  <center>
<a href="buycredits.php" target="_self"><img src="images/overige/vip.jpg" width="100%" height="175" border="0" /></a>  
</cemter>
  <tr><td class=mainTxt>




<tr>
<td width=20 class=mainTxt></td>
<td class=mainTxt width="208">Gain access to further game options, play and experience The Gangster Game the way its meant to be experienced!<br><br>

</td><td class=mainTxt width="199">


It only cost a little money and you will get 150 VIP Credits. You will get unlimited access for 30 Days to all of this...<br><br>
Boxing, Specialised Shop with extra weapons and items, Weed Cultivation Centre, Drug Dealing, Special Drugs, Hire a murderer, Run a Cocaine Factory and employe drug runners to do you dirty work, weed farm | water and harvest the crop as you see fit, Car Stealing Training and Crime Training!<br><br>
Also 25% experience is added to your current member rank.<br>




</td>
</tr>


<tr>
<td width=20 class=mainTxt><input type=radio name=gebruik value="clangeld"></td>
<td class=mainTxt width="208"><font color="yellow"><b>VIP Account </b> <img src="images/smilies/icon_star_gold.gif" border="0"></font></td>

<td class=mainTxt width="199">
<a href="buycredits.php" target="_self">Cost 150 VIP Credits</a></td>
</tr>


<tr>
<td colspan=2 class=mainTxt><b>Current Credits:</b> <? echo $data->belcredits ?></td>
<td align=right class=mainTxt width="199">
<p align="left">Ammount<input type=input value="0" size=3 name="bieden">x
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=submit value="Buy Now!" name="submit">

</tr></td><table width="441" align="center">
  <?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "geld") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 100*$_POST['bieden'];
           $genoeg = 100*$wtf;
           $land = 2500000;
           $wtf = $_POST['bieden'];
           $landz = $land*$_POST['bieden'];
           $credits = $data->belcredits;
           $kost1 = $kost*1;
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough VIP Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Well... Do you want to buy it!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}
$insert = "UPDATE `[users]` SET `bank`=`bank`+'$landz',`belcredits`=`belcredits`-'$kost1'  WHERE `login`='$data->login'";
$insert_now = mysql_query($insert) or die("FOUT in query ");
$landz = $bieden*1;
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased <b>&#8364;2.500.000</b> <b>$bieden</b>x <br></td></tr>\n";
}
}
?><?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "geld2") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 500*$_POST['bieden'];
           $genoeg = 500*$wtf;
           $land = 12500000;
           $wtf = $_POST['bieden'];
           $landz = $land*$_POST['bieden'];
           $credits = $data->belcredits;
           $kost1 = $kost*1;
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
$insert = "UPDATE `[users]` SET `bank`=`bank`+'$landz',`belcredits`=`belcredits`-'$kost1'  WHERE `login`='$data->login'";
$insert_now = mysql_query($insert) or die("FOUT in query ");
$landz = $bieden*1;
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>&#8364;12.500.000</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?><?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "power") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,3);
           $kost = 100*$_POST['bieden'];
           $land = 500000;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*1;
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
$insert = "UPDATE `[users]` SET `attack`=`attack`+'$landz', `defence`=`defence`+'$landz', `belcredits`=`belcredits`-'$kost1'  WHERE `login`='$data->login'";
$insert_now = mysql_query($insert) or die("FOUT in query ");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>500.000 power</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?><?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "power2") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 500*$_POST['bieden'];
           $land = 1800000;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*1;
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
$insert = "UPDATE `[users]` SET `attack`=`attack`+'$landz', `defence`=`defence`+'$landz', `belcredits`=`belcredits`-'$kost1'  WHERE `login`='$data->login'";
$insert_now = mysql_query($insert) or die("FOUT in query ");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>1.800.000 power</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "clangeld") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 150;
           $land = 1;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">You dont have enough VIP Credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Do you want to buy it!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaum of 100 each time!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimum of 1</td></tr>\n";
exit;
}

            mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'150' WHERE `login`='{$_SESSION['login']}'");
	    mysql_query("UPDATE `[users]` SET `rankvord`=`rankvord`+'25' WHERE `login`='{$_SESSION['login']}'");
	    mysql_query("UPDATE `[users]` SET `vip`=`vip`+'30' WHERE `login`='{$_SESSION['login']}'");
		mysql_query("UPDATE `[users]` SET `gebeltx`=`gebeltx`+1 WHERE `login`='$data->login'  ");
    print "  <tr><td class=\"mainTxt\" align=\"center\">You have purchased a <b>VIP Account</b> <BR><BR>Press F5 or refresh your page to let loose the Great VIP Options!<br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "clicks") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 250;
           $land = 5000;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `clicks`=`clicks`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>5000 clicks</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "kogels") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 250;
           $land = 500;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `kogels`=`kogels`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>500 kogels</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "kogels2") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 1500;
           $land = 2500;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `kogels`=`kogels`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>2500 kogels</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "kogels3") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 5000;
           $land = 10000;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `kogels`=`kogels`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>10.000 kogels</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "kogels4") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 20000;
           $land = 100000;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `kogels`=`kogels`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>100.000 kogels</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>

<?PHP
if (isset($_POST['gebruik'])) {
if($_POST['gebruik'] == "banken") {
if($amount > 0 && preg_match('/^[0-9]{1,15}$/',$_POST['banken'])) {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 150;
           $land = 50;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `bankleft`=`bankleft`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>50x extra banken</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "maffia") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 2000;
           $land = 1;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
if($bieden > 1) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Max. 1 uur achter elkaar</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `maffiamode`=1, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je staat onder maffia mode tot het volgende uur<br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "drugs") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $kost = 50;
           $land = 1500;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `drugspower`=`drugspower`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>1500 drugspower</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "coffeeshops") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 300;
           $land = 20;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je zit niet in een clan!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl1`=`money_lvl1`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>20 cofeeshops</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "boor") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 750;
           $land = 20;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je zit niet in een clan!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl9`=`money_lvl9`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>20 booreilanden</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "boor") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 25000;
           $land = 250;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je zit niet in een clan!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl9`=`money_lvl9`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>250 booreilanden</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>

<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "energie") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 1000;
           $land = 20;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je zit niet in een clan!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl10`=`money_lvl10`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>20 energiefabrieken</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "energie2") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 2500;
           $land = 50;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je zit niet in een clan!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `money_lvl10`=`money_lvl10`+$landz WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>50 energiefabrieken</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "geldbanken") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 150;
           $land = 50;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
mysql_query("UPDATE `[users]` SET `bankleft`=`bankleft`+$landz, `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>50x extra banken</b> <b>$bieden</b>x gekocht <br></td></tr>\n";
}
}
?>
<?PHP
if (isset($_POST['gebruik'])) {
           if($_POST['gebruik'] == "clanbes") {
           $bieden = $_POST['bieden'];
           $bieden = htmlspecialchars($_POST['bieden']);
           $bieden = substr($_POST['bieden'],0,2);
           $clanlevel = $data->clanlevel;
           $kost = 750;
           $land = 1;
           $landz = $land*$_POST['bieden'];
           $kost1 = $kost*$_POST['bieden'];
           $koopx         = "$aantal";
           $dbres = mysql_query("SELECT `name`,`info`,UNIX_TIMESTAMP(`started`) AS `started` FROM `[clans]` WHERE `name`='{$data->clan}'");
           $clan                                      = mysql_fetch_object($dbres);
           $protection                                = round($clan->started/3600-time()/3600) + 24;

if($kost1 > $data->belcredits){
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt niet genoeg credits</td></tr>\n";
exit;
}
if($data->belcredits < 0){
echo "  <tr><td class=\"mainTxt\" align=\"center\"><font color=red><b><center>eRRoR</b></center></font></td></tr>";
exit;
}
if($bieden ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je wel wat kopen!?</td></tr>\n";
exit;
}
if($clanlevel ==0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je zit niet in een clan!</td></tr>\n";
exit;
}
if($bieden > 100) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 100 per keer!</td></tr>\n";
exit;
}
if($bieden > 1) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Maximaal 1 per keer..</td></tr>\n";
exit;
}
if($protection > 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Je clan staat al onder bescherming.</td></tr>\n";
exit;
}
if($bieden < 0) {
    print "  <tr><td class=\"mainTxt\" align=\"center\">Minimaal 1</td></tr>\n";
exit;
}
mysql_query("UPDATE `[users]` SET `belcredits`=`belcredits`-'$kost1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[clans]` SET `started`=`started`=NOW() WHERE `name`='$data->clan'");    
print "  <tr><td class=\"mainTxt\" align=\"center\">Je hebt <b>24 uur clan bescherming</b> gekocht <br></td></tr>\n";
}
}
}
?>


