<?php
error_reporting(0);

include_once("_include-config.php");
    include("_include-gevangenis.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><title><?php echo $page->sitetitle; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

<FORM name=kopen method=post>
<BODY>
<TABLE align=center width="534">
  <TBODY><tr><td class=subtitle colspan=2 background=images/topic2.gif height=23>
	<b>Home Growing</b></td></tr>
  <TR>
    <TD class=mainTxt colSpan=2><SP>
	<p align="center">
	<img border="0" src="images/game/planten.jpg" width="402" height="150"><br>
	Home Growing
      </SPAN></b><BR>You can start growing your home grown weed here. 
      Firstly pick a good room, I advise the attic!<BR>
      The life exspectancy of a plant is 3 days!<BR><BR><b><SPAN 
      class=tekstheader>Lifestyle</SPAN></b><br>You have to water your plant atleast twice a day.
<BR>No more than that.<BR>You can harvest only ONCE per whole plantation
. You will harvest a minium of 200 grams per plant, and the maximum depends on how many plants you grow and keep watered...</TD></TR>
  <TR>
    <TD colSpan=2>&nbsp;</TD></TR>
    
<?PHP
 
 $checkerd = mysql_query("SELECT * FROM `[wietplantage]` WHERE eigenaar='".$_SESSION['login']."'");
 $plantage = mysql_num_rows($checkerd);
 
 if($plantage < 1){
 
 if(isset($_POST['submitkoop']) && preg_match('/^[0-9]+$/',$_POST['aantalkopen']))
 {
 $total = round($_POST['aantalkopen']*400);
 
  if($data->cash < $total)
  {
    Die("<tr><td class=maintxt align=center><font color=red><b>You cant afford that much stuff!</font></b></tr></td>");
  }
  if($_POST['aantalkopen'] < 1000 || $_POST['aantalkopen'] > 50000){
  Die("<tr><td class=maintxt align=center><font color=red><b>You can only buy a minimum of 1,000 and maximum of 50,000!!</font></b></tr></td>");
  }
 
   mysql_query("INSERT INTO `[wietplantage]` ( `eigenaar` , `planten` , `begonnen` ,  `procent`) VALUES ('".$data->login."', '".$_POST['aantalkopen']."', NOW(),  '0')");
   mysql_query("UPDATE `[users]` SET cash=cash-'$total' where login='".$_SESSION['login']."'");
   Die("<tr><td class=Maintxt>You have purchased ".$_POST['aantalkopen']." for a total of ".number_format($total)."</tr></td>");
 }
 
 
 echo "
  <TR>
    <TD class=subTitle background=images/topic2.gif height=23 align=middle width=528 colSpan=2><B>Things Needed</B></TD></TR>
  <TR>
    <TD class=mainTxt width=471>Lighting - per plant</TD>
    <TD class=mainTxt align=right width=53>100</TD></TR>
  <TR>
    <TD class=mainTxt width=471>Materials - per plant</TD>
    <TD class=mainTxt align=right width=53>199</TD></TR>
  <TR>
    <TD class=mainTxt width=471>Food/Soil - per plant</TD>
    <TD class=mainTxt align=right width=53>50</TD></TR>
  <TR>
    <TD class=mainTxt width=471>Harvest - per plant</TD>
    <TD class=mainTxt align=right width=53>50</TD></TR>
  <TR>
    <TD class=mainTxt width=471>Seeds - per plant</TD>
    <TD class=mainTxt align=right width=53>1</TD></TR>
  <TR>
    <TD class=mainTxt width=471><B><FONT color=red>Total Cost per palnt</B></FONT></TD>
    <TD class=mainTxt align=right width=53><B><FONT 
    color=red>400</FONT></B></TD></TR>
  <TR>
    <TD width=528 colSpan=2>&nbsp;</TD></TR>
  <TR>
    <TD class=subTitle background=images/topic2.gif height=23 align=middle width=528 colSpan=2><B>Purchasing</B></TD></TR>
  <TR>
    <TD class=mainTxt width=471><B>Amount of Plants</B><BR>Minimum 1.000 - 
      Maximum 50.000</TD>
    <TD class=mainTxt width=53><INPUT maxLength=5 class='btn btn-info' size=5 name=aantalkopen> x 
      400</TD></TR>
  <TR>
    <TD class=mainTxt width=471><STRONG>Buying Plants!</STRONG></TD>
    <TD class=mainTxt width=53><INPUT type=submit class='btn btn-info' value=Buy! name=submitkoop></TD></TR></TBODY></TABLE></FORM></BODY></HTML>
    ";
   }
   
  
   if($plantage > 0){
   
   $groei = mysql_query("SELECT * FROM `[wietplantage]` WHERE eigenaar='".$_SESSION[login]."'");
   $plant = mysql_fetch_assoc($groei);
   
  
   
 
   
   $gemiddeldekgs = round($plant[procent] *  $plant[planten] / 60);
   
   
   if($gemiddeldekgs < 0){
   $gemiddeldekgs = 0;
   }
   echo "<form method=post>
   <TD class=subTitle background=images/topic2.gif height=23 align=middle width=600 colSpan=2><B>THC content of the plants</B></TD></TR>
  <TR>
    <TD class=mainTxt align=middle width=600 colSpan=2>
      <TABLE align=center>
        <TBODY>
        <TR>
          <TD>
            <TABLE class=snelmenuitem align=left>
              <TBODY>
              <TR>
                <TD>
                  <TABLE height= 
                  cellSpacing=0 height=30 cellPadding=0 width=500 border=1>
                    <TBODY>
                    <TR></TD>
                      <TD align=middle width=500 bgColor=#00ff00><FONT 
                        color=black><B>$plant[procent]%</B></FONT></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR>
  <TR>
    <TD class=mainTxt width=300>Estimated Harvest Amount</TD>
    <TD class=mainTxt align=right width=300>".$gemiddeldekgs." kg</TD></TR>
  <TR>
    <TD colSpan=2>&nbsp;</TD></TR>
  <TR>
    <TD class=subTitle background=images/topic2.gif height=23 align=middle width=600 colSpan=2><B>Information</B></TD></TR>
  <TR>
    <TD class=mainTxt width=300>Planted On</TD>
    <TD class=mainTxt align=right width=300>$plant[begonnen]</TD></TR>
  <TR>
    <TD class=mainTxt width=300>Amount of Plants</TD>
    <TD class=mainTxt align=right width=300>$plant[planten]</TD></TR>
  <TR>
    <TD colSpan=2>&nbsp;</TD></TR>
  <TR>
    <TD class=subTitle background=images/topic2.gif height=23 align=middle width=600 colSpan=2><B>Actie met de 
      Dames</B></TD></TR>
  <TR>
    <TD class=mainTxt width=300><INPUT type=radio value=voeden 
      name=plantenactie> Water Plants</TD>
    <TD class=mainTxt width=300><INPUT type=radio value=oogsten 
      name=plantenactie> Harvest Plants</TD></TR>
  <TR>
    <TD class=mainTxt width=300>Confirm</TD>
    <TD class=mainTxt width=300><INPUT type=submit class=btn btn-info value=Action! name=submitaktie></TD>
    </form>
   ";
   
   
   if(isset($_POST['submitaktie']))
   {
   

   
    if($_POST['plantenactie'] == "voeden")
    {
    
     $fuck  = mysql_query("SELECT *,UNIX_TIMESTAMP(`voedtijd`) AS `voedtijd`,0 FROM `[wietplantage]` WHERE `eigenaar`='".$data->login."'");
     $omg = mysql_fetch_assoc($fuck);

     if($omg['voedtijd'] + '3600' > time())
     {
      die("<tr><td class=maintxt colspan=2><font color=red>You have already watered the plants once this hour.</font></tr></td>");
     }

   if($plant[voedingkeer] == '5')
   {
     Die("<tr><td class=maintxt colspan=2><font color=red><b>You have watered your plants 5x already.</b></font></tr></td>");
   }
   
    $rand = rand(1,5);
    



    if($rand == '1'){ 
    mysql_query("UPDATE `[wietplantage]` SET procent=procent+'13' WHERE eigenaar='".$_SESSION['login']."' ");
    Die("<tr><td class=maintxt colspan=2>Goog...Good... There growing nicely.</tr></td>");
    }
    elseif($rand == '2'){ 
       mysql_query("UPDATE `[wietplantage]` SET procent=procent+'9' WHERE eigenaar='".$_SESSION['login']." '");
    Die("<tr><td class=maintxt colspan=2>A little to much water that time i'm afraid..</tr></td>");
    }
    elseif($rand == '3'){ 
        mysql_query("UPDATE `[wietplantage]` SET procent=procent+'7' WHERE eigenaar='".$_SESSION['login']."'");
    Die("<tr><td class=maintxt colspan=2>o...k.. You kindof drowned them abit..</tr></td>");
    }
    elseif($rand == '4'){ 
      mysql_query("UPDATE `[wietplantage]` SET procent=procent+'11' WHERE eigenaar='".$_SESSION['login']."' ");
    Die("<tr><td class=maintxt colspan=2>Try putting abit more water on the soil next time..</tr></td>");
    }
    elseif($rand == '5'){ 
       mysql_query("UPDATE `[wietplantage]` SET procent=procent+'15' WHERE eigenaar='".$_SESSION['login']."' ");
    Die("<tr><td class=maintxt colspan=2>Excellent!... YOu sure you havent grown dope before?</tr></td>");
    }
    
   


   }
  
    if($_POST['plantenactie'] == "oogsten")
    {
    $randje = rand(1,7);
    if($randje == '7'){
    mysql_query("DELETE FROM `[wietplantage]` WHERE eigenaar='".$_SESSION['login']."'");
    Die("<tr><td class=maintxt colspan=2>Well done smart ass... you cropped them to early and fucked it up!</tr></td>");
    }
    if($randje == '4'){
    mysql_query("DELETE FROM `[wietplantage]` WHERE eigenaar='".$_SESSION['login']."'");
    Die("<tr><td class=maintxt colspan=2>What the fuck you playing at? </tr></td>");
    }
    if($randje == '6'){
    mysql_query("DELETE FROM `[wietplantage]` WHERE eigenaar='".$_SESSION['login']."'");
    Die("<tr><td class=maintxt colspan=2>Oh.. For fuck sake. Dead... everyone of them... start again!</tr></td>");
    }
    elseif($randje != '7' && $randje != '4' && $randje != '6') {
    
    $oogst = round($plant[procent] *  $plant[planten] / 60);
    
    if($oogst < 0)
    {
      $oogst = $oogst;
    }
    
    mysql_query("UPDATE `[users]` SET wiet=wiet+'".$oogst."' WHERE login='".$_SESSION['login']."'");
    mysql_query("DELETE FROM `[wietplantage]` WHERE eigenaar='".$_SESSION['login']."'");
    Die("<tr><td class=maintxt colspan=2>You manage to harvest ".$oogst." kiliograms!</tr></td>");
    }
    }
   
  
   }
  }