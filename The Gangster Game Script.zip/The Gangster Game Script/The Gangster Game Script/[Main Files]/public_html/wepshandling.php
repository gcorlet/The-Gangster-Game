<?php
error_reporting(0);

  include("_include-config.php");
  include("_include-gevangenis.php");
    $data2				= mysql_query("SELECT * FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($data2);
// Wapens die je op hebt geslagen op de eilanden
	$ak47 		= $data->ak47;
	$m16		= $data->m16;
	$m60		= $data->m60;
	$krieg550	= $data->krieg550;
	$sig552		= $data->sig552;
	$c4		= $data->c4;

// Wapens die je hebt gesmokkelt
	$ak47v 		= $data->ak47v;
	$m16v		= $data->m16v;
	$m60v		= $data->m60v;
	$krieg550v	= $data->krieg550v;
	$sig552v	= $data->sig552v;
	$c4v		= $data->c4v;
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">
</head>
<body style="margin: 0px;">
<?
if(! isset($_GET[id]))
{ 

echo "
<table width=\"100%\" align=\"center\">
<tr><td class=subTitle colspan=2><b>Weapon Handling</b></td>
<tr><td class=\"mainTxt\" colspan=2><center><form method=\"post\">
<select onchange=\"location.href=''+this.options[this.selectedIndex].value\">
<option value=\"\">Select an option from Weapons Handling</option>
<option value=\"sail.php\">Sail</option>
<option value=\"wepshandling.php\">Weapons Handling</option>
<option value=\"loading.php\">loading</option>
</select>
</table>
";
}
?> 

<BODY onLoad="movein()">
<table align="center" width="60%">
<tr><td class="subTitle" colspan="3">WeaponsHandling</td></tr>
<?
if($data->boot == 0) {
?>
<tr><td class="mainTxt" align="center">You dont have a boat</td></tr>
<?
exit;
}
?>
<?
	$m60erbij 	= round($_POST['verkoopm60']*11000);
	$krieg550erbij 	= round($_POST['verkoopkrieg550']*9000);
	$sig552erbij 	= round($_POST['verkoopsig552']*6500);
	$m16erbij 	= round($_POST['verkoopm16']*4000);
	$ak47erbij 	= round($_POST['verkoopak47']*2500);
	$c4erbij 	= round($_POST['verkoopc4']*1000);

	$m60eraf 	= round($_POST['koopm60']*9500);
	$krieg550eraf 	= round($_POST['koopkrieg550']*7200);
	$sig552eraf 	= round($_POST['koopsig552']*4300);
	$m16eraf 	= round($_POST['koopm16']*2100);
	$ak47eraf 	= round($_POST['koopak47']*1600);
	$c4eraf 	= round($_POST['koopc4']*600);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if(isset($_POST['verkoopm60'])) {
if($_POST['verkoopm60'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must fill in a positive number.</td></tr>\n";
} else if(empty($_POST['verkoopm60'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must fill in something.</td></tr>\n";
} else if($_POST['verkoopm60'] > $m60v) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">Theres not that many M60's.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `m60v`=`m60v`-{$_POST['verkoopm60']}, `bank`=`bank`+$m60erbij WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['verkoopm60']}</b> M60('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['verkoopkrieg550'])) {
if($_POST['verkoopkrieg550'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['verkoopkrieg550'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have to enter something.</td></tr>\n";
} else if($_POST['verkoopkrieg550'] > $krieg550v) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">There isnt that many KRIEG 550's.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `krieg550v`=`krieg550v`-{$_POST['verkoopkrieg550']}, `bank`=`bank`+$krieg550erbij WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['verkoopkrieg550']}</b> KRIEG 550('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['verkoopsig552'])) {
if($_POST['verkoopsig552'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['verkoopsig552'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($_POST['verkoopsig552'] > $sig552v) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">There isnt that many SIG 552's.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `sig552v`=`sig552v`-{$_POST['verkoopsig552']}, `bank`=`bank`+$sig552erbij WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['verkoopsig552']}</b> SIG 552('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['verkoopm16'])) {
if($_POST['verkoopm16'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['verkoopm16'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($_POST['verkoopm16'] > $m16v) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">There isnt that many M16's.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `m16v`=`m16v`-{$_POST['verkoopm16']}, `bank`=`bank`+$m16erbij WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['verkoopm16']}</b> M16('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['verkoopak47'])) {
if($_POST['verkoopak47'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['verkoopak47'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($_POST['verkoopak47'] > $ak47v) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">There isnt that many Ak47's.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `ak47v`=`ak47v`-{$_POST['verkoopak47']}, `bank`=`bank`+$ak47erbij WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['verkoopak']}</b> Ak47('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['verkoopc4'])) {
if($_POST['verkoopc4'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['verkoopc4'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($_POST['verkoopc4'] > $c4v) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">There isnt that many kilos of C4.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `c4v`=`c4v`-{$_POST['verkoopc4']}, `bank`=`bank`+$c4erbij WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['verkoopc4']}</b> kilos of C4.<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if(isset($_POST['koopm60'])) {
if($_POST['koopm60'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['koopm60'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($data->cash < $m60eraf) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You dont have enough cash.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `m60`=`m60`+{$_POST['koopm60']}, `cash`=`cash`-$m60eraf WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['koopm60']}</b> M60('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['koopkrieg550'])) {
if($_POST['koopkrieg550'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['koopkrieg550'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($data->cash < $krieg550eraf) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You dont have enough cash.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `krieg550`=`krieg550`+{$_POST['koopkrieg550']}, `cash`=`cash`-$krieg550eraf WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['koopkrieg550']}</b> KRIEG 550('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['koopsig552'])) {
if($_POST['koopsig552'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['koopsig552'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($data->cash < $sig552eraf) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You dont have enough cash.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `sig552`=`sig552`+{$_POST['koopsig552']}, `cash`=`cash`-$sig552eraf WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['koopsig552']}</b> SIG 552('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['koopm16'])) {
if($_POST['koopm16'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['koopm16'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($data->cash < $m16eraf) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You dont have enough cash.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `m16`=`m16`+{$_POST['koopm16']}, `cash`=`cash`-$m16eraf WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['koopm16']}</b> M16('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['koopak47'])) {
if($_POST['koopak47'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['koopak47'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($data->cash < $ak47eraf) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You dont have enough cash.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `ak47`=`ak47`+{$_POST['koopak47']}, `cash`=`cash`-$ak47eraf WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['koopak47']}</b> Ak 47('s).<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
  if(isset($_POST['koopc4'])) {
if($_POST['koopc4'] < 0) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter a positive number.</td></tr>\n";
} else if(empty($_POST['koopc4'])) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You must enter something.</td></tr>\n";
} else if($data->cash < $c4eraf) {
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You dont have enough cash.</td></tr>\n";
} else {
    mysql_query("UPDATE `[users]` SET `c4`=`c4`+{$_POST['koopc4']}, `cash`=`cash`-$c4eraf WHERE `login`='{$data->login}'");
    print " <tr><td class=\"mainTxt\" colspan=\"3\" align=\"center\">You have bought <b>{$_POST['koopc4']}</b> kilos of C4.<script language=\"javascript\">setTimeout('self.window.location.href=\"wepshandling.php\"',500)</script></td></tr>\n";
}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////Einde///////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


if($data->eilanden != 1) {
?>
<tr><td class="mainTxt" colspan="3" align="center">You are <b>not</b> currently on the islands.</td></tr>
<tr><td class="mainTxt" colspan="3" align="center">You can Sell you imported weapons here!</td></tr>
<form method="POST">
<tr><td class="mainTxt">M60's:</td><td class="mainTxt"><input maxlength="5" type="text" name="verkoopm60"> <input type="submit" value="Sell"></td><td width="100" class="mainTxt">;11000 p/s</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">KRIEG 550's:</td><td class="mainTxt"><input maxlength="5" type="text" name="verkoopkrieg550"> <input type="submit" value="Sell"></td><td width="100" class="mainTxt">;9000 p/s</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">SIG 552's:</td><td class="mainTxt"><input maxlength="5" type="text" name="verkoopsig552"> <input type="submit" value="Sell"></td><td width="100" class="mainTxt">;6500 p/s</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">M16's:</td><td class="mainTxt"><input maxlength="5" type="text" name="verkoopm16"> <input type="submit" value="Sell"></td><td width="100" class="mainTxt">;4000 p/s</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">Ak47's:</td><td class="mainTxt"><input maxlength="5" type="text" name="verkoopak47"> <input type="submit" value="Sell"></td><td width="100" class="mainTxt">;2500 p/s</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">C4 (kilo's):</td><td class="mainTxt"><input maxlength="5" type="text" name="verkoopc4"> <input type="submit" value="Sell"></td><td width="100" class="mainTxt">;1000 p/s</td></tr>
</form>
<tr><td class="mainTxt" colspan="3" align="center">
Here are the weapons you have to sell from the islands!
</td></tr>
<tr><td class="mainTxt">M60's:</td><td colspan="2" class="mainTxt"><?=$m60v?></td></tr>
<tr><td class="mainTxt">KRIEG 550's:</td><td colspan="2" class="mainTxt"><?=$krieg550v?></td></tr>
<tr><td class="mainTxt">SIG 552's:</td><td colspan="2" class="mainTxt"><?=$sig552v?></td></tr>
<tr><td class="mainTxt">M16's:</td><td colspan="2" class="mainTxt"><?=$m16v?></td></tr>
<tr><td class="mainTxt">Ak47's:</td><td colspan="2" class="mainTxt"><?=$ak47v?></td></tr>
<tr><td class="mainTxt">C4:</td><td colspan="2" class="mainTxt"><?=$c4v?></td></tr>
<?
}
else if($data->eilanden == 1) {
?>
<tr><td class="mainTxt" colspan="3" align="center">At the moment you are <b>on</b> the islands.</td></tr>
<tr><td class="mainTxt" colspan="3" align="center">You can buy weapons here.</td></tr>
<form method="POST">
<tr><td class="mainTxt">M60's:</td><td class="mainTxt"><input maxlength="5" type="text" name="koopm60"> <input type="submit" value="Buy"></td><td class="mainTxt" width="100">;9500</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">KRIEG 550's:</td><td class="mainTxt"><input maxlength="5" type="text" name="koopkrieg550"> <input type="submit" value="Buy"></td><td class="mainTxt" width="100">;7200</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">SIG 552's:</td><td class="mainTxt"><input maxlength="5" type="text" name="koopsig552"> <input type="submit" value="Buy"></td><td class="mainTxt" width="100">;4300</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">M16's:</td><td class="mainTxt"><input maxlength="5" type="text" name="koopm16"> <input type="submit" value="Buy"></td><td class="mainTxt" width="100">;2100</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">Ak 47's:</td><td class="mainTxt"><input maxlength="5" type="text" name="koopak47"> <input type="submit" value="Buy"></td><td class="mainTxt" width="100">;1600</td></tr>
</form>
<form method="POST">
<tr><td class="mainTxt">C4:</td><td class="mainTxt"><input maxlength="5" type="text" name="koopc4"> <input type="submit" value="Buy"></td><td class="mainTxt" width="100">;600</td></tr>
</form>
<tr><td class="mainTxt" colspan="3" align="center">
You can see here what weapons have risen and which have dropped on the islands.
</td></tr>
<tr><td class="mainTxt">M60's:</td><td colspan="2" class="mainTxt"><?=$m60?></td></tr>
<tr><td class="mainTxt">KRIEG 550's:</td><td colspan="2" class="mainTxt"><?=$krieg550?></td></tr>
<tr><td class="mainTxt">SIG 552's:</td><td colspan="2" class="mainTxt"><?=$sig552?></td></tr>
<tr><td class="mainTxt">M16's:</td><td colspan="2" class="mainTxt"><?=$m16?></td></tr>
<tr><td class="mainTxt">Ak 47's:</td><td colspan="2" class="mainTxt"><?=$ak47?></td></tr>
<tr><td class="mainTxt">C4:</td><td colspan="2" class="mainTxt"><?=$c4?></td></tr>
<?
}
?>
</table>
</body>
</html>