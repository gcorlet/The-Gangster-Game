<?php
error_reporting(0);


  include("_include-config.php");
  include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");


/* ------------------------- */ ?>
<html>


<head>
<title><?=$title; ?></title>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/ingame-css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>


<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/ingame-css/css.css">
<table width=100%>
<td align=center background=topic.gif><b>Will and Testament</b></TD>

<?php /* ------------------------- */

print "<tr><td class=\"mainTxt\">";
  if(isset($_POST['nieuwe'])) {
    $test				= preg_replace('/\</','&#60;',$_POST['test']);
    $verdediger     = mysql_query("SELECT * FROM `[users]` WHERE `login`='$test'"); 
   $verdediger1    = mysql_fetch_object($verdediger);
   $controle       = mysql_num_rows($verdediger); 

if($test =="{$data->login}"){
print "You cant give yourself a Will";
die();
}

elseif($verdediger1->level == 10){
echo "Admins do not want a Will from you";
die();
}

elseif($controle <1){
	echo "This user does not exist";
		die();
		}
    mysql_query("UPDATE `[users]` SET `testament`='{$test}' WHERE `login`='{$data->login}'");
    print "  <tr><td class=\"mainTxt\">The notary has transfered your Will: {$test}</td></tr>\n";
  }
  print <<<ENDHTML
  <tr><td class="mainTxt">
	<form method="post"><table align="center">
<h3>Will</h3><div id="text_container"><p>You use your Will and Testament to help you get by at the begining of the game once you die.

<ul>
<li>How it works: You enter a name in, and once you die, the owner of the Will gets half of what you own when nyou die.</li>
<li>You make sure get a Will holder before you die, therefore none of your belongings will be divided.</li>
<li><b>TIP</b> Make sure the holder of your Will is someone you trust!</li>
</ul>

</p>
<br>
	  <tr><td width=100>Will and Testament:</td>	<td>{$data->testament}</td></tr>
	  <tr><td width=100>Transfer to:</td>	<td><input type="text" class='btn btn-info' name="test" value=""></td></tr>				<td align="right"><input type="submit" name="nieuwe" class='btn btn-info' value="Change Will Holder"></td></tr>
	</table></form>
  </td></tr>
  <tr><td><br></td></tr>
ENDHTML;

/* ------------------------- */ ?>
</table>

</body>


</html>