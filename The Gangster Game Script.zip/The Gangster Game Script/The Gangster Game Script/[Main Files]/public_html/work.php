<?php
error_reporting(0);

  include("_include-config.php");
      include("_include-gevangenis.php");
  if(! check_login()) {
    header("Location: login.php");
    exit;
  }

    $dbres				= mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup`,UNIX_TIMESTAMP(`online`) AS `online` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);
  mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");
    $werkover				= $data->dagenwerken-1;

if($data->dagenwerken > 2) {
$dagdagen = dagen; }
elseif($data->dagenwerken == 2) {
$dagdagen = dag; }
if($data->ontslag > 1) {
$dagdagen2 = dagen; }
elseif($data->ontslag == 1) {
$dagdagen2 = dag; }

    $dbres				= mysql_query("SELECT *,UNIX_TIMESTAMP(`signup`) AS `signup`,UNIX_TIMESTAMP(`online`) AS `online` FROM `[users]` WHERE `login`='{$_SESSION['login']}'");
    $data				= mysql_fetch_object($dbres);

    $werkover				= $data->dagenwerken-1;

      if($data->ontslag >= 1){
    print <<<ENDHTML

<html>


<head>
<title></title>

<link rel="stylesheet" type="text/css" href="layout/layout$page->layout/css/css.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/Responsive.css>
</head>
<body> 
  <table width=100% height=10%>
    <tr><td class="subTitle"><b>Discharged</b></td></tr>
    <tr><td class="mainTxt">
	<center>You have been dismissed from work because of {$data->ontslag} and you need to wait {$dagdagen2} days before your allowed back to work.</center>
    </td></tr>
  </table>
</body>
</html>
ENDHTML;
    exit;
    }


?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<? echo $sitelink;?>/layout/layout<?php echo $page->layout; ?>/css/css.css">

</head>

<body style="margin: 0px;">
<table width=100%>
  <tr><td class="subTitle" colspan=2><b>Working</b></td></tr>
<?php    mysql_query("UPDATE `[users]` SET `online`=NOW() WHERE `login`='{$data->login}'");

	if($data->baan >= 1){
	print "<tr><td class=\"mainTxt\" align=\"center\"><center>You will complete your job in {$werkover} days.</center></td></tr>";
                print "<tr><td align=\"center\"><iframe frameborder=0 height=160 border=0 src=quitjob.php></td></tr>";
	}else{

if($data->werklevel == 1) {
$werk1 = Postman;
$werk2 = Waiter;
$werk3 = MusicTeacher;
$baan1 = 1;
$baan2 = 2;
$baan3 = 3;
$verdien1 = 100;
$verdien2 = 200;
$verdien3 = 400; }
elseif($data->werklevel == 2) {
$werk1 = Violinist;
$werk2 = Conductor;
$werk3 = ConciegeAssistant;
$baan1 = 2;
$baan2 = 3;
$baan3 = 4;
$verdien1 = 200;
$verdien2 = 400;
$verdien3 = 600; }
elseif($data->werklevel == 3) {
$werk1 = ProffesionalViolinist;
$werk2 = HeadConciege;
$werk3 = PrivateConciege;
$baan1 = 3;
$baan2 = 4;
$baan3 = 5;
$verdien1 = 400;
$verdien2 = 600;
$verdien3 = 700; }
elseif($data->werklevel == 4) {
$werk1 = PrivateConcierge;
$werk2 = HeadConciege;
$werk3 = Poet;
$baan1 = 4;
$baan2 = 5;
$baan3 = 6;
$verdien1 = 600;
$verdien2 = 700;
$verdien3 = 800; }
elseif($data->werklevel == 5) {
$werk1 = HeadConciege;
$werk2 = Poet;
$werk3 = Conductor;
$baan1 = 5;
$baan2 = 6;
$baan3 = 7;
$verdien1 = 700;
$verdien2 = 800;
$verdien3 = 1200; }
elseif($data->werklevel == 6) {
$werk1 = Leraar;
$werk2 = Conrector;
$werk3 = Magazijnhulp;
$baan1 = 6;
$baan2 = 7;
$baan3 = 8;
$verdien1 = 800;
$verdien2 = 1200;
$verdien3 = 1400; }
elseif($data->werklevel == 7) {
$werk1 = Conrector;
$werk2 = Magazijnhulp;
$werk3 = Magazijnmanager;
$baan1 = 7;
$baan2 = 8;
$baan3 = 9;
$verdien1 = 1200;
$verdien2 = 1400;
$verdien3 = 1500; }
elseif($data->werklevel == 8) {
$werk1 = Magazijnhulp;
$werk2 = Magazijnmanager;
$werk3 = HoofdMagazijn;
$baan1 = 8;
$baan2 = 9;
$baan3 = 10;
$verdien1 = 1400;
$verdien2 = 1500;
$verdien3 = 1800; }
elseif($data->werklevel == 9) {
$werk1 = Magazijnmanager;
$werk2 = HoofdMagazijn;
$werk3 = Beveilingsbeambte;
$baan1 = 9;
$baan2 = 10;
$baan3 = 11;
$verdien1 = 1500;
$verdien2 = 1800;
$verdien3 = 2000; }
elseif($data->werklevel == 10) {
$werk1 = HoofdMagazijn;
$werk2 = Beveilingsbeambte;
$werk3 = HoofdBeveiling;
$baan1 = 10;
$baan2 = 11;
$baan3 = 12;
$verdien1 = 1800;
$verdien2 = 2200;
$verdien3 = 2500; }
elseif($data->werklevel == 11) {
$werk1 = Beveilingsbeambte;
$werk2 = HoofdBeveiling;
$werk3 = Onderdirecteur;
$baan1 = 11;
$baan2 = 12;
$baan3 = 13;
$verdien1 = 2200;
$verdien2 = 2500;
$verdien3 = 2800; }
elseif($data->werklevel == 12) {
$werk1 = HoofdBeveiling;
$werk2 = Onderdirecteur;
$werk3 = Directeur;
$baan1 = 12;
$baan2 = 13;
$baan3 = 14;
$verdien1 = 2500;
$verdien2 = 2800;
$verdien3 = 3000; }

  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='1'");
  $werklevel1				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='2'");
  $werklevel2				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='3'");
  $werklevel3				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='4'");
  $werklevel4				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='5'");
  $werklevel5				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='6'");
  $werklevel6				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='7'");
  $werklevel7				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='8'");
  $werklevel8				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='9'");
  $werklevel9				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='10'");
  $werklevel10				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='11'");
  $werklevel11				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='12'");
  $werklevel12				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='13'");
  $werklevel13				= mysql_num_rows($dbres);
  $dbres				= mysql_query("SELECT id FROM `[users]` WHERE `werklevel`='14'");
  $werklevel14				= mysql_num_rows($dbres);

	if(!isset($_POST['B'])){
print <<<ENDHTML
<tr><td class="mainTxt" colspan=2>
<form method="POST">
	<p><input type="radio" class="btn btn-info" value="1" name="B1" checked> <font color="FFFFFF">Work as $werk1 for 5 days</font></p>
	<p><input type="radio" class="btn btn-info" value="2" name="B1"> <font color="FFFFFF">Work as $werk2 for 5 days</font></p>
	<p><input type="radio" class="btn btn-info" value="3" name="B1"> <font color="FFFFFF">Work as $werk3 for 5 days</font></p>
	<p><input type="submit" class="btn btn-info" value="Go to Work!" name="B"></p>
</form>
</td></tr>
  <tr><td class="subTitle" colspan=2><b>Description</b></td></tr>
<tr><td class="mainTxt" colspan=2>
As part of the game, you need cash. An easy way to get some extra cash is to work for 5 days at a time.<br>
If after a period of time your work level has increased by 1, a new job with higher pay will become open to you.<br>
<br>
Your current work level now is: {$data->werklevel}
</td></tr>
<tr><td class="subTitle" width=50%><b>Work Levels</b></td><td class="subTitle" width=50%><b>Members Working level</b></td></tr>
<tr><td class="mainTxt">- Worklevel 1:</td><td class="mainTxt">{$werklevel1}</td></tr>
<tr><td class="mainTxt">- Worklevel 2:</td><td class="mainTxt">{$werklevel2}</td></tr>
<tr><td class="mainTxt">- Worklevel 3:</td><td class="mainTxt">{$werklevel3}</td></tr>
<tr><td class="mainTxt">- Worklevel 4:</td><td class="mainTxt">{$werklevel4}</td></tr>
<tr><td class="mainTxt">- Worklevel 5:</td><td class="mainTxt">{$werklevel5}</td></tr>
<tr><td class="mainTxt">- Worklevel 6:</td><td class="mainTxt">{$werklevel6}</td></tr>
<tr><td class="mainTxt">- Worklevel 7:</td><td class="mainTxt">{$werklevel7}</td></tr>
<tr><td class="mainTxt">- Worklevel 8:</td><td class="mainTxt">{$werklevel8}</td></tr>
<tr><td class="mainTxt">- Worklevel 9:</td><td class="mainTxt">{$werklevel9}</td></tr>
<tr><td class="mainTxt">- Worklevel 10:</td><td class="mainTxt">{$werklevel10}</td></tr>
<tr><td class="mainTxt">- Worklevel 11:</td><td class="mainTxt">{$werklevel11}</td></tr>
<tr><td class="mainTxt">- Worklevel 12:</td><td class="mainTxt">{$werklevel12}</td></tr>
<tr><td class="mainTxt" colspan=2></td></tr>
ENDHTML;

	}

if(isset($_POST['B'])){
	$b1         = $_POST['B1'];
	$b2         = $_POST['B2'];
	
if($b1 == 1){
mysql_query("UPDATE `[users]` SET `dagenwerken`='6', `werk2`='1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `baan`='{$baan1}' WHERE `login`='$data->login'");
}
if($b1 == 2){
mysql_query("UPDATE `[users]` SET `dagenwerken`='6', `werk2`='1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `baan`='{$baan2}' WHERE `login`='$data->login'");
}
if($b1 == 3){
mysql_query("UPDATE `[users]` SET `dagenwerken`='6', `werk2`='1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `baan`='{$baan3}' WHERE `login`='$data->login'");
}
if($b2 == 1){
mysql_query("UPDATE `[users]` SET `dagenwerken`='0', `werk2`='1' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `baan`='0' WHERE `login`='$data->login'");
mysql_query("UPDATE `[users]` SET `ontslag`='2' WHERE `login`='$data->login'");
}

if($b1 == 1){
print "<tr><td class=\"mainTxt\">You'll be working as $werk1 for 5 days and you will earn ;$verdien1 per day</td></tr>";
}
if($b1 == 2){
print "<tr><td class=\"mainTxt\">You'll be working as $werk2 for 5 days and you will earn ;$verdien2 per day</td></tr>";
}
if($b1 == 3){
print "<tr><td class=\"mainTxt\">You'll be  working as $werk3 for 5 days and you will earn ;$verdien3 per day</td></tr>";
}
if($b2 == 1){
print "<tr><td class=\"mainTxt\">You have been dismissed from work and you must wait another 2 days before your allowed to work.</td></tr>";
}

	}
	
	
	
	}
/* ------------------------- */ ?>

</body>
</html>